// $Id: OS_NS_sys_wait.cpp 92712 2010-11-25 12:22:13Z johnnyw $

#include "ace/OS_NS_sys_wait.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_sys_wait.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */
