<?php

$config['language'] = "francais";