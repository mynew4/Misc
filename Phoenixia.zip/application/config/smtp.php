<?php

$config['use_own_smtp_settings'] = false;
$config['smtp_host'] = "ssl://smtp.gmail.com";
$config['smtp_user'] = "USERNAME@gmail.com";
$config['smtp_pass'] = "GMAIL-PASSWORD";
$config['smtp_port'] = 465;
$config['mail_debug'] = false;