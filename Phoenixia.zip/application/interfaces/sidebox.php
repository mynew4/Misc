<?php

/** 
 * Only kept for backwards compatibility - you do not need
 * to "implement Sidebox" in your sidebox controller classes
 * @deprecated 6.1
 */
interface Sidebox { }