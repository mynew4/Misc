<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 13:13:56
         compiled from "application\modules\changelog\views\changelog.tpl" */ ?>
<?php /*%%SmartyHeaderCode:186605284be84c0ad04-83449050%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '65eae4e70996f1545834de297a9be4baeb144ae0' => 
    array (
      0 => 'application\\modules\\changelog\\views\\changelog.tpl',
      1 => 1362161302,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '186605284be84c0ad04-83449050',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'categories' => 0,
    'category' => 0,
    'attributes' => 0,
    'changes' => 0,
    'k' => 0,
    'change_time' => 0,
    'k_type' => 0,
    'change_type' => 0,
    'url' => 0,
    'change' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5284be84d52f04_97649173',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5284be84d52f04_97649173')) {function content_5284be84d52f04_97649173($_smarty_tpl) {?><?php if (hasPermission("canAddChange")){?>
	<div id="changelog_add">


		<?php if (hasPermission("canAddChange")){?>
		<form id="change_form" onSubmit="Changelog.addChange(); return false" style="display:none;">
			<?php if (!count($_smarty_tpl->tpl_vars['categories']->value)){?>
				Please add a category first
			<?php }else{ ?>
			<input type="text" placeholder="<?php echo lang("change_info","changelog");?>
" id="change_text" name="change" style="width:62%" />
			<select style="width:20%" name="category" id="changelog_types">
				<?php  $_smarty_tpl->tpl_vars['category'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['category']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['categories']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['category']->key => $_smarty_tpl->tpl_vars['category']->value){
$_smarty_tpl->tpl_vars['category']->_loop = true;
?>
					<option value="<?php echo $_smarty_tpl->tpl_vars['category']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['category']->value['typeName'];?>
</option>
				<?php } ?>
			</select>
			<input type="submit" value="<?php echo lang("add","changelog");?>
"/>
			<?php }?>
		</form>
		<?php }?>

		<?php if (hasPermission("canAddCategory")){?>

		
			<?php echo form_open('changelog/addCategory',$_smarty_tpl->tpl_vars['attributes']->value);?>

				<input type="text" placeholder="<?php echo lang("category_name","changelog");?>
" name="category" style="width:83%" />
				<input type="submit" value="<?php echo lang("add","changelog");?>
"/>
			</form>
		<?php }?>

		<?php if (hasPermission("canAddChange")){?>
			<a href="javascript:void(0)" onClick="$('#category_form').hide();$('#change_form').fadeToggle(150)" class="nice_button"><?php echo lang("new_change","changelog");?>
</a>
		<?php }?>
		
		<?php if (hasPermission("canAddCategory")){?>
			<a href="javascript:void(0)" onClick="$('#change_form').hide();$('#category_form').fadeToggle(150)" class="nice_button"><?php echo lang("new_category","changelog");?>
</a>
		<?php }?>
	</div>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['changes']->value){?>
<div id="changelog">
	<?php  $_smarty_tpl->tpl_vars['change_time'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['change_time']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['changes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['change_time']->key => $_smarty_tpl->tpl_vars['change_time']->value){
$_smarty_tpl->tpl_vars['change_time']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['change_time']->key;
?>
		<table class="nice_table">
			<tr>
				<td><div class="changelog_info"><?php echo lang("changes_made_on","changelog");?>
 <?php echo $_smarty_tpl->tpl_vars['k']->value;?>
</div></td>
			</tr>
			<?php  $_smarty_tpl->tpl_vars['change_type'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['change_type']->_loop = false;
 $_smarty_tpl->tpl_vars['k_type'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['change_time']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['change_type']->key => $_smarty_tpl->tpl_vars['change_type']->value){
$_smarty_tpl->tpl_vars['change_type']->_loop = true;
 $_smarty_tpl->tpl_vars['k_type']->value = $_smarty_tpl->tpl_vars['change_type']->key;
?>
				
				<tr>
					<td><a><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['k_type']->value);?>
</a></td>
				</tr>

				<?php  $_smarty_tpl->tpl_vars['change'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['change']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['change_type']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['change']->key => $_smarty_tpl->tpl_vars['change']->value){
$_smarty_tpl->tpl_vars['change']->_loop = true;
?>
					<tr>
						<td><?php if (hasPermission("canRemoveChange")){?><a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
changelog/remove/<?php echo $_smarty_tpl->tpl_vars['change']->value['change_id'];?>
" style="display:inline !important;margin:0px !important;"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/delete.png" align="absmiddle" /></a><?php }?> &nbsp;<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['change']->value['changelog']);?>
</td>
					</tr>
				<?php } ?>
				
			<?php } ?>
		</table>
	<?php } ?>
</div>
<?php }else{ ?>
	<div id="changelog">
		<center style="padding:10px;"><?php echo lang("no_changes","changelog");?>
</center>
	</div>
<?php }?><?php }} ?>