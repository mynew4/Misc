<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 23:21:29
         compiled from "application\modules\item\views\item.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1957352854ce9c9bee5-35861709%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd73edd8546aa30cfa314f0a1233bf05c44581d4a' => 
    array (
      0 => 'application\\modules\\item\\views\\item.tpl',
      1 => 1359559562,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1957352854ce9c9bee5-35861709',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'icon' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_52854ce9ca7a67_94224928',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52854ce9ca7a67_94224928')) {function content_52854ce9ca7a67_94224928($_smarty_tpl) {?><div id="item_space">
<?php echo $_smarty_tpl->tpl_vars['icon']->value;?>

<div class="item_bg tooltip"><?php echo $_smarty_tpl->tpl_vars['item']->value;?>
</div>
<div class="clear"></div>
</div><?php }} ?>