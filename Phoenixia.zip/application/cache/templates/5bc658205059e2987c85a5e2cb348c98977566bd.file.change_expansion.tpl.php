<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 11:06:00
         compiled from "application\modules\ucp\views\change_expansion.tpl" */ ?>
<?php /*%%SmartyHeaderCode:217775284a088eed187-93100551%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5bc658205059e2987c85a5e2cb348c98977566bd' => 
    array (
      0 => 'application\\modules\\ucp\\views\\change_expansion.tpl',
      1 => 1360516440,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '217775284a088eed187-93100551',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'expansions' => 0,
    'id' => 0,
    'my_expansion' => 0,
    'expansion' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5284a08904ee86_49229666',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5284a08904ee86_49229666')) {function content_5284a08904ee86_49229666($_smarty_tpl) {?><?php echo form_open('ucp/expansion','class="page_form"');?>

	<table style="width:80%">
		<tr>
			<td><label for="expansion"><?php echo lang("expansion","ucp");?>
</label></td>
			<td>
				<select id="expansion" name="expansion">
					<?php  $_smarty_tpl->tpl_vars['expansion'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['expansion']->_loop = false;
 $_smarty_tpl->tpl_vars['id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['expansions']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['expansion']->key => $_smarty_tpl->tpl_vars['expansion']->value){
$_smarty_tpl->tpl_vars['expansion']->_loop = true;
 $_smarty_tpl->tpl_vars['id']->value = $_smarty_tpl->tpl_vars['expansion']->key;
?>
						<option value="<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
" <?php if ($_smarty_tpl->tpl_vars['my_expansion']->value==$_smarty_tpl->tpl_vars['id']->value){?>selected<?php }?>><?php echo lang(strtolower($_smarty_tpl->tpl_vars['expansion']->value),"ucp");?>
</option>
					<?php } ?>
				</select>
			</td>
		</tr>
	</table>
	<center style="margin-bottom:10px;">
		<input type="submit" name="change_submit" value="<?php echo lang("change_expansion","ucp");?>
" />
	</center>
</form><?php }} ?>