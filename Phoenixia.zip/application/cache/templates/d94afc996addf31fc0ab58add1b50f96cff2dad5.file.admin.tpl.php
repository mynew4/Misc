<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 18:12:40
         compiled from "application/modules/changelog/views/admin.tpl" */ ?>
<?php /*%%SmartyHeaderCode:137156013251508588192e61-08244886%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd94afc996addf31fc0ab58add1b50f96cff2dad5' => 
    array (
      0 => 'application/modules/changelog/views/admin.tpl',
      1 => 1362156154,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '137156013251508588192e61-08244886',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'changes' => 0,
    'categories' => 0,
    'category' => 0,
    'change' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5150858828dfa6_22813808',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5150858828dfa6_22813808')) {function content_5150858828dfa6_22813808($_smarty_tpl) {?><section class="box big" id="main_changelog">
	<h2>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_grid.png"/>
		Changes (<div style="display:inline;" id="changelog_count"><?php if (!$_smarty_tpl->tpl_vars['changes']->value){?>0<?php }else{ ?><?php echo count($_smarty_tpl->tpl_vars['changes']->value);?>
<?php }?></div>)
	</h2>
	
	<?php if (hasPermission("canAddCategory")){?>
		<span>
			<a class="nice_button" href="javascript:void(0)" onClick="Changelog.add()">Create category</a>
		</span>
	<?php }?>

	<?php if ($_smarty_tpl->tpl_vars['categories']->value){?>
	<?php  $_smarty_tpl->tpl_vars['category'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['category']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['categories']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['category']->key => $_smarty_tpl->tpl_vars['category']->value){
$_smarty_tpl->tpl_vars['category']->_loop = true;
?>
		<ul id="changelog_list">
			<li id="headline_<?php echo $_smarty_tpl->tpl_vars['category']->value['id'];?>
">
				<table width="100%">
					<tr>
						<?php if (hasPermission("canAddChange")){?>
							<td width="5%"><a href="javascript:void(0)" onClick="Changelog.addChange(<?php echo $_smarty_tpl->tpl_vars['category']->value['id'];?>
)" data-tip="Add change"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_plus.png" /></a></td>
						<?php }?>
						<td><b><?php echo $_smarty_tpl->tpl_vars['category']->value['typeName'];?>
</b></td>
						
						<td style="text-align:right;" width="10%">
							
							<?php if (hasPermission("canEditCategory")){?>
								<a href="javascript:void(0)" onClick="Changelog.renameCategory(<?php echo $_smarty_tpl->tpl_vars['category']->value['id'];?>
, this)" data-tip="Rename category"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_edit.png" /></a>&nbsp;
							<?php }?>
							
							<?php if (hasPermission("canRemoveCategory")){?>
								<a href="javascript:void(0)" onClick="Changelog.removeCategory(<?php echo $_smarty_tpl->tpl_vars['category']->value['id'];?>
, this)" data-tip="Delete category and all its entries"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_minus.png" /></a>
							<?php }?>
						</td>
					</tr>
				</table>
			</li>
			<?php  $_smarty_tpl->tpl_vars['change'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['change']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['changes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['change']->key => $_smarty_tpl->tpl_vars['change']->value){
$_smarty_tpl->tpl_vars['change']->_loop = true;
?>
				<?php if ($_smarty_tpl->tpl_vars['category']->value['id']==$_smarty_tpl->tpl_vars['change']->value['type']){?>
					<li>
						<table width="100%">
							<tr>
								<td width="40%"><?php echo $_smarty_tpl->tpl_vars['change']->value['changelog'];?>
</td>
								<td width="20%"><?php echo $_smarty_tpl->tpl_vars['change']->value['author'];?>
</td>
								<td width="20%"><?php echo date('Y/m/d',$_smarty_tpl->tpl_vars['change']->value['time']);?>
</td>
								
								<td style="text-align:right;" width="10%">
									<?php if (hasPermission("canEditChange")){?>
										<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
changelog/admin/edit/<?php echo $_smarty_tpl->tpl_vars['change']->value['change_id'];?>
" data-tip="Edit"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_edit.png" /></a>&nbsp;
									<?php }?>

									<?php if (hasPermission("canRemoveChange")){?>
										<a href="javascript:void(0)" onClick="Changelog.remove(<?php echo $_smarty_tpl->tpl_vars['change']->value['change_id'];?>
, this)" data-tip="Delete"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_minus.png" /></a>
									<?php }?>
								</td>
							</tr>
						</table>
					</li>
				<?php }?>
			<?php } ?>
		</ul>
	<?php } ?>
	<?php }?>
</section>

<section class="box big" id="add_changelog" style="display:none;">
	<h2><a href='javascript:void(0)' onClick="Changelog.add()" data-tip="Return to changelog">Changelog</a> &rarr; New category</h2>

	<form onSubmit="Changelog.create(this); return false" id="submit_form">
		<label for="name">Category name</label>
		<input type="text" name="typeName" id="typeName" />
	
		<input type="submit" value="Submit category" />
	</form>
</section><?php }} ?>