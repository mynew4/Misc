<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 10:46:06
         compiled from "application\themes\default\modules\sidebox_status\status.tpl" */ ?>
<?php /*%%SmartyHeaderCode:503952849bde671380-50153004%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0432b031b3642a9bcf938ef4d53d0596e0edf353' => 
    array (
      0 => 'application\\themes\\default\\modules\\sidebox_status\\status.tpl',
      1 => 1359559562,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '503952849bde671380-50153004',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'realms' => 0,
    'realm' => 0,
    'realmlist' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_52849bde753c82_06774736',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52849bde753c82_06774736')) {function content_52849bde753c82_06774736($_smarty_tpl) {?><?php  $_smarty_tpl->tpl_vars['realm'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['realm']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['realms']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['realm']->key => $_smarty_tpl->tpl_vars['realm']->value){
$_smarty_tpl->tpl_vars['realm']->_loop = true;
?>
	<div class="realm">
		<div class="realm_online">
			<?php if ($_smarty_tpl->tpl_vars['realm']->value->isOnline()){?>
				<?php echo $_smarty_tpl->tpl_vars['realm']->value->getOnline();?>
 / <?php echo $_smarty_tpl->tpl_vars['realm']->value->getCap();?>

			<?php }else{ ?>
				Offline
			<?php }?>
		</div>
		<?php echo $_smarty_tpl->tpl_vars['realm']->value->getName();?>

		
		<div class="realm_bar">
			<?php if ($_smarty_tpl->tpl_vars['realm']->value->isOnline()){?>
				<div class="realm_bar_fill" style="width:<?php echo $_smarty_tpl->tpl_vars['realm']->value->getPercentage();?>
%"></div>
			<?php }?>
		</div>

		<!--
			Other values, for designers:

			$realm->getOnline("horde")
			$realm->getPercentage("horde")

			$realm->getOnline("alliance")
			$realm->getPercentage("alliance")

		-->

	</div>

	<div class="side_divider"></div>
<?php } ?>
<div id="realmlist">set realmlist <?php echo $_smarty_tpl->tpl_vars['realmlist']->value;?>
</div><?php }} ?>