<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 13:46:42
         compiled from "application/modules/donate/views/admin.tpl" */ ?>
<?php /*%%SmartyHeaderCode:135928922551504732b1c0e7-95778764%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'db87e8e6bbc0ee2fa369b1433946b432962f6ea1' => 
    array (
      0 => 'application/modules/donate/views/admin.tpl',
      1 => 1359559561,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '135928922551504732b1c0e7-95778764',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'currency' => 0,
    'first_date' => 0,
    'last_date' => 0,
    'top' => 0,
    'monthly_income_stack' => 0,
    'paypal_enabled' => 0,
    'url' => 0,
    'paypal_logs' => 0,
    'paypal_log' => 0,
    'paygol_enabled' => 0,
    'paygol_logs' => 0,
    'paygol_log' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51504732c21160_84339017',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51504732c21160_84339017')) {function content_51504732c21160_84339017($_smarty_tpl) {?><div class="statistics">
	<span>Monthly income (<?php echo $_smarty_tpl->tpl_vars['currency']->value;?>
)</span>
	<div class="image">
		<img src="https://chart.googleapis.com/chart?chf=bg,s,FFFFFF&chxl=0:|<?php echo $_smarty_tpl->tpl_vars['first_date']->value;?>
|<?php echo $_smarty_tpl->tpl_vars['last_date']->value;?>
&chxp=0,12,87&chxr=1,0,<?php echo $_smarty_tpl->tpl_vars['top']->value+20;?>
&chxs=1,676767,11.5,0,lt,676767&chxt=x,y&chs=667x190&cht=lc&chco=095a9d&chds=0,<?php echo $_smarty_tpl->tpl_vars['top']->value+20;?>
&chd=t:<?php echo $_smarty_tpl->tpl_vars['monthly_income_stack']->value;?>
&chdlp=l&chls=2&chma=5,5,5,5" />
	</div>
</div>

<?php if ($_smarty_tpl->tpl_vars['paypal_enabled']->value){?>
	<section class="box big" id="donate_articles">
		<h2>
			<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_text_document.png"/>
			Last 10 PayPal donations
		</h2>

		<form style="margin-top:0px;" onSubmit="Donate.search('paypal'); return false">
			<input type="text" name="search_paypal" id="search_paypal" placeholder="Search by username, PayPal email or TXN ID" style="width:90%;margin-right:5px;"/>
			<input type="submit" value="Search" style="display:inline;padding:8px;" />
		</form>
	
		<ul id="donate_list_paypal">
			<?php if ($_smarty_tpl->tpl_vars['paypal_logs']->value){?>
				<?php  $_smarty_tpl->tpl_vars['paypal_log'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['paypal_log']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['paypal_logs']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['paypal_log']->key => $_smarty_tpl->tpl_vars['paypal_log']->value){
$_smarty_tpl->tpl_vars['paypal_log']->_loop = true;
?>
					<li>
						<table width="100%" style="font-size:11px;">
							
							<tr>
								<td width="13%"><?php echo date("Y/m/d",$_smarty_tpl->tpl_vars['paypal_log']->value['timestamp']);?>
</td>
								<td width="13%">
									<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
profile/<?php echo $_smarty_tpl->tpl_vars['paypal_log']->value['user_id'];?>
" target="_blank">
										<?php echo $_smarty_tpl->tpl_vars['paypal_log']->value['nickname'];?>

									</a>
								</td>
								
								<td width="13%" <?php if (!$_smarty_tpl->tpl_vars['paypal_log']->value['validated']){?>style="text-decoration:line-through"<?php }?>>
									<b>
										<?php echo $_smarty_tpl->tpl_vars['paypal_log']->value['payment_amount'];?>
 <?php echo $_smarty_tpl->tpl_vars['paypal_log']->value['payment_currency'];?>

									</b>
								</td>

								<?php if ($_smarty_tpl->tpl_vars['paypal_log']->value['validated']){?>
									<td width="15%" ><?php echo $_smarty_tpl->tpl_vars['paypal_log']->value['payment_status'];?>
</td>
								<?php }else{ ?>
									<td width="15%" data-tip="<?php echo $_smarty_tpl->tpl_vars['paypal_log']->value['error'];?>
" style="color:red;cursor:pointer;">
										Error (?)
									</td>
								<?php }?>

								<td data-tip="Transaction ID: <?php echo $_smarty_tpl->tpl_vars['paypal_log']->value['txn_id'];?>
" style="font-size:11px;"><?php echo $_smarty_tpl->tpl_vars['paypal_log']->value['payer_email'];?>
</td>
							
								<?php if (!$_smarty_tpl->tpl_vars['paypal_log']->value['validated']){?><td><a class="nice_button" style="float:right;" href="javascript:void(0)" onClick="Donate.give(<?php echo $_smarty_tpl->tpl_vars['paypal_log']->value['id'];?>
, this)">Give DP</a></td><?php }?>
							</tr>
						
						</table>
					</li>
				<?php } ?>
			<?php }?>
		</ul>
	</section>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['paygol_enabled']->value){?>
	<section class="box big" id="donate_articles">
		<h2>
			<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_text_document.png"/>
			Last 10 PayGol donations
		</h2>

		<form style="margin-top:0px;" onSubmit="Donate.search('paygol'); return false">
			<input type="text" name="search_paygol" id="search_paygol" placeholder="Search by username, phone number or message ID" style="width:90%;margin-right:5px;"/>
			<input type="submit" value="Search" style="display:inline;padding:8px;" />
		</form>
	
		<ul id="donate_list_paygol">
			<?php if ($_smarty_tpl->tpl_vars['paygol_logs']->value){?>
				<?php  $_smarty_tpl->tpl_vars['paygol_log'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['paygol_log']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['paygol_logs']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['paygol_log']->key => $_smarty_tpl->tpl_vars['paygol_log']->value){
$_smarty_tpl->tpl_vars['paygol_log']->_loop = true;
?>
					<li>
						<table width="100%" style="font-size:11px;">
							<tr>
								<td width="15%"><?php echo date("Y/m/d",$_smarty_tpl->tpl_vars['paygol_log']->value['timestamp']);?>
</td>
								<td width="13%">
									<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
profile/<?php echo $_smarty_tpl->tpl_vars['paygol_log']->value['custom'];?>
" target="_blank">
										<?php echo $_smarty_tpl->tpl_vars['paygol_log']->value['nickname'];?>

									</a>
								</td>
								<td width="15%"><b><?php echo round($_smarty_tpl->tpl_vars['paygol_log']->value['price']);?>
 <?php echo $_smarty_tpl->tpl_vars['paygol_log']->value['currency'];?>
</b></td>
								<td width="15%"><?php echo $_smarty_tpl->tpl_vars['paygol_log']->value['operator'];?>
</td>
								<td width="10%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/flags/<?php echo strtolower($_smarty_tpl->tpl_vars['paygol_log']->value['country']);?>
.png" data-tip="<?php echo $_smarty_tpl->tpl_vars['paygol_log']->value['country'];?>
" style="opacity:1;"/></td>
								<td data-tip="Message ID: <?php echo $_smarty_tpl->tpl_vars['paygol_log']->value['message_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['paygol_log']->value['sender'];?>
</td>
							
							</tr>
						</table>
					</li>
				<?php } ?>
			<?php }?>
		</ul>
	</section>
<?php }?><?php }} ?>