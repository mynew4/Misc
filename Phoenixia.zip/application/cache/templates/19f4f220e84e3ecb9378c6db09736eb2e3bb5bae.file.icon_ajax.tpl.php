<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 23:21:12
         compiled from "application\modules\armory\views\icon_ajax.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1978052854cd8521de6-83709110%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '19f4f220e84e3ecb9378c6db09736eb2e3bb5bae' => 
    array (
      0 => 'application\\modules\\armory\\views\\icon_ajax.tpl',
      1 => 1359559562,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1978052854cd8521de6-83709110',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'id' => 0,
    'url' => 0,
    'realm' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_52854cd85970e3_45243318',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52854cd85970e3_45243318')) {function content_52854cd85970e3_45243318($_smarty_tpl) {?><span class="get_icon_<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
">
	<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/armory/default/loading.gif" width="18" height="18"/>
</span>

<script type="text/javascript">
	$(document).ready(function()
	{
		$.get(Config.URL + "icon/get/" + <?php echo $_smarty_tpl->tpl_vars['realm']->value;?>
 + "/" + <?php echo $_smarty_tpl->tpl_vars['id']->value;?>
, function(data)
	 	{
	 		$(".get_icon_" + <?php echo $_smarty_tpl->tpl_vars['id']->value;?>
).each(function()
	 		{
	 			$(this).html("<img src='https://wow.zamimg.com/images/wow/icons/small/" + data + ".jpg' align='absmiddle'/>");
	 		});
	 	});
	});
</script><?php }} ?>