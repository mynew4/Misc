<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 10:47:37
         compiled from "application\themes\admin\box.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1462352849c39f2f802-43756253%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '717535be6d5f9a960bcf39bb4bed9930578a8578' => 
    array (
      0 => 'application\\themes\\admin\\box.tpl',
      1 => 1359559562,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1462352849c39f2f802-43756253',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'headline' => 0,
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_52849c39f3b386_16136162',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52849c39f3b386_16136162')) {function content_52849c39f3b386_16136162($_smarty_tpl) {?><h1 id="page_title"><?php echo $_smarty_tpl->tpl_vars['headline']->value;?>
</h1>
<section id="content">
	<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

</section><?php }} ?>