<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 11:07:13
         compiled from "application\modules\error\views\error.tpl" */ ?>
<?php /*%%SmartyHeaderCode:305395284a0d124ea09-64494332%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6523f8ad5b86eb79a4fe20eb0b802d0ad5b83184' => 
    array (
      0 => 'application\\modules\\error\\views\\error.tpl',
      1 => 1361020210,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '305395284a0d124ea09-64494332',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'is404' => 0,
    'errorMessage' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5284a0d12c3d07_78703080',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5284a0d12c3d07_78703080')) {function content_5284a0d12c3d07_78703080($_smarty_tpl) {?><?php if (isset($_smarty_tpl->tpl_vars['is404']->value)&&$_smarty_tpl->tpl_vars['is404']->value){?>
	<center style='margin:10px;font-weight:bold;'><?php echo lang("404_long","error");?>
</center>
<?php }else{ ?>
	<center style='margin:10px;font-weight:bold;'><?php echo $_smarty_tpl->tpl_vars['errorMessage']->value;?>
</center>
<?php }?><?php }} ?>