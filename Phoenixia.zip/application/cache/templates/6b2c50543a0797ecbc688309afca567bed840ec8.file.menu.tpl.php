<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 10:48:00
         compiled from "application\modules\admin\views\menu\menu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2017052849c50c45689-02910514%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6b2c50543a0797ecbc688309afca567bed840ec8' => 
    array (
      0 => 'application\\modules\\admin\\views\\menu\\menu.tpl',
      1 => 1364231528,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2017052849c50c45689-02910514',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'pages' => 0,
    'url' => 0,
    'links' => 0,
    'link' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_52849c50d99409_94964374',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52849c50d99409_94964374')) {function content_52849c50d99409_94964374($_smarty_tpl) {?><script type="text/javascript">
	var customPages = JSON.parse('<?php echo json_encode($_smarty_tpl->tpl_vars['pages']->value);?>
');
</script>

<section class="box big" id="main_link">
	<h2>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_list.png"/>
		Menu links (<div style="display:inline;" id="link_count"><?php if (!$_smarty_tpl->tpl_vars['links']->value){?>0<?php }else{ ?><?php echo count($_smarty_tpl->tpl_vars['links']->value);?>
<?php }?></div>)
	</h2>

	<?php if (hasPermission("addMenuLinks")){?>
	<span>
		<a class="nice_button" href="javascript:void(0)" onClick="Menu.add()">Create link</a>
	</span>
	<?php }?>

	<ul id="link_list">
		<?php if ($_smarty_tpl->tpl_vars['links']->value){?>
		<?php  $_smarty_tpl->tpl_vars['link'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['link']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['links']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['link']->key => $_smarty_tpl->tpl_vars['link']->value){
$_smarty_tpl->tpl_vars['link']->_loop = true;
?>
			<li>
				<table width="100%">
					<tr>
						<td width="10%">
							<?php if (hasPermission("editMenuLinks")){?>
							<a href="javascript:void(0)" onClick="Menu.move('up', <?php echo $_smarty_tpl->tpl_vars['link']->value['id'];?>
, this)" data-tip="Move up"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_up.png" /></a>
							<a href="javascript:void(0)" onClick="Menu.move('down', <?php echo $_smarty_tpl->tpl_vars['link']->value['id'];?>
, this)" data-tip="Move down"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_down.png" /></a>
							<?php }?>
						</td>
						<td width="30%"><span style="font-size:10px;padding:0px;display:inline;"><?php echo $_smarty_tpl->tpl_vars['link']->value['side'];?>
&nbsp;&nbsp;</span> <b><?php echo langColumn($_smarty_tpl->tpl_vars['link']->value['name']);?>
</b></td>
						<td width="50%"><a href="<?php echo $_smarty_tpl->tpl_vars['link']->value['link'];?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['link']->value['link_short'];?>
</a></td>
						<td style="text-align:right;">
							<?php if (hasPermission("editMenuLinks")){?>
							<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/menu/edit/<?php echo $_smarty_tpl->tpl_vars['link']->value['id'];?>
" data-tip="Edit"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_edit.png" /></a>
							<?php }?>
							&nbsp;
							<?php if (hasPermission("deleteMenuLinks")){?>
							<a href="javascript:void(0)" onClick="Menu.remove(<?php echo $_smarty_tpl->tpl_vars['link']->value['id'];?>
, this)" data-tip="Delete"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_minus.png" /></a>
							<?php }?>
						</td>
					</tr>
				</table>
			</li>
		<?php } ?>
		<?php }?>
	</ul>
</section>

<section class="box big" id="add_link" style="display:none;">
	<h2><a href='javascript:void(0)' onClick="Menu.add()" data-tip="Return to menu links">Menu links</a> &rarr; New link</h2>

	<form onSubmit="Menu.create(this); return false" id="submit_form">
		<label for="name">Title</label>
		<input type="text" name="name" id="name" placeholder="My link" />

		<label for="type" data-tip="External links must begin with http://">URL (or <a href="javascript:void(0)" onClick="Menu.selectCustom()">select from custom pages</a>) <a>(?)</a></label>
		<input type="text" name="link" id="link" placeholder="http://"/>

		<label for="side">Menu location</label>
		<select name="side" id="side">
				<option value="top">Top</option>
				<option value="side">Side</option>
		</select>

		<label for="visibility">Visibility mode</label>
		<select name="visibility" id="visibility" onChange="if(this.value == 'group'){ $('#groups').fadeIn(300); } else { $('#groups').fadeOut(300); }">
			<option value="everyone" selected>Visible to everyone</option>
			<option value="group">Controlled per group</option>
		</select>

		<div id="groups" style="display:none;">
			Please manage the group visibility via <a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/aclmanager/groups">the group manager</a> once you have created the link
		</div>

<label for="direct_link" data-tip="If you want to link to a non-FusionCMS page on the same domain, you must select 'Yes' otherwise FusionCMS will try to load it 'inside' the theme.">Internal direct link <a>(?)</a></label>
		<select name="direct_link" id="direct_link">
				<option value="0">No</option>
				<option value="1">Yes</option>
		</select>
	
		<input type="submit" value="Submit link" />
	</form>
</section>

<script>
	require([Config.URL + "application/themes/admin/js/mli.js"], function()
	{
		new MultiLanguageInput($("#name"));
	});
</script><?php }} ?>