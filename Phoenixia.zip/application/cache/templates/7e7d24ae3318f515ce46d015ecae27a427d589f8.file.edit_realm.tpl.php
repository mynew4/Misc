<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 12:57:59
         compiled from "application\modules\admin\views\edit_realm.tpl" */ ?>
<?php /*%%SmartyHeaderCode:231055284bac7df3185-92295645%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7e7d24ae3318f515ce46d015ecae27a427d589f8' => 
    array (
      0 => 'application\\modules\\admin\\views\\edit_realm.tpl',
      1 => 1362836812,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '231055284bac7df3185-92295645',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'realm' => 0,
    'hostname_char' => 0,
    'username_char' => 0,
    'password_char' => 0,
    'port_char' => 0,
    'hostname_world' => 0,
    'username_world' => 0,
    'password_world' => 0,
    'port_world' => 0,
    'emulators' => 0,
    'emu_id' => 0,
    'emu_name' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5284bac7ee9307_14057183',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5284bac7ee9307_14057183')) {function content_5284bac7ee9307_14057183($_smarty_tpl) {?><section class="box big">
	<h2><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_settings.png"/> Realm settings</h2>

	<form onSubmit="Settings.saveRealm(<?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
); return false">
		<label for="realmName">Realm name</label>
		<input type="text" id="realmName" name="realmName" value="<?php echo $_smarty_tpl->tpl_vars['realm']->value->getName();?>
" />

		<label for="realmName">Hostname / IP (to your emulator server)</label>
		<input type="text" id="hostname" value="<?php echo $_smarty_tpl->tpl_vars['realm']->value->getConfig('hostname');?>
" />

		<label for="override_hostname_char">Characters: database hostname</label>
		<input type="text" id="override_hostname_char" value="<?php echo $_smarty_tpl->tpl_vars['hostname_char']->value;?>
" />

		<label for="override_username_char">Characters: database username</label>
		<input type="text" id="override_username_char" value="<?php echo $_smarty_tpl->tpl_vars['username_char']->value;?>
" />

		<label for="override_password_char">Characters: database password</label>
		<input type="password" id="override_password_char" value="<?php echo $_smarty_tpl->tpl_vars['password_char']->value;?>
" />

		<label for="override_port_char">Characters: database port</label>
		<input type="text" id="override_port_char" value="<?php echo $_smarty_tpl->tpl_vars['port_char']->value;?>
"  />

		<label for="override_hostname_world">World: database hostname</label>
		<input type="text" id="override_hostname_world" value="<?php echo $_smarty_tpl->tpl_vars['hostname_world']->value;?>
" />

		<label for="override_username_world">World: database username</label>
		<input type="text" id="override_username_world" value="<?php echo $_smarty_tpl->tpl_vars['username_world']->value;?>
" />

		<label for="override_password_world">World: database password</label>
		<input type="password" id="override_password_world" value="<?php echo $_smarty_tpl->tpl_vars['password_world']->value;?>
" />

		<label for="override_port_world">World: database port</label>
		<input type="text" id="override_port_world" value="<?php echo $_smarty_tpl->tpl_vars['port_world']->value;?>
"  />

		<label for="characters">Characters database</label>
		<input type="text" id="characters" name="characters" value="<?php echo $_smarty_tpl->tpl_vars['realm']->value->getConfig('characters_database');?>
" />

		<label for="world">World database</label>
		<input type="text" id="world" name="world" value="<?php echo $_smarty_tpl->tpl_vars['realm']->value->getConfig('world_database');?>
" />

		<label for="cap">Max allowed players online</label>
		<input type="text" id="cap" name="cap" value="<?php echo $_smarty_tpl->tpl_vars['realm']->value->getCap();?>
" />

		<label for="port">Realm port (usually 8129)</label>
		<input type="text" id="port" name="port" value="<?php echo $_smarty_tpl->tpl_vars['realm']->value->getConfig('realm_port');?>
" />


		<label for="emulator">Emulator</label>
		<select id="emulator" name="emulator">
			<?php  $_smarty_tpl->tpl_vars['emu_name'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['emu_name']->_loop = false;
 $_smarty_tpl->tpl_vars['emu_id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['emulators']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['emu_name']->key => $_smarty_tpl->tpl_vars['emu_name']->value){
$_smarty_tpl->tpl_vars['emu_name']->_loop = true;
 $_smarty_tpl->tpl_vars['emu_id']->value = $_smarty_tpl->tpl_vars['emu_name']->key;
?>
			<option value="<?php echo $_smarty_tpl->tpl_vars['emu_id']->value;?>
" <?php if ($_smarty_tpl->tpl_vars['emu_id']->value==$_smarty_tpl->tpl_vars['realm']->value->getConfig('emulator')){?>selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['emu_name']->value;?>
</option>
			<?php } ?>
		</select>

		<label for="console_port">Console port (only required for emulators that use remote console systems; usually 3443 for RA and 7878 for SOAP)</label>
		<input type="text" id="console_port" name="console_port" value="<?php echo $_smarty_tpl->tpl_vars['realm']->value->getConfig('console_port');?>
"/>

		<label for="console_username" data-tip="For an ingame account with GM level high enough to connect to your<br />emulator console remotely (see your emulator's config files for more details)">Console username (only required for emulators that use remote console systems) (?)</label>
		<input type="text" id="console_username" name="console_username" value="<?php echo $_smarty_tpl->tpl_vars['realm']->value->getConfig('console_username');?>
" />

		<label for="console_password" data-tip="For an ingame account with GM level high enough to connect to your<br />emulator console remotely (see your emulator's config files for more details)">Console password (only required for emulators that use remote console systems) (?)</label>
		<input type="text" id="console_password" name="console_password" placeholder="Enter a new password if you want to change it" />

		<input type="submit" value="Save realm" />
	</form>
</section><?php }} ?>