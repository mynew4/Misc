<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 19:11:45
         compiled from "application\modules\store\views\items.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2079052851261ec05e1-58457520%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da55e919a50d0566d7582119c51fd8b2c9bfd8ff' => 
    array (
      0 => 'application\\modules\\store\\views\\items.tpl',
      1 => 1363632692,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2079052851261ec05e1-58457520',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'items' => 0,
    'item' => 0,
    'realms' => 0,
    'realm' => 0,
    'groups' => 0,
    'group' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_52851262248f60_32975216',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52851262248f60_32975216')) {function content_52851262248f60_32975216($_smarty_tpl) {?><section class="box big" id="main_item">
	<h2>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_tag.png"/>
		Items (<div style="display:inline;" id="item_count"><?php if (!$_smarty_tpl->tpl_vars['items']->value){?>0<?php }else{ ?><?php echo count($_smarty_tpl->tpl_vars['items']->value);?>
<?php }?></div>)
	</h2>

	<?php if (hasPermission("canAddItems")||hasPermission("canAddGroups")){?>
	<span>
		<?php if (hasPermission("canAddItems")){?>
			<a class="nice_button" href="javascript:void(0)" onClick="Items.add()">Create item</a>&nbsp;
		<?php }?>

		<?php if (hasPermission("canAddGroups")){?>
			<a class="nice_button" href="javascript:void(0)" onClick="Items.addGroup()">Create group</a>
		<?php }?>
	</span>
	<?php }?>

	<ul id="item_list">
		<?php if ($_smarty_tpl->tpl_vars['items']->value){?>
		<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['items']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
			<li>
				<table width="100%">
					<tr>
						<td width="5%"><img style="opacity:1;" src="https://wow.zamimg.com/images/wow/icons/small/<?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
.jpg" /></td>
						<td width="30%" data-tip="<?php echo $_smarty_tpl->tpl_vars['item']->value['description'];?>
"><b class="q<?php echo $_smarty_tpl->tpl_vars['item']->value['quality'];?>
"><?php echo character_limiter($_smarty_tpl->tpl_vars['item']->value['name'],20);?>
</b></td>
						<td width="20%" <?php if (array_key_exists("title",$_smarty_tpl->tpl_vars['item']->value)&&$_smarty_tpl->tpl_vars['item']->value['title']){?>class="item_group"<?php }?>>
							<?php if (array_key_exists("title",$_smarty_tpl->tpl_vars['item']->value)&&$_smarty_tpl->tpl_vars['item']->value['title']){?>
								<div class="group_actions" style="display:none;">
									<?php if (hasPermission("canEditGroups")){?>
									<a href="javascript:void(0)" onClick="Items.renameGroup(<?php echo $_smarty_tpl->tpl_vars['item']->value['group'];?>
, this)" data-tip="Rename group"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_edit.png" /></a>&nbsp;
									<?php }?>

									<?php if (hasPermission("canRemoveGroups")){?>
									<a href="javascript:void(0)" onClick="Items.removeGroup(<?php echo $_smarty_tpl->tpl_vars['item']->value['group'];?>
, this, true)" data-tip="Delete group and all of it's items">
										<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_minus.png" />
									</a>
									<?php }?>
								</div>
								<div class="group_title"><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</div>
							<?php }?>
						</td>
						<td width="30%">
							<?php if ($_smarty_tpl->tpl_vars['item']->value['vp_price']){?>
								<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/lightning.png" style="opacity:1;margin-top:3px;position:absolute;" /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_smarty_tpl->tpl_vars['item']->value['vp_price'];?>
 VP
							<?php }?>
							<?php if ($_smarty_tpl->tpl_vars['item']->value['dp_price']){?>
								<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/coins.png" style="opacity:1;margin-top:3px;position:absolute;"/> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								<?php echo $_smarty_tpl->tpl_vars['item']->value['dp_price'];?>
 DP
							<?php }?>
						</td>
						<td style="text-align:right;">
							<?php if (hasPermission("canEditItems")){?>
								<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
store/admin_items/edit/<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
" data-tip="Edit"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_edit.png" /></a>&nbsp;
							<?php }?>

							<?php if (hasPermission("canRemoveItems")){?>
								<a href="javascript:void(0)" onClick="Items.remove(<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
, this)" data-tip="Delete"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_minus.png" /></a>
							<?php }?>
						</td>
					</tr>
				</table>
			</li>
		<?php } ?>
		<?php }?>
	</ul>
</section>

<section class="box big" id="add_item" style="display:none;">
	<h2><a href='javascript:void(0)' onClick="Items.add()" data-tip="Return to items">Items</a> &rarr; New item</h2>

	<form>
		<label for="item_type">Item type</label>
		<select id="item_type" name="item_type" onChange="Items.changeType(this)">
			<option value="item" selected>Item</option>
			<option value="command">Console command</option>
			<option value="query">Query</option>
		</select>
	</form>

	<form onSubmit="Items.create(this); return false" id="command_form" style="display:none;">

		<label for="name">Name</label>
		<input type="text" name="name" id="name" />

		<label for="description">Description (very short; displayed below item name)</label>
		<input type="text" name="description" id="description" />

		<label for="quality">Item quality</label>
		<select id="quality" name="quality">
			<option value="0" class="q0">Poor</option>
			<option value="1" class="q1">Common</option>
			<option value="2" class="q2">Uncommon</option>
			<option value="3" class="q3">Rare</option>
			<option value="4" class="q4">Epic</option>
			<option value="5" class="q5">Legendary</option>
			<option value="6" class="q6">Artifact</option>
			<option value="7" class="q7">Heirloom</option>
		</select>

		<label>Need character</label>
		<input type="checkbox" id="command_need_character" name="command_need_character" checked="yes" value="1"/>
		<label for="command_need_character" class="inline_label">Make the user select a character</label>

		<label>Require offline</label>
		<input type="checkbox" id="require_character_offline" name="require_character_offline" value="1"/>
		<label for="require_character_offline" class="inline_label">Make sure the selected character is offline</label>

		<label for="command">Command</label>
		<textarea id="command" name="command"></textarea>
		<span>
			
				<b>{ACCOUNT}</b> = Account Name, 
				<b>{CHARACTER}</b> = Character Name
			
		</span>

		<label for="realm">Realm</label>
		<select name="realm" id="realm">
			<?php  $_smarty_tpl->tpl_vars['realm'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['realm']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['realms']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['realm']->key => $_smarty_tpl->tpl_vars['realm']->value){
$_smarty_tpl->tpl_vars['realm']->_loop = true;
?>
				<option value="<?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
"><?php echo $_smarty_tpl->tpl_vars['realm']->value->getName();?>
</option>
			<?php } ?>
		</select>

		<label for="group">Item group</label>
		<select name="group" id="group">
			<option value="0">None</option>
			<?php  $_smarty_tpl->tpl_vars['group'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['group']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['groups']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['group']->key => $_smarty_tpl->tpl_vars['group']->value){
$_smarty_tpl->tpl_vars['group']->_loop = true;
?>
				<option value="<?php echo $_smarty_tpl->tpl_vars['group']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['group']->value['title'];?>
</option>
			<?php } ?>
		</select>

		<div class="vp_price">
			<label for="vpCost">VP price</label>
			<input type="text" name="vpCost" id="vpCost" value="0"/>
		</div>

		<div class="dp_price">
			<label for="dpCost">DP price</label>
			<input type="text" name="dpCost" id="dpCost" value="0"/>
		</div>

		<label for="icon">Icon name</label>
		<input type="text" name="icon" id="icon" value="" />

		<input type="submit" value="Save command" />
	</form>

	<form onSubmit="Items.create(this); return false" id="query_form" style="display:none;">

		<label for="name">Name</label>
		<input type="text" name="name" id="name" />

		<label for="description">Description (very short; displayed below item name)</label>
		<input type="text" name="description" id="description" />

		<label for="quality">Item quality</label>
		<select id="quality" name="quality">
			<option value="0" class="q0">Poor</option>
			<option value="1" class="q1">Common</option>
			<option value="2" class="q2">Uncommon</option>
			<option value="3" class="q3">Rare</option>
			<option value="4" class="q4">Epic</option>
			<option value="5" class="q5">Legendary</option>
			<option value="6" class="q6">Artifact</option>
			<option value="7" class="q7">Heirloom</option>
		</select>

		<label for="query_database">Database</label>
		<select id="query_database" name="query_database">
			<option value="cms">CMS</option>
			<option value="realm">Realm (characters)</option>
			<option value="realmd">Realmd (accounts/auth/logon)</option>
		</select>

		<label>Need character</label>
		<input type="checkbox" id="query_need_character" name="query_need_character" checked="yes" value="1"/>
		<label for="query_need_character" class="inline_label">Make the user select a character</label>

		<label>Require offline</label>
		<input type="checkbox" id="require_character_offline" name="require_character_offline" value="1"/>
		<label for="require_character_offline" class="inline_label">Make sure the selected character is offline</label>

		<label for="query" data-tip="Example query: UPDATE characters SET level = 80 WHERE guid = {CHARACTER}">SQL query <a>(?)</a></label>
		<textarea id="query" name="query"></textarea>
		<span>
			
				<b>{ACCOUNT}</b> = Account ID, 
				<b>{CHARACTER}</b> = Character ID, 
				<b>{REALM}</b> = Realm ID
			
		</span>

		<label for="realm">Realm</label>
		<select name="realm" id="realm">
			<?php  $_smarty_tpl->tpl_vars['realm'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['realm']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['realms']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['realm']->key => $_smarty_tpl->tpl_vars['realm']->value){
$_smarty_tpl->tpl_vars['realm']->_loop = true;
?>
				<option value="<?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
"><?php echo $_smarty_tpl->tpl_vars['realm']->value->getName();?>
</option>
			<?php } ?>
		</select>

		<label for="group">Item group</label>
		<select name="group" id="group">
			<option value="0">None</option>
			<?php  $_smarty_tpl->tpl_vars['group'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['group']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['groups']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['group']->key => $_smarty_tpl->tpl_vars['group']->value){
$_smarty_tpl->tpl_vars['group']->_loop = true;
?>
				<option value="<?php echo $_smarty_tpl->tpl_vars['group']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['group']->value['title'];?>
</option>
			<?php } ?>
		</select>

		<div class="vp_price">
			<label for="vpCost">VP price</label>
			<input type="text" name="vpCost" id="vpCost" value="0"/>
		</div>

		<div class="dp_price">
			<label for="dpCost">DP price</label>
			<input type="text" name="dpCost" id="dpCost" value="0"/>
		</div>

		<label for="icon">Icon name</label>
		<input type="text" name="icon" id="icon" value="" />

		<input type="submit" value="Submit query" />
	</form>

	<form onSubmit="Items.create(this); return false" id="item_form">

		<label for="name">Name (only required for multiple items)</label>
		<input type="text" name="name" id="name" placeholder="Will be added automatically if you only specify one item ID" />

		<label for="itemid">Item ID (tip: separate ids with , (comma) to add multiple as one)</label>
		<input type="text" name="itemid" id="itemid" placeholder="12345" />

		<label for="description">Description (very short; displayed below item name)</label>
		<input type="text" name="description" id="description" placeholder="For example, 'Head (Plate)'" />

		<label for="realm">Realm</label>
		<select name="realm" id="realm">
			<?php  $_smarty_tpl->tpl_vars['realm'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['realm']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['realms']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['realm']->key => $_smarty_tpl->tpl_vars['realm']->value){
$_smarty_tpl->tpl_vars['realm']->_loop = true;
?>
				<option value="<?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
"><?php echo $_smarty_tpl->tpl_vars['realm']->value->getName();?>
</option>
			<?php } ?>
		</select>

		<label for="group">Item group</label>
		<select name="group" id="group">
			<option value="0">None</option>
			<?php  $_smarty_tpl->tpl_vars['group'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['group']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['groups']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['group']->key => $_smarty_tpl->tpl_vars['group']->value){
$_smarty_tpl->tpl_vars['group']->_loop = true;
?>
				<option value="<?php echo $_smarty_tpl->tpl_vars['group']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['group']->value['title'];?>
</option>
			<?php } ?>
		</select>

		<div class="vp_price">
			<label for="vpCost">VP price</label>
			<input type="text" name="vpCost" id="vpCost" value="0"/>
		</div>

		<div class="dp_price">
			<label for="dpCost">DP price</label>
			<input type="text" name="dpCost" id="dpCost" value="0"/>
		</div>

		<label for="icon">Icon name</label>
		<input type="text" name="icon" id="icon" placeholder="Will be added automatically if you leave empty, and only specify one item ID" />

		<input type="submit" value="Submit item" />
	</form>
</section>

<section class="box big" id="add_group" style="display:none;">
	<h2><a href='javascript:void(0)' onClick="Items.addGroup()" data-tip="Return to items">Items</a> &rarr; New group</h2>

	<form onSubmit="Items.create(this, true); return false">
		<label for="title">Group name</label>
		<input type="text" name="title" id="title" />

		<input type="submit" value="Submit group" />
	</form>
</section><?php }} ?>