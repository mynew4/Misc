<?php /* Smarty version Smarty-3.1.8, created on 2013-03-26 11:18:45
         compiled from "application/themes/default/message.tpl" */ ?>
<?php /*%%SmartyHeaderCode:67884299151517605977432-96298224%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3159744bf497add7a896cdb057c6836ac33b81fd' => 
    array (
      0 => 'application/themes/default/message.tpl',
      1 => 1359559561,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '67884299151517605977432-96298224',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'title' => 0,
    'size' => 0,
    'headline' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51517605a024d2_08363638',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51517605a024d2_08363638')) {function content_51517605a024d2_08363638($_smarty_tpl) {?><!DOCTYPE html>
<html>

	<!--
		Global announcement message
	-->

	<head>
		<title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
		<style type="text/css">
			body {
				background-color:#141414;
				padding:0px;
				margin:0px;
				text-align:center;
				color:#ffffff;
				line-height:1.5;
			}

			@font-face {
				font-family: 'MuseoSans';
				src: url('application/fonts/MuseoSans_500-webfont.eot');
				src: url('application/fonts/MuseoSans_500-webfont.eot?#iefix') format('embedded-opentype'),
					url('application/fonts/MuseoSans_500-webfont.woff') format('woff'),
					url('application/fonts/MuseoSans_500-webfont.ttf') format('truetype'),
					url('application/fonts/MuseoSans_500-webfont.svg#MuseoSans500') format('svg');
				font-weight: normal;
				font-style: normal;
			}

			@font-face {
				font-family: 'MuseoSlab';
				src: url('application/fonts/Museo_Slab_500-webfont.eot');
				src: url('application/fonts/Museo_Slab_500-webfont.eot?#iefix') format('embedded-opentype'),
					url('application/fonts/Museo_Slab_500-webfont.woff') format('woff'),
					url('application/fonts/Museo_Slab_500-webfont.ttf') format('truetype'),
					url('application/fonts/Museo_Slab_500-webfont.svg#Museo_Slab500') format('svg');
				font-weight: normal;
				font-style: normal;
			}

			h1 {
				margin:0px;
				padding:0px;
				margin-bottom:50px;
				font-family:'MuseoSlab', Arial, Sans-serif;
				font-size:<?php echo $_smarty_tpl->tpl_vars['size']->value;?>
px;
				font-weight:normal;
				margin-top:200px;
				text-shadow:1px 0px 0px #666, 2px 1px 0px #666, 3px 2px 0px #666, 4px 3px 0px #000;
			}

			p {
				display:block;
				margin-left:auto;
				margin-right:auto;
				width:550px;
				font-size:20px;
				font-family:'MuseoSans', Arial, Sans-serif;
				color:#666;
				text-shadow:1px 1px 0px #000;
			}
		</style>
	</head>

	<body>
		<h1><?php echo $_smarty_tpl->tpl_vars['headline']->value;?>
</h1>
		<p><?php echo $_smarty_tpl->tpl_vars['message']->value;?>
</p>
	</body>
</html><?php }} ?>