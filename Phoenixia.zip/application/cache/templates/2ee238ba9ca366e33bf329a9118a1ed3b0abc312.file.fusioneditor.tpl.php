<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 13:02:05
         compiled from "application\views\fusioneditor.tpl" */ ?>
<?php /*%%SmartyHeaderCode:243065284bbbdf37509-45962903%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2ee238ba9ca366e33bf329a9118a1ed3b0abc312' => 
    array (
      0 => 'application\\views\\fusioneditor.tpl',
      1 => 1360062834,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '243065284bbbdf37509-45962903',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'id' => 0,
    'url' => 0,
    'tools' => 0,
    'tool' => 0,
    'name' => 0,
    'height' => 0,
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5284bbbe0d3b87_64109224',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5284bbbe0d3b87_64109224')) {function content_5284bbbe0d3b87_64109224($_smarty_tpl) {?><div id="wrap_<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
" class="fusioneditor">
	<div class="fusioneditor_tools">
		<div style="float:right;display:none" id="fusioneditor_<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
_close">
			<a class="fusioneditor_close" href="javascript:void(0)" onClick="FusionEditor.close('<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
')" data-tip="<?php echo lang("close_tool");?>
">
				<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/bullet_arrow_up.png" />
			</a>
		</div>

		<?php  $_smarty_tpl->tpl_vars['tool'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['tool']->_loop = false;
 $_smarty_tpl->tpl_vars['name'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['tools']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['tool']->key => $_smarty_tpl->tpl_vars['tool']->value){
$_smarty_tpl->tpl_vars['tool']->_loop = true;
 $_smarty_tpl->tpl_vars['name']->value = $_smarty_tpl->tpl_vars['tool']->key;
?>
			<?php if ($_smarty_tpl->tpl_vars['tool']->value['enabled']){?>
				<a href="javascript:void(0)" onClick="FusionEditor.Tools.<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
('<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
')" data-tip="<?php echo $_smarty_tpl->tpl_vars['tool']->value['text'];?>
">
					<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/<?php echo $_smarty_tpl->tpl_vars['tool']->value['icon'];?>
.png" />
				</a>
			<?php }?>
		<?php } ?>
		<div class="clear"></div>
		<div class="fusioneditor_toolbox" id="fusioneditor_<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
_toolbox" style="display:none;"></div>
	</div>
	<div id="<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
" class="fusioneditor_field" style="min-height:<?php echo $_smarty_tpl->tpl_vars['height']->value;?>
px"><?php echo $_smarty_tpl->tpl_vars['content']->value;?>
</div>
</div>

<script type="text/javascript">
	$(document).ready(function()
	{
		function enableFusionEditor()
		{
			if(typeof FusionEditor != "undefined")
			{
				FusionEditor.create("<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
");
			}
			else
			{
				setTimeout(enableFusionEditor, 50);
			}
		}

		enableFusionEditor();
	});
</script><?php }} ?>