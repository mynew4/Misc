<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 13:01:55
         compiled from "application\modules\admin\views\logging\logging.tpl" */ ?>
<?php /*%%SmartyHeaderCode:282445284bbb3aa7582-08365130%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6c60ed8014b9493447c04c84552739c5a12ee93b' => 
    array (
      0 => 'application\\modules\\admin\\views\\logging\\logging.tpl',
      1 => 1364290952,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '282445284bbb3aa7582-08365130',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'modules' => 0,
    'key' => 0,
    'logs' => 0,
    'log' => 0,
    'CI' => 0,
    'show_more' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5284bbb3ba9282_56645919',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5284bbb3ba9282_56645919')) {function content_5284bbb3ba9282_56645919($_smarty_tpl) {?><section class="box big" id="main_link">
	<h2>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_list.png"/>
		Logs
	</h2>

	<!-- Note to whoever continues this: create javascript Logging object -->
	<form style="margin-top:0px;" onSubmit="Logging.search(); return false">
		<select id="module" name="module" style="margin-top:15px;">
			<option selected="selected" value="">-- All modules --</option>
			<?php  $_smarty_tpl->tpl_vars['module'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['module']->_loop = false;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['modules']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['module']->key => $_smarty_tpl->tpl_vars['module']->value){
$_smarty_tpl->tpl_vars['module']->_loop = true;
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['module']->key;
?>
				<option value="<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
"><?php echo ucfirst($_smarty_tpl->tpl_vars['key']->value);?>
</option>
			<?php } ?>
		</select>
		<input type="text" name="search" id="search" placeholder="Search by username, IP address or user ID" style="width:90%;margin-right:5px;">
		<input type="submit" value="Search" style="display:inline;padding:8px;margin-top:0px;">
	</form>

	<ul id="log_list">
        <?php if ($_smarty_tpl->tpl_vars['logs']->value){?>
            <?php  $_smarty_tpl->tpl_vars['log'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['log']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['logs']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['log']->key => $_smarty_tpl->tpl_vars['log']->value){
$_smarty_tpl->tpl_vars['log']->_loop = true;
?>
                <li>
                    <table width="100%">
                        <tr>
                            <td width="15%"><b><?php echo ucfirst($_smarty_tpl->tpl_vars['log']->value['module']);?>
</b></td>
                            <td width="30%"><?php echo $_smarty_tpl->tpl_vars['log']->value['logType'];?>
 <a data-tip="<?php echo $_smarty_tpl->tpl_vars['log']->value['logMessage'];?>
">(details)</a></td>
                            <td width="15%" >
                                <?php if ($_smarty_tpl->tpl_vars['log']->value['user']==0){?>
                                    Guest
                                <?php }else{ ?>
                                    <a data-tip="View profile" href="../profile/<?php echo $_smarty_tpl->tpl_vars['log']->value['user'];?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['CI']->value->user->getUsername($_smarty_tpl->tpl_vars['log']->value['user']);?>
</a>
                                <?php }?>
                                </td>
                            <td width="15%" style="font-size:10px;"><?php echo $_smarty_tpl->tpl_vars['log']->value['ip'];?>
</td>
                            <td width="15%" style="font-size:10px;"><?php echo date("Y-m-d H:i",$_smarty_tpl->tpl_vars['log']->value['time']);?>
</td>
                        </tr>
                    </table>
                </li>
            <?php } ?>
            <li id="show_more_count" <?php if ($_smarty_tpl->tpl_vars['show_more']->value<=0){?>style="display:none;"<?php }?>>
                <!-- Instead of pagination, just use a "show more" button that will show next X logs every time you press it -->
                <a id="button_log_count" class="nice_button" style="display:block" onClick="Logging.loadMore(); return false;">Show more (<?php echo $_smarty_tpl->tpl_vars['show_more']->value;?>
)</a>
                <input type="hidden" id="js_load_more" value="<?php echo $_smarty_tpl->tpl_vars['show_more']->value;?>
"/>
            </li>
        <?php }?>
	</ul>

</section><?php }} ?>