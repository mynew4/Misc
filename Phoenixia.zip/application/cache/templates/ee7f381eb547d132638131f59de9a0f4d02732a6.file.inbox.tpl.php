<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 22:06:04
         compiled from "application\modules\messages\views\inbox.tpl" */ ?>
<?php /*%%SmartyHeaderCode:351352853b3c99e4e2-87259384%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ee7f381eb547d132638131f59de9a0f4d02732a6' => 
    array (
      0 => 'application\\modules\\messages\\views\\inbox.tpl',
      1 => 1362163990,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '351352853b3c99e4e2-87259384',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'is_sent' => 0,
    'inbox_count' => 0,
    'sent_count' => 0,
    'messages' => 0,
    'message' => 0,
    'pagination' => 0,
    'sent' => 0,
    'sent_pagination' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_52853b3caf60e0_28906459',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52853b3caf60e0_28906459')) {function content_52853b3caf60e0_28906459($_smarty_tpl) {?><div id="pm_controls">
	<div id="pm_controls_right">
		<?php if (hasPermission("compose")){?>
			<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
messages/create" class="nice_button"><?php echo lang("compose_message","messages");?>
</a>
		<?php }?>
		<a href="javascript:void(0)" onClick="Messages.clearInbox()" class="nice_button" id="pm_empty"><?php echo lang("empty_inbox","messages");?>
</a>
	</div>
	
	<a href="javascript:void(0)" onClick="Messages.showTab('inbox', this)" class="nice_button <?php if (!$_smarty_tpl->tpl_vars['is_sent']->value){?>nice_active<?php }?>"><?php echo lang("inbox","messages");?>
 (<?php echo $_smarty_tpl->tpl_vars['inbox_count']->value;?>
)</a>
	<a href="javascript:void(0)" onClick="Messages.showTab('sent', this)" class="nice_button <?php if ($_smarty_tpl->tpl_vars['is_sent']->value){?>nice_active<?php }?>"><?php echo lang("sent_messages","messages");?>
 (<?php echo $_smarty_tpl->tpl_vars['sent_count']->value;?>
)</a>
</div>
<div class="ucp_divider"></div>

<div id="pm_inbox" class="pm_spot" <?php if ($_smarty_tpl->tpl_vars['is_sent']->value){?>style="display:none;"<?php }?>>
	<?php if ($_smarty_tpl->tpl_vars['messages']->value){?>
		<table class="nice_table" width="100%">
			<tr>
				<td width="18%"><?php echo lang("sender","messages");?>
</td>
				<td><?php echo lang("message_title","messages");?>
</td>
				<td width="18%" align="center"><?php echo lang("date","messages");?>
</td>
			</tr>
			<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['messages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value){
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
				<tr>
					<td><a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
profile/<?php echo $_smarty_tpl->tpl_vars['message']->value['sender_id'];?>
" data-tip="View profile"><?php echo $_smarty_tpl->tpl_vars['message']->value['sender_name'];?>
</td>
					<td><a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
messages/read/<?php echo $_smarty_tpl->tpl_vars['message']->value['id'];?>
" data-tip="Read message" <?php if ($_smarty_tpl->tpl_vars['message']->value['read']==0){?>class="pm_new"<?php }?>><?php echo $_smarty_tpl->tpl_vars['message']->value['title'];?>
</a></td>
					<td align="center"><?php echo date("Y-m-d",$_smarty_tpl->tpl_vars['message']->value['time']);?>
</td>
				</tr>
			<?php } ?>
		</table>
		<div style="height:10px;"></div>
		<?php echo $_smarty_tpl->tpl_vars['pagination']->value;?>

	<?php }else{ ?>
		<div style="text-align:center;padding:10px;"><?php echo lang("no_messages","messages");?>
.</div>
	<?php }?>
</div>

<div id="pm_sent" class="pm_spot" <?php if (!$_smarty_tpl->tpl_vars['is_sent']->value){?>style="display:none;"<?php }?>>
	<?php if ($_smarty_tpl->tpl_vars['sent']->value){?>
		<table class="nice_table" width="100%">
			<tr>
				<td width="18%"><?php echo lang("receiver","messages");?>
</td>
				<td><?php echo lang("message_title","messages");?>
</td>
				<td width="18%" align="center">Date</td>
			</tr>
			<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['sent']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value){
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
				<tr>
					<td><a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
profile/<?php echo $_smarty_tpl->tpl_vars['message']->value['user_id'];?>
" data-tip="View profile"><?php echo $_smarty_tpl->tpl_vars['message']->value['receiver_name'];?>
</td>
					<td><a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
messages/read/<?php echo $_smarty_tpl->tpl_vars['message']->value['id'];?>
" data-tip="Read message"><?php echo $_smarty_tpl->tpl_vars['message']->value['title'];?>
</a></td>
					<td align="center"><?php echo date("Y-m-d",$_smarty_tpl->tpl_vars['message']->value['time']);?>
</td>
				</tr>
			<?php } ?>
		</table>
		<div style="height:10px;"></div>
		<?php echo $_smarty_tpl->tpl_vars['sent_pagination']->value;?>

	<?php }else{ ?>
		<div style="text-align:center;padding:10px;"><?php echo lang("no_messages","messages");?>
.</div>
	<?php }?>
</div><?php }} ?>