<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 13:02:09
         compiled from "application\modules\admin\views\sidebox\edit_sidebox.tpl" */ ?>
<?php /*%%SmartyHeaderCode:276225284bbc1c60c03-79154553%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fa358547cf9afea9060098f693ef91e152fff7ce' => 
    array (
      0 => 'application\\modules\\admin\\views\\sidebox\\edit_sidebox.tpl',
      1 => 1364231476,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '276225284bbc1c60c03-79154553',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'sidebox' => 0,
    'sideboxModules' => 0,
    'name' => 0,
    'module' => 0,
    'url' => 0,
    'fusionEditor' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5284bbc1d91700_50203233',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5284bbc1d91700_50203233')) {function content_5284bbc1d91700_50203233($_smarty_tpl) {?><section class="box big">
	<h2>Edit sidebox</h2>

	<form onSubmit="Sidebox.save(this, <?php echo $_smarty_tpl->tpl_vars['sidebox']->value['id'];?>
); return false" id="submit_form">
		<label for="displayName">Headline</label>
		<input type="text" name="displayName" id="displayName" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['sidebox']->value['displayName']);?>
"/>

		<label for="type">Sidebox module</label>
		<select id="type" name="type" onChange="Sidebox.toggleCustom(this)">
			<?php  $_smarty_tpl->tpl_vars['module'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['module']->_loop = false;
 $_smarty_tpl->tpl_vars['name'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['sideboxModules']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['module']->key => $_smarty_tpl->tpl_vars['module']->value){
$_smarty_tpl->tpl_vars['module']->_loop = true;
 $_smarty_tpl->tpl_vars['name']->value = $_smarty_tpl->tpl_vars['module']->key;
?>
				<option value="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
" <?php if ($_smarty_tpl->tpl_vars['sidebox']->value['type']==preg_replace("/sidebox_/",'',$_smarty_tpl->tpl_vars['name']->value)){?>selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['module']->value['name'];?>
</option>
			<?php } ?>
		</select>

		<label for="visibility">Visibility mode</label>
		<select name="visibility" id="visibility" onChange="if(this.value == 'group'){ $('#groups').fadeIn(300); } else { $('#groups').fadeOut(300); }">
			<option value="everyone" <?php if (!$_smarty_tpl->tpl_vars['sidebox']->value['permission']){?>selected<?php }?>>Visible to everyone</option>
			<option value="group" <?php if ($_smarty_tpl->tpl_vars['sidebox']->value['permission']){?>selected<?php }?>>Controlled per group</option>
		</select>

		<div <?php if (!$_smarty_tpl->tpl_vars['sidebox']->value['permission']){?>style="display:none"<?php }?> id="groups">
			Please manage the group visibility via <a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/aclmanager/groups">the group manager</a>
		</div>
	</form>

	<span id="custom_field" style="padding-top:0px;padding-bottom:0px;<?php if ($_smarty_tpl->tpl_vars['sidebox']->value['type']!="custom"){?>display:none<?php }?>" >
		<label for="text">Content</label>
		<?php echo $_smarty_tpl->tpl_vars['fusionEditor']->value;?>

	</span>

	<form onSubmit="Sidebox.save(document.getElementById('submit_form'), <?php echo $_smarty_tpl->tpl_vars['sidebox']->value['id'];?>
); return false">
		<input type="submit" value="Save sidebox" />
	</form>
</section>

<script>
	require([Config.URL + "application/themes/admin/js/mli.js"], function()
	{
		new MultiLanguageInput($("#displayName"));
	});
</script><?php }} ?>