<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 13:58:31
         compiled from "application/modules/login/views/login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:803481122515049f7638a82-38196077%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3de619eb7f8fae721b96a85beec28cabd3955152' => 
    array (
      0 => 'application/modules/login/views/login.tpl',
      1 => 1359559561,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '803481122515049f7638a82-38196077',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'class' => 0,
    'username' => 0,
    'username_error' => 0,
    'password_error' => 0,
    'has_smtp' => 0,
    'url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_515049f76d11c7_51950267',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_515049f76d11c7_51950267')) {function content_515049f76d11c7_51950267($_smarty_tpl) {?><?php echo form_open('login',$_smarty_tpl->tpl_vars['class']->value);?>

	<table>
		<tr>
			<td><label for="login_username"><?php echo lang("username","login");?>
</label></td>
			<td>
				<input type="text" name="login_username" id="login_username" value="<?php echo $_smarty_tpl->tpl_vars['username']->value;?>
"/>
				<span id="username_error"><?php echo $_smarty_tpl->tpl_vars['username_error']->value;?>
</span>
			</td>
		</tr>
		<tr>
			<td><label for="login_password"><?php echo lang("password","login");?>
</label></td>
			<td>
				<input type="password" name="login_password" id="login_password" value=""/>
				<span id="password_error"><?php echo $_smarty_tpl->tpl_vars['password_error']->value;?>
</span>
			</td>
		</tr>
	</table>

	<center>
		<div id="remember_me">
			<label for="login_remember" data-tip="<?php echo lang("remember_me","login");?>
"><?php echo lang("remember_me_short","login");?>
</label>
			<input type="checkbox" name="login_remember" id="login_remember"/>
		</div>

		<input type="submit" name="login_submit" value="<?php echo lang("log_in","login");?>
!" />

		<?php if ($_smarty_tpl->tpl_vars['has_smtp']->value){?>
			<section id="forgot"><a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
password_recovery"><?php echo lang("lost_your_password","login");?>
</a></section>
		<?php }?>
	</center>
</form>
<?php }} ?>