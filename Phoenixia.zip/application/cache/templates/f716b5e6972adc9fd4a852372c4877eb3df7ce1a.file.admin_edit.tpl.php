<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 13:04:27
         compiled from "application\modules\page\views\admin_edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:218005284bc4b67cf03-16861496%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f716b5e6972adc9fd4a852372c4877eb3df7ce1a' => 
    array (
      0 => 'application\\modules\\page\\views\\admin_edit.tpl',
      1 => 1364231454,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '218005284bc4b67cf03-16861496',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'page' => 0,
    'url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5284bc4b957685_06456213',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5284bc4b957685_06456213')) {function content_5284bc4b957685_06456213($_smarty_tpl) {?><?php echo TinyMCE();?>

<section class="box big">
	<h2>Edit page</h2>

	<form onSubmit="Pages.send(<?php echo $_smarty_tpl->tpl_vars['page']->value['id'];?>
); return false">
		<label for="headline">Headline</label>
		<input type="text" id="headline" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['page']->value['name']);?>
"/>
		
		<label for="identifier">Unique link identifier (as in mywebsite.com/page/<b>mypage</b>)</label>
		<input type="text" id="identifier" placeholder="mypage" value="<?php echo $_smarty_tpl->tpl_vars['page']->value['identifier'];?>
" />

		<label for="visibility">Visibility mode</label>
		<select name="visibility" id="visibility" onChange="if(this.value == 'group'){ $('#groups').fadeIn(300); } else { $('#groups').fadeOut(300); }">
			<option value="everyone" <?php if (!$_smarty_tpl->tpl_vars['page']->value['permission']){?>selected<?php }?>>Visible to everyone</option>
			<option value="group" <?php if ($_smarty_tpl->tpl_vars['page']->value['permission']){?>selected<?php }?>>Controlled per group</option>
		</select>

		<div <?php if (!$_smarty_tpl->tpl_vars['page']->value['permission']){?>style="display:none"<?php }?> id="groups">
			Please manage the group visibility via <a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/aclmanager/groups">the group manager</a>
		</div>

		<label for="Pages_content">
			Content
		</label>
	</form>
		<div style="padding:10px;">
			<textarea name="pages_content" class="tinymce" id="pages_content" cols="30" rows="10"><?php echo $_smarty_tpl->tpl_vars['page']->value['content'];?>
</textarea>
		</div>
	<form onSubmit="Pages.send(<?php echo $_smarty_tpl->tpl_vars['page']->value['id'];?>
); return false">
		<input type="submit" value="Save page" />
	</form>
</section>

<script>
	require([Config.URL + "application/themes/admin/js/mli.js"], function()
	{
		new MultiLanguageInput($("#headline"));
	});
</script><?php }} ?>