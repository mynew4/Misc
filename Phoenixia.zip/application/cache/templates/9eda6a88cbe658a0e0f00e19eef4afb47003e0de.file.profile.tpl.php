<?php /* Smarty version Smarty-3.1.8, created on 2013-03-26 10:39:18
         compiled from "application/modules/profile/views/profile.tpl" */ ?>
<?php /*%%SmartyHeaderCode:135282293651516cc67888a2-15260241%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9eda6a88cbe658a0e0f00e19eef4afb47003e0de' => 
    array (
      0 => 'application/modules/profile/views/profile.tpl',
      1 => 1361147075,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '135282293651516cc67888a2-15260241',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'avatar' => 0,
    'url' => 0,
    'username' => 0,
    'location' => 0,
    'status' => 0,
    'register_date' => 0,
    'groups' => 0,
    'group' => 0,
    'online' => 0,
    'not_me' => 0,
    'id' => 0,
    'characters' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51516cc68567b3_99175986',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51516cc68567b3_99175986')) {function content_51516cc68567b3_99175986($_smarty_tpl) {?><section id="ucp_top">
	<a id="ucp_avatar" style="width:44px;height:44px;margin-top:7px;">
		<img src="<?php echo $_smarty_tpl->tpl_vars['avatar']->value;?>
"/>
	</a>

	<section id="ucp_info" style="height:auto;">
		<aside style="height:auto;width:190px;margin-right:10px;">
			<table width="100%">
				<tr>
					<td width="10%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/user.png" /></td>
					<td width="40%"><?php echo lang("nickname","profile");?>
</td>
					<td width="50%" style="overflow:hidden;"><?php echo $_smarty_tpl->tpl_vars['username']->value;?>
</td>
				</tr>
				<tr>
					<td width="10%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/world.png" /></td>
					<td width="40%"><?php echo lang("location","profile");?>
</td>
					<td width="50%"><?php echo $_smarty_tpl->tpl_vars['location']->value;?>
</td>
				</tr>
			</table>
		</aside>

		<aside style="height:auto;width:190px;">
			<table width="100%">
				<tr>
					<td width="10%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/shield.png" /></td>
					<td width="40%"><?php echo lang("status","profile");?>
</td>
					<td width="50%"><?php echo $_smarty_tpl->tpl_vars['status']->value;?>
</td>
				</tr>
				<tr>
					<td width="10%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/date.png" /></td>
					<td width="40%"><?php echo lang("signed_up","profile");?>
</td>
					<td width="50%"><?php echo $_smarty_tpl->tpl_vars['register_date']->value;?>
</td>
				</tr>
			</table>
		</aside>
		<aside style="height:auto;width:200px;padding-left:10px;">
			<table width="100%">
				<tr>
					<td width="10%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/award_star_bronze_1.png" /></td>
					<td width="20%"><?php echo lang("rank","profile");?>
</td>
					<td width="70%"><?php  $_smarty_tpl->tpl_vars['group'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['group']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['groups']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['group']->key => $_smarty_tpl->tpl_vars['group']->value){
$_smarty_tpl->tpl_vars['group']->_loop = true;
?> <span <?php if ($_smarty_tpl->tpl_vars['group']->value['color']){?>style="color:<?php echo $_smarty_tpl->tpl_vars['group']->value['color'];?>
"<?php }?>><?php echo $_smarty_tpl->tpl_vars['group']->value['name'];?>
</span> <?php } ?></td>
				</tr>
				<?php if ($_smarty_tpl->tpl_vars['online']->value&&$_smarty_tpl->tpl_vars['not_me']->value){?>
					<tr>
						<td><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/email.png" /></td>
						<td><?php echo lang("contact","profile");?>
</td>
						<td><a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
messages/create/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
"><?php echo lang("pm","profile");?>
</a></td>
					</tr>
				<?php }else{ ?>
					<tr>
						<td>&nbsp;</td>
						<td></td>
					</tr>
				<?php }?>
			</table>
		</aside>
	</section>

	<div style="clear:both;"></div>	
</section>
<?php echo $_smarty_tpl->tpl_vars['characters']->value;?>
<?php }} ?>