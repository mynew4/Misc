<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 18:28:03
         compiled from "application/themes/raxezwow/views/modals.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16369031525150892330b572-11603072%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ec7bebec0baf15c146a2eaa563f34c3328030065' => 
    array (
      0 => 'application/themes/raxezwow/views/modals.tpl',
      1 => 1359559561,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16369031525150892330b572-11603072',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'vote_reminder' => 0,
    'url' => 0,
    'vote_reminder_image' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5150892331d0a6_67426859',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5150892331d0a6_67426859')) {function content_5150892331d0a6_67426859($_smarty_tpl) {?><div id="popup_bg"></div>

<!-- confirm box -->
<div id="confirm" class="popup">
	<h1 class="popup_question" id="confirm_question"></h1>

	<div class="popup_links">
		<a href="javascript:void(0)" class="popup_button" id="confirm_button"></a>
		<a href="javascript:void(0)" class="popup_hide" id="confirm_hide" onClick="UI.hidePopup()">
			Cancel
		</a>
		<div style="clear:both;"></div>
	</div>
</div>

<!-- alert box -->
<div id="alert" class="popup">
	<h1 class="popup_message" id="alert_message"></h1>

	<div class="popup_links">
		<a href="javascript:void(0)" class="popup_button" id="alert_button">Okay</a>
		<div style="clear:both;"></div>
	</div>
</div>

<?php if ($_smarty_tpl->tpl_vars['vote_reminder']->value){?>
	<!-- Vote reminder popup -->
	<div id="vote_reminder">
		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
vote">
			<img src="<?php echo $_smarty_tpl->tpl_vars['vote_reminder_image']->value;?>
" />
		</a>
	</div>
<?php }?><?php }} ?>