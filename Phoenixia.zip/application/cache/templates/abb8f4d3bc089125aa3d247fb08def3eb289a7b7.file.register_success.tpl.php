<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 16:21:15
         compiled from "application\modules\register\views\register_success.tpl" */ ?>
<?php /*%%SmartyHeaderCode:312745284ea6be85629-66869010%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'abb8f4d3bc089125aa3d247fb08def3eb289a7b7' => 
    array (
      0 => 'application\\modules\\register\\views\\register_success.tpl',
      1 => 1360432310,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '312745284ea6be85629-66869010',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'email_activation' => 0,
    'account' => 0,
    'url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5284ea6c016128_13605661',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5284ea6c016128_13605661')) {function content_5284ea6c016128_13605661($_smarty_tpl) {?><?php if ($_smarty_tpl->tpl_vars['email_activation']->value){?>
	<span id="success">
		<?php echo lang("the_account","register");?>
 <b><?php echo $_smarty_tpl->tpl_vars['account']->value;?>
</b> <?php echo lang("has_been_created","register");?>

	</span>
<?php }else{ ?>
	<script type="text/javascript">
			setTimeout(function(){
				window.location = "<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
ucp";
			}, 1000);
	</script>

	<span id="success">
		<?php echo lang("the_account","register");?>
 <b><?php echo $_smarty_tpl->tpl_vars['account']->value;?>
</b> <?php echo lang("has_been_created_redirecting","register");?>
 <?php echo anchor("ucp",lang("user_panel","register"));?>
...
	</span>
<?php }?><?php }} ?>