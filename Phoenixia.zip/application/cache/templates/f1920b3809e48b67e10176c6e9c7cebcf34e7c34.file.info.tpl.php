<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 13:46:00
         compiled from "application/modules/sidebox_info_login/views/info.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1291174623515047082221f1-87029832%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f1920b3809e48b67e10176c6e9c7cebcf34e7c34' => 
    array (
      0 => 'application/modules/sidebox_info_login/views/info.tpl',
      1 => 1359921654,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1291174623515047082221f1-87029832',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'expansion' => 0,
    'lastIp' => 0,
    'currentIp' => 0,
    'vp' => 0,
    'dp' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51504708291fa7_39816458',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51504708291fa7_39816458')) {function content_51504708291fa7_39816458($_smarty_tpl) {?><section class="sidebox_info">
	<table width="100%">
		<tr>
			<td width="50%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/plugin.png" align="absmiddle" /> <?php echo lang("expansion","sidebox_info");?>
</td>
			<td>
				<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
ucp/expansion" data-tip="Change expansion" style="float:right;margin-right:10px;">
					<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/cog.png" align="absbottom" />
				</a>
				<?php echo $_smarty_tpl->tpl_vars['expansion']->value;?>

			</td>
		</tr>
		<tr>
			<td><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/computer_error.png" align="absmiddle" /> <?php echo lang("last_ip","sidebox_info");?>
</td>
			<td><?php echo $_smarty_tpl->tpl_vars['lastIp']->value;?>
</td>
		</tr>
		<tr>
			<td><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/computer.png" align="absmiddle" /> <?php echo lang("current_ip","sidebox_info");?>
</td>
			<td><?php echo $_smarty_tpl->tpl_vars['currentIp']->value;?>
</td>
		</tr>
		<tr>
			<td><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/lightning.png" align="absmiddle" /> <?php echo lang("vp","sidebox_info");?>
</td>
			<td id="info_vp"><?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
</td>
		</tr>
		<tr>
			<td><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/coins.png" align="absmiddle" /> <?php echo lang("dp","sidebox_info");?>
</td>
			<td id="info_dp"><?php echo $_smarty_tpl->tpl_vars['dp']->value;?>
</td>
		</tr>
	</table>
	<center>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
ucp" class="nice_button"><?php echo lang("user_panel","sidebox_info");?>
</a>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
logout" class="nice_button"><?php echo lang("log_out","sidebox_info");?>
</a>
	</center>
</section><?php }} ?>