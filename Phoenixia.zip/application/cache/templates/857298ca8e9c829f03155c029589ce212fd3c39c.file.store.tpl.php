<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 11:04:21
         compiled from "application\modules\store\views\store.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6145284a0257ec201-83196924%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '857298ca8e9c829f03155c029589ce212fd3c39c' => 
    array (
      0 => 'application\\modules\\store\\views\\store.tpl',
      1 => 1360086770,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6145284a0257ec201-83196924',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'vp' => 0,
    'dp' => 0,
    'url' => 0,
    'data' => 0,
    'realmId' => 0,
    'realm' => 0,
    'minimize' => 0,
    'group' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5284a025b95a04_76345248',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5284a025b95a04_76345248')) {function content_5284a025b95a04_76345248($_smarty_tpl) {?><section id="store_wrapper">
	<script type="text/javascript">
		$(document).ready(function()
		{
			function checkIfLoaded()
			{
				if(typeof Store != "undefined")
				{
					Store.Customer.initialize(<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
, <?php echo $_smarty_tpl->tpl_vars['dp']->value;?>
);
				}
				else
				{
					setTimeout(checkIfLoaded, 50);
				}
			}

			checkIfLoaded();
		});
	</script>

	<section id="checkout"></section>

	<section id="store">
		<form onSubmit="return false">
			<section class="filter_field">
				<label for="sort_by"><?php echo lang("sort_by","store");?>
</label>
				<select id="sort_by" name="sort_by" onChange="Store.Filter.sort(this.value)">
					<option value="standard" selected><?php echo lang("default","store");?>
</option>
					<option value="name"><?php echo lang("name","store");?>
</option>
					<option value="priceVp"><?php echo lang("price","store");?>
 (<?php echo lang("vp","store");?>
)</option>
					<option value="priceDp"><?php echo lang("price","store");?>
 (<?php echo lang("dp","store");?>
)</option>
					<option value="quality"><?php echo lang("item_quality","store");?>
</option>
				</select>
			</section>
			<section class="filter_field">
				<select id="item_quality" name="item_quality" onChange="Store.Filter.setQuality(this.value)">
					<option value="ALL" selected><?php echo lang("all_items","store");?>
</option>
					<option value="0" class="q0"><?php echo lang("poor","store");?>
</option>
					<option value="1" class="q1"><?php echo lang("common","store");?>
</option>
					<option value="2" class="q2"><?php echo lang("uncommon","store");?>
</option>
					<option value="3" class="q3"><?php echo lang("rare","store");?>
</option>
					<option value="4" class="q4"><?php echo lang("epic","store");?>
</option>
					<option value="5" class="q5"><?php echo lang("legendary","store");?>
</option>
					<option value="6" class="q6"><?php echo lang("artifact","store");?>
</option>
					<option value="7" class="q7"><?php echo lang("heirloom","store");?>
</option>
				</select>
			</section>
			<section class="filter_field">
				<input type="text" id="filter_name" placeholder="<?php echo lang("filter","store");?>
" onKeyUp="Store.Filter.setName(this.value)" />
			</section>
			<section class="filter_field">
				<a href="javascript:void(0)" onClick="Store.Filter.toggleVote(this)" class="nice_button nice_active">
					<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/lightning.png" align="absmiddle" /> <?php echo lang("vp","store");?>

				</a>

				<a href="javascript:void(0)" onClick="Store.Filter.toggleDonate(this)" class="nice_button nice_active">
					<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/coins.png" align="absmiddle" /> <?php echo lang("dp","store");?>

				</a>
			</section>
			<div class="clear"></div>
		</form>

		<div class="ucp_divider"></div>

		<section id="store_content">
			<section id="cart">
				<div class="online_realm_button"><?php echo lang("cart","store");?>
 (<span id="cart_item_count">0</span> <?php echo lang("items","store");?>
)</div>
				<div id="empty_cart"><?php echo lang("empty_cart","store");?>
</div>
				<section id="cart_items"></section>

				<div id="cart_price">
					<div id="cart_price_divider"></div>

					<a href="javascript:void(0)" onClick="Store.Cart.checkout(this)" class="nice_button"><?php echo lang("checkout","store");?>
</a>

					<div id="vp_price_full">
						<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/lightning.png" align="absmiddle" /> <span id="vp_price">0</span> <?php echo lang("vp","store");?>

					</div>

					<div id="dp_price_full">
						<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/coins.png" align="absmiddle" /> <span id="dp_price">0</span> <?php echo lang("dp","store");?>

					</div>

					<div class="clear"></div>
				</div>
			</section>

			<section id="store_realms">
				<?php  $_smarty_tpl->tpl_vars['realm'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['realm']->_loop = false;
 $_smarty_tpl->tpl_vars['realmId'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['data']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['realm']->key => $_smarty_tpl->tpl_vars['realm']->value){
$_smarty_tpl->tpl_vars['realm']->_loop = true;
 $_smarty_tpl->tpl_vars['realmId']->value = $_smarty_tpl->tpl_vars['realm']->key;
?>
				<a href="javascript:void(0)" onClick="Store.Filter.toggle(<?php echo $_smarty_tpl->tpl_vars['realmId']->value;?>
)" class="online_realm_button">
					<div style="float:right;" id="realm_indicator_<?php echo $_smarty_tpl->tpl_vars['realmId']->value;?>
">[-]</div>
					<?php echo $_smarty_tpl->tpl_vars['realm']->value['name'];?>

				</a>

				<section class="realm_items" id="realm_items_<?php echo $_smarty_tpl->tpl_vars['realmId']->value;?>
">
					<?php if (count($_smarty_tpl->tpl_vars['realm']->value['items']['groups'])){?>
						<div style="padding:0px 12px;padding-top:12px;"><a href="javascript:void(0)" onClick="Store.toggleAllGroups(this)"><?php if ($_smarty_tpl->tpl_vars['minimize']->value){?>[+] <?php echo lang("max","store");?>
<?php }else{ ?>[-] <?php echo lang("min","store");?>
<?php }?></a></div>
					<?php }?>

					<?php  $_smarty_tpl->tpl_vars['group'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['group']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['realm']->value['items']['groups']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['group']->key => $_smarty_tpl->tpl_vars['group']->value){
$_smarty_tpl->tpl_vars['group']->_loop = true;
?>
					<div class="item_group_title"><a data-tip="<?php echo lang("hide","store");?>
" class="hide_group" href="javascript:void(0)" onClick="Store.toggleGroup(this)"><?php if ($_smarty_tpl->tpl_vars['minimize']->value){?>[+]<?php }else{ ?>[-]<?php }?></a> <?php echo $_smarty_tpl->tpl_vars['group']->value['title'];?>
</div>
					<section class="item_group" <?php if ($_smarty_tpl->tpl_vars['minimize']->value){?>style="display:none"<?php }?>>
						<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['group']->value['items']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
						<div class="store_item" id="item_<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
">
							<section class="store_buttons">
								<?php if ($_smarty_tpl->tpl_vars['item']->value['vp_price']){?>
								<a href="javascript:void(0)" onClick="Store.Cart.add(<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
, '<?php echo $_smarty_tpl->tpl_vars['item']->value['itemid'];?>
', '<?php echo addslashes($_smarty_tpl->tpl_vars['item']->value['name']);?>
', <?php echo $_smarty_tpl->tpl_vars['item']->value['vp_price'];?>
, 'vp', '<?php echo addslashes($_smarty_tpl->tpl_vars['realm']->value['name']);?>
', <?php echo $_smarty_tpl->tpl_vars['realmId']->value;?>
, <?php echo $_smarty_tpl->tpl_vars['item']->value['quality'];?>
, <?php echo $_smarty_tpl->tpl_vars['item']->value['tooltip'];?>
)" class="nice_button vp_button">
									<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/lightning.png" align="absmiddle" /> <span class="vp_price_value"><?php echo $_smarty_tpl->tpl_vars['item']->value['vp_price'];?>
</span> <?php echo lang("vp","store");?>

								</a>
								<?php }?>

								<?php if ($_smarty_tpl->tpl_vars['item']->value['dp_price']){?>
								<a href="javascript:void(0)" onClick="Store.Cart.add(<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
, '<?php echo $_smarty_tpl->tpl_vars['item']->value['itemid'];?>
', '<?php echo addslashes($_smarty_tpl->tpl_vars['item']->value['name']);?>
', <?php echo $_smarty_tpl->tpl_vars['item']->value['dp_price'];?>
, 'dp', '<?php echo addslashes($_smarty_tpl->tpl_vars['realm']->value['name']);?>
', <?php echo $_smarty_tpl->tpl_vars['realmId']->value;?>
, <?php echo $_smarty_tpl->tpl_vars['item']->value['quality'];?>
, <?php echo $_smarty_tpl->tpl_vars['item']->value['tooltip'];?>
)" class="nice_button dp_button">
									<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/coins.png" align="absmiddle" /> <span class="dp_price_value"><?php echo $_smarty_tpl->tpl_vars['item']->value['dp_price'];?>
</span> <?php echo lang("dp","store");?>

								</a>
								<?php }?>
							</section>

							<img class="item_icon" src="https://wow.zamimg.com/images/wow/icons/medium/<?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
.jpg" align="absmiddle" <?php if ($_smarty_tpl->tpl_vars['item']->value['tooltip']){?>data-realm="<?php echo $_smarty_tpl->tpl_vars['item']->value['realm'];?>
" rel="item=<?php echo $_smarty_tpl->tpl_vars['item']->value['itemid'];?>
"<?php }?>>
							<a <?php if ($_smarty_tpl->tpl_vars['item']->value['tooltip']){?>href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
item/<?php echo $_smarty_tpl->tpl_vars['item']->value['realm'];?>
/<?php echo $_smarty_tpl->tpl_vars['item']->value['itemid'];?>
" data-realm="<?php echo $_smarty_tpl->tpl_vars['item']->value['realm'];?>
" rel="item=<?php echo $_smarty_tpl->tpl_vars['item']->value['itemid'];?>
"<?php }?> class="item_name q<?php echo $_smarty_tpl->tpl_vars['item']->value['quality'];?>
">
								<?php echo character_limiter($_smarty_tpl->tpl_vars['item']->value['name'],20);?>

							</a>
							<br /><?php echo character_limiter($_smarty_tpl->tpl_vars['item']->value['description'],25);?>

							<div class="clear"></div>
						</div>
						<?php } ?>
					</section> <!-- group end -->
					<?php } ?>

					<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['realm']->value['items']['items']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
					<div class="store_item" id="item_<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
">
						<section class="store_buttons">
							<?php if ($_smarty_tpl->tpl_vars['item']->value['vp_price']){?>
								<a href="javascript:void(0)" onClick="Store.Cart.add(<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
, '<?php echo $_smarty_tpl->tpl_vars['item']->value['itemid'];?>
', '<?php echo addslashes(preg_replace('/"/',"'",$_smarty_tpl->tpl_vars['item']->value['name']));?>
', <?php echo $_smarty_tpl->tpl_vars['item']->value['vp_price'];?>
, 'vp', '<?php echo addslashes($_smarty_tpl->tpl_vars['realm']->value['name']);?>
', <?php echo $_smarty_tpl->tpl_vars['realmId']->value;?>
, <?php echo $_smarty_tpl->tpl_vars['item']->value['quality'];?>
, <?php echo $_smarty_tpl->tpl_vars['item']->value['tooltip'];?>
)" class="nice_button vp_button">
									<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/lightning.png" align="absmiddle" /> <span class="vp_price_value"><?php echo $_smarty_tpl->tpl_vars['item']->value['vp_price'];?>
</span> <?php echo lang("vp","store");?>

								</a>
								<?php }?>

								<?php if ($_smarty_tpl->tpl_vars['item']->value['dp_price']){?>
								<a href="javascript:void(0)" onClick="Store.Cart.add(<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
, '<?php echo $_smarty_tpl->tpl_vars['item']->value['itemid'];?>
', '<?php echo addslashes(preg_replace('/"/',"'",$_smarty_tpl->tpl_vars['item']->value['name']));?>
', <?php echo $_smarty_tpl->tpl_vars['item']->value['dp_price'];?>
, 'dp', '<?php echo addslashes($_smarty_tpl->tpl_vars['realm']->value['name']);?>
', <?php echo $_smarty_tpl->tpl_vars['realmId']->value;?>
, <?php echo $_smarty_tpl->tpl_vars['item']->value['quality'];?>
, <?php echo $_smarty_tpl->tpl_vars['item']->value['tooltip'];?>
)" class="nice_button dp_button">
									<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/coins.png" align="absmiddle" /> <span class="dp_price_value"><?php echo $_smarty_tpl->tpl_vars['item']->value['dp_price'];?>
</span> <?php echo lang("dp","store");?>

								</a>
								<?php }?>
						</section>

						<img class="item_icon" src="https://wow.zamimg.com/images/wow/icons/medium/<?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
.jpg" align="absmiddle" <?php if ($_smarty_tpl->tpl_vars['item']->value['tooltip']){?>data-realm="<?php echo $_smarty_tpl->tpl_vars['item']->value['realm'];?>
" rel="item=<?php echo $_smarty_tpl->tpl_vars['item']->value['itemid'];?>
"<?php }?>>
						<a <?php if ($_smarty_tpl->tpl_vars['item']->value['tooltip']){?>href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
item/<?php echo $_smarty_tpl->tpl_vars['item']->value['realm'];?>
/<?php echo $_smarty_tpl->tpl_vars['item']->value['itemid'];?>
" data-realm="<?php echo $_smarty_tpl->tpl_vars['item']->value['realm'];?>
" rel="item=<?php echo $_smarty_tpl->tpl_vars['item']->value['itemid'];?>
"<?php }?> class="item_name q<?php echo $_smarty_tpl->tpl_vars['item']->value['quality'];?>
">
							<?php echo character_limiter($_smarty_tpl->tpl_vars['item']->value['name'],20);?>

						</a>
						<br /><?php echo character_limiter($_smarty_tpl->tpl_vars['item']->value['description'],25);?>

						<div class="clear"></div>
					</div>
					<?php } ?>

				</section> <!-- realm end -->
				<?php } ?>
			</section>

			<div class="clear"></div>
		</section>

	</section>
</section><?php }} ?>