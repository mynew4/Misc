<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 11:06:33
         compiled from "application\modules\gm\views\panel.tpl" */ ?>
<?php /*%%SmartyHeaderCode:188555284a0a9d4f081-53101152%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '504039ae66cfebb617eb6e3bb70b1df42f34bad0' => 
    array (
      0 => 'application\\modules\\gm\\views\\panel.tpl',
      1 => 1362156154,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '188555284a0a9d4f081-53101152',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'hasConsole' => 0,
    'realmId' => 0,
    'url' => 0,
    'tickets' => 0,
    'ticket' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5284a0a9f10406_10732878',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5284a0a9f10406_10732878')) {function content_5284a0a9f10406_10732878($_smarty_tpl) {?><div id="gm">
	<div id="top_tools">
		<?php if ($_smarty_tpl->tpl_vars['hasConsole']->value&&hasPermission("kick")){?>
			<a href="javascript:void(0)" onClick="Gm.kick(<?php echo $_smarty_tpl->tpl_vars['realmId']->value;?>
)" class="nice_button">
			<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/door_out.png" align="absmiddle">
				<?php echo lang("kick","gm");?>

			</a>
		<?php }?>

		<?php if (hasPermission("ban")){?>
			<a href="javascript:void(0)" onClick="Gm.ban()" class="nice_button">
				<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/cross.png" align="absmiddle">
				<?php echo lang("ban","gm");?>

			</a>
		<?php }?>
	</div>
	<?php if ($_smarty_tpl->tpl_vars['tickets']->value){?>
		<?php  $_smarty_tpl->tpl_vars['ticket'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['ticket']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['tickets']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['ticket']->key => $_smarty_tpl->tpl_vars['ticket']->value){
$_smarty_tpl->tpl_vars['ticket']->_loop = true;
?>
		<div class="gm_ticket">
			<div class="gm_ticket_info">
				<table class="nice_table" cellspacing="0" cellpadding="0">
					<tr>
						<td width="30%"><?php echo lang("ticket","gm");?>
</td>
						<td width="25%"><?php echo lang("time","gm");?>
</td>
						<td width="30%"><?php echo lang("message","gm");?>
</td>
						<td>&nbsp;</td>
					</tr>

					<tr>
						<td>#<?php echo $_smarty_tpl->tpl_vars['ticket']->value['ticketId'];?>
 <?php echo lang("by","gm");?>
 <a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
character/<?php echo $_smarty_tpl->tpl_vars['realmId']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['ticket']->value['guid'];?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['ticket']->value['name'];?>
</a></td>
						<td><?php echo $_smarty_tpl->tpl_vars['ticket']->value['ago'];?>
</td>
						<td><?php echo $_smarty_tpl->tpl_vars['ticket']->value['message_short'];?>
</td>
						<td style="text-align:right;">
							<a class="nice_button" onClick="Gm.view(this)" href="javascript:void(0)"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/bullet_toggle_plus.png" align="absmiddle"> <?php echo lang("view","gm");?>
</a>
						</td>
					</tr>
				</table>
			</div>

			<div class="gm_ticket_info_full">
				<table class="nice_table" cellspacing="0" cellpadding="0">
					<tr>
						<td width="30%"><?php echo lang("ticket","gm");?>
</td>
						<td width="25%"><?php echo lang("time","gm");?>
</td>
						<td>&nbsp;</td>
					</tr>

					<tr>
						<td>#<?php echo $_smarty_tpl->tpl_vars['ticket']->value['ticketId'];?>
 <?php echo lang("by","gm");?>
 <a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
character/<?php echo $_smarty_tpl->tpl_vars['realmId']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['ticket']->value['guid'];?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['ticket']->value['name'];?>
</a></td>
						<td><?php echo $_smarty_tpl->tpl_vars['ticket']->value['ago'];?>
</td>
						<td style="text-align:right;">
							<a class="nice_button" onClick="Gm.hide(this)" href="javascript:void(0)"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/bullet_toggle_minus.png" align="absmiddle"> <?php echo lang("hide","gm");?>
</a>
						</td>
					</tr>
				</table>
				<div class="gm_ticket_text"><?php echo $_smarty_tpl->tpl_vars['ticket']->value['message'];?>
</div>
			</div>

			<div class="gm_tools">
				<?php if (hasPermission("answer")){?>
					<a href="javascript:void(0)" onClick="Gm.close(<?php echo $_smarty_tpl->tpl_vars['realmId']->value;?>
, <?php echo $_smarty_tpl->tpl_vars['ticket']->value['ticketId'];?>
, this)" class="nice_button"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/accept.png" align="absmiddle"> <?php echo lang("close","gm");?>
</a>
					<a href="javascript:void(0)" onClick="Gm.answer(<?php echo $_smarty_tpl->tpl_vars['realmId']->value;?>
, <?php echo $_smarty_tpl->tpl_vars['ticket']->value['ticketId'];?>
, this)" class="nice_button"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/email.png" align="absmiddle"> <?php echo lang("answer","gm");?>
</a>
				<?php }?>

				<?php if (hasPermission("unstuck")){?>
					<a href="javascript:void(0)" onClick="Gm.unstuck(<?php echo $_smarty_tpl->tpl_vars['realmId']->value;?>
, <?php echo $_smarty_tpl->tpl_vars['ticket']->value['ticketId'];?>
, this)" class="nice_button"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/wand.png" align="absmiddle"> <?php echo lang("unstuck","gm");?>
</a>
				<?php }?>

				<?php if (hasPermission("sendItem")){?>
					<a href="javascript:void(0)" onClick="Gm.sendItem(<?php echo $_smarty_tpl->tpl_vars['realmId']->value;?>
, <?php echo $_smarty_tpl->tpl_vars['ticket']->value['ticketId'];?>
, this)" class="nice_button"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/lorry.png" align="absmiddle"> <?php echo lang("send_item","gm");?>
</a>
				<?php }?>
			</div>
		</div>
		<?php } ?>
	<?php }else{ ?>
		<div style="padding:20px;"><?php echo lang("no_tickets","gm");?>
</div>
	<?php }?>
</div><?php }} ?>