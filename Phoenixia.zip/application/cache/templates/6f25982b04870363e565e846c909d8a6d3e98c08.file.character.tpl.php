<?php /* Smarty version Smarty-3.1.8, created on 2013-03-26 10:39:16
         compiled from "application/modules/character/views/character.tpl" */ ?>
<?php /*%%SmartyHeaderCode:107888041551516cc4746084-81384005%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6f25982b04870363e565e846c909d8a6d3e98c08' => 
    array (
      0 => 'application/modules/character/views/character.tpl',
      1 => 1359559561,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '107888041551516cc4746084-81384005',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'stats' => 0,
    'secondBarValue' => 0,
    'secondBar' => 0,
    'url' => 0,
    'avatar' => 0,
    'name' => 0,
    'realmId' => 0,
    'guild' => 0,
    'guildName' => 0,
    'level' => 0,
    'raceName' => 0,
    'className' => 0,
    'realmName' => 0,
    'bg' => 0,
    'items' => 0,
    'has_stats' => 0,
    'pvp' => 0,
    'fcms_tooltip' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51516cc4a8d3d8_67988792',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51516cc4a8d3d8_67988792')) {function content_51516cc4a8d3d8_67988792($_smarty_tpl) {?><!-- Top part -->
<section id="armory_top">
	<section id="armory_bars">
		<?php if ($_smarty_tpl->tpl_vars['stats']->value['maxhealth']&&$_smarty_tpl->tpl_vars['stats']->value['maxhealth']!="Unknown"){?>
			<div id="armory_health">Health: <b><?php echo $_smarty_tpl->tpl_vars['stats']->value['maxhealth'];?>
</b></div>
		<?php }?>

		
		<?php if ($_smarty_tpl->tpl_vars['secondBarValue']->value&&$_smarty_tpl->tpl_vars['secondBarValue']->value!="Unknown"){?>
			<div id="armory_<?php echo $_smarty_tpl->tpl_vars['secondBar']->value;?>
"><?php echo ucfirst($_smarty_tpl->tpl_vars['secondBar']->value);?>
: <b><?php echo $_smarty_tpl->tpl_vars['secondBarValue']->value;?>
</b></div>
		<?php }?>
	</section>

	<img class="avatar" src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/avatars/<?php echo $_smarty_tpl->tpl_vars['avatar']->value;?>
.gif"/>
	
	<section id="armory_name">
		<h1><?php echo $_smarty_tpl->tpl_vars['name']->value;?>
 <a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
guild/<?php echo $_smarty_tpl->tpl_vars['realmId']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['guild']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['guildName']->value;?>
</a></h1>
		<h2><b><?php echo $_smarty_tpl->tpl_vars['level']->value;?>
</b> <?php echo $_smarty_tpl->tpl_vars['raceName']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['className']->value;?>
, <i><?php echo $_smarty_tpl->tpl_vars['realmName']->value;?>
</i></h2>
	</section>

	<div class="clear"></div>
</section>

<div class="ucp_divider"></div>

<!-- Main part -->
<section id="armory" style="background-image:url(<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/armory/<?php echo $_smarty_tpl->tpl_vars['bg']->value;?>
.png)">
	<section id="armory_left">
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['head'];?>
</div>
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['neck'];?>
</div>
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['shoulders'];?>
</div>
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['back'];?>
</div>
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['chest'];?>
</div>
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['body'];?>
</div>
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['tabard'];?>
</div>
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['wrists'];?>
</div>
	</section>

	<!--[if LT IE 8]>
		<script type="text/javascript">
			function noIE()
			{
				if(typeof UI != "undefined")
				{
					UI.alert("The armory is not fully compatible with Internet Explorer 8 or below!");
				}
				else
				{
					setTimeout(noIE, 100);
				}
			}

			$(document).ready(function()
			{
				noIE();
			});
		</script>
	<![endif]-->

	<section id="armory_stats">
		<center id="armory_stats_top">
			<?php if ($_smarty_tpl->tpl_vars['has_stats']->value){?>
				<a href="javascript:void(0)" onClick="Character.tab('stats', this)" class="armory_current_tab">
					<?php echo lang("attributes","character");?>

				</a>
			<?php }?>

			<?php if ($_smarty_tpl->tpl_vars['pvp']->value['kills']||$_smarty_tpl->tpl_vars['pvp']->value['honor']||$_smarty_tpl->tpl_vars['pvp']->value['arena']){?>
				<a href="javascript:void(0)" onClick="Character.tab('pvp', this)" <?php if (!$_smarty_tpl->tpl_vars['has_stats']->value){?>class="armory_current_tab"<?php }?>>
					<?php echo lang("pvp","character");?>

				</a>
			<?php }?>
		</center>
		
		<?php if ($_smarty_tpl->tpl_vars['has_stats']->value){?>
		<section id="tab_stats" style="display:block;">
			<div style="width:1200px;height:194px;" id="attributes_wrapper">
				<div id="tab_armory_1" style="float:left;">
					<table width="367px" cellspacing="0" cellpadding="0">
						<tr>
							<td width="50%"><?php echo lang("str","character");?>
</td>
							<td><?php if (strlen($_smarty_tpl->tpl_vars['stats']->value['strength'])){?><?php echo $_smarty_tpl->tpl_vars['stats']->value['strength'];?>
<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
						</tr>
						<tr>
							<td width="50%"><?php echo lang("sta","character");?>
</td>
							<td><?php if (strlen($_smarty_tpl->tpl_vars['stats']->value['stamina'])){?><?php echo $_smarty_tpl->tpl_vars['stats']->value['stamina'];?>
<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
						</tr>
						<tr>
							<td width="50%"><?php echo lang("int","character");?>
</td>
							<td><?php if (strlen($_smarty_tpl->tpl_vars['stats']->value['intellect'])){?><?php echo $_smarty_tpl->tpl_vars['stats']->value['intellect'];?>
<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
						</tr>
						<tr>
							<td width="50%"><?php echo lang("sp","character");?>
</td>
							<td><?php if (strlen($_smarty_tpl->tpl_vars['stats']->value['spellPower'])){?><?php echo $_smarty_tpl->tpl_vars['stats']->value['spellPower'];?>
<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
						</tr>
						<tr>
							<td width="50%"><?php echo lang("ap","character");?>
</td>
							<td><?php if (strlen($_smarty_tpl->tpl_vars['stats']->value['attackPower'])){?><?php echo $_smarty_tpl->tpl_vars['stats']->value['attackPower'];?>
<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
						</tr>
					</table>

					<center id="armory_stats_next"><a href="javascript:void(0)" onClick="Character.attributes(2)"><?php echo lang("next","character");?>
 &rarr;</a></center>
				</div>

				<div id="tab_armory_2" style="float:left;">
					<table width="367px" cellspacing="0" cellpadding="0">
						<tr>
							<td width="50%"><?php echo lang("res","character");?>
</td>
							<td><?php if (strlen($_smarty_tpl->tpl_vars['stats']->value['resilience'])){?><?php echo $_smarty_tpl->tpl_vars['stats']->value['resilience'];?>
<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
						</tr>
						<tr>
							<td width="50%"><?php echo lang("armor","character");?>
</td>
							<td><?php if (strlen($_smarty_tpl->tpl_vars['stats']->value['armor'])){?><?php echo $_smarty_tpl->tpl_vars['stats']->value['armor'];?>
<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
						</tr>
						<tr>
							<td width="50%"><?php echo lang("block","character");?>
</td>
							<td><?php if (strlen($_smarty_tpl->tpl_vars['stats']->value['blockPct'])){?><?php echo $_smarty_tpl->tpl_vars['stats']->value['blockPct'];?>
%<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
						</tr>
						<tr>
							<td width="50%"><?php echo lang("dodge","character");?>
</td>
							<td><?php if (strlen($_smarty_tpl->tpl_vars['stats']->value['dodgePct'])){?><?php echo $_smarty_tpl->tpl_vars['stats']->value['dodgePct'];?>
%<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
						</tr>
						<tr>
							<td width="50%"><?php echo lang("parry","character");?>
</td>
							<td><?php if (strlen($_smarty_tpl->tpl_vars['stats']->value['parryPct'])){?><?php echo $_smarty_tpl->tpl_vars['stats']->value['parryPct'];?>
%<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
						</tr>
					</table>

					<center id="armory_stats_next">
						<a href="javascript:void(0)" onClick="Character.attributes(1)">&larr; <?php echo lang("previous","character");?>
</a>
						<a href="javascript:void(0)" onClick="Character.attributes(3)"><?php echo lang("next","character");?>
 &rarr;</a>
					</center>
				</div>

				<div id="tab_armory_3" style="float:left;">
					<table width="367px" cellspacing="0" cellpadding="0">
						<tr>
							<td width="50%"><?php echo lang("crit","character");?>
</td>
							<td><?php if (strlen($_smarty_tpl->tpl_vars['stats']->value['critPct'])){?><?php echo $_smarty_tpl->tpl_vars['stats']->value['critPct'];?>
%<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
						</tr>
						<tr>
							<td width="50%"><?php echo lang("ranged_crit","character");?>
</td>
							<td><?php if (strlen($_smarty_tpl->tpl_vars['stats']->value['rangedCritPct'])){?><?php echo $_smarty_tpl->tpl_vars['stats']->value['rangedCritPct'];?>
%<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
						</tr>
						<tr>
							<td width="50%"><?php echo lang("spell_crit","character");?>
</td>
							<td><?php if (strlen($_smarty_tpl->tpl_vars['stats']->value['spellCritPct'])){?><?php echo $_smarty_tpl->tpl_vars['stats']->value['spellCritPct'];?>
%<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
						</tr>
						<tr>
							<td width="50%"><?php echo lang("spirit","character");?>
</td>
							<td><?php if (strlen($_smarty_tpl->tpl_vars['stats']->value['spirit'])){?><?php echo $_smarty_tpl->tpl_vars['stats']->value['spirit'];?>
<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
						</tr>
						<tr>
							<td width="50%">&nbsp;</td>
							<td></td>
						</tr>
					</table>

					<center id="armory_stats_next"><a href="javascript:void(0)" onClick="Character.attributes(2)">&larr; <?php echo lang("previous","character");?>
</a></center>
				</div>
			</div>
		</section>
		<?php }?>

		<section id="tab_pvp" <?php if (!$_smarty_tpl->tpl_vars['has_stats']->value){?>style="display:block;"<?php }?>>
			<table width="367px" cellspacing="0" cellpadding="0">
				<?php if ($_smarty_tpl->tpl_vars['pvp']->value['kills']!==false){?>
				<tr>
					<td width="50%"><?php echo lang("kills","character");?>
</td>
					<td><?php if (strlen($_smarty_tpl->tpl_vars['pvp']->value['kills'])){?><?php echo $_smarty_tpl->tpl_vars['pvp']->value['kills'];?>
<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
				</tr>
				<?php }?>

				<?php if ($_smarty_tpl->tpl_vars['pvp']->value['honor']!==false){?>
				<tr>
					<td width="50%"><?php echo lang("honor","character");?>
</td>
					<td><?php if (strlen($_smarty_tpl->tpl_vars['pvp']->value['honor'])){?><?php echo $_smarty_tpl->tpl_vars['pvp']->value['honor'];?>
<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
				</tr>
				<?php }?>

				<?php if ($_smarty_tpl->tpl_vars['pvp']->value['arena']!==false){?>
				<tr>
					<td width="50%"><?php echo lang("arena","character");?>
</td>
					<td><?php if (strlen($_smarty_tpl->tpl_vars['pvp']->value['arena'])){?><?php echo $_smarty_tpl->tpl_vars['pvp']->value['arena'];?>
<?php }else{ ?><?php echo lang("unknown","character");?>
<?php }?></td>
				</tr>
				<?php }?>
			</table>
		</section>
	</section>

	<section id="armory_right">
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['hands'];?>
</div>
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['waist'];?>
</div>
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['legs'];?>
</div>
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['feet'];?>
</div>
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['finger1'];?>
</div>
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['finger2'];?>
</div>
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['trinket1'];?>
</div>
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['trinket2'];?>
</div>
	</section>

	<section id="armory_bottom">
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['mainhand'];?>
</div>
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['offhand'];?>
</div>
		<div class="item"><a></a><?php echo $_smarty_tpl->tpl_vars['items']->value['ranged'];?>
</div>
	</section>
</section>

<!-- Load wowhead tooltip -->
<?php if (!$_smarty_tpl->tpl_vars['fcms_tooltip']->value){?>
<script type="text/javascript" src="https://static.wowhead.com/widgets/power.js"></script>
<script>var wowhead_tooltips = { "colorlinks": false, "iconizelinks": false, "renamelinks": false }</script>
<?php }?><?php }} ?>