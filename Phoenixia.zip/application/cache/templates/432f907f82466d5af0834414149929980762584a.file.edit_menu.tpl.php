<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 19:05:26
         compiled from "application\modules\admin\views\menu\edit_menu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:27528510e6653ba8-81564801%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '432f907f82466d5af0834414149929980762584a' => 
    array (
      0 => 'application\\modules\\admin\\views\\menu\\edit_menu.tpl',
      1 => 1364231462,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '27528510e6653ba8-81564801',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'link' => 0,
    'url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_528510e673a326_61794923',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_528510e673a326_61794923')) {function content_528510e673a326_61794923($_smarty_tpl) {?><section class="box big">
	<h2>Edit link</h2>

	<form onSubmit="Menu.save(this, <?php echo $_smarty_tpl->tpl_vars['link']->value['id'];?>
); return false" id="submit_form">
		<label for="name">Title</label>
		<input type="text" name="name" id="name" placeholder="My link" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['link']->value['name']);?>
" />

		<label for="type" data-tip="External links must begin with http://">URL <a>(?)</a></label>
		<input type="text" name="link" id="link" placeholder="http://" value="<?php echo $_smarty_tpl->tpl_vars['link']->value['link'];?>
"/>

		<label for="side">Menu location</label>
		<select name="side" id="side">
			<option value="top" <?php if ($_smarty_tpl->tpl_vars['link']->value['side']=="top"){?>selected<?php }?>>Top</option>
			<option value="side" <?php if ($_smarty_tpl->tpl_vars['link']->value['side']=="side"){?>selected<?php }?>>Side</option>
		</select>

		<label for="visibility">Visibility mode</label>
		<select name="visibility" id="visibility" onChange="if(this.value == 'group'){ $('#groups').fadeIn(300); } else { $('#groups').fadeOut(300); }">
			<option value="everyone" <?php if (!$_smarty_tpl->tpl_vars['link']->value['permission']){?>selected<?php }?>>Visible to everyone</option>
			<option value="group" <?php if ($_smarty_tpl->tpl_vars['link']->value['permission']){?>selected<?php }?>>Controlled per group</option>
		</select>

		<div <?php if (!$_smarty_tpl->tpl_vars['link']->value['permission']){?>style="display:none"<?php }?> id="groups">
			Please manage the group visibility via <a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/aclmanager/groups">the group manager</a>
		</div>
		
		<label for="direct_link" data-tip="If you want to link to a non-FusionCMS page on the same domain, you must select 'Yes' otherwise FusionCMS will try to load it 'inside' the theme.">Internal direct link <a>(?)</a></label>
		<select name="direct_link" id="direct_link">
				<option value="0" <?php if ($_smarty_tpl->tpl_vars['link']->value['direct_link']=="0"){?>selected<?php }?>>No</option>
				<option value="1" <?php if ($_smarty_tpl->tpl_vars['link']->value['direct_link']=="1"){?>selected<?php }?>>Yes</option>
		</select>

		<input type="submit" value="Save link" />
	</form>
</section>

<script>
	require([Config.URL + "application/themes/admin/js/mli.js"], function()
	{
		new MultiLanguageInput($("#name"));
	});
</script><?php }} ?>