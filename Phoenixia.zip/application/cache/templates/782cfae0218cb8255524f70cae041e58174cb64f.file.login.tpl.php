<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 13:58:28
         compiled from "application/modules/sidebox_info_login/views/login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1256123838515049f412cca2-62816273%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '782cfae0218cb8255524f70cae041e58174cb64f' => 
    array (
      0 => 'application/modules/sidebox_info_login/views/login.tpl',
      1 => 1359922077,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1256123838515049f412cca2-62816273',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_515049f4189de3_44653471',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_515049f4189de3_44653471')) {function content_515049f4189de3_44653471($_smarty_tpl) {?><?php echo form_open('login');?>

	<center id="sidebox_login">
		<input type="text" name="login_username" id="login_username" value="" placeholder="<?php echo lang("username","sidebox_info");?>
">
		<input type="password" name="login_password" id="login_password" value="" placeholder="<?php echo lang("password","sidebox_info");?>
">
		<input type="submit" name="login_submit" value="<?php echo lang("log_in","sidebox_info");?>
">
	</center>
</form><?php }} ?>