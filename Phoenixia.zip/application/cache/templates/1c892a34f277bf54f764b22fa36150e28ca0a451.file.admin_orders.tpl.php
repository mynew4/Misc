<?php /* Smarty version Smarty-3.1.8, created on 2013-03-26 11:18:57
         compiled from "application/modules/store/views/admin_orders.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1119745672515176118cca28-06988640%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1c892a34f277bf54f764b22fa36150e28ca0a451' => 
    array (
      0 => 'application/modules/store/views/admin_orders.tpl',
      1 => 1363632456,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1119745672515176118cca28-06988640',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'failed' => 0,
    'failed_log' => 0,
    'item' => 0,
    'completed' => 0,
    'completed_log' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_515176119c0c98_89876091',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_515176119c0c98_89876091')) {function content_515176119c0c98_89876091($_smarty_tpl) {?><section class="box big">
	<h2>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_list.png"/>
		Failed orders in the past week
	</h2>

	<span>
		Orders that show up here have failed because of a system error. If the error didn't occur immediately some items might have been delivered. You should manually investigate if the user should be refunded.
	</span>

	<ul>
		<?php if ($_smarty_tpl->tpl_vars['failed']->value){?>
			<?php  $_smarty_tpl->tpl_vars['failed_log'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['failed_log']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['failed']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['failed_log']->key => $_smarty_tpl->tpl_vars['failed_log']->value){
$_smarty_tpl->tpl_vars['failed_log']->_loop = true;
?>
				<li>
					<table width="100%">
						<tr>
							<td width="20%"><?php echo date("Y/m/d",$_smarty_tpl->tpl_vars['failed_log']->value['timestamp']);?>
</td>
							<td width="16%">
								<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
profile/<?php echo $_smarty_tpl->tpl_vars['failed_log']->value['user_id'];?>
" target="_blank">
									<?php echo $_smarty_tpl->tpl_vars['failed_log']->value['username'];?>

								</a>
							</td>
							
							<td width="35%">
								<?php if ($_smarty_tpl->tpl_vars['failed_log']->value['vp_cost']){?><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/lightning.png" align="absmiddle" style="margin:0px;opacity:1;" /> <b><?php echo $_smarty_tpl->tpl_vars['failed_log']->value['vp_cost'];?>
 VP</b>&nbsp;&nbsp;&nbsp;<?php }?>
								<?php if ($_smarty_tpl->tpl_vars['failed_log']->value['dp_cost']){?><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/coins.png" align="absmiddle"  style="margin:0px;opacity:1;"/> <b><?php echo $_smarty_tpl->tpl_vars['failed_log']->value['dp_cost'];?>
 DP</b><?php }?>
							</td>

							<td>
								<a data-tip="<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['failed_log']->value['json']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?><?php echo $_smarty_tpl->tpl_vars['item']->value['itemName'];?>
 to <?php echo $_smarty_tpl->tpl_vars['item']->value['characterName'];?>
<br /><?php } ?>"><?php echo count($_smarty_tpl->tpl_vars['failed_log']->value['json']);?>
 items</a>
							</td>
							
							<?php if (hasPermission("canRefundOrders")){?>
								<td style="text-align:right;">
									<a class="nice_button" href="javascript:void(0)" onClick="Orders.refund(<?php echo $_smarty_tpl->tpl_vars['failed_log']->value['id'];?>
, this)">Refund</a>
								</td>
							<?php }?>
						</tr>
					</table>
				</li>
			<?php } ?>
		<?php }?>
	</ul>
</section>

<section class="box big">
	<h2>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_list.png"/>
		Last 10 successful orders
	</h2>

	<ul>
		<?php if ($_smarty_tpl->tpl_vars['completed']->value){?>
			<?php  $_smarty_tpl->tpl_vars['completed_log'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['completed_log']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['completed']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['completed_log']->key => $_smarty_tpl->tpl_vars['completed_log']->value){
$_smarty_tpl->tpl_vars['completed_log']->_loop = true;
?>
				<li>
					<table width="100%">
						<tr>
							<td width="20%"><?php echo date("Y/m/d",$_smarty_tpl->tpl_vars['completed_log']->value['timestamp']);?>
</td>
							<td width="16%">
								<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
profile/<?php echo $_smarty_tpl->tpl_vars['completed_log']->value['user_id'];?>
" target="_blank">
									<?php echo $_smarty_tpl->tpl_vars['completed_log']->value['username'];?>

								</a>
							</td>
							
							<td width="35%">
								<?php if ($_smarty_tpl->tpl_vars['completed_log']->value['vp_cost']){?><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/lightning.png" align="absmiddle" style="margin:0px;opacity:1;" /> <b><?php echo $_smarty_tpl->tpl_vars['completed_log']->value['vp_cost'];?>
 VP</b>&nbsp;&nbsp;&nbsp;<?php }?>
								<?php if ($_smarty_tpl->tpl_vars['completed_log']->value['dp_cost']){?><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/coins.png" align="absmiddle"  style="margin:0px;opacity:1;"/> <b><?php echo $_smarty_tpl->tpl_vars['completed_log']->value['dp_cost'];?>
 DP</b><?php }?>
							</td>

							<td>
								<a data-tip="<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['completed_log']->value['json']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?><?php echo $_smarty_tpl->tpl_vars['item']->value['itemName'];?>
 to <?php echo $_smarty_tpl->tpl_vars['item']->value['characterName'];?>
<br /><?php } ?>"><?php echo count($_smarty_tpl->tpl_vars['completed_log']->value['json']);?>
 items</a>
							</td>
						</tr>
					</table>
				</li>
			<?php } ?>
		<?php }?>
	</ul>
</section><?php }} ?>