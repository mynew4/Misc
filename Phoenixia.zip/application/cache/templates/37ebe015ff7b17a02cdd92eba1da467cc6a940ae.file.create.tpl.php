<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 22:06:08
         compiled from "application\modules\messages\views\create.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1904152853b40529ae4-73038370%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '37ebe015ff7b17a02cdd92eba1da467cc6a940ae' => 
    array (
      0 => 'application\\modules\\messages\\views\\create.tpl',
      1 => 1359559562,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1904152853b40529ae4-73038370',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'username' => 0,
    'url' => 0,
    'editor' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_52853b405be1e5_41999001',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52853b405be1e5_41999001')) {function content_52853b405be1e5_41999001($_smarty_tpl) {?><div id="pm_spot">
	
	<table width="100%">
		<tr>
			<td width="12%" valign="top" style="padding-top:15px;"><label for="pm_username"><?php echo lang("recipient","messages");?>
</label></td>
			<td>
				<input type="text" name="pm_username" id="pm_username" placeholder="<?php echo lang("search","messages");?>
" onKeyUp="Create.autoComplete(this)" <?php if ($_smarty_tpl->tpl_vars['username']->value){?>value="<?php echo $_smarty_tpl->tpl_vars['username']->value;?>
"<?php }?>/>
				<div id="pm_username_autocomplete"></div>
			</td>
			<td width="5%" style="text-align:right;padding-top:15px;" valign="top">
				<span id="pm_username_error"><?php if ($_smarty_tpl->tpl_vars['username']->value){?><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/accept.png"/><?php }?></span>
			</td>
		</tr>
		<tr>
			<td><label for="pm_title"><?php echo lang("title","messages");?>
</label></td>
			<td>
				<input type="text" name="pm_title" id="pm_title" maxlength="50" placeholder="<?php echo lang("hi_there","messages");?>
" onBlur="Create.validateTitle(this)"/>
			</td>
			<td style="text-align:right;">
				<span id="pm_title_error"></span>
			</td>
		</tr>
	</table>

	<div style="height:10px"></div>
	<?php echo $_smarty_tpl->tpl_vars['editor']->value;?>


	<div style="height:10px"></div>

	<form onSubmit="Create.send(); return false">
		<center><input type="submit" value="<?php echo lang("send","messages");?>
" /></center>
	</form>

	<div style="height:10px"></div>
</div><?php }} ?>