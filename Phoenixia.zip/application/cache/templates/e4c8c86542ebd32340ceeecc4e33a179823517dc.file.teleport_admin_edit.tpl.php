<?php /* Smarty version Smarty-3.1.8, created on 2013-11-15 00:44:56
         compiled from "application\modules\teleport\views\teleport_admin_edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:259785285607822a1a7-60376658%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e4c8c86542ebd32340ceeecc4e33a179823517dc' => 
    array (
      0 => 'application\\modules\\teleport\\views\\teleport_admin_edit.tpl',
      1 => 1359559562,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '259785285607822a1a7-60376658',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'teleport_location' => 0,
    'realms' => 0,
    'realm' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_528560783b88a5_84405281',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_528560783b88a5_84405281')) {function content_528560783b88a5_84405281($_smarty_tpl) {?><section class="box big">
	<h2>Edit teleport location</h2>

	<form onSubmit="Teleport.save(this, <?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['id'];?>
); return false" id="submit_form">
		<label for="name">Location name</label>
		<input type="text" name="name" id="name" value="<?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['name'];?>
"/>

		<label for="description">Description</label>
		<input type="text" name="description" id="description" value="<?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['description'];?>
"/>

		<label for="realm">Realm</label>
		<select id="realm" name="realm">
			<?php  $_smarty_tpl->tpl_vars['realm'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['realm']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['realms']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['realm']->key => $_smarty_tpl->tpl_vars['realm']->value){
$_smarty_tpl->tpl_vars['realm']->_loop = true;
?>
				<option value="<?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
" <?php if ($_smarty_tpl->tpl_vars['teleport_location']->value['realm']==$_smarty_tpl->tpl_vars['realm']->value->getId()){?>selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['realm']->value->getName();?>
</option>
			<?php } ?>
		</select>

		<label for="priceType">Price type</label>
		<select id="priceType" name="priceType" onChange="Teleport.changePrice(this)">
			<option value="free" <?php if (!$_smarty_tpl->tpl_vars['teleport_location']->value['vpCost']&&!$_smarty_tpl->tpl_vars['teleport_location']->value['dpCost']&&$_smarty_tpl->tpl_vars['teleport_location']->value['goldCost']){?>selected<?php }?>>Free</option>
			<option value="vp" <?php if ($_smarty_tpl->tpl_vars['teleport_location']->value['vpCost']){?>selected<?php }?>>VP</option>
			<option value="dp" <?php if ($_smarty_tpl->tpl_vars['teleport_location']->value['dpCost']){?>selected<?php }?>>DP</option>
			<option value="gold" <?php if ($_smarty_tpl->tpl_vars['teleport_location']->value['goldCost']){?>selected<?php }?>>Gold</option>
		</select>

		<div id="vp_price" style="display:none;">
			<label for="vpCost">VP price</label>
			<input type="text" name="vpCost" id="vpCost" value="<?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['vpCost'];?>
"/>
		</div>

		<div id="dp_price" style="display:none;">
			<label for="dpCost">DP price</label>
			<input type="text" name="dpCost" id="dpCost" value="<?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['dpCost'];?>
"/>
		</div>

		<div id="gold_price" style="display:none;">
			<label for="goldCost">Gold price</label>
			<input type="text" name="goldCost" id="goldCost" value="<?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['goldCost'];?>
"/>
		</div>
		
		<label for="x">X coordinate</label>
		<input type="text" name="x" id="x" value="<?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['x'];?>
"/>
		
		<label for="y">Y coordinate</label>
		<input type="text" name="y" id="y" value="<?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['y'];?>
"/>
		
		<label for="z">Z coordinate</label>
		<input type="text" name="z" id="z" value="<?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['z'];?>
"/>
		
		<label for="orientation">Orientation</label>
		<input type="text" name="orientation" id="orientation" value="<?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['orientation'];?>
"/>
		
		<label for="mapId">Map ID</label>
		<input type="text" name="mapId" id="mapId" value="<?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['mapId'];?>
"/>

		<label for="required_faction">Required faction</label>
		<select id="required_faction" name="required_faction">
			<option value="0" <?php if ($_smarty_tpl->tpl_vars['teleport_location']->value['required_faction']==0){?>selected<?php }?>>Any</option>
			<option value="1" <?php if ($_smarty_tpl->tpl_vars['teleport_location']->value['required_faction']==1){?>selected<?php }?>>Alliance</option>
			<option value="2" <?php if ($_smarty_tpl->tpl_vars['teleport_location']->value['required_faction']==2){?>selected<?php }?>>Horde</option>
		</select>
		
		<input type="submit" value="Save location" />
	</form>
</section><?php }} ?>