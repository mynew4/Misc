<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 16:19:37
         compiled from "application\modules\register\views\register.tpl" */ ?>
<?php /*%%SmartyHeaderCode:136075284ea09d1a1a5-22653955%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '573cd27951be1d96bb23fb15c37158b6df6718d5' => 
    array (
      0 => 'application\\modules\\register\\views\\register.tpl',
      1 => 1360063362,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '136075284ea09d1a1a5-22653955',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'username_error' => 0,
    'email_error' => 0,
    'password_error' => 0,
    'password_confirm_error' => 0,
    'expansions' => 0,
    'id' => 0,
    'expansion' => 0,
    'use_captcha' => 0,
    'url' => 0,
    'captcha_error' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5284ea0a035522_86255364',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5284ea0a035522_86255364')) {function content_5284ea0a035522_86255364($_smarty_tpl) {?><?php echo form_open('register','class="page_form"');?>

	<table style="width:80%">
		<tr>
			<td><label for="register_username"><?php echo lang("username","register");?>
</label></td>
			<td>
				<input type="text" name="register_username" id="register_username" value="<?php echo set_value('register_username');?>
" onChange="Validate.checkUsername()"/>
				<span id="username_error"><?php echo $_smarty_tpl->tpl_vars['username_error']->value;?>
</span>
			</td>
		</tr>
		<tr>
			<td><label for="register_email"><?php echo lang("email","register");?>
</label></td>
			<td>
				<input type="email" name="register_email" id="register_email" value="<?php echo set_value('register_email');?>
" onChange="Validate.checkEmail()"/>
				<span id="email_error"><?php echo $_smarty_tpl->tpl_vars['email_error']->value;?>
</span>
			</td>
		</tr>
		<tr>
			<td><label for="register_password"><?php echo lang("password","register");?>
</label></td>
			<td>
				<input type="password" name="register_password" id="register_password" value="<?php echo set_value('register_password');?>
" onChange="Validate.checkPassword()"/>
				<span id="password_error"><?php echo $_smarty_tpl->tpl_vars['password_error']->value;?>
</span>
			</td>
		</tr>
		<tr>
			<td><label for="register_password_confirm"><?php echo lang("confirm","register");?>
</label></td>
			<td>
				<input type="password" name="register_password_confirm" id="register_password_confirm" value="<?php echo set_value('register_password_confirm');?>
" onChange="Validate.checkPasswordConfirm()"/>
				<span id="password_confirm_error"><?php echo $_smarty_tpl->tpl_vars['password_confirm_error']->value;?>
</span>
			</td>
		</tr>
		<tr>
			<td><label for="register_expansion"><?php echo lang("expansion","register");?>
</label></td>
			<td>
				<select id="register_expansion" name="register_expansion">
					<?php  $_smarty_tpl->tpl_vars['expansion'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['expansion']->_loop = false;
 $_smarty_tpl->tpl_vars['id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['expansions']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['expansion']->key => $_smarty_tpl->tpl_vars['expansion']->value){
$_smarty_tpl->tpl_vars['expansion']->_loop = true;
 $_smarty_tpl->tpl_vars['id']->value = $_smarty_tpl->tpl_vars['expansion']->key;
?>
						<option value="<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['expansion']->value;?>
</option>
					<?php } ?>
				</select>
			</td>
		</tr>

		<?php if ($_smarty_tpl->tpl_vars['use_captcha']->value){?>
			<tr>
				<td><label for="captcha"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/modules/register/controllers/getCaptcha.php?<?php echo uniqid();?>
" /></label></td>
				<td>
					<input type="text" name="register_captcha" id="register_captcha"/>
					
					<span id="captcha_error"><?php echo $_smarty_tpl->tpl_vars['captcha_error']->value;?>
</span>
				</td>
			</tr>
		<?php }?>
	</table>
	<center style="margin-bottom:10px;">
		<input type="submit" name="login_submit" value="<?php echo lang("submit","register");?>
" />
	</center>
<?php echo form_close();?>
<?php }} ?>