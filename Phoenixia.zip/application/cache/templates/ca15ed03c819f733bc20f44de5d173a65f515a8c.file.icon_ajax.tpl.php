<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 23:21:29
         compiled from "application\modules\item\views\icon_ajax.tpl" */ ?>
<?php /*%%SmartyHeaderCode:35152854ce9bec266-78067133%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ca15ed03c819f733bc20f44de5d173a65f515a8c' => 
    array (
      0 => 'application\\modules\\item\\views\\icon_ajax.tpl',
      1 => 1359559562,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '35152854ce9bec266-78067133',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'id' => 0,
    'url' => 0,
    'realm' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_52854ce9c59864_49003382',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52854ce9c59864_49003382')) {function content_52854ce9c59864_49003382($_smarty_tpl) {?><span class="get_icon_<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
">
	<div class='item'>
		<a></a>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/armory/default/loading.gif" />
	</div>
</span>

<script type="text/javascript">
	$(document).ready(function()
	{
		$.get(Config.URL + "icon/get/" + <?php echo $_smarty_tpl->tpl_vars['realm']->value;?>
 + "/" + <?php echo $_smarty_tpl->tpl_vars['id']->value;?>
, function(data)
	 	{
	 		$(".get_icon_" + <?php echo $_smarty_tpl->tpl_vars['id']->value;?>
).each(function()
	 		{
	 			$(this).html("<div class='item'><a></a><img src='https://wow.zamimg.com/images/wow/icons/large/" + data + ".jpg' /></div>");
	 		});
	 	});
	});
</script><?php }} ?>