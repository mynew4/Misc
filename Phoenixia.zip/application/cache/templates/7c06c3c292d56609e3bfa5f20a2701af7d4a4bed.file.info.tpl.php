<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 10:46:14
         compiled from "application\modules\sidebox_info_login\views\info.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1530752849be66de982-87660771%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7c06c3c292d56609e3bfa5f20a2701af7d4a4bed' => 
    array (
      0 => 'application\\modules\\sidebox_info_login\\views\\info.tpl',
      1 => 1359921654,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1530752849be66de982-87660771',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'expansion' => 0,
    'lastIp' => 0,
    'currentIp' => 0,
    'vp' => 0,
    'dp' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_52849be6748104_57214971',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52849be6748104_57214971')) {function content_52849be6748104_57214971($_smarty_tpl) {?><section class="sidebox_info">
	<table width="100%">
		<tr>
			<td width="50%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/plugin.png" align="absmiddle" /> <?php echo lang("expansion","sidebox_info");?>
</td>
			<td>
				<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
ucp/expansion" data-tip="Change expansion" style="float:right;margin-right:10px;">
					<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/cog.png" align="absbottom" />
				</a>
				<?php echo $_smarty_tpl->tpl_vars['expansion']->value;?>

			</td>
		</tr>
		<tr>
			<td><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/computer_error.png" align="absmiddle" /> <?php echo lang("last_ip","sidebox_info");?>
</td>
			<td><?php echo $_smarty_tpl->tpl_vars['lastIp']->value;?>
</td>
		</tr>
		<tr>
			<td><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/computer.png" align="absmiddle" /> <?php echo lang("current_ip","sidebox_info");?>
</td>
			<td><?php echo $_smarty_tpl->tpl_vars['currentIp']->value;?>
</td>
		</tr>
		<tr>
			<td><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/lightning.png" align="absmiddle" /> <?php echo lang("vp","sidebox_info");?>
</td>
			<td id="info_vp"><?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
</td>
		</tr>
		<tr>
			<td><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/coins.png" align="absmiddle" /> <?php echo lang("dp","sidebox_info");?>
</td>
			<td id="info_dp"><?php echo $_smarty_tpl->tpl_vars['dp']->value;?>
</td>
		</tr>
	</table>
	<center>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
ucp" class="nice_button"><?php echo lang("user_panel","sidebox_info");?>
</a>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
logout" class="nice_button"><?php echo lang("log_out","sidebox_info");?>
</a>
	</center>
</section><?php }} ?>