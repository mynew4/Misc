<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 20:03:34
         compiled from "application\modules\armory\views\result.tpl" */ ?>
<?php /*%%SmartyHeaderCode:392052851e8668ace4-41806150%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '01df95ce8bba9d5ca948197a9f1c6a0e5ebe83db' => 
    array (
      0 => 'application\\modules\\armory\\views\\result.tpl',
      1 => 1359559562,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '392052851e8668ace4-41806150',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'realms' => 0,
    'realm' => 0,
    'show' => 0,
    'characters' => 0,
    'guilds' => 0,
    'items' => 0,
    'character' => 0,
    'url' => 0,
    'guild' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_52851e8695d766_10704915',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52851e8695d766_10704915')) {function content_52851e8695d766_10704915($_smarty_tpl) {?><!--[if LT IE 8]>
	<script type="text/javascript">
		function noIE()
		{
			if(typeof UI != "undefined")
			{
				UI.alert("The armory is not fully compatible with Internet Explorer 8 or below!");
			}
			else
			{
				setTimeout(noIE, 100);
			}
		}

		$(document).ready(function()
		{
			noIE();
		});
	</script>
<![endif]-->
	
<div id="search_sections">
	<div id="search_realms">
		<?php  $_smarty_tpl->tpl_vars['realm'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['realm']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['realms']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['realm']->key => $_smarty_tpl->tpl_vars['realm']->value){
$_smarty_tpl->tpl_vars['realm']->_loop = true;
?>
			<a href="javascript:void(0)" onClick="Search.toggleRealm(<?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
, this)" class="search_realm nice_button nice_active">
				<?php echo $_smarty_tpl->tpl_vars['realm']->value->getName();?>

			</a>
		<?php } ?>
	</div>

	<a href="javascript:void(0)" onClick="Search.showTab(1, this)" class="search_link <?php if ($_smarty_tpl->tpl_vars['show']->value['characters']=='block'){?>nice_active<?php }?> nice_button"><?php echo lang('characters','armory');?>
 (<?php echo count($_smarty_tpl->tpl_vars['characters']->value);?>
)</a>
	<a href="javascript:void(0)" onClick="Search.showTab(2, this)" class="search_link <?php if ($_smarty_tpl->tpl_vars['show']->value['guilds']=='block'){?>nice_active<?php }?> nice_button"><?php echo lang('guilds','armory');?>
 (<?php echo count($_smarty_tpl->tpl_vars['guilds']->value);?>
)</a>
	<a href="javascript:void(0)" onClick="Search.showTab(3, this)" class="search_link <?php if ($_smarty_tpl->tpl_vars['show']->value['items']=='block'){?>nice_active<?php }?> nice_button"><?php echo lang('items','armory');?>
 (<?php echo count($_smarty_tpl->tpl_vars['items']->value);?>
)</a>
</div>

<div class="ucp_divider"></div>

<div id="search_tab_1" class="search_tab" style="display:<?php echo $_smarty_tpl->tpl_vars['show']->value['characters'];?>
">
	<?php if (count($_smarty_tpl->tpl_vars['characters']->value)>0){?>
		<?php  $_smarty_tpl->tpl_vars['character'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['character']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['characters']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['character']->key => $_smarty_tpl->tpl_vars['character']->value){
$_smarty_tpl->tpl_vars['character']->_loop = true;
?>
			<div class="search_result_realm_<?php echo $_smarty_tpl->tpl_vars['character']->value['realm'];?>
 search_result_character">
				<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
character/<?php echo $_smarty_tpl->tpl_vars['character']->value['realm'];?>
/<?php echo $_smarty_tpl->tpl_vars['character']->value['guid'];?>
"><img width="54" height="54" src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/avatars/<?php echo $_smarty_tpl->tpl_vars['character']->value['avatar'];?>
.gif" class="avatar"/></a>
				<a class="color-c<?php echo $_smarty_tpl->tpl_vars['character']->value['race'];?>
 name" href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
character/<?php echo $_smarty_tpl->tpl_vars['character']->value['realm'];?>
/<?php echo $_smarty_tpl->tpl_vars['character']->value['guid'];?>
"><?php echo $_smarty_tpl->tpl_vars['character']->value['name'];?>
</a>
				<span>
					<b><?php echo $_smarty_tpl->tpl_vars['character']->value['level'];?>
</b> <?php echo $_smarty_tpl->tpl_vars['character']->value['raceName'];?>
 <?php echo $_smarty_tpl->tpl_vars['character']->value['className'];?>
<br />
					<?php echo $_smarty_tpl->tpl_vars['character']->value['realmName'];?>

				</span>
			</div>
		<?php } ?>
		<div class="clear"></div>
	<?php }else{ ?>
		<center><?php echo lang("no_characters_found","armory");?>
</center>
	<?php }?>
</div>

<div id="search_tab_2" class="search_tab" style="display:<?php echo $_smarty_tpl->tpl_vars['show']->value['guilds'];?>
;">
	<?php if (count($_smarty_tpl->tpl_vars['guilds']->value)>0){?>
		<table class="nice_table" cellspacing="0" >
			<tr>
				<td><?php echo lang("name","armory");?>
</td>
				<td align="center"><?php echo lang("members","armory");?>
</td>
				<td><?php echo lang("owner","armory");?>
</td>
				<td><?php echo lang("realm","armory");?>
</td>
			</tr>

			<?php  $_smarty_tpl->tpl_vars['guild'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['guild']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['guilds']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['guild']->key => $_smarty_tpl->tpl_vars['guild']->value){
$_smarty_tpl->tpl_vars['guild']->_loop = true;
?>
				<tr class="search_result_realm_<?php echo $_smarty_tpl->tpl_vars['guild']->value['realm'];?>
 search_result_item">
					<td><a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
guild/<?php echo $_smarty_tpl->tpl_vars['guild']->value['realm'];?>
/<?php echo $_smarty_tpl->tpl_vars['guild']->value['id'];?>
" data-tip="View guild page"><?php echo $_smarty_tpl->tpl_vars['guild']->value['name'];?>
</a></td>
					<td align="center"><?php echo $_smarty_tpl->tpl_vars['guild']->value['members'];?>
</td>
					<td>
						<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
character/<?php echo $_smarty_tpl->tpl_vars['guild']->value['realm'];?>
/<?php echo $_smarty_tpl->tpl_vars['guild']->value['ownerGuid'];?>
" data-tip="<?php echo lang('view_character_profile','armory');?>
"><?php echo $_smarty_tpl->tpl_vars['guild']->value['ownerName'];?>
</a>
					</td>
					<td><?php echo $_smarty_tpl->tpl_vars['guild']->value['realmName'];?>
</td>
				</tr>
			<?php } ?>
		</table>
	<?php }else{ ?>
		<center><?php echo lang("no_guilds_found","armory");?>
</center>
	<?php }?>
</div>

<div id="search_tab_3" class="search_tab" style="display:<?php echo $_smarty_tpl->tpl_vars['show']->value['items'];?>
;">
	<?php if (count($_smarty_tpl->tpl_vars['items']->value)>0){?>
		<table class="nice_table" cellspacing="0">
			<tr>
				<td width="30%"><?php echo lang("name","armory");?>
</td>
				<td align="center" width="15%"><?php echo lang("level","armory");?>
</td>
				<td align="center" width="15%"><?php echo lang("required","armory");?>
</td>
				<td width="20%"><?php echo lang("type","armory");?>
</td>
				<td width="20%"><?php echo lang("realm","armory");?>
</td>
			</tr>

			<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['items']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
				<tr class="search_result_realm_<?php echo $_smarty_tpl->tpl_vars['item']->value['realm'];?>
 search_result_item">
					<td style="font-size:12px; !important">
						<?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>

						&nbsp;
						<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
item/<?php echo $_smarty_tpl->tpl_vars['item']->value['realm'];?>
/<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
" class="q<?php echo $_smarty_tpl->tpl_vars['item']->value['quality'];?>
" data-realm="<?php echo $_smarty_tpl->tpl_vars['item']->value['realm'];?>
" rel="item=<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
">
							<?php if (strlen($_smarty_tpl->tpl_vars['item']->value['name'])<22){?>
								<?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>

							<?php }else{ ?>
								<?php echo substr($_smarty_tpl->tpl_vars['item']->value['name'],0,20);?>
...
							<?php }?>
						</a>
					</td>
					<td align="center" style="font-size:12px; !important"><?php echo $_smarty_tpl->tpl_vars['item']->value['level'];?>
</td>
					<td align="center" style="font-size:12px; !important"><?php echo $_smarty_tpl->tpl_vars['item']->value['required'];?>
</td>
					<td style="font-size:12px; !important"><?php echo $_smarty_tpl->tpl_vars['item']->value['type'];?>
</td>
					<td style="font-size:12px; !important"><?php echo $_smarty_tpl->tpl_vars['item']->value['realmName'];?>
</td>
				</tr>
			<?php } ?>
		</table>
	<?php }else{ ?>
		<center><?php echo lang("no_items_found","armory");?>
</center>
	<?php }?>
</div><?php }} ?>