<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 13:46:00
         compiled from "application/themes/default/modules/news/articles.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6472116855150470812ce84-25673365%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e25ff992158095b0bbb682bb661112c1782f0f56' => 
    array (
      0 => 'application/themes/default/modules/news/articles.tpl',
      1 => 1362506373,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6472116855150470812ce84-25673365',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'articles' => 0,
    'url' => 0,
    'article' => 0,
    'tag' => 0,
    'pagination' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51504708216909_96462786',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51504708216909_96462786')) {function content_51504708216909_96462786($_smarty_tpl) {?><?php  $_smarty_tpl->tpl_vars['article'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['article']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['articles']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['article']->key => $_smarty_tpl->tpl_vars['article']->value){
$_smarty_tpl->tpl_vars['article']->_loop = true;
?>
	<article>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
news/view/<?php echo $_smarty_tpl->tpl_vars['article']->value['id'];?>
" class="top"><?php echo langColumn($_smarty_tpl->tpl_vars['article']->value['headline']);?>
</a>
		<section class="body">
			<?php if ($_smarty_tpl->tpl_vars['article']->value['avatar']){?>
				<div class="avatar">
					<img src="<?php echo $_smarty_tpl->tpl_vars['article']->value['avatar'];?>
" alt="avatar" height="120" width="120">
				</div>
			<?php }?>
			
			<?php echo langColumn($_smarty_tpl->tpl_vars['article']->value['content']);?>

			
			<div class="clear"></div>
			
			<div class="news_bottom">

				<?php if ($_smarty_tpl->tpl_vars['article']->value['comments']!=-1){?>
					<a <?php echo $_smarty_tpl->tpl_vars['article']->value['link'];?>
 class="comments_button" <?php echo $_smarty_tpl->tpl_vars['article']->value['comments_button_id'];?>
>
						<?php echo lang("comments","news");?>
 (<?php echo $_smarty_tpl->tpl_vars['article']->value['comments'];?>
)
					</a>
				<?php }?>

				<?php echo lang("posted_by","news");?>
 <a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
profile/<?php echo $_smarty_tpl->tpl_vars['article']->value['author_id'];?>
" data-tip="<?php echo lang("view_profile","news");?>
"><?php echo $_smarty_tpl->tpl_vars['article']->value['author'];?>
</a> <?php echo lang("on","news");?>
 <?php echo $_smarty_tpl->tpl_vars['article']->value['date'];?>


				<?php if ($_smarty_tpl->tpl_vars['article']->value['tags']){?>
					<?php  $_smarty_tpl->tpl_vars['tag'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['tag']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['article']->value['tags']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['tag']->key => $_smarty_tpl->tpl_vars['tag']->value){
$_smarty_tpl->tpl_vars['tag']->_loop = true;
?>
						<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
/news/<?php echo $_smarty_tpl->tpl_vars['tag']->value['name'];?>
"><?php echo $_smarty_tpl->tpl_vars['tag']->value['name'];?>
</a>
					<?php } ?>
				<?php }?>
			</div>

			<div class="comments" <?php echo $_smarty_tpl->tpl_vars['article']->value['comments_id'];?>
></div>
		</section>
	</article>

<?php } ?>
<?php echo $_smarty_tpl->tpl_vars['pagination']->value;?>
<?php }} ?>