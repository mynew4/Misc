<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 13:24:06
         compiled from "application\modules\vote\views\vote.tpl" */ ?>
<?php /*%%SmartyHeaderCode:71045284c0e6c2df89-31492517%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c14abf7d86790d12d8c2d9a52d9eb3202274ce41' => 
    array (
      0 => 'application\\modules\\vote\\views\\vote.tpl',
      1 => 1364484478,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '71045284c0e6c2df89-31492517',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'vote_sites' => 0,
    'vote_site' => 0,
    'formAttributes' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5284c0e6dc4389_00067972',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5284c0e6dc4389_00067972')) {function content_5284c0e6dc4389_00067972($_smarty_tpl) {?><table id="vote" class="nice_table" cellspacing="0" cellpadding="0">
	<tr>
		<td width="30%"><?php echo lang("topsite","vote");?>
</td>
		<td width="30%"><?php echo lang("value","vote");?>
</td>
		<td width="40%">&nbsp;</td>
	</tr>

	<?php if ($_smarty_tpl->tpl_vars['vote_sites']->value){?>
	<?php  $_smarty_tpl->tpl_vars['vote_site'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['vote_site']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['vote_sites']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['vote_site']->key => $_smarty_tpl->tpl_vars['vote_site']->value){
$_smarty_tpl->tpl_vars['vote_site']->_loop = true;
?>
		<tr>
			<td><?php if ($_smarty_tpl->tpl_vars['vote_site']->value['vote_image']){?><img src="<?php echo $_smarty_tpl->tpl_vars['vote_site']->value['vote_image'];?>
" /><?php }else{ ?><?php echo $_smarty_tpl->tpl_vars['vote_site']->value['vote_sitename'];?>
<?php }?></td>
			<td><?php echo $_smarty_tpl->tpl_vars['vote_site']->value['points_per_vote'];?>

				<?php if ($_smarty_tpl->tpl_vars['vote_site']->value['points_per_vote']>1){?>
					<?php echo lang("voting_points","vote");?>

				<?php }else{ ?>
					<?php echo lang("voting_point","vote");?>

				<?php }?>
			</td>
			<td id="vote_field_<?php echo $_smarty_tpl->tpl_vars['vote_site']->value['id'];?>
">
				<?php if ($_smarty_tpl->tpl_vars['vote_site']->value['canVote']){?>
					<?php echo form_open("vote/site/",$_smarty_tpl->tpl_vars['formAttributes']->value);?>

						<input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['vote_site']->value['id'];?>
" />
						<input type="submit" onClick="Vote.open(<?php echo $_smarty_tpl->tpl_vars['vote_site']->value['id'];?>
, <?php echo $_smarty_tpl->tpl_vars['vote_site']->value['hour_interval'];?>
);" value="<?php echo lang("vote_now","vote");?>
"/>
					</form>
				<?php }else{ ?>
					<?php echo $_smarty_tpl->tpl_vars['vote_site']->value['nextVote'];?>
 <?php echo lang("remaining","vote");?>

				<?php }?>
			</td>
		</tr>
	<?php } ?>
	<?php }?>
</table>

<div class="firefox" style="display:none;text-align:center;padding:10px;font-style:italic;">
	Please allow pop-up windows from this website to be able to vote.
</div><?php }} ?>