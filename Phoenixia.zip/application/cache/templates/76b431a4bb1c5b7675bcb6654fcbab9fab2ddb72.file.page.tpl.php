<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 13:46:01
         compiled from "application/themes/default/views/page.tpl" */ ?>
<?php /*%%SmartyHeaderCode:134620480851504709d00464-44744507%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '76b431a4bb1c5b7675bcb6654fcbab9fab2ddb72' => 
    array (
      0 => 'application/themes/default/views/page.tpl',
      1 => 1359559561,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '134620480851504709d00464-44744507',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'headline' => 0,
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51504709d1ebf6_63377854',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51504709d1ebf6_63377854')) {function content_51504709d1ebf6_63377854($_smarty_tpl) {?><article>
	<h1 class="top"><?php echo $_smarty_tpl->tpl_vars['headline']->value;?>
</h1>
	<section class="body">
		<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

	</section>
</article><?php }} ?>