<?php /* Smarty version Smarty-3.1.8, created on 2013-11-15 00:12:26
         compiled from "application\modules\admin\views\slider\edit_slider.tpl" */ ?>
<?php /*%%SmartyHeaderCode:18500528558da1d2362-30626565%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0532e4898f428ef543c0fac8a87af656f5686c50' => 
    array (
      0 => 'application\\modules\\admin\\views\\slider\\edit_slider.tpl',
      1 => 1360148836,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18500528558da1d2362-30626565',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'slide' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_528558da25aee5_35563396',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_528558da25aee5_35563396')) {function content_528558da25aee5_35563396($_smarty_tpl) {?><section class="box big">
	<h2>Edit slide</h2>

	<form onSubmit="Slider.save(this, <?php echo $_smarty_tpl->tpl_vars['slide']->value['id'];?>
); return false" id="submit_form">
		<label for="image">Image URL</label>
		<input type="text" name="image" id="image" placeholder="http://" value="<?php echo preg_replace('/{path}/','',$_smarty_tpl->tpl_vars['slide']->value['image']);?>
"/>

		<label for="link">Link (optional)</label>
		<input type="text" name="link" id="link" placeholder="http://"value="<?php echo $_smarty_tpl->tpl_vars['slide']->value['link'];?>
"/>

		<label for="text">Image text (optional)</label>
		<input type="text" name="text" id="text"value="<?php echo $_smarty_tpl->tpl_vars['slide']->value['text'];?>
"/>

		<input type="submit" value="Save slide" />
	</form>
</section><?php }} ?>