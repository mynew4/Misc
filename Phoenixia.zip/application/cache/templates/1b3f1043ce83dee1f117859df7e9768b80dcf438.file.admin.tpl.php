<?php /* Smarty version Smarty-3.1.8, created on 2013-03-26 11:19:28
         compiled from "application/modules/page/views/admin.tpl" */ ?>
<?php /*%%SmartyHeaderCode:31370315151517630648ae1-15474516%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1b3f1043ce83dee1f117859df7e9768b80dcf438' => 
    array (
      0 => 'application/modules/page/views/admin.tpl',
      1 => 1364231240,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '31370315151517630648ae1-15474516',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'pages' => 0,
    'page' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_515176307153e5_34800784',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_515176307153e5_34800784')) {function content_515176307153e5_34800784($_smarty_tpl) {?><?php echo TinyMCE();?>

<section class="box big" id="pages">
	<h2>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_text_document.png"/>
		Pages (<div style="display:inline;" id="page_count"><?php if (!$_smarty_tpl->tpl_vars['pages']->value){?>0<?php }else{ ?><?php echo count($_smarty_tpl->tpl_vars['pages']->value);?>
<?php }?></div>)
	</h2>

	<?php if (hasPermission("canAdd")){?>
		<span>
			<a class="nice_button" href="javascript:void(0)" onClick="Pages.show()">Create page</a>
		</span>
	<?php }?>

	<ul id="pages_list">
		<?php if ($_smarty_tpl->tpl_vars['pages']->value){?>
		<?php  $_smarty_tpl->tpl_vars['page'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['page']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['pages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['page']->key => $_smarty_tpl->tpl_vars['page']->value){
$_smarty_tpl->tpl_vars['page']->_loop = true;
?>
			<li>
				<table width="100%">
					<tr>
						<td width="25%"><a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
page/<?php echo $_smarty_tpl->tpl_vars['page']->value['identifier'];?>
/" target="_blank">/page/<?php echo $_smarty_tpl->tpl_vars['page']->value['identifier'];?>
/</a></td>
						<td width="60%"><b><?php echo $_smarty_tpl->tpl_vars['page']->value['name'];?>
</b></td>
						<td style="text-align:right;">
							<?php if (hasPermission("canEdit")){?>
							<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
page/admin/edit/<?php echo $_smarty_tpl->tpl_vars['page']->value['id'];?>
" data-tip="Edit"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_edit.png" /></a>&nbsp;
							<?php }?>

							<?php if (hasPermission("canRemove")){?>
								<a href="javascript:void(0)" onClick="Pages.remove(<?php echo $_smarty_tpl->tpl_vars['page']->value['id'];?>
, this)" data-tip="Delete"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_minus.png" /></a>
							<?php }?>
						</td>
					</tr>
				</table>
			</li>
		<?php } ?>
		<?php }?>
	</ul>
</section>

<div id="add_pages" style="display:none;">
	<section class="box big">
		<h2><a href='javascript:void(0)' onClick="Pages.show()" data-tip="Return to pages">Pages</a> &rarr; New page</h2>

		<form onSubmit="Pages.send(); return false">
			<label for="headline">Headline</label>
			<input type="text" id="headline" />
			
			<label for="identifier">Unique link identifier (as in mywebsite.com/page/<b>mypage</b>)</label>
			<input type="text" id="identifier" placeholder="mypage" />

			<label for="visibility">Visibility mode</label>
			<select name="visibility" id="visibility" onChange="if(this.value == 'group'){ $('#groups').fadeIn(300); } else { $('#groups').fadeOut(300); }">
				<option value="everyone" selected>Visible to everyone</option>
				<option value="group">Controlled per group</option>
			</select>

			<div id="groups" style="display:none;">
				Please manage the group visibility via <a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/aclmanager/groups">the group manager</a> once you have created the page
			</div>

			<label for="pages_content">
				Content
			</label>
		</form>
			<div style="padding:10px;">
				<textarea name="pages_content" class="tinymce" id="pages_content" cols="30" rows="10"></textarea>
			</div>
		<form onSubmit="Pages.send(); return false">
			<input type="submit" value="Submit page" />
		</form>
	</section>
</div>

<script>
	require([Config.URL + "application/themes/admin/js/mli.js"], function()
	{
		new MultiLanguageInput($("#headline"));
	});
</script><?php }} ?>