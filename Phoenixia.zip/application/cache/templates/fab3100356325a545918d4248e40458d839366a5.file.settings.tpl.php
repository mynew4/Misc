<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 12:57:38
         compiled from "application\modules\admin\views\settings.tpl" */ ?>
<?php /*%%SmartyHeaderCode:134315284bab2b43980-43460213%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fab3100356325a545918d4248e40458d839366a5' => 
    array (
      0 => 'application\\modules\\admin\\views\\settings.tpl',
      1 => 1363432630,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '134315284bab2b43980-43460213',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'realms' => 0,
    'realm' => 0,
    'emulators' => 0,
    'emu_id' => 0,
    'emu_name' => 0,
    'config' => 0,
    'smtp' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5284bab2d81d04_94909028',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5284bab2d81d04_94909028')) {function content_5284bab2d81d04_94909028($_smarty_tpl) {?><section class="box big" id="realm_settings">
	<h2><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_cloud.png"/> Realms (<div style="display:inline;" id="realm_count"><?php echo count($_smarty_tpl->tpl_vars['realms']->value);?>
</div>)</h2>
	<span>
		<div style="float:right;" data-tip="The logon emulator is the emulator of the first realm"><b>Logon/realmd/auth emulator:</b> <?php echo strtoupper($_smarty_tpl->tpl_vars['realms']->value[0]->getConfig("emulator"));?>
</div>
		<a class="nice_button" href="javascript:void(0)" onClick="Settings.showAddRealm()">Add a new realm</a>
	</span>
	<ul id="realm_list">
		<?php  $_smarty_tpl->tpl_vars['realm'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['realm']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['realms']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['realm']->key => $_smarty_tpl->tpl_vars['realm']->value){
$_smarty_tpl->tpl_vars['realm']->_loop = true;
?>
			<li>
				<table width="100%">
					<tr>
						<td width="10%">ID: <?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
</td>
						<td width="30%"><b><?php echo $_smarty_tpl->tpl_vars['realm']->value->getName();?>
</b></td>
						<td width="30%"><?php echo $_smarty_tpl->tpl_vars['realm']->value->getConfig("hostname");?>
</td>
						<td width="20%"><?php echo strtoupper($_smarty_tpl->tpl_vars['realm']->value->getConfig("emulator"));?>
</td>
						<td style="text-align:right;">
							<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/realmmanager/edit/<?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
" data-tip="Edit"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_edit.png" /></a>&nbsp;
							<a href="javascript:void(0)" onClick="Settings.remove(<?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
, this)" data-tip="Delete"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_minus.png" /></a>
						</td>
					</tr>
				</table>
			</li>
		<?php } ?>
	</ul>
</section>

<div id="add_realm" style="display:none;">
	<section class="box big">
		<h2><a href='javascript:void(0)' onClick="Settings.showAddRealm()" data-tip="Return to settings">Settings</a> &rarr; New realm</h2>

		<form onSubmit="Settings.addRealm(); return false">
			<label for="realmName">Realm name</label>
			<input type="text" id="realmName" />

			<label for="realmName">Hostname / IP (to your emulator server)</label>
			<input type="text" id="hostname" />

			<label>Server structure (mainly for the bigger private servers with clustered hosts)</label>
			<select id="server_structure" onChange="Settings.changeStructure(this)">
				<option value="1" selected>[All in one] I host emulator and both characters and world databases on the same server (default)</option>
				<option value="2">[Emulator and databases separated] I host the emulator on one server and the databases on another</option>
				<option value="3">[All separate] I host emulator, world and characters on three different servers</option>
			</select>

			<div id="one">
				<label for="username">Database username</label>
				<input type="text" id="username" />

				<label for="password">Database password</label>
				<input type="password" id="password" />
			</div>

			<div id="two" style="display:none;">
				<label for="override_hostname_char">Characters &amp; world: database hostname</label>
				<input type="text" id="override_hostname_char" />

				<label for="override_username_char">Characters &amp; world: database username</label>
				<input type="text" id="override_username_char" />

				<label for="override_password_char">Characters &amp; world: database password</label>
				<input type="password" id="override_password_char" />

				<label for="override_port_char">Characters &amp; world: database port</label>
				<input type="text" id="override_port_char" value="3306" />
			</div>

			<div id="three" style="display:none;">
				<label for="override_hostname_char_three">Characters: database hostname</label>
				<input type="text" id="override_hostname_char_three" />

				<label for="override_username_char_three">Characters: database username</label>
				<input type="text" id="override_username_char_three" />

				<label for="override_password_char_three">Characters: database password</label>
				<input type="password" id="override_password_char_three" />

				<label for="override_port_char_three">Characters: database port</label>
				<input type="text" id="override_port_char_three" value="3306" />

				<label for="override_hostname_world_three">World: database hostname</label>
				<input type="text" id="override_hostname_world_three" />

				<label for="override_username_world_three">World: database username</label>
				<input type="text" id="override_username_world_three" />

				<label for="override_password_world_three">World: database password</label>
				<input type="password" id="override_password_world_three" />

				<label for="override_port_world_three">World: database port</label>
				<input type="text" id="override_port_world_three" value="3306" />
			</div>

			<label for="characters">Characters database</label>
			<input type="text" id="characters"/>

			<label for="world">World database</label>
			<input type="text" id="world" />

			<label for="cap">Max allowed players online</label>
			<input type="text" id="cap" />

			<label for="port">Realm port (usually 8129)</label>
			<input type="text" id="port" />


			<label for="emulator">Emulator</label>
			<select id="emulator">
				<?php  $_smarty_tpl->tpl_vars['emu_name'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['emu_name']->_loop = false;
 $_smarty_tpl->tpl_vars['emu_id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['emulators']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['emu_name']->key => $_smarty_tpl->tpl_vars['emu_name']->value){
$_smarty_tpl->tpl_vars['emu_name']->_loop = true;
 $_smarty_tpl->tpl_vars['emu_id']->value = $_smarty_tpl->tpl_vars['emu_name']->key;
?>
					<option value="<?php echo $_smarty_tpl->tpl_vars['emu_id']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['emu_name']->value;?>
</option>
				<?php } ?>
			</select>

			<label for="console_port">Console port (only required for emulators that use RA or SOAP; usually 3443 for RA and 7878 for SOAP)</label>
			<input type="text" id="console_port" />

			<label for="console_username" data-tip="For an ingame account with GM level high enough to connect to your<br />emulator console remotely (see your emulator's config files for more details)">Console username (only required for emulators that use remote console systems) (?)</label>
			<input type="text" id="console_username" />

			<label for="console_password" data-tip="For an ingame account with GM level high enough to connect to your<br />emulator console remotely (see your emulator's config files for more details)">Console password (only required for emulators that use remote console systems) (?)</label>
			<input type="password" id="console_password" />

			<input type="submit" value="Add realm" />
		</form>
	</section>
</div>

<div id="non_realm">
	<section class="box big">
		<h2><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_settings.png"/> Website</h2>
		
		<form onSubmit="Settings.saveWebsiteSettings(); return false">
			<label for="title">Website title</label>
			<input type="text" id="title" placeholder="MyServer" value="<?php echo $_smarty_tpl->tpl_vars['config']->value['title'];?>
" />

			<label for="server_name">Server name</label>
			<input type="text" id="server_name" placeholder="MyServer" value="<?php echo $_smarty_tpl->tpl_vars['config']->value['server_name'];?>
" />

			<label for="realmlist">Realmlist</label>
			<input type="text" id="realmlist" placeholder="logon.myserver.com" value="<?php echo $_smarty_tpl->tpl_vars['config']->value['realmlist'];?>
" />

			<label for="disabled_expansions">Max expansion</label>
			<select id="disabled_expansions">
				<option value="cata" <?php if (count($_smarty_tpl->tpl_vars['config']->value['disabled_expansions'])==0){?>selected<?php }?>>Cataclysm</option>
				<option value="wotlk" <?php if (count($_smarty_tpl->tpl_vars['config']->value['disabled_expansions'])==1){?>selected<?php }?>>Wrath of the Lich King</option>
				<option value="tbc" <?php if (count($_smarty_tpl->tpl_vars['config']->value['disabled_expansions'])==2){?>selected<?php }?>>The Burning Crusade</option>
				<option value="none" <?php if (count($_smarty_tpl->tpl_vars['config']->value['disabled_expansions'])==3){?>selected<?php }?>>No expansion allowed</option>
			</select>

			<label for="keywords">Search engine: keywords (separated by comma)</label>
			<input type="text" id="keywords" placeholder="world of warcraft,wow,private server,pvp" value="<?php echo $_smarty_tpl->tpl_vars['config']->value['keywords'];?>
" />

			<label for="description">Search engine: description</label>
			<input type="text" id="description" placeholder="Best World of Warcraft private server in the entire world!" value="<?php echo $_smarty_tpl->tpl_vars['config']->value['description'];?>
" />

			<label for="analytics"><a href="http://analytics.google.com" target="_blank">Google Analytics</a> website ID for advanced statistics (optional)</label>
			<input type="text" id="analytics" placeholder="XX-YYYYYYYY-Z" value="<?php echo $_smarty_tpl->tpl_vars['config']->value['analytics'];?>
"/>

			<label for="vote_reminder">Enable vote reminder popup</label>
			<select id="vote_reminder" onChange="Settings.toggleVoteReminder(this)">
				<option value="1" <?php if ($_smarty_tpl->tpl_vars['config']->value['vote_reminder']){?>selected<?php }?>>Yes</option>
				<option value="0" <?php if (!$_smarty_tpl->tpl_vars['config']->value['vote_reminder']){?>selected<?php }?>>No</option>
			</select>

			<div id="vote_reminder_settings" <?php if (!$_smarty_tpl->tpl_vars['config']->value['vote_reminder']){?>style="display:none;"<?php }?>>
				<label for="vote_reminder_image">Vote reminder image URL</label>
				<input type="text" id="vote_reminder_image" placeholder="http://mywebsite.com/images/banner.gif" value="<?php echo $_smarty_tpl->tpl_vars['config']->value['vote_reminder_image'];?>
"/>

				<label for="reminder_interval">Vote reminder interval (in hours)</label>
				<input type="text" id="reminder_interval" value="<?php echo $_smarty_tpl->tpl_vars['config']->value['reminder_interval']/60/24;?>
" placeholder="12" />
			</div>

			<label for="cdn">Use content delivery network for Javascript libraries (do only disable it for LAN-only environments)</label>
			<select id="cdn">
				<option value="1" <?php if ($_smarty_tpl->tpl_vars['config']->value['cdn']){?>selected<?php }?>>Yes</option>
				<option value="0" <?php if (!$_smarty_tpl->tpl_vars['config']->value['cdn']){?>selected<?php }?>>No</option>
			</select>

			<label for="has_smtp">Enable password recovery (requires SMTP server)</label>
			<select id="has_smtp">
				<option value="1" <?php if ($_smarty_tpl->tpl_vars['config']->value['has_smtp']){?>selected<?php }?>>Yes</option>
				<option value="0" <?php if (!$_smarty_tpl->tpl_vars['config']->value['has_smtp']){?>selected<?php }?>>No</option>
			</select>


			<input type="submit" value="Save settings" />

			<center id="website_ajax"></center>
		</form>
	</section>

	<section class="box big">
		<h2><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_settings.png"/> SMTP mail settings</h2>
		
		<form onSubmit="Settings.saveSmtpSettings(); return false">
			<label for="use_own_smtp_settings">Use own SMTP settings (enter them below)</label>
			<select id="use_own_smtp_settings">
				<option value="1" <?php if ($_smarty_tpl->tpl_vars['smtp']->value['use_own_smtp_settings']){?>selected<?php }?>>Yes</option>
				<option value="0" <?php if (!$_smarty_tpl->tpl_vars['smtp']->value['use_own_smtp_settings']){?>selected<?php }?>>No</option>
			</select>

			<label for="smtp_host">SMTP hostname</label>
			<input type="text" id="smtp_host" value="<?php echo $_smarty_tpl->tpl_vars['smtp']->value['smtp_host'];?>
" />

			<label for="smtp_user">SMTP username</label>
			<input type="text" id="smtp_user" value="<?php echo $_smarty_tpl->tpl_vars['smtp']->value['smtp_user'];?>
" />

			<label for="smtp_pass">SMTP password</label>
			<input type="text" id="smtp_pass" value="<?php echo $_smarty_tpl->tpl_vars['smtp']->value['smtp_pass'];?>
" />

			<label for="smtp_port">SMTP port</label>
			<input type="text" id="smtp_port" value="<?php echo $_smarty_tpl->tpl_vars['smtp']->value['smtp_port'];?>
" />

			<input type="submit" value="Save settings" />

			<center id="smtp_ajax"></center>
		</form>
	</section>

	<section class="box big">
		<h2><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_power.png"/> Performance settings</h2>
		
		<form onSubmit="Settings.savePerformanceSettings(); return false">

			<label for="disable_visitor_graph" data-tip="If you have many visitors, the admin panel will become very slow because of the statistics graph - disabling it will help a lot">Disable dashboard visitor graph <a>(?)</a></label>
			<select name="disable_visitor_graph" id="disable_visitor_graph">
				<option value="1" <?php if ($_smarty_tpl->tpl_vars['config']->value['disable_visitor_graph']){?>selected<?php }?>>Yes</option>
				<option value="0" <?php if (!$_smarty_tpl->tpl_vars['config']->value['disable_visitor_graph']){?>selected<?php }?>>No</option>
			</select>

			<input type="submit" value="Save settings" />

			<center id="performance_ajax"></center>
		</form>
	</section>
</div><?php }} ?>