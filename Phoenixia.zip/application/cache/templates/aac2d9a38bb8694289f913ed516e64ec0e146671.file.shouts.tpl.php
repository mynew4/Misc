<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 10:46:05
         compiled from "application\modules\sidebox_shoutbox\views\shouts.tpl" */ ?>
<?php /*%%SmartyHeaderCode:851452849bdd465c80-16178925%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aac2d9a38bb8694289f913ed516e64ec0e146671' => 
    array (
      0 => 'application\\modules\\sidebox_shoutbox\\views\\shouts.tpl',
      1 => 1359924408,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '851452849bdd465c80-16178925',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'shouts' => 0,
    'shout' => 0,
    'user_is_gm' => 0,
    'url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_52849bdd4e6b03_43730904',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52849bdd4e6b03_43730904')) {function content_52849bdd4e6b03_43730904($_smarty_tpl) {?><?php if ($_smarty_tpl->tpl_vars['shouts']->value){?>
	<?php  $_smarty_tpl->tpl_vars['shout'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['shout']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['shouts']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['shout']->key => $_smarty_tpl->tpl_vars['shout']->value){
$_smarty_tpl->tpl_vars['shout']->_loop = true;
?>
		<div class="shout">
			<span class="shout_date"><?php echo $_smarty_tpl->tpl_vars['shout']->value['date'];?>
 <?php echo lang("ago","sidebox_shoutbox");?>
 <?php if ($_smarty_tpl->tpl_vars['user_is_gm']->value){?><a href="javascript:void(0)" onClick="Shoutbox.remove(this, <?php echo $_smarty_tpl->tpl_vars['shout']->value['id'];?>
)"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/delete.png" align="absmiddle"/></a><?php }?></span>
			<div class="shout_author <?php if ($_smarty_tpl->tpl_vars['shout']->value['is_gm']){?>shout_staff<?php }?>"><a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
profile/<?php echo $_smarty_tpl->tpl_vars['shout']->value['author'];?>
" data-tip="<?php echo lang("view_profile","sidebox_shoutbox");?>
"><?php if ($_smarty_tpl->tpl_vars['shout']->value['is_gm']){?><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/icon_blizzard.gif" align="absmiddle"/>&nbsp;<?php }?> <?php echo $_smarty_tpl->tpl_vars['shout']->value['nickname'];?>
</a> <?php echo lang("said","sidebox_shoutbox");?>
:</div>
			<?php echo word_wrap($_smarty_tpl->tpl_vars['shout']->value['content'],35);?>

		</div>
	<?php } ?>
<?php }?><?php }} ?>