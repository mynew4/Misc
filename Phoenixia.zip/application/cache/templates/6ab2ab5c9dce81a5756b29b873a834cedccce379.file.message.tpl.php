<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 16:03:48
         compiled from "application/modules/admin/views/message.tpl" */ ?>
<?php /*%%SmartyHeaderCode:76440989451506754174193-71308315%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6ab2ab5c9dce81a5756b29b873a834cedccce379' => 
    array (
      0 => 'application/modules/admin/views/message.tpl',
      1 => 1361720349,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '76440989451506754174193-71308315',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'message_enabled' => 0,
    'message_headline' => 0,
    'message_headline_size' => 0,
    'message_text' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51506754218ad8_83067489',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51506754218ad8_83067489')) {function content_51506754218ad8_83067489($_smarty_tpl) {?><?php if (hasPermission("toggleMessage")){?>
<section class="box big">
	<h2>Message</h2>
	<span>
		This will temporarily disable the entire site to display the message until you turn it off.<br /><br />To directly access the admin panel, please go to <a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/"><?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/</a>
	</span>

	<form onSubmit="Settings.submitMessage(this);return false">
		
		<label for="message_enabled">Global announcement message</label>
		<select id="message_enabled" name="message_enabled">
			<option value="true" <?php if ($_smarty_tpl->tpl_vars['message_enabled']->value){?>selected<?php }?>>Enabled</div>
			<option value="false" <?php if (!$_smarty_tpl->tpl_vars['message_enabled']->value){?>selected<?php }?>>Disabled</div>
		</select>

		<label for="message_headline">Headline</label>
		<input type="text" id="message_headline" name="message_headline" value="<?php echo $_smarty_tpl->tpl_vars['message_headline']->value;?>
" onKeyUp="Settings.liveUpdate(this, 'headline')"/>
		
		<label for="message_headline_size">Headline size (default: 56)</label>
		<input type="text" id="message_headline_size" name="message_headline_size" value="<?php echo $_smarty_tpl->tpl_vars['message_headline_size']->value;?>
" onKeyUp="Settings.liveUpdate(this, 'headline_size')"/>

		<label for="message_text">Message</label>
		<textarea id="message_text" name="message_text" rows="10" onKeyUp="Settings.liveUpdate(this, 'text')"><?php echo $_smarty_tpl->tpl_vars['message_text']->value;?>
</textarea>

		<input type="submit" value="Save config" />
	</form>
</section>
<?php }?>

<section class="box big">
	<h2>Preview</h2>
	<span>
		<span class="announcement">
		<h3 id="live_headline" style="font-size:<?php echo $_smarty_tpl->tpl_vars['message_headline_size']->value;?>
px;"><?php echo $_smarty_tpl->tpl_vars['message_headline']->value;?>
</h3>
		<p id="live_text"><?php echo $_smarty_tpl->tpl_vars['message_text']->value;?>
</p>
		</span>
	</span>
</section><?php }} ?>