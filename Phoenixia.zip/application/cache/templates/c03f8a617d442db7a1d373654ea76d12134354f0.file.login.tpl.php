<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 13:46:18
         compiled from "application/themes/admin/login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13698032425150471a877a47-47979169%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c03f8a617d442db7a1d373654ea76d12134354f0' => 
    array (
      0 => 'application/themes/admin/login.tpl',
      1 => 1363698680,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13698032425150471a877a47-47979169',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'cdn' => 0,
    'isOnline' => 0,
    'username' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5150471a93b663_08308068',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5150471a93b663_08308068')) {function content_5150471a93b663_08308068($_smarty_tpl) {?><!DOCTYPE html>
<html>
	<head>
		<title>Log in - FusionCMS</title>

		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/> 

		<link rel="shortcut icon" href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/favicon.png" />
		<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/css/login.css" type="text/css" />

		<script src="<?php if ($_smarty_tpl->tpl_vars['cdn']->value){?>//html5shiv.googlecode.com/svn/trunk/html5.js<?php }else{ ?><?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/js/html5shiv.js<?php }?>"></script>
		<script type="text/javascript" src="<?php if ($_smarty_tpl->tpl_vars['cdn']->value){?>https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js<?php }else{ ?><?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/js/jquery.min.js<?php }?>"></script>

		<script type="text/javascript">
			function getCookie(c_name)
			{
				var i, x, y, ARRcookies = document.cookie.split(";");

				for(i = 0; i < ARRcookies.length;i++)
				{
					x = ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
					y = ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
					x = x.replace(/^\s+|\s+$/g,"");
					
					if(x == c_name)
					{
						return unescape(y);
					}
				}
			}

			var Config = {
				URL: "<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
",
				CSRF: getCookie('csrf_cookie_name'),
			};
		</script>

		<script src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/js/require.js" type="text/javascript" ></script>
		<script type="text/javascript">

			var scripts = [
				"<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/js/jquery.placeholder.min.js",
				"<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/js/jquery.transit.min.js",
				"<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/js/login.js"
			];

			require(scripts, function()
			{
				$('input[placeholder], textarea[placeholder]').placeholder();
			});
		</script>
	</head>

	<body>
		<div id="wrap">
			<div id="fixer">
				<!-- Top bar -->
				<header>
					<div class="center_1020">
						<a href="#" class="logo"></a>

						<!-- Top menu -->
						<aside class="right">
							<nav>
								<a href="#" class="active">
									<div class="icon logout"></div>
									Log in
								</a>
							</nav>

							<div class="welcome">
								Welcome, <b><?php if ($_smarty_tpl->tpl_vars['isOnline']->value){?><?php echo ucfirst($_smarty_tpl->tpl_vars['username']->value);?>
<?php }else{ ?>stranger<?php }?></b>
							</div>
						</aside>
					</div>
				</header>

				<div id="content">
					<h1>Administration</h1>

					<form onSubmit="Login.send(this); return false">
						<input type="text" placeholder="Username" <?php if ($_smarty_tpl->tpl_vars['isOnline']->value){?>disabled value="<?php echo $_smarty_tpl->tpl_vars['username']->value;?>
"<?php }?> id="username"/>
						<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/user.png" /><input type="password" placeholder="Password" <?php if ($_smarty_tpl->tpl_vars['isOnline']->value){?>disabled value="Password"<?php }?> id="password"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/lock.png" /><input type="password" placeholder="Security code" id="security_code" />
						<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/star.png" />
						<input type="submit" value="Log in" />
					</form>
				</div>
			</div>
		</div>

		<!-- Footer -->
		<footer>
			<div class="center_1020">
				<div class="divider2"></div>
				<aside id="logo"><a href="#" class="logo"></a></aside>
				<div class="divider"></div>
				<aside id="links">
					<a href="http://fusion.raxezdev.com/" target="_blank">FusionHub</a>
					<a href="http://fusion.raxezdev.com/modules" target="_blank">Modules</a>
					<a href="http://fusion.raxezdev.com/themes" target="_blank">Themes</a>
					<a href="http://fusion.raxezdev.com/support" target="_blank">Support</a>
				</aside>
				<div class="divider"></div>
				<aside id="twitter">
					<h1>Follow us on Twitter!</h1>
					<div id="twitter_icon"></div>
					<a href="http://twitter.com/FusionHub" target="_blank">@FusionHub</a>
				</aside>
				<div class="divider"></div>
				<aside id="html5">
					<a href="http://www.w3.org/html/logo/" data-tip="This website makes use of the next generation of web technologies">
						<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/html5.png">
					</a>
				</aside>
				<div class="divider"></div>
				<div class="clear"></div>
			</div>
		</footer>
	</body>
</html><?php }} ?>