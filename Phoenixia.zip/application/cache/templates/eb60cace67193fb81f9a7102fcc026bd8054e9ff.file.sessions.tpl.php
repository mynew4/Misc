<?php /* Smarty version Smarty-3.1.8, created on 2013-03-26 11:17:53
         compiled from "application/modules/admin/views/sessions/sessions.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1755539718515175d1b27fe8-84190110%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'eb60cace67193fb81f9a7102fcc026bd8054e9ff' => 
    array (
      0 => 'application/modules/admin/views/sessions/sessions.tpl',
      1 => 1359559561,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1755539718515175d1b27fe8-84190110',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'sessions' => 0,
    'visitor' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_515175d1c44b85_46066762',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_515175d1c44b85_46066762')) {function content_515175d1c44b85_46066762($_smarty_tpl) {?><section class="box big" id="donate_articles">
	<h2>
		<img src="<?php echo @pageURL;?>
application/themes/admin/images/icons/black16x16/ic_users.png"/>
		Visitors in the past 5 minutes (<?php echo count($_smarty_tpl->tpl_vars['sessions']->value);?>
)
	</h2>

	<ul>
		<?php if ($_smarty_tpl->tpl_vars['sessions']->value){?>
			<?php  $_smarty_tpl->tpl_vars['visitor'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['visitor']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['sessions']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['visitor']->key => $_smarty_tpl->tpl_vars['visitor']->value){
$_smarty_tpl->tpl_vars['visitor']->_loop = true;
?>
				<li>
					<table width="100%">
						<tr>
							<td width="15%">
								<?php echo date("H:i:s",$_smarty_tpl->tpl_vars['visitor']->value['last_activity']);?>

							</td>

							<td width="20%">
								<?php if (isset($_smarty_tpl->tpl_vars['visitor']->value['nickname'])){?>
									<a href="<?php echo @pageURL;?>
profile/<?php echo $_smarty_tpl->tpl_vars['visitor']->value['user_id'];?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['visitor']->value['nickname'];?>
</a>
								<?php }else{ ?>
									Guest
								<?php }?>
							</td>

							<td>
								<?php echo $_smarty_tpl->tpl_vars['visitor']->value['ip_address'];?>

							</td>

							<td width="20%">
								<img src="<?php echo @pageURL;?>
application/images/browsers/<?php echo $_smarty_tpl->tpl_vars['visitor']->value['browser'];?>
.png" style="opacity:1;position:absolute;margin-top:2px;"/>
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo ucfirst($_smarty_tpl->tpl_vars['visitor']->value['browser']);?>

							</td>

							<td width="20%">
								<img src="<?php echo @pageURL;?>
application/images/platforms/<?php echo $_smarty_tpl->tpl_vars['visitor']->value['os'];?>
.png" style="opacity:1;position:absolute;margin-top:2px;"/>
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo ucfirst($_smarty_tpl->tpl_vars['visitor']->value['os']);?>

							</td>
						</tr>
					</table>
				</li>
			<?php } ?>
		<?php }?>
	</ul>
</section><?php }} ?>