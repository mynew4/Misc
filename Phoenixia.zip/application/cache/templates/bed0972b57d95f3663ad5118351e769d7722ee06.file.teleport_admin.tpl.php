<?php /* Smarty version Smarty-3.1.8, created on 2013-03-26 11:18:56
         compiled from "application/modules/teleport/views/teleport_admin.tpl" */ ?>
<?php /*%%SmartyHeaderCode:814489442515176102f8530-64850612%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bed0972b57d95f3663ad5118351e769d7722ee06' => 
    array (
      0 => 'application/modules/teleport/views/teleport_admin.tpl',
      1 => 1363630901,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '814489442515176102f8530-64850612',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'teleport_locations' => 0,
    'teleport_location' => 0,
    'realms' => 0,
    'realm' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51517610403e43_10028607',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51517610403e43_10028607')) {function content_51517610403e43_10028607($_smarty_tpl) {?><section class="box big" id="main_teleport">
	<h2>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_picture.png"/>
		Teleport locations (<div style="display:inline;" id="teleport_count"><?php if (!$_smarty_tpl->tpl_vars['teleport_locations']->value){?>0<?php }else{ ?><?php echo count($_smarty_tpl->tpl_vars['teleport_locations']->value);?>
<?php }?></div>)
	</h2>

	<?php if (hasPermission("canAdd")){?>
		<span>
			<a class="nice_button" href="javascript:void(0)" onClick="Teleport.add()">Create teleport location</a>
		</span>
	<?php }?>

	<ul id="teleport_locationr_list">
		<?php if ($_smarty_tpl->tpl_vars['teleport_locations']->value){?>
			<?php  $_smarty_tpl->tpl_vars['teleport_location'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['teleport_location']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['teleport_locations']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['teleport_location']->key => $_smarty_tpl->tpl_vars['teleport_location']->value){
$_smarty_tpl->tpl_vars['teleport_location']->_loop = true;
?>
				<li>
					<table width="100%">
						<tr>
							<td width="20%"><b><?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['name'];?>
</b></td>
							<td width="25%"><?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['description'];?>
</td>
							<td width="25%"><?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['realmName'];?>
</td>
							<td width="15%">
								<?php if ($_smarty_tpl->tpl_vars['teleport_location']->value['vpCost']){?>
									<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/lightning.png" style="opacity:1;margin-top:3px;position:absolute;" /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['vpCost'];?>
 VP
								<?php }elseif($_smarty_tpl->tpl_vars['teleport_location']->value['dpCost']){?>
									<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/coins.png" style="opacity:1;margin-top:3px;position:absolute;"/> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
									<?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['dpCost'];?>
 DP
								<?php }elseif($_smarty_tpl->tpl_vars['teleport_location']->value['goldCost']){?>
								<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/coins.png" style="opacity:1;margin-top:3px;position:absolute;"/> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
									<?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['goldCost'];?>
 Gold
								<?php }else{ ?>
									Free
								<?php }?>
							</td>
							<td style="text-align:right;">
								<?php if (hasPermission("canEdit")){?>
								<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
teleport/admin/edit/<?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['id'];?>
" data-tip="Edit"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_edit.png" /></a>&nbsp;
								<?php }?>

								<?php if (hasPermission("canRemove")){?>
									<a href="javascript:void(0)" onClick="Teleport.remove(<?php echo $_smarty_tpl->tpl_vars['teleport_location']->value['id'];?>
, this)" data-tip="Delete"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_minus.png" /></a>
								<?php }?>
							</td>
						</tr>
					</table>
				</li>
			<?php } ?>
		<?php }?>
	</ul>
</section>

<section class="box big" id="add_teleport" style="display:none;">
	<h2><a href='javascript:void(0)' onClick="Teleport.add()" data-tip="Return to teleport locations">Teleport locations</a> &rarr; New teleport location</h2>

	<form onSubmit="Teleport.create(this); return false" id="submit_form">

		<label for="name">Location name</label>
		<input type="text" name="name" id="name"/>

		<label for="description">Description</label>
		<input type="text" name="description" id="description"/>

		<label for="realm">Realm</label>
		<select id="realm" name="realm">
			<?php  $_smarty_tpl->tpl_vars['realm'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['realm']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['realms']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['realm']->key => $_smarty_tpl->tpl_vars['realm']->value){
$_smarty_tpl->tpl_vars['realm']->_loop = true;
?>
				<option value="<?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
"><?php echo $_smarty_tpl->tpl_vars['realm']->value->getName();?>
</option>
			<?php } ?>
		</select>

		<label for="priceType">Price type</label>
		<select id="priceType" name="priceType" onChange="Teleport.changePrice(this)">
			<option value="free">Free</option>
			<option value="vp">VP</option>
			<option value="dp">DP</option>
			<option value="gold">Gold</option>
		</select>

		<div id="vp_price" style="display:none;">
			<label for="vpCost">VP price</label>
			<input type="text" name="vpCost" id="vpCost" value="0"/>
		</div>

		<div id="dp_price" style="display:none;">
			<label for="dpCost">DP price</label>
			<input type="text" name="dpCost" id="dpCost" value="0"/>
		</div>

		<div id="gold_price" style="display:none;">
			<label for="goldCost">Gold price</label>
			<input type="text" name="goldCost" id="goldCost" value="0"/>
		</div>
		
		<label for="x">X coordinate</label>
		<input type="text" name="x" id="x"/>
		
		<label for="y">Y coordinate</label>
		<input type="text" name="y" id="y"/>
		
		<label for="z">Z coordinate</label>
		<input type="text" name="z" id="z"/>
		
		<label for="orientation">Orientation</label>
		<input type="text" name="orientation" id="orientation"/>
		
		<label for="mapId">Map ID</label>
		<input type="text" name="mapId" id="mapId"/>

		<label for="required_faction">Required faction</label>
		<select id="required_faction" name="required_faction">
			<option value="0">Any</option>
			<option value="1">Alliance</option>
			<option value="2">Horde</option>
		</select>

		<input type="submit" value="Submit location" />
	</form>
</section><?php }} ?>