<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 13:46:40
         compiled from "application/themes/admin/box.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1677769820515047309b83b0-87231015%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6b9306af5f6afaae506c8a4993ab97e999ff3216' => 
    array (
      0 => 'application/themes/admin/box.tpl',
      1 => 1359559561,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1677769820515047309b83b0-87231015',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'headline' => 0,
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_515047309c2537_19669725',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_515047309c2537_19669725')) {function content_515047309c2537_19669725($_smarty_tpl) {?><h1 id="page_title"><?php echo $_smarty_tpl->tpl_vars['headline']->value;?>
</h1>
<section id="content">
	<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

</section><?php }} ?>