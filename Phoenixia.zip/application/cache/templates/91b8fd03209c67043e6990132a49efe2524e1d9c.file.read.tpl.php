<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 23:15:21
         compiled from "application\modules\messages\views\read.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1098152854b79c13365-85631612%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '91b8fd03209c67043e6990132a49efe2524e1d9c' => 
    array (
      0 => 'application\\modules\\messages\\views\\read.tpl',
      1 => 1362164276,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1098152854b79c13365-85631612',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'messages' => 0,
    'message' => 0,
    'me' => 0,
    'url' => 0,
    'myAvatar' => 0,
    'editor' => 0,
    'him' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_52854b79d43e65_53115679',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52854b79d43e65_53115679')) {function content_52854b79d43e65_53115679($_smarty_tpl) {?><?php if (!$_smarty_tpl->tpl_vars['messages']->value){?>
	<center style="margin:10px;font-weight:bold;">Message not found</center>
<?php }else{ ?>
	<div id="pm_read">
		<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['messages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value){
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<div class="message_box" style="float:<?php if ($_smarty_tpl->tpl_vars['message']->value['sender_id']==$_smarty_tpl->tpl_vars['me']->value){?>right<?php }else{ ?>left<?php }?>">
				<div class="message_box_date" style="float:<?php if ($_smarty_tpl->tpl_vars['message']->value['sender_id']==$_smarty_tpl->tpl_vars['me']->value){?>left<?php }else{ ?>right<?php }?>"><?php echo date("Y/m/d",$_smarty_tpl->tpl_vars['message']->value['time']);?>
</div>
				<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
profile/<?php echo $_smarty_tpl->tpl_vars['message']->value['sender_id'];?>
" data-tip="View profile" style="float:<?php if ($_smarty_tpl->tpl_vars['message']->value['sender_id']==$_smarty_tpl->tpl_vars['me']->value){?>right<?php }else{ ?>left<?php }?>"><img src="<?php echo $_smarty_tpl->tpl_vars['message']->value['avatar'];?>
" height="44" width="44" style="<?php if ($_smarty_tpl->tpl_vars['message']->value['sender_id']==$_smarty_tpl->tpl_vars['me']->value){?>margin-right:0px;<?php }?>"/></a>
				<a class="message_box_author" href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
profile/<?php echo $_smarty_tpl->tpl_vars['message']->value['sender_id'];?>
" data-tip="View profile" style="text-align:<?php if ($_smarty_tpl->tpl_vars['message']->value['sender_id']==$_smarty_tpl->tpl_vars['me']->value){?>right<?php }else{ ?>left<?php }?>"><?php echo $_smarty_tpl->tpl_vars['message']->value['name'];?>
</a>
				<?php echo $_smarty_tpl->tpl_vars['message']->value['message'];?>

				<div class="clear"></div>
			</div>
			<div class="clear"></div>
		<?php } ?>
			<div id="pm_spot">
				<div id="pm_spot_ajax"></div>
				<div id="pm_spot_message" class="message_box" style="float:right;display:none;">
					<div class="message_box_date" id="pm_date" style="float:left"></div>
					<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
profile/<?php echo $_smarty_tpl->tpl_vars['me']->value;?>
" data-tip="View profile" style="float:right"><img src="<?php echo $_smarty_tpl->tpl_vars['myAvatar']->value;?>
" height="44" width="44" style="margin-right:0px;"/></a>
					<a class="message_box_author" href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
profile/<?php echo $_smarty_tpl->tpl_vars['me']->value;?>
" data-tip="<?php echo lang("view_profile","messages");?>
" style="text-align:right"><?php echo lang("you","messages");?>
</a>
					<span id="pm_message"></span>
					<div class="clear"></div>
				</div>
				<div class="clear"></div>
			</div>
			
		<?php if (hasPermission("reply")){?>
			<div id="pm_form">
				<?php echo $_smarty_tpl->tpl_vars['editor']->value;?>

				<div style="height:15px;"></div>
				<center>
					<form onSubmit="Read.reply(<?php echo $_smarty_tpl->tpl_vars['him']->value;?>
); return false">
						<a class="nice_button" href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
messages">&larr; <?php echo lang("inbox","messages");?>
</a>
						&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="submit" value="<?php echo lang("send","messages");?>
" />
					</form>
				</center>
			</div>
		<?php }?>
	</div>
<?php }?><?php }} ?>