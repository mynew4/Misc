<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 23:21:29
         compiled from "application\modules\item\views\ajax.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1425252854ce9c74de2-92895480%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e4f77d88bc981330eaaa4f9e1b3af56b88fa2263' => 
    array (
      0 => 'application\\modules\\item\\views\\ajax.tpl',
      1 => 1359559562,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1425252854ce9c74de2-92895480',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'realm' => 0,
    'id' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_52854ce9c847e3_62290414',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52854ce9c847e3_62290414')) {function content_52854ce9c847e3_62290414($_smarty_tpl) {?><script type="text/javascript">
	$(document).ready(function()
	{
		$(".item_bg").html(lang("loading", "item"));
		
		$.get(Config.URL + "tooltip/" + <?php echo $_smarty_tpl->tpl_vars['realm']->value;?>
 + "/" + <?php echo $_smarty_tpl->tpl_vars['id']->value;?>
, function(data)
	 	{
	 		$(".item_bg").html(data);
	 	});
	});
</script><?php }} ?>