<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 13:52:29
         compiled from "application/modules/ucp/views/ucp.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14499739185150488d2f3cd7-65792204%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ea0b78855bb4560c6072caebac005cc25608769e' => 
    array (
      0 => 'application/modules/ucp/views/ucp.tpl',
      1 => 1362161410,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14499739185150488d2f3cd7-65792204',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'avatar' => 0,
    'id' => 0,
    'username' => 0,
    'location' => 0,
    'expansion' => 0,
    'groups' => 0,
    'group' => 0,
    'vp' => 0,
    'dp' => 0,
    'status' => 0,
    'register_date' => 0,
    'config' => 0,
    'characters' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5150488d49db69_08901570',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5150488d49db69_08901570')) {function content_5150488d49db69_08901570($_smarty_tpl) {?><section id="ucp_top">
	<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
ucp/avatar" id="ucp_avatar">
		<div><?php echo lang("change_avatar","ucp");?>
</div>
		<img src="<?php echo $_smarty_tpl->tpl_vars['avatar']->value;?>
"/>
	</a>

	<section id="ucp_info">
		<aside>
			<table width="100%">
				<tr>
					<td width="10%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/user.png" /></td>
					<td width="40%"><?php echo lang("nickname","ucp");?>
</td>
					<td width="50%">
						<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
ucp/settings" data-tip="Change nickname" style="float:right;margin-right:10px;"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/pencil.png" align="absbottom" /></a>
						<a href="profile/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
" data-tip="View profile"><?php echo $_smarty_tpl->tpl_vars['username']->value;?>
</a>
					</td>
				</tr>
				<tr>
					<td width="10%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/world.png" /></td>
					<td width="40%"><?php echo lang("location","ucp");?>
</td>
					<td width="50%">
						<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
ucp/settings" data-tip="Change location" style="float:right;margin-right:10px;"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/pencil.png" align="absbottom" /></a>
						<?php echo $_smarty_tpl->tpl_vars['location']->value;?>

					</td>
				</tr>
				<tr>
					<td width="10%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/plugin.png" /></td>
					<td width="40%">Expansion</td>
					<td width="50%">
						<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
ucp/expansion" data-tip="Change expansion" style="float:right;margin-right:10px;"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/cog.png" align="absbottom" /></a>
						<?php echo $_smarty_tpl->tpl_vars['expansion']->value;?>

					</td>
				</tr>
				<tr>
					<td width="10%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/award_star_bronze_1.png" /></td>
					<td width="40%"><?php echo lang("account_rank","ucp");?>
</td>
					<td width="50%"><?php  $_smarty_tpl->tpl_vars['group'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['group']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['groups']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['group']->key => $_smarty_tpl->tpl_vars['group']->value){
$_smarty_tpl->tpl_vars['group']->_loop = true;
?> <span <?php if ($_smarty_tpl->tpl_vars['group']->value['color']){?>style="color:<?php echo $_smarty_tpl->tpl_vars['group']->value['color'];?>
"<?php }?>><?php echo $_smarty_tpl->tpl_vars['group']->value['name'];?>
</span> <?php } ?></td>
				</tr>
			</table>
		</aside>

		<aside>
			<table width="100%">
				<tr data-tip="Earn voting points by voting for the server">
					<td width="10%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/lightning.png" /></td>
					<td width="40%"><?php echo lang("voting_points","ucp");?>
</td>
					<td width="50%"><?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
</td>
				</tr>
				<tr data-tip="Earn donation points by donating money to the server">
					<td width="10%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/coins.png" /></td>
					<td width="40%"><?php echo lang("donation_points","ucp");?>
</td>
					<td width="50%"><?php echo $_smarty_tpl->tpl_vars['dp']->value;?>
</td>
				</tr>
				<tr>
					<td width="10%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/shield.png" /></td>
					<td width="40%"><?php echo lang("account_status","ucp");?>
</td>
					<td width="50%"><?php echo $_smarty_tpl->tpl_vars['status']->value;?>
</td>
				</tr>
				<tr>
					<td width="10%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/date.png" /></td>
					<td width="40%"><?php echo lang("member_since","ucp");?>
</td>
					<td width="50%"><?php echo $_smarty_tpl->tpl_vars['register_date']->value;?>
</td>
				</tr>
			</table>
		</aside>
	</section>

	<div class="clear"></div>	
</section>

<div class="ucp_divider"></div>

<section id="ucp_buttons">
	<?php if (hasPermission('view',"vote")&&$_smarty_tpl->tpl_vars['config']->value['vote']){?>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
<?php echo $_smarty_tpl->tpl_vars['config']->value['vote'];?>
" style="background-image:url(<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/modules/ucp/images/vote_panel.jpg)"></a>
	<?php }?>

	<?php if (hasPermission('view',"donate")&&$_smarty_tpl->tpl_vars['config']->value['donate']){?>
	<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
<?php echo $_smarty_tpl->tpl_vars['config']->value['donate'];?>
" style="background-image:url(<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/modules/ucp/images/donate_panel.jpg)"></a>
	<?php }?>

	<?php if (hasPermission('view',"store")&&$_smarty_tpl->tpl_vars['config']->value['store']){?>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
<?php echo $_smarty_tpl->tpl_vars['config']->value['store'];?>
" style="background-image:url(<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/modules/ucp/images/item_store.jpg)"></a>
	<?php }?>

	<?php if (hasPermission('canUpdateAccountSettings','ucp')&&$_smarty_tpl->tpl_vars['config']->value['settings']){?>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
<?php echo $_smarty_tpl->tpl_vars['config']->value['settings'];?>
" style="background-image:url(<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/modules/ucp/images/account_settings.jpg)"></a>
	<?php }?>

	<?php if (hasPermission('canChangeExpansion',"ucp")&&$_smarty_tpl->tpl_vars['config']->value['expansion']){?>
        <a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
<?php echo $_smarty_tpl->tpl_vars['config']->value['expansion'];?>
" style="background-image:url(<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/modules/ucp/images/change_expansion.jpg)"></a>
	<?php }?>

	<?php if (hasPermission('view',"teleport")&&$_smarty_tpl->tpl_vars['config']->value['teleport']){?>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
<?php echo $_smarty_tpl->tpl_vars['config']->value['teleport'];?>
" style="background-image:url(<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/modules/ucp/images/teleport_hub.jpg)"></a>
	<?php }?>

	<?php if (hasPermission('view',"gm")&&$_smarty_tpl->tpl_vars['config']->value['gm']){?>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
<?php echo $_smarty_tpl->tpl_vars['config']->value['gm'];?>
" style="background-image:url(<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/modules/ucp/images/gm_panel.jpg)"></a>
	<?php }?>

	<?php if (hasPermission('view',"admin")&&$_smarty_tpl->tpl_vars['config']->value['admin']){?>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
<?php echo $_smarty_tpl->tpl_vars['config']->value['admin'];?>
" style="background-image:url(<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/modules/ucp/images/admin_panel.jpg)"></a>
	<?php }?>
	
	<div class="clear"></div>
</section>

<?php echo $_smarty_tpl->tpl_vars['characters']->value;?>
<?php }} ?>