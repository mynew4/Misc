<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 18:12:40
         compiled from "application/modules/admin/views/languages/languages.tpl" */ ?>
<?php /*%%SmartyHeaderCode:212327077851508588e36185-74013468%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7769ea119f882b2fd29b284b045cf6b3bc62a745' => 
    array (
      0 => 'application/modules/admin/views/languages/languages.tpl',
      1 => 1361722290,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '212327077851508588e36185-74013468',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'languages' => 0,
    'language' => 0,
    'default' => 0,
    'flag' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51508588ef7f31_13399396',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51508588ef7f31_13399396')) {function content_51508588ef7f31_13399396($_smarty_tpl) {?><section class="box big" id="main_link">
	<h2>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_list.png"/>
		Supported languages (<div style="display:inline;" id="logs_count"><?php if (!$_smarty_tpl->tpl_vars['languages']->value){?>0<?php }else{ ?><?php echo count($_smarty_tpl->tpl_vars['languages']->value);?>
<?php }?></div>)
	</h2>

	<ul id="log_list">
	<?php if ($_smarty_tpl->tpl_vars['languages']->value){?>
		<?php  $_smarty_tpl->tpl_vars['language'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['language']->_loop = false;
 $_smarty_tpl->tpl_vars['flag'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['language']->key => $_smarty_tpl->tpl_vars['language']->value){
$_smarty_tpl->tpl_vars['language']->_loop = true;
 $_smarty_tpl->tpl_vars['flag']->value = $_smarty_tpl->tpl_vars['language']->key;
?>
			<li>
				<div style="float:right">
					<?php if ($_smarty_tpl->tpl_vars['language']->value==$_smarty_tpl->tpl_vars['default']->value){?>
						<div style="color:green">Default language</div>
					<?php }elseif(hasPermission("changeDefaultLanguage")){?>
						<a class="nice_button" href="javascript:void(0)" onClick="Languages.set('<?php echo $_smarty_tpl->tpl_vars['language']->value;?>
')">Set as default</a>
					<?php }?>
				</div>

				<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/flags/<?php echo $_smarty_tpl->tpl_vars['flag']->value;?>
.png" alt="<?php echo $_smarty_tpl->tpl_vars['flag']->value;?>
"> <?php echo ucfirst($_smarty_tpl->tpl_vars['language']->value);?>

			</li>
		<?php } ?>
	<?php }?>
	</ul>

	<span>
		<center><b>Want more?</b> Get more languages from the <a href="https://github.com/raxezdev/FusionCMS-Localization" target="_blank">localization GitHub repository</a></center>
	</span>
</section><?php }} ?>