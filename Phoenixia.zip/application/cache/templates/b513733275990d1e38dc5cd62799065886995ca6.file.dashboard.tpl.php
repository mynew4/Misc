<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 10:47:37
         compiled from "application\modules\admin\views\dashboard.tpl" */ ?>
<?php /*%%SmartyHeaderCode:940652849c3932d488-47627994%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b513733275990d1e38dc5cd62799065886995ca6' => 
    array (
      0 => 'application\\modules\\admin\\views\\dashboard.tpl',
      1 => 1363431440,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '940652849c3932d488-47627994',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'graph' => 0,
    'pendingUpdate' => 0,
    'url' => 0,
    'unique' => 0,
    'views' => 0,
    'income' => 0,
    'votes' => 0,
    'signups' => 0,
    'enabled_modules' => 0,
    'module' => 0,
    'key' => 0,
    'disabled_modules' => 0,
    'php_version' => 0,
    'version' => 0,
    'theme' => 0,
    'header_url' => 0,
    'theme_value' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_52849c39529186_30043007',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52849c39529186_30043007')) {function content_52849c39529186_30043007($_smarty_tpl) {?><?php if ($_smarty_tpl->tpl_vars['graph']->value){?>
<div class="statistics">
	<span>Unique views</span>
	<div class="image">
		<img src="https://chart.googleapis.com/chart?chf=bg,s,FFFFFF&chxl=0:|<?php echo $_smarty_tpl->tpl_vars['graph']->value['first_date'];?>
|<?php echo $_smarty_tpl->tpl_vars['graph']->value['last_date'];?>
&chxp=0,12,87&chxr=1,0,<?php echo $_smarty_tpl->tpl_vars['graph']->value['top']+20;?>
&chxs=1,676767,11.5,0,lt,676767&chxt=x,y&chs=667x190&cht=lc&chco=095a9d&chds=0,<?php echo $_smarty_tpl->tpl_vars['graph']->value['top']+20;?>
&chd=t:<?php echo $_smarty_tpl->tpl_vars['graph']->value['stack'];?>
&chdlp=l&chls=2&chma=5,5,5,5" />
	</div>
</div>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['pendingUpdate']->value){?>
	<section id="content" style="border-top:none;">
		<section class="box big shouldHaveAlert">
		<h1>Pending update</h1>
		<span style="text-align:center;padding:15px;">
			There is a pending update to <b><?php echo $_smarty_tpl->tpl_vars['pendingUpdate']->value;?>
</b> available.
			<a class="nice_button" href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
update" data-hasevent="1">Go to the update installer</a>
		</span>
		</section>
	</section>
<?php }?>

<div class="info_box">
	<aside>
		<h2><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_pin.png"/> Website</h2>
		<table>
			<tr
>				<td>Unique visitors today</td>
				<td><?php echo $_smarty_tpl->tpl_vars['unique']->value['today'];?>
</td>
			</tr>
			<tr>
				<td>Unique visitors this month</td>
				<td><?php echo $_smarty_tpl->tpl_vars['unique']->value['month'];?>
</td>
			</tr>
			<tr>
				<td>Page views today</td>
				<td><?php echo $_smarty_tpl->tpl_vars['views']->value['today'];?>
</td>
			</tr>
			<tr>
				<td>Page views this month</td>
				<td><?php echo $_smarty_tpl->tpl_vars['views']->value['month'];?>
</td>
			</tr>
		</table>
	</aside>
	<aside>
		<h2><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_graph.png"/> Shop</h2>
		<table>
			<tr>
				<td>Income this month</td>
				<td>$ <?php echo $_smarty_tpl->tpl_vars['income']->value['this'];?>
</td>
			</tr>
			<tr>
				<td>Income last month</td>
				<td>$ <?php echo $_smarty_tpl->tpl_vars['income']->value['last'];?>
</td>
			</tr>
			<tr>
				<td>Votes this month</td>
				<td><?php echo $_smarty_tpl->tpl_vars['votes']->value['this'];?>
</td>
			</tr>
			<tr>
				<td>Votes last month</td>
				<td><?php echo $_smarty_tpl->tpl_vars['votes']->value['last'];?>
</td>
			</tr>
		</table>
	</aside>
	<aside>
		<h2><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_users.png"/> Users</h2>
		<table>
			<tr>
				<td>Registrations today</td>
				<td><?php echo $_smarty_tpl->tpl_vars['signups']->value['today'];?>
</td>
			</tr>
			<tr>
				<td>Registrations this month</td>
				<td><?php echo $_smarty_tpl->tpl_vars['signups']->value['this'];?>
</td>
			</tr>
			<tr>
				<td>Registrations last month</td>
				<td><?php echo $_smarty_tpl->tpl_vars['signups']->value['last'];?>
</td>
			</tr>
			<tr>
				<td>Total accounts</td>
				<td><?php echo $_smarty_tpl->tpl_vars['signups']->value['total'];?>
</td>
			</tr>
		</table>
	</aside>
	<div class="clear"></div>
</div>

<aside class="side_left">
	<section class="box">
		<h2><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_grid.png"/> Installed modules (<div style="display:inline;" id="enabled_count"><?php echo count($_smarty_tpl->tpl_vars['enabled_modules']->value);?>
</div>)</h2>
		<ul id="enabled_modules">
			<?php  $_smarty_tpl->tpl_vars['module'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['module']->_loop = false;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['enabled_modules']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['module']->key => $_smarty_tpl->tpl_vars['module']->value){
$_smarty_tpl->tpl_vars['module']->_loop = true;
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['module']->key;
?>
				<li>
					<?php if (hasPermission("toggleModules")){?>
						<?php if ($_smarty_tpl->tpl_vars['module']->value['enabled']){?><a href="javascript:void(0)" onClick="Admin.disableModule('<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
', this);" class="button">Disable</a><?php }else{ ?><a href="javascript:void(0)" onClick="Admin.enableModule('<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
', this);" class="button">Enable</a><?php }?>
					<?php }?>
					<?php if ($_smarty_tpl->tpl_vars['module']->value['has_configs']&&hasPermission("editModuleConfigs")){?><a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/edit/<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
" class="button">Edit configs</a><?php }?>
					<span style="display:inline !important;padding:0px !important;" data-tip="<?php echo $_smarty_tpl->tpl_vars['module']->value['description'];?>
"><b><?php echo ucfirst($_smarty_tpl->tpl_vars['module']->value['name']);?>
</b> by <a href="<?php echo $_smarty_tpl->tpl_vars['module']->value['author']['website'];?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['module']->value['author']['name'];?>
</a></span>
				</li>
			<?php } ?>
		</ul>
	</section>

	<section class="box">
		<h2><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_grid.png"/> Disabled modules (<div style="display:inline;" id="disabled_count"><?php echo count($_smarty_tpl->tpl_vars['disabled_modules']->value);?>
</div>)</h2>
		<ul id="disabled_modules">
			<?php  $_smarty_tpl->tpl_vars['module'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['module']->_loop = false;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['disabled_modules']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['module']->key => $_smarty_tpl->tpl_vars['module']->value){
$_smarty_tpl->tpl_vars['module']->_loop = true;
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['module']->key;
?>
				<li>
					<?php if (hasPermission("toggleModules")){?>
						<?php if ($_smarty_tpl->tpl_vars['module']->value['enabled']){?><a href="javascript:void(0)" onClick="Admin.disableModule('<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
', this);" class="button">Disable</a><?php }else{ ?><a href="javascript:void(0)" onClick="Admin.enableModule('<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
', this);" class="button">Enable</a><?php }?>
					<?php }?>
					<?php if ($_smarty_tpl->tpl_vars['module']->value['has_configs']&&hasPermission("editModuleConfigs")){?><a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/edit/<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
" class="button">Edit configs</a><?php }?>
					<span style="display:inline !important;padding:0px !important;" data-tip="<?php echo $_smarty_tpl->tpl_vars['module']->value['description'];?>
"><b><?php echo ucfirst($_smarty_tpl->tpl_vars['module']->value['name']);?>
</b> by <a href="<?php echo $_smarty_tpl->tpl_vars['module']->value['author']['website'];?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['module']->value['author']['name'];?>
</a></span>
				</li>
			<?php } ?>
		</ul>
	</section>
</aside>

<aside class="side_right">
	<section class="box" id="system_box">
		<h2><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_settings.png"/> System information</h2>
		
		<table width="90%" align="center" style="margin-top:5px;margin-bottom:5px;">
			<tr>
				<td>PHP version</td>
				<td style="text-align:right;"><?php echo $_smarty_tpl->tpl_vars['php_version']->value;?>
</td>
			</tr>
			<tr>
				<td>CMS version</td>
				<td style="text-align:right;"><?php echo $_smarty_tpl->tpl_vars['version']->value;?>
</td>
			</tr>
		</table>
		<div id="update" style="display:none;">
			<div class="divider"></div>
			<a href="http://raxezdev.com/fusioncms/update" class="button">An update is available</a>
		</div>
	</section>

	<section class="box">
		<h2><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_picture.png"/> Theme information</h2>
		
		<table width="90%" align="center" style="margin-top:5px;margin-bottom:5px;">
			<tr>
				<td>Name</td>
				<td><?php echo $_smarty_tpl->tpl_vars['theme']->value['name'];?>
</td>
			</tr>
			<tr>
				<td>Author</td>
				<td><a href="<?php echo $_smarty_tpl->tpl_vars['theme']->value['website'];?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['theme']->value['author'];?>
</a></td>
			</tr>
			<?php if (hasPermission("changeThemeHeader")){?>
				<tr>
					<td>Header</td>
					<td><b style="font-weight:normal;" id="header_field"><?php if (!$_smarty_tpl->tpl_vars['header_url']->value){?>Default<?php }else{ ?>Custom<?php }?> <?php if ($_smarty_tpl->tpl_vars['theme']->value['blank_header']){?></b> (<a href="javascript:void(0)" onClick="Admin.changeHeader('<?php echo $_smarty_tpl->tpl_vars['header_url']->value;?>
', '<?php echo $_smarty_tpl->tpl_vars['theme']->value['blank_header'];?>
', '<?php echo $_smarty_tpl->tpl_vars['theme_value']->value;?>
')">change</a>)<?php }?></td>
				</tr>
			<?php }?>
		</table>
		<?php if (hasPermission("changeTheme")){?>
			<div class="divider"></div>
			<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/theme" class="button">Change theme</a>
		<?php }?>
	</section>
</aside>

<div class="clear"></div><?php }} ?>