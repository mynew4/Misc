<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 13:51:29
         compiled from "application/modules/admin/views/aclmanager/edit_group.tpl" */ ?>
<?php /*%%SmartyHeaderCode:175719118151504851305d82-41154643%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5978a9ac34790474cdda79610613c5e50c6f1890' => 
    array (
      0 => 'application/modules/admin/views/aclmanager/edit_group.tpl',
      1 => 1364209820,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '175719118151504851305d82-41154643',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'group' => 0,
    'guestId' => 0,
    'playerId' => 0,
    'members' => 0,
    'member' => 0,
    'CI' => 0,
    'url' => 0,
    'links' => 0,
    'link' => 0,
    'pages' => 0,
    'page' => 0,
    'sideboxes' => 0,
    'sidebox' => 0,
    'modules' => 0,
    'module' => 0,
    'name' => 0,
    'role' => 0,
    'roleName' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51504851560125_39169032',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51504851560125_39169032')) {function content_51504851560125_39169032($_smarty_tpl) {?><section class="box big">
	<h2>Edit group</h2>

	<form onSubmit="Groups.save(this, <?php echo $_smarty_tpl->tpl_vars['group']->value['id'];?>
); return false" id="submit_form">

		<label for="name">Group name</label>
		<input type="text" name="name" id="name" value="<?php echo $_smarty_tpl->tpl_vars['group']->value['name'];?>
"/>

		<label for="description">Description (optional)</label>
		<input type="text" name="description" id="description" value="<?php echo $_smarty_tpl->tpl_vars['group']->value['description'];?>
"/>

		<label for="color">Group color (optional)</label>
		<input type="color" name="color" id="color" value="<?php echo $_smarty_tpl->tpl_vars['group']->value['color'];?>
"/>

		<label for="members">Members</label>
		<span>
			<div class="memberList">
				
				<?php if ($_smarty_tpl->tpl_vars['group']->value['id']==$_smarty_tpl->tpl_vars['guestId']->value){?>
					Visitors that are signed out will automatically be assigned to this group
				<?php }elseif($_smarty_tpl->tpl_vars['group']->value['id']==$_smarty_tpl->tpl_vars['playerId']->value){?>
					Visitors that are signed in will automatically be assigned to this group
				<?php }else{ ?>
					<?php if ($_smarty_tpl->tpl_vars['members']->value){?>
						<?php  $_smarty_tpl->tpl_vars['member'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['member']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['members']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['member']->key => $_smarty_tpl->tpl_vars['member']->value){
$_smarty_tpl->tpl_vars['member']->_loop = true;
?>
							<a href="javascript:void(0)" onClick="Groups.removeAccount('<?php echo $_smarty_tpl->tpl_vars['member']->value['username'];?>
', this, <?php echo $_smarty_tpl->tpl_vars['group']->value['id'];?>
 <?php if ($_smarty_tpl->tpl_vars['member']->value['username']==$_smarty_tpl->tpl_vars['CI']->value->user->getUsername()){?>, true<?php }?>)">
								<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/delete.png" />
								<?php echo ucfirst($_smarty_tpl->tpl_vars['member']->value['username']);?>

							</a>
						<?php } ?>
					<?php }?>

					<a href="javascript:void(0)" onClick="Groups.addAccount(this, <?php echo $_smarty_tpl->tpl_vars['group']->value['id'];?>
)" class="add">
						<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/add.png" />Add
					</a>
					<div class="clear"></div>
				<?php }?>
			</div>
		</span>

		<label for="roles">
			<a href="javascript:void(0)" onClick="$('#visibility input[type=checkbox]').each(function(){ this.checked = true; });" style="float:right;display:block;">[Select all]</a>
			Visibility permissions
		</label>

		<div id="visibility">
			<?php if ($_smarty_tpl->tpl_vars['links']->value){?>
				<div class="role_module">
					<h3>Menu links</h3>
					<?php  $_smarty_tpl->tpl_vars['link'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['link']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['links']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['link']->key => $_smarty_tpl->tpl_vars['link']->value){
$_smarty_tpl->tpl_vars['link']->_loop = true;
?>
						<table width="100%">
							<?php if ($_smarty_tpl->tpl_vars['link']->value['permission']){?>
								<tr>
									<td width="5%" style="text-align:center;"><input type="checkbox" name="MENU_<?php echo $_smarty_tpl->tpl_vars['link']->value['id'];?>
" id="MENU_<?php echo $_smarty_tpl->tpl_vars['link']->value['id'];?>
" <?php if ($_smarty_tpl->tpl_vars['link']->value['has']){?>checked="checked"<?php }?>></td>
									<td width="25%">
										<span style="font-size:10px;padding:0px;display:inline;"><?php echo $_smarty_tpl->tpl_vars['link']->value['side'];?>
&nbsp;&nbsp;</span>

										<label for="MENU_<?php echo $_smarty_tpl->tpl_vars['link']->value['id'];?>
" style="display:inline;border:none;font-weight:bold;"><?php echo langColumn($_smarty_tpl->tpl_vars['link']->value['name']);?>
</label></td>
									<td style="font-size:10px;"><?php echo $_smarty_tpl->tpl_vars['link']->value['link'];?>
</td>
								</tr>
							<?php }else{ ?>
								<tr style="opacity:0.6" data-tip="This menu link is set to 'Visible to everyone'-mode.<br />If you want to control the visibility per group, please<br /> go to 'Menu links' and change the visibility mode.">
									<td width="5%" style="text-align:center;"><input type="checkbox" disabled="disabled" checked="checked"></td>
									<td width="25%">
										<span style="font-size:10px;padding:0px;display:inline;"><?php echo $_smarty_tpl->tpl_vars['link']->value['side'];?>
&nbsp;&nbsp;</span>

										<label style="	display:inline;border:none;font-weight:bold;"><?php echo langColumn($_smarty_tpl->tpl_vars['link']->value['name']);?>
</label></td>
									<td style="font-size:10px;"><?php echo $_smarty_tpl->tpl_vars['link']->value['link'];?>
</td>
								</tr>
							<?php }?>		
						</table>
					<?php } ?>
				</div>
			<?php }?>

			<?php if ($_smarty_tpl->tpl_vars['pages']->value){?>
				<div class="role_module">
					<h3>Custom pages</h3>
					<?php  $_smarty_tpl->tpl_vars['page'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['page']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['pages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['page']->key => $_smarty_tpl->tpl_vars['page']->value){
$_smarty_tpl->tpl_vars['page']->_loop = true;
?>
						<table width="100%">
							<?php if ($_smarty_tpl->tpl_vars['page']->value['permission']){?>
								<tr>
									<td width="5%" style="text-align:center;"><input type="checkbox" name="PAGE_<?php echo $_smarty_tpl->tpl_vars['page']->value['id'];?>
" id="PAGE_<?php echo $_smarty_tpl->tpl_vars['page']->value['id'];?>
" <?php if ($_smarty_tpl->tpl_vars['page']->value['has']){?>checked="checked"<?php }?>></td>
									<td width="25%">
										<label for="PAGE_<?php echo $_smarty_tpl->tpl_vars['page']->value['id'];?>
" style="display:inline;border:none;font-weight:bold;"><?php echo langColumn($_smarty_tpl->tpl_vars['page']->value['name']);?>
</label></td>
									<td style="font-size:10px;">pages/<?php echo $_smarty_tpl->tpl_vars['page']->value['identifier'];?>
</td>
								</tr>
							<?php }else{ ?>
								<tr style="opacity:0.6" data-tip="This page is set to 'Visible to everyone'-mode.<br />If you want to control the visibility per group, please<br /> go to 'Custom pages' and change the visibility mode.">
									<td width="5%" style="text-align:center;"><input type="checkbox" disabled="disabled" checked="checked"></td>
									<td width="25%">
										<label for="PAGE_<?php echo $_smarty_tpl->tpl_vars['page']->value['id'];?>
" style="display:inline;border:none;font-weight:bold;"><?php echo langColumn($_smarty_tpl->tpl_vars['page']->value['name']);?>
</label></td>
									<td style="font-size:10px;">pages/<?php echo $_smarty_tpl->tpl_vars['page']->value['identifier'];?>
</td>
								</tr>
							<?php }?>		
						</table>
					<?php } ?>
				</div>
			<?php }?>

			<?php if ($_smarty_tpl->tpl_vars['sideboxes']->value){?>
				<div class="role_module">
					<h3>Sideboxes</h3>
					<?php  $_smarty_tpl->tpl_vars['sidebox'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['sidebox']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['sideboxes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['sidebox']->key => $_smarty_tpl->tpl_vars['sidebox']->value){
$_smarty_tpl->tpl_vars['sidebox']->_loop = true;
?>
						<table width="100%">
							<?php if ($_smarty_tpl->tpl_vars['sidebox']->value['permission']){?>
								<tr>
									<td width="5%" style="text-align:center;"><input type="checkbox" name="SIDEBOX_<?php echo $_smarty_tpl->tpl_vars['sidebox']->value['id'];?>
" id="SIDEBOX_<?php echo $_smarty_tpl->tpl_vars['sidebox']->value['id'];?>
" <?php if ($_smarty_tpl->tpl_vars['sidebox']->value['has']){?>checked="checked"<?php }?>></td>
									<td width="25%">
										<label for="SIDEBOX_<?php echo $_smarty_tpl->tpl_vars['sidebox']->value['id'];?>
" style="display:inline;border:none;font-weight:bold;"><?php echo langColumn($_smarty_tpl->tpl_vars['sidebox']->value['displayName']);?>
</label></td>
									<td style="font-size:10px;"><?php echo $_smarty_tpl->tpl_vars['sidebox']->value['type'];?>
</td>
								</tr>
							<?php }else{ ?>
								<tr style="opacity:0.6" data-tip="This sidebox is set to 'Visible to everyone'-mode.<br />If you want to control the visibility per group, please<br /> go to 'Sideboxes' and change the visibility mode.">
									<td width="5%" style="text-align:center;"><input type="checkbox" disabled="disabled" checked="checked"></td>
									<td width="25%">
										<label for="SIDEBOX_<?php echo $_smarty_tpl->tpl_vars['sidebox']->value['id'];?>
" style="display:inline;border:none;font-weight:bold;"><?php echo langColumn($_smarty_tpl->tpl_vars['sidebox']->value['displayName']);?>
</label></td>
									<td style="font-size:10px;"><?php echo $_smarty_tpl->tpl_vars['sidebox']->value['type'];?>
</td>
								</tr>
							<?php }?>		
						</table>
					<?php } ?>
				</div>
			<?php }?>
		</div>
		
		<label for="roles" data-tip="A role is a pre-defined set of permissions. The color indicates the role's danger-level. Please note that certain permissions may have a default value of 'allowed', such as actions that are meant to be performed by everyone by default.">
			<a href="javascript:void(0)" onClick="$('#roles input[type=checkbox]').each(function(){ this.checked = true; });" style="float:right;display:block;">[Select all]</a>
			Roles <a>(?)</a>
		</label>
		<div id="roles">
		<?php  $_smarty_tpl->tpl_vars['module'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['module']->_loop = false;
 $_smarty_tpl->tpl_vars['name'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['modules']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['module']->key => $_smarty_tpl->tpl_vars['module']->value){
$_smarty_tpl->tpl_vars['module']->_loop = true;
 $_smarty_tpl->tpl_vars['name']->value = $_smarty_tpl->tpl_vars['module']->key;
?>
			<?php if ($_smarty_tpl->tpl_vars['module']->value['db']||$_smarty_tpl->tpl_vars['module']->value['manifest']){?>
				<div class="role_module">
					<h3><?php echo ucfirst($_smarty_tpl->tpl_vars['module']->value['name']);?>
</h3>
					<table width="100%">
						<?php if ($_smarty_tpl->tpl_vars['module']->value['db']){?>
							<?php  $_smarty_tpl->tpl_vars['role'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['role']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['module']->value['db']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['role']->key => $_smarty_tpl->tpl_vars['role']->value){
$_smarty_tpl->tpl_vars['role']->_loop = true;
?>
								<tr>
									<td width="5%" style="text-align:center;"><input type="checkbox" name="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['role']->value['name'];?>
" id="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['role']->value['name'];?>
" <?php if ($_smarty_tpl->tpl_vars['role']->value['has']){?>checked="checked"<?php }?>></td>
									<td width="25%">Custom role: <label for="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['role']->value['name'];?>
" style="	display:inline;border:none;font-weight:bold;"><?php echo $_smarty_tpl->tpl_vars['role']->value['name'];?>
</label></td>
									<td style="font-size:10px;"><?php echo $_smarty_tpl->tpl_vars['role']->value['description'];?>
</td>
								</tr>
							<?php } ?>
						<?php }?>
						
						<?php if ($_smarty_tpl->tpl_vars['module']->value['manifest']){?>
							<?php  $_smarty_tpl->tpl_vars['role'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['role']->_loop = false;
 $_smarty_tpl->tpl_vars['roleName'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['module']->value['manifest']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['role']->key => $_smarty_tpl->tpl_vars['role']->value){
$_smarty_tpl->tpl_vars['role']->_loop = true;
 $_smarty_tpl->tpl_vars['roleName']->value = $_smarty_tpl->tpl_vars['role']->key;
?>
								<tr>
									<td width="5%" style="text-align:center;"><input type="checkbox" name="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['roleName']->value;?>
" id="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['roleName']->value;?>
" <?php if ($_smarty_tpl->tpl_vars['role']->value['has']){?>checked="checked"<?php }?>></td>
									<td width="25%">
										<label for="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['roleName']->value;?>
" style="display:inline;border:none;font-weight:bold;<?php if (isset($_smarty_tpl->tpl_vars['role']->value['color'])){?>color:<?php echo $_smarty_tpl->tpl_vars['role']->value['color'];?>
;<?php }?>">
											<?php echo $_smarty_tpl->tpl_vars['roleName']->value;?>

										</label>
									</td>
									<td style="font-size:10px;"><?php echo $_smarty_tpl->tpl_vars['role']->value['description'];?>
</td>
								</tr>
							<?php } ?>
						<?php }?>
					</table>
				</div>
			<?php }?>
		<?php } ?>
		</div>

		<input type="submit" value="Submit group" />
	</form>
</section><?php }} ?>