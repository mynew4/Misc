<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 21:40:12
         compiled from "application\modules\news\views\admin_edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:139765285352cca9369-54276950%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '62cefc14701a32dd17fa1fdabbf22f8f794f1c45' => 
    array (
      0 => 'application\\modules\\news\\views\\admin_edit.tpl',
      1 => 1364230910,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '139765285352cca9369-54276950',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'article' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5285352cd512e6_69040115',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5285352cd512e6_69040115')) {function content_5285352cd512e6_69040115($_smarty_tpl) {?><?php echo TinyMCE();?>

<section class="box big">
	<h2>Edit article</h2>

	<form onSubmit="News.send(<?php echo $_smarty_tpl->tpl_vars['article']->value['id'];?>
); return false">
		<label for="headline">Headline</label>
		<input type="hidden" id="headline" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['article']->value['headline']);?>
"/>
		
		<label for="news_content">
			Content
		</label>
	</form>
		<div style="padding:10px;">
			<textarea name="news_content" class="tinymce" id="news_content" cols="30" rows="10"><?php echo $_smarty_tpl->tpl_vars['article']->value['content'];?>
</textarea>
		</div>
	<form onSubmit="News.send(<?php echo $_smarty_tpl->tpl_vars['article']->value['id'];?>
); return false">
		<label>Article settings</label>

		<input type="checkbox" id="avatar" <?php if ($_smarty_tpl->tpl_vars['article']->value['avatar']){?>checked="yes"<?php }?> value="1"/>
		<label for="avatar" class="inline_label">Show your avatar</label>

		<input type="checkbox" id="comments" <?php if ($_smarty_tpl->tpl_vars['article']->value['comments']!=-1){?>checked="yes"<?php }?> value="1"/>
		<label for="comments" class="inline_label">Allow comments</label>

		<input type="submit" value="Save article" />
	</form>
</section>

<script>
	require([Config.URL + "application/themes/admin/js/mli.js"], function()
	{
		new MultiLanguageInput($("#headline"));
	});
</script><?php }} ?>