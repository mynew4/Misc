<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 18:28:03
         compiled from "application/themes/raxezwow/views/page.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9830886425150892313d581-57593360%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b31d2c33dd7ddb1bc84d31469ae2b73bd1c07a8f' => 
    array (
      0 => 'application/themes/raxezwow/views/page.tpl',
      1 => 1359559561,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9830886425150892313d581-57593360',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'headline' => 0,
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5150892315bb76_33792050',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5150892315bb76_33792050')) {function content_5150892315bb76_33792050($_smarty_tpl) {?><article class="main_box">
	<a class="main_box_top"><?php echo $_smarty_tpl->tpl_vars['headline']->value;?>
</a>
	<div class="main_box_body">
		<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

	</div>
</article><?php }} ?>