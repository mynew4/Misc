<?php /* Smarty version Smarty-3.1.8, created on 2013-11-14 10:46:14
         compiled from "application\themes\default\views\page.tpl" */ ?>
<?php /*%%SmartyHeaderCode:578652849be6698483-47429306%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4449538a7ae8f1a16ca63fad034946d0b83f925c' => 
    array (
      0 => 'application\\themes\\default\\views\\page.tpl',
      1 => 1359559562,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '578652849be6698483-47429306',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'headline' => 0,
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_52849be66a4003_90071603',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52849be66a4003_90071603')) {function content_52849be66a4003_90071603($_smarty_tpl) {?><article>
	<h1 class="top"><?php echo $_smarty_tpl->tpl_vars['headline']->value;?>
</h1>
	<section class="body">
		<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

	</section>
</article><?php }} ?>