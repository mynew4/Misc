UPDATE `armory_db_version` SET `version` = 'armory_r491';
INSERT INTO `armory_item_sources` (`key`, `parent`, `item`, `type`, `subtype`) VALUES ('enchP', 0, 0, 0, 8), ('enchT', 0, 0, 0, 8);