function setArmorySearchFocus() {
document.formSearch.armorySearch.focus();
}
window.onload = setArmorySearchFocus;