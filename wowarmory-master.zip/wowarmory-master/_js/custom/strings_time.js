L10n.formatTimestamps("span.timestamp-news", {
	withinHour: "{0} мин. назад",
	withinHourSingular: "{0} мин. назад",
	withinDay: "{0} ч назад",
	withinDaySingular: "{0} ч назад",
	today: "Сегодня, {0}",
	yesterday: "Вчера",
	date: "d-M-yyyy"
});