function initializeTeamInfo(){
	$("#teamsTable").tablesorter();
}