SQLGather tool 
use this tool for merging all loose sql updates in the 
sql Repository directory to make a single query for importing.

to use, simply copy the batch file into the main directory,
and click. 3 files will be made, auth/char/world.

*Do remember if your going to use this tool, 
remove it and the generated sql files b4 staging a commit :s