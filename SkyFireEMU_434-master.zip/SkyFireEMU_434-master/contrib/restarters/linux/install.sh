chmod +x skyfire restarter
cp skyfire /etc/init.d/
cp restarter /opt/skyfire/
