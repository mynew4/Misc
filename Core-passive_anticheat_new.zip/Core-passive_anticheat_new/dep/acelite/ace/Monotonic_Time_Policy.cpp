// $Id: Monotonic_Time_Policy.cpp 96061 2012-08-16 09:36:07Z mcorino $

#include "ace/Monotonic_Time_Policy.h"

#if !defined(__ACE_INLINE__)
# include "ace/Monotonic_Time_Policy.inl"
#endif /* __ACE_INLINE__ */
