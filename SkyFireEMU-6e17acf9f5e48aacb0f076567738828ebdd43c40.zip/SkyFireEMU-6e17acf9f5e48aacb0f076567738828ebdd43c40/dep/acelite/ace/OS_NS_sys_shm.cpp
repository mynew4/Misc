// $Id: OS_NS_sys_shm.cpp 91286 2010-08-05 09:04:31Z johnnyw $

#include "ace/OS_NS_sys_shm.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_sys_shm.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

