// -*- C++ -*-
// $Id: OS_NS_errno.cpp 91781 2010-09-15 12:49:15Z johnnyw $

#include "ace/OS_NS_errno.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_errno.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

