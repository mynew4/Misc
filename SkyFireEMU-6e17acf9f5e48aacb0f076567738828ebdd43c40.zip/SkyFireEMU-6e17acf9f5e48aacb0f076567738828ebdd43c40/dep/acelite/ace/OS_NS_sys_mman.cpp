// $Id: OS_NS_sys_mman.cpp 92837 2010-12-08 17:31:02Z johnnyw $

#include "ace/OS_NS_sys_mman.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_sys_mman.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

