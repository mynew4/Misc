-- Linux Restarter --

Description:
this is just a basic restart-tool for *nix.

* this has not been fully tested, nor am i completely done with it
but it was confirmed working.

Content:
- File "skyfire" is an interface to use a easier "screen" command.
- File "restarter" is to restart a daemon if it has stopped.
- install.sh is bash-script that initializes the hole shabang.

Credits goes to the original Author for the base script:
- MiLk (OregonCore)
