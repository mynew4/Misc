Simple world restarters, 
copy to your working server directory and click.
if you change the names of the exe's or configs,
you will have to edit these batch files.
otherwise there working.