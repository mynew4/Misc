Random clean-up queries
*if you do not know what these are for and what they do,
i would suggest you not use any of the import scripts in this file.