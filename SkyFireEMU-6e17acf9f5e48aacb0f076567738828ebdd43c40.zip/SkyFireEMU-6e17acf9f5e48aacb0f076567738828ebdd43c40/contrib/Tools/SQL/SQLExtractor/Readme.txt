Localextract tool (simple_MySQLDump)
Use to fully extract a database or use for single table extractions.
