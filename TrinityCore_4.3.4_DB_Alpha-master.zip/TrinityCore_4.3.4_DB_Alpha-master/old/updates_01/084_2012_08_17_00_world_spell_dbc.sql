UPDATE `spell_dbc` SET `ProcChance`=101,`ProcCharges`=0,`SpellFamilyName`=3,`SpellFamilyFlags2`=0 WHERE `Id`=35009;
