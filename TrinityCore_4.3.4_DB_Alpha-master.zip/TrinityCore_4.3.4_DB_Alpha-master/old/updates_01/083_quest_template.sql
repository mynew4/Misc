UPDATE `quest_template` SET `RequiredNpcOrGo1`=-1721, `RequiredNpcOrGo2`=-1722 WHERE `Id`=498; -- The Rescue
UPDATE `quest_template` SET `RequiredNpcOrGo3`=-1761 WHERE `Id`=532; -- Battle of Hillsbrad
UPDATE `quest_template` SET `RequiredNpcOrGo1`=-1768, `RequiredNpcOrGo2`=-1769, `RequiredNpcOrGo3`=-1770 WHERE `Id`=553; -- Helcular's Revenge
UPDATE `quest_template` SET `RequiredNpcOrGo1`=-2704 WHERE `Id`=633; -- The Thandol Span
UPDATE `quest_template` SET `RequiredNpcOrGo1`=-3189, `RequiredNpcOrGo2`=-3190, `RequiredNpcOrGo3`=-3192 WHERE `Id`=786; -- Thwarting Kolkar Aggression
UPDATE `quest_template` SET `RequiredNpcOrGo1`=-3644 WHERE `Id`=849; -- Revenge of Gann
UPDATE `quest_template` SET `RequiredNpcOrGo1`=-3737 WHERE `Id`=877; -- The Stagnant Oasis
UPDATE `quest_template` SET `RequiredNpcOrGo1`=-4072, `RequiredNpcOrGo2`=-61936, `RequiredNpcOrGo3`=-61935 WHERE `Id`=900; -- Samophlange
UPDATE `quest_template` SET `RequiredNpcOrGo1`=-3525 WHERE `Id`=924; -- The Demon Seed
UPDATE `quest_template` SET `RequiredNpcOrGo1`=-17188, `RequiredNpcOrGo2`=-17189 WHERE `Id`=953; -- The Fall of Ameth'Aran
UPDATE `quest_template` SET `RequiredNpcOrGo1`=-16393 WHERE `Id`=957; -- Bashal'Aran
UPDATE `quest_template` SET `RequiredNpcOrGo1`=-19027 WHERE `Id`=1022; -- The Howling Vale
UPDATE `quest_template` SET `RequiredNpcOrGo1`=-19030 WHERE `Id`=1043; -- The Scythe of Elune
UPDATE `quest_template` SET `RequiredNpcOrGo1`=-19901, `RequiredNpcOrGo2`=-20352 WHERE `Id`=1140; -- The Tower of Althalaxx
UPDATE `quest_template` SET `RequiredNpcOrGo1`=-20359 WHERE `Id`=1172; -- The Brood of Onyxia
UPDATE `quest_template` SET `RequiredNpcOrGo1`=-3189, `RequiredNpcOrGo2`=-3190, `RequiredNpcOrGo3`=-3192 WHERE `Id`=25169; -- The War of Northwatch Aggression
UPDATE `quest_template` SET `RequiredNpcOrGo1`=-20359 WHERE `Id`=27415; -- The Brood of Onyxia
UPDATE `quest_template` SET `RequiredNpcOrGo1`=-4072, `RequiredNpcOrGo2`=-61936, `RequiredNpcOrGo3`=-61935 WHERE `Id`=29022; -- Samophlange
