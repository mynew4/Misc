UPDATE `creature_classlevelstats` SET `basehp3` = 30951 WHERE `level` = 80 AND `class` IN (1, 2, 4);
UPDATE `creature_classlevelstats` SET `basehp3` = 37187 WHERE `level` = 81 AND `class` IN (1, 2, 4);
UPDATE `creature_classlevelstats` SET `basehp3` = 44679 WHERE `level` = 82 AND `class` IN (1, 2, 4);
UPDATE `creature_classlevelstats` SET `basehp3` = 53681 WHERE `level` = 83 AND `class` IN (1, 2, 4);
UPDATE `creature_classlevelstats` SET `basehp3` = 64496 WHERE `level` = 84 AND `class` IN (1, 2, 4);
UPDATE `creature_classlevelstats` SET `basehp3` = 77490 WHERE `level` = 85 AND `class` IN (1, 2, 4);
UPDATE `creature_classlevelstats` SET `basehp3` = 80195 WHERE `level` = 86 AND `class` IN (1, 2, 4);
UPDATE `creature_classlevelstats` SET `basehp3` = 82994 WHERE `level` = 87 AND `class` IN (1, 2, 4);
UPDATE `creature_classlevelstats` SET `basehp3` = 85892 WHERE `level` = 88 AND `class` IN (1, 2, 4);
UPDATE `creature_classlevelstats` SET `basehp3` = 107596 WHERE `level` BETWEEN 89 AND 100 AND `class` IN (1, 2, 4);

UPDATE `creature_classlevelstats` SET `basemana` = 4322 WHERE `level` = 84 AND `class` = 2;
UPDATE `creature_classlevelstats` SET `basemana` = 4412 WHERE `level` = 85 AND `class` = 2;
UPDATE `creature_classlevelstats` SET `basemana` = 4502 WHERE `level` = 86 AND `class` = 2;
UPDATE `creature_classlevelstats` SET `basemana` = 5502 WHERE `level` = 87 AND `class` = 2;
UPDATE `creature_classlevelstats` SET `basemana` = 5502 WHERE `level` BETWEEN 87 AND 100 AND `class` = 2;

UPDATE `creature_classlevelstats` SET `basehp3` = 24761 WHERE `level` = 80 AND `class` = 8;
UPDATE `creature_classlevelstats` SET `basehp3` = 29750 WHERE `level` = 81 AND `class` = 8;
UPDATE `creature_classlevelstats` SET `basehp3` = 35743 WHERE `level` = 82 AND `class` = 8;
UPDATE `creature_classlevelstats` SET `basehp3` = 42945 WHERE `level` = 83 AND `class` = 8;
UPDATE `creature_classlevelstats` SET `basehp3` = 51597, `basemana` = 9517 WHERE `level` = 84 AND `class` = 8;
UPDATE `creature_classlevelstats` SET `basehp3` = 73299, `basemana` = 9694 WHERE `level` = 85 AND `class` = 8;
UPDATE `creature_classlevelstats` SET `basehp3` = 86077, `basemana` = 9873 WHERE `level` = 86 AND `class` = 8;
UPDATE `creature_classlevelstats` SET `basehp3` = 107596, `basemana` = 10052 WHERE `level` BETWEEN 87 AND 100 AND `class` = 8;
