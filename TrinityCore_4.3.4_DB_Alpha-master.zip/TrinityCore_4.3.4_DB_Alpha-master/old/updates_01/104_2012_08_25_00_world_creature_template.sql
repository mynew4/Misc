-- Wintergrasp Siege Turret
UPDATE `creature_template` SET `faction_A`=1732,`faction_H`=1732 WHERE `entry`=28319; -- Alliance
UPDATE `creature_template` SET `faction_A`=1735,`faction_H`=1735 WHERE `entry`=32629; -- Horde
