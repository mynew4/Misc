UPDATE `quest_template` SET `NextQuestId`=12257 WHERE `ID`=12468;
