DELETE FROM `spell_group` WHERE `spell_id` IN (-1053,-1052,-1056,-1055,-1058,-1067,-1104,-1106,-1105,-1094);
DELETE FROM `spell_group_stack_rules` WHERE `group_id` IN (1054,1057,1113,1117);
