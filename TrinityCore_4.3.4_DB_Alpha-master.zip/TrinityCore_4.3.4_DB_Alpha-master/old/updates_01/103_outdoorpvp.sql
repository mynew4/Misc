DELETE FROM `outdoorpvp_template` WHERE `TypeId` = 6; -- Eastern Plaguelands
