TRUNCATE `item_template`;
TRUNCATE `instance_encounters`;
