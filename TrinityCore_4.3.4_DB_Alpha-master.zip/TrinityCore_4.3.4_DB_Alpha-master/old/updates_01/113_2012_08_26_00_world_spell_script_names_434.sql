DELETE FROM `spell_script_names` WHERE `spell_id`=15473;
INSERT INTO `spell_script_names` (`spell_id`,`ScriptName`) VALUES
(15473,'spell_pri_shadowform');
