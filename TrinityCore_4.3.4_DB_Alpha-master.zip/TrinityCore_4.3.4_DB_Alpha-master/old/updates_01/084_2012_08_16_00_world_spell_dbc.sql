DELETE FROM `spell_dbc` WHERE `Id`=35009;
INSERT INTO `spell_dbc` (`Id`,`Attributes`,`AttributesEx`,`AttributesEx2`,`AttributesEx3`,`Targets`,`CastingTimeIndex`,`ProcCharges`,`SpellLevel`,`RangeIndex`,`Effect1`,`EffectDieSides1`,`EffectBasePoints1`,`EffectImplicitTargetA1`,`EffectImplicitTargetB1`,`EffectRadiusIndex1`,`SpellFamilyName`,`SpellFamilyFlags2`,`DmgMultiplier1`,`SchoolMask`,`Comment`) VALUES
(35009,134545792,1024,268435460,65536,64,1,101,1,13,125,1,-11,22,16,27,10,4,1,6,'Invisibility - Reducing threat');
