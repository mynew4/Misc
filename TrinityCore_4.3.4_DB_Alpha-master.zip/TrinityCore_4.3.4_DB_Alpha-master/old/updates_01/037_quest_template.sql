UPDATE `quest_template` SET `Flags`=2152726592 WHERE `Id`=28617; -- Flower Power
UPDATE `quest_template` SET `Flags`=2152726592 WHERE `Id`=28733; -- Basic Botany
UPDATE `quest_template` SET `Flags`=2152726592 WHERE `Id`=28744; -- Ghouls Hate My Grains
UPDATE `quest_template` SET `Flags`=2152726592 WHERE `Id`=28747; -- Someone Setup the Pumpkin Bomb
UPDATE `quest_template` SET `Flags`=2152726592 WHERE `Id`=28748; -- Lawn of the Dead
