UPDATE `creature` SET `phaseMask`=256 WHERE `id`=34300;
