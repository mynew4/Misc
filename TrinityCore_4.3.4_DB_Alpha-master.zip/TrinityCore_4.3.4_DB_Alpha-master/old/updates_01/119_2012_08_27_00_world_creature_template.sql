-- NPC script linking for Wyrmrest Defender ID: 27629
UPDATE `creature_template` SET `ScriptName`='npc_wyrmrest_defender' WHERE `entry`=27629;
