UPDATE `creature_template` SET `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=582; -- Old Blanchy
UPDATE `creature_template` SET `unit_flags`=67141632, `unit_flags2`=33556480 WHERE `entry`=44220; -- Jade Rager
UPDATE `creature_template` SET `unit_flags`=67141632, `dynamicflags`=4 WHERE `entry`=45825; -- Swampstrider
UPDATE `creature_template` SET `unit_flags`=67141632, `dynamicflags`=4 WHERE `entry`=45321; -- Riverbed Crocolisk
UPDATE `creature_template` SET `unit_flags`=67141632, `dynamicflags`=4 WHERE `entry`=41293; -- Harbor Shredfin
UPDATE `creature_template` SET `unit_flags`=67108864, `dynamicflags`=4 WHERE `entry`=5420; -- Glasshide Gazer
UPDATE `creature_template` SET `unit_flags`=67108864, `dynamicflags`=4 WHERE `entry`=37208; -- Thunderhead
UPDATE `creature_template` SET `unit_flags`=67108864, `dynamicflags`=4 WHERE `entry`=2022; -- Timberling
UPDATE `creature_template` SET `unit_flags`=67108864, `dynamicflags`=4 WHERE `entry`=16863; -- Deranged Helboar
UPDATE `creature_template` SET `unit_flags`=67108864, `dynamicflags`=4 WHERE `entry`=1125; -- Crag Boar
UPDATE `creature_template` SET `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=41166; -- Gomegaz
UPDATE `creature_template` SET `unit_flags`=570721024, `unit_flags2`=33556481, `dynamicflags`=32 WHERE `entry`=43228; -- Stone Trogg Berserker
UPDATE `creature_template` SET `unit_flags`=570720512, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=38531; -- Oomlot Warrior
UPDATE `creature_template` SET `unit_flags`=570720256, `unit_flags2`=2049 WHERE `entry`=11682; -- Warsong Grunt
UPDATE `creature_template` SET `unit_flags`=570687488, `unit_flags2`=2049, `dynamicflags`=32, `VehicleId`=0 WHERE `entry`=36942; -- Fledgling Brave
UPDATE `creature_template` SET `unit_flags`=570687488, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=37088; -- Elder Zhevra
UPDATE `creature_template` SET `unit_flags`=570687488, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=37082; -- Dusthoof Giraffe
UPDATE `creature_template` SET `unit_flags`=537166592, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=45198; -- Forsaken Catapult
UPDATE `creature_template` SET `unit_flags`=537166592, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=26271; -- Emaciated Mammoth Bull
UPDATE `creature_template` SET `unit_flags`=537166080, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=46575; -- Darktusk Boar
UPDATE `creature_template` SET `unit_flags`=537165824, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=35810; -- Frightened Miner
UPDATE `creature_template` SET `unit_flags`=537133824, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=948; -- Rotted One
UPDATE `creature_template` SET `unit_flags`=537133824, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=5996; -- Nethergarde Miner
UPDATE `creature_template` SET `unit_flags`=537133824, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=3; -- Flesh Eater
UPDATE `creature_template` SET `unit_flags`=537133824, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=210; -- Bone Chewer
UPDATE `creature_template` SET `unit_flags`=33587200, `unit_flags2`=33622016 WHERE `entry`=38745; -- Kezan Citizen
UPDATE `creature_template` SET `unit_flags`=33587200, `unit_flags2`=33622016 WHERE `entry`=38409; -- Goblin Survivor
UPDATE `creature_template` SET `unit_flags`=33587200 WHERE `entry`=38661; -- Rageroar Sea Dog
UPDATE `creature_template` SET `unit_flags`=33587200 WHERE `entry`=31238; -- Hira Snowdawn
UPDATE `creature_template` SET `unit_flags`=33554688 WHERE `entry`=45847; -- S.A.F.E. Operative
UPDATE `creature_template` SET `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=3681; -- Wisp
UPDATE `creature_template` SET `unit_flags`=33554432 WHERE `entry`=42925; -- Ravenous Tunneler
UPDATE `creature_template` SET `unit_flags`=33536 WHERE `entry`=40891; -- Dranosh'ar Laborer
UPDATE `creature_template` SET `unit_flags`=33536 WHERE `entry`=40820; -- War Kodo
UPDATE `creature_template` SET `unit_flags`=33280 WHERE `entry`=44911; -- Dreadguard
UPDATE `creature_template` SET `unit_flags`=33280 WHERE `entry`=28029; -- Argent Crusader
UPDATE `creature_template` SET `unit_flags`=33024 WHERE `entry`=46187; -- Marshtide Carouser
UPDATE `creature_template` SET `unit_flags`=32832, `dynamicflags`=4 WHERE `entry`=33695; -- Cultist Bombardier
UPDATE `creature_template` SET `unit_flags`=32784, `dynamicflags`=0 WHERE `entry`=51899; -- Hammerfall Guardian
UPDATE `creature_template` SET `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=41158; -- Nethergarde Defender
UPDATE `creature_template` SET `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=39138; -- Theramore Highway Guard
UPDATE `creature_template` SET `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=38855; -- Volcanoth
UPDATE `creature_template` SET `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=38696; -- Yngwie
UPDATE `creature_template` SET `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=3383; -- Southsea Cutthroat
UPDATE `creature_template` SET `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=32969; -- Lor'danel Sentinel
UPDATE `creature_template` SET `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=11682; -- Warsong Grunt
UPDATE `creature_template` SET `unit_flags`=32768 WHERE `entry`=55783; -- Ravenholdt Sentry
UPDATE `creature_template` SET `unit_flags`=32768 WHERE `entry`=46294; -- Captive Pygmy
UPDATE `creature_template` SET `unit_flags`=32768 WHERE `entry`=46284; -- Captive Pygmy
UPDATE `creature_template` SET `unit_flags`=32768 WHERE `entry`=46166; -- Stonard Warrior
UPDATE `creature_template` SET `unit_flags`=32768 WHERE `entry`=44474; -- Whitetail Fox
UPDATE `creature_template` SET `unit_flags`=32768 WHERE `entry`=40892; -- Dranosh'ar Overseer
UPDATE `creature_template` SET `unit_flags`=32768 WHERE `entry`=35202; -- Kezan Partygoer
UPDATE `creature_template` SET `unit_flags`=32768 WHERE `entry`=33053; -- Grimclaw
UPDATE `creature_template` SET `unit_flags`=32768 WHERE `entry`=29212; -- Risen Drudge
UPDATE `creature_template` SET `unit_flags`=32768 WHERE `entry`=28028; -- Argent Shieldman
UPDATE `creature_template` SET `unit_flags`=272 WHERE `entry`=32341; -- Gold Mage
UPDATE `creature_template` SET `unit_flags`=272 WHERE `entry`=32322; -- Gold Warrior
UPDATE `creature_template` SET `unit_flags`=262144, `dynamicflags`=0 WHERE `entry`=1117; -- Rockjaw Bonesnapper
UPDATE `creature_template` SET `unit_flags`=262144 WHERE `entry`=52227; -- Balgor Whipshank
UPDATE `creature_template` SET `unit_flags`=256 WHERE `entry`=32340; -- Gold Shaman
UPDATE `creature_template` SET `unit_flags`=2181300992 WHERE `entry`=25075; -- Zeppelin Controls
UPDATE `creature_template` SET `unit_flags`=2147779328 WHERE `entry`=33479; -- Stormwind Valiant
UPDATE `creature_template` SET `unit_flags`=2147779328 WHERE `entry`=33460; -- Orgrimmar Valiant
UPDATE `creature_template` SET `unit_flags`=2147746560 WHERE `entry`=24935; -- Vend-O-Tron D-Luxe
UPDATE `creature_template` SET `unit_flags`=2147746560 WHERE `entry`=24934; -- Snack-O-Matic IV
UPDATE `creature_template` SET `unit_flags`=16448, `unit_flags2`=33556480, `dynamicflags`=0 WHERE `entry`=44218; -- Emerald Colossus
UPDATE `creature_template` SET `unit_flags`=16 WHERE `entry`=41478; -- Snow Tracker Wolf
UPDATE `creature_template` SET `unit_flags`=0, `unit_flags2`=33556480 WHERE `entry`=43170; -- Earthen Geomancer
UPDATE `creature_template` SET `unit_flags`=0, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=12430; -- Grunt Kor'ja
UPDATE `creature_template` SET `unit_flags`=0, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=12429; -- Sentinel Shaya
UPDATE `creature_template` SET `unit_flags`=0, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=12427; -- Mountaineer Dolf
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=9857; -- Auctioneer Grizzlin
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=9564; -- Frezza
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=9047; -- Jenal
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=8723; -- Auctioneer Golothas
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=8669; -- Auctioneer Tolon
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=7740; -- Gracina Spiritmight
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=5546; -- Grunt Zuul
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=5419; -- Glasshide Basilisk
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=5184; -- Theramore Sentry
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=45439; -- Cockroach
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=43480; -- Temperamental Rumbler
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=4244; -- Shadow
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=4243; -- Nightshade
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=4235; -- Turian
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=4164; -- Cylania
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=3571; -- Teldrassil Sentinel
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=3469; -- Ancient of War
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=3338; -- Sergra Darkthorn
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=330; -- Princess
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=3221; -- Brave Rockhorn
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=3220; -- Brave Darksky
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=3217; -- Brave Dawneagle
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=25680; -- Marsh Caribou
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=2516; -- Mountaineer Kamdar
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=2513; -- Mountaineer Janha
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=2512; -- Mountaineer Roghan
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=2510; -- Mountaineer Ozmok
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=2509; -- Mountaineer Cragg
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=2508; -- Mountaineer Wuar
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=23635; -- Krixx
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=2041; -- Ancient Protector
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=1777; -- Dakk Blunderblast
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=17109; -- Cersei Dusksinger
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=16227; -- Bragok
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=16012; -- Mokvar
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=14893; -- Guard Kurall
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=13842; -- Frostwolf Ambassador Rokhstrom
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=1278; -- Mountaineer Stenn
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=1245; -- Kogan Forgestone
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=12136; -- Snurk Bucksquick
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=11193; -- Seril Scourgebane
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=11192; -- Kilram
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=11176; -- Krathok Moltenfist
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=1115; -- Rockjaw Skullthumper
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=11118; -- Innkeeper Vizzie
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=10978; -- Legacki
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=10878; -- Herald Moonstalker
UPDATE `creature_template` SET `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=10036; -- Brackenwall Enforcer
UPDATE `creature_template` SET `unit_flags`=0 WHERE `entry`=869; -- Protector Dorana
UPDATE `creature_template` SET `unit_flags`=0 WHERE `entry`=36943; -- Bristleback Invader
UPDATE `creature_template` SET `unit_flags`=0 WHERE `entry`=35984; -- Sunreaver Dragonhawk
UPDATE `creature_template` SET `unit_flags`=0 WHERE `entry`=30566; -- Strand of the Ancients Emissary
UPDATE `creature_template` SET `unit_flags`=0 WHERE `entry`=30281; -- Silver Covenant Hippogryph
UPDATE `creature_template` SET `unit_flags`=0 WHERE `entry`=29152; -- Stormwind Dock Worker
UPDATE `creature_template` SET `unit_flags`=0 WHERE `entry`=28246; -- Sky Terror
UPDATE `creature_template` SET `unit_flags`=0 WHERE `entry`=28093; -- Sholazar Tickbird
UPDATE `creature_template` SET `unit_flags`=0 WHERE `entry`=11657; -- Morloch
UPDATE `creature_template` SET `unit_flags2`=67584 WHERE `entry`=55415; -- Life Warden
UPDATE `creature_template` SET `unit_flags2`=67584 WHERE `entry`=49849; -- Krazzworks Cannoneer
UPDATE `creature_template` SET `unit_flags2`=67584 WHERE `entry`=49848; -- Krazz Cannon
UPDATE `creature_template` SET `unit_flags2`=67584 WHERE `entry`=49680; -- Krazz Cannon
UPDATE `creature_template` SET `unit_flags2`=67584 WHERE `entry`=48925; -- Mook Disguise
UPDATE `creature_template` SET `unit_flags2`=67584 WHERE `entry`=45224; -- Lashed to the Mast
UPDATE `creature_template` SET `unit_flags2`=67584 WHERE `entry`=45064; -- Catapult Driver
UPDATE `creature_template` SET `unit_flags2`=67584 WHERE `entry`=44577; -- General Husam
UPDATE `creature_template` SET `unit_flags2`=67584 WHERE `entry`=43952; -- Earthen Catapult
UPDATE `creature_template` SET `unit_flags2`=67584 WHERE `entry`=38526; -- B.C. Eliminator
UPDATE `creature_template` SET `unit_flags2`=67584 WHERE `entry`=34132; -- Astranaar Thrower
UPDATE `creature_template` SET `unit_flags2`=67143680 WHERE `entry`=46671; -- Twilight Rune of Earth
UPDATE `creature_template` SET `unit_flags2`=67110913 WHERE `entry`=48598; -- Titanic Guardian
UPDATE `creature_template` SET `unit_flags2`=67110912 WHERE `entry`=56131; -- Sandbox Tiger
UPDATE `creature_template` SET `unit_flags2`=67110912 WHERE `entry`=56130; -- Sandbox Tiger
UPDATE `creature_template` SET `unit_flags2`=67110912 WHERE `entry`=56129; -- Sandbox Tiger
UPDATE `creature_template` SET `unit_flags2`=67110912 WHERE `entry`=56097; -- Sandbox Tiger
UPDATE `creature_template` SET `unit_flags2`=67110912 WHERE `entry`=54475; -- Crab
UPDATE `creature_template` SET `unit_flags2`=67110912 WHERE `entry`=52171; -- Muddy Tracks
UPDATE `creature_template` SET `unit_flags2`=67110912 WHERE `entry`=50291; -- Arcane Tesseract
UPDATE `creature_template` SET `unit_flags2`=67110912 WHERE `entry`=49691; -- Fertilize-o-tron 2000
UPDATE `creature_template` SET `unit_flags2`=67110912 WHERE `entry`=48560; -- Emberscar the Devourer
UPDATE `creature_template` SET `unit_flags2`=67110912 WHERE `entry`=43003; -- Venture Co. Sawblade
UPDATE `creature_template` SET `unit_flags2`=67108864 WHERE `entry`=49697; -- Spitter
UPDATE `creature_template` SET `unit_flags2`=67108864 WHERE `entry`=49696; -- Freezya
UPDATE `creature_template` SET `unit_flags2`=67108864 WHERE `entry`=49692; -- Sunflower
UPDATE `creature_template` SET `unit_flags2`=65536 WHERE `entry`=43259; -- Rocket Defense Turret
UPDATE `creature_template` SET `unit_flags2`=51201 WHERE `entry`=56371; -- Suspicious Infiltrator
UPDATE `creature_template` SET `unit_flags2`=34848 WHERE `entry`=54945; -- Sandstorm
UPDATE `creature_template` SET `unit_flags2`=34848 WHERE `entry`=48334; -- Dust Devil
UPDATE `creature_template` SET `unit_flags2`=34817 WHERE `entry`=50634; -- Menacing Emissary
UPDATE `creature_template` SET `unit_flags2`=34817 WHERE `entry`=46819; -- Corpse of Forgemaster Finlay
UPDATE `creature_template` SET `unit_flags2`=34817 WHERE `entry`=45695; -- Slain Scourge Trooper
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=823; -- Deputy Willem
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=7024; -- Agent Kearnen
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=58233; -- Twilight Portal
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=55305; -- Carl Goodup
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=53652; -- Aggra
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=53649; -- Thrall
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=53518; -- Thrall
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=52809; -- Blax Bottlerocket
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=52358; -- Craggle Wobbletop
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=50253; -- Twilight Hammer Cult Site
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=49451; -- Oil Leak Bunny
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=49386; -- Craw MacGraw
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=49148; -- Dark Ritualist Zakahn
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=48758; -- Hammelhand
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=48549; -- Pool of Lava
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=48526; -- Bilgewater Buccaneer
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=48366; -- Russell Brower
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=48010; -- Low Shaman Blundy
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=46717; -- The Hammer of Twilight
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=464; -- Guard Parker
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=46337; -- Torth
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=46135; -- High Priest Amet
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=45752; -- Ambermill Dimensional Portal
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=45286; -- KTC Train-a-Tron Deluxe
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=45244; -- Farseer Krogar
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=45226; -- Naraat the Earthspeaker
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=44222; -- Seer Galekk
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=44126; -- War Guardian
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=44049; -- Giant Mushroom
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=43082; -- First Mate Moody
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=42813; -- Kil'karil
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=42620; -- Lashtail Egg
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=42469; -- Kor the Immovable
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=42173; -- The Undershell Tentacle Flavor
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=41359; -- Bloodwash Crate Spawner
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=39456; -- Captured Goblin
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=39341; -- Mine Cart
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=37897; -- Capturing The Unknown - Bunny 4
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=37896; -- Capturing The Unknown - Bunny 3
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=37895; -- Capturing The Unknown - Bunny 2
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=37872; -- Capturing The Unknown - Bunny 1
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=36918; -- Lorekeeper's Summoning Stone
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=36127; -- Gyrochoppa
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=2239; -- Drull
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=2238; -- Tog'thar
UPDATE `creature_template` SET `unit_flags2`=34816 WHERE `entry`=15192; -- Anachronos
UPDATE `creature_template` SET `unit_flags2`=33589248 WHERE `entry`=38518; -- Warrior-Matic NX-01
UPDATE `creature_template` SET `unit_flags2`=33589248 WHERE `entry`=36525; -- Warrior-Matic NX-01
UPDATE `creature_template` SET `unit_flags2`=33589248 WHERE `entry`=35807; -- Warrior-Matic NX-01
UPDATE `creature_template` SET `unit_flags2`=33589248 WHERE `entry`=34697; -- Warrior-Matic NX-01
UPDATE `creature_template` SET `unit_flags2`=33556481 WHERE `entry`=47502; -- Silenced Twilight Patroller
UPDATE `creature_template` SET `unit_flags2`=33556481 WHERE `entry`=47409; -- Twilight Cryomagus
UPDATE `creature_template` SET `unit_flags2`=33556481 WHERE `entry`=47407; -- Twilight Earthbinder
UPDATE `creature_template` SET `unit_flags2`=33556481 WHERE `entry`=47406; -- Twilight Sentinel
UPDATE `creature_template` SET `unit_flags2`=33556481 WHERE `entry`=47401; -- Twilight Stalker
UPDATE `creature_template` SET `unit_flags2`=33556481 WHERE `entry`=47394; -- Twilight Guardsman
UPDATE `creature_template` SET `unit_flags2`=33556481 WHERE `entry`=46345; -- Destroyed Battle Suit
UPDATE `creature_template` SET `unit_flags2`=33556481 WHERE `entry`=43250; -- Needlerock Rider
UPDATE `creature_template` SET `unit_flags2`=33556481 WHERE `entry`=43234; -- Stone Trogg Geomancer
UPDATE `creature_template` SET `unit_flags2`=33556481 WHERE `entry`=43174; -- Stone Trogg Digger
UPDATE `creature_template` SET `unit_flags2`=33556481 WHERE `entry`=43134; -- Stone Trogg Ambusher
UPDATE `creature_template` SET `unit_flags2`=33556480, `dynamicflags`=4 WHERE `entry`=45175; -- Axebite Marine
UPDATE `creature_template` SET `unit_flags2`=33556480, `dynamicflags`=4 WHERE `entry`=42823; -- Twilight Priestess
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=58287; -- Cannon [Do Not Translate]
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=58235; -- Twilight Siege Captain
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=58193; -- Wyrmrest Protector
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=57261; -- Siege Breaker Stalker
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=56126; -- Target Dummy
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=55636; -- Twilight Drake
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=55091; -- General Purpose Bunny JMF (Look 2 - Flying, Infinite AOI)
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=51313; -- Wildhammer Homesteader
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=50740; -- Crushblow Defender
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=50682; -- Victor's Point Soldier
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=49684; -- Stormtalon Rider
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=49632; -- Wildhammer Raider
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=49629; -- Krazzworks Defender
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=49628; -- Wildhammer Raider
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=49366; -- Highbank Marksman
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=49350; -- Tidebreaker Sailor
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=49344; -- Highbank Cannoneer
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=49343; -- Highbank Prison Guard
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=49342; -- Highbank Guardsman
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=49341; -- Highbank Marksman
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=49113; -- Scorch Mark Bunny JSB
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=49025; -- Highbank Cannoneer
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=49008; -- Axebite Infantry
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=48760; -- Wildhammer Lookout
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=48697; -- Ramkahen Archer
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=48543; -- Falling Rubble Bunny
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=47907; -- Tederastrasz
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=47797; -- Obsidian Charscale
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=47796; -- Obsidian Viletongue
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=47597; -- Highbank Marine
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=47491; -- Red Dragon Strafe Bunny
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=47184; -- Stone Trogg Fungalmancer
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=47168; -- Wildhammer Homesteader
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=47073; -- New Kargath Grunt
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=46756; -- Karkrog the Exterminator
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=46377; -- Cliff Thundermar
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=46321; -- Thundermar Gryphon Rider
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=46320; -- Wildhammer Warbrand
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=46310; -- Dragonmaw Marauder
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=46107; -- Victor's Point Gryphon
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=46106; -- Victor's Point Wildhammer
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45876; -- Vermillion Strafe Bunny
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45838; -- Twilight Ettin
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45798; -- Crushblow Warrior
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45795; -- Bloodeye Magelord
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45787; -- Bloodeye Brute
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45424; -- Tharm Wildfire
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45414; -- Greater Earth Elemental
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45413; -- Greater Fire Elemental
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45392; -- Hargoth Dimblaze
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45175; -- Axebite Marine
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45174; -- Highbank Marine
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45039; -- Tharm Wildfire
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45038; -- Stormcaller Jalara
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45037; -- Tawn Winterbluff
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45036; -- Hargoth Dimblaze
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45035; -- Yuldris Smolderfury
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45007; -- Enslaved Bandit
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=45001; -- Enslaved Bandit
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=44649; -- Twilight Centurion
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=44619; -- Twilight Binder
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=44220; -- Jade Rager
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=44218; -- Emerald Colossus
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=43995; -- Needlerock Mystic
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=43984; -- Deactivated War Construct
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=43960; -- Stone Trogg Reinforcement
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=43954; -- Fungal Terror
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=43871; -- War Construct
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=43319; -- Earthmender Deepvein
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=43233; -- Stonehearth Geomaster
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=43232; -- Earthen Champion
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=43228; -- Stone Trogg Berserker
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=43170; -- Earthen Geomancer
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=43169; -- Clay Mudaxle
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=43168; -- Gravel Longslab
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=43138; -- Stonehearth Defender
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=43101; -- Son of Kor
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=42823; -- Twilight Priestess
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=42607; -- Rockslice Ripper
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=42606; -- Rockslice Flayer
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=42574; -- Initiate Goldmine
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=42525; -- Jaspertip Ravager
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=42524; -- Jaspertip Borer
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=42521; -- Jaspertip Swarmer
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=39591; -- Orc Battlesworn
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=39589; -- Brute Bodyguard
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=39069; -- Alliance Paratrooper
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=39068; -- Orc Scout
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=39044; -- Orc Battlesworn
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=38928; -- Sassy Hardwrench
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=38851; -- Volcanoth Priest
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=38850; -- Volcanoth Champion
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=38746; -- Gobber
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=38745; -- Kezan Citizen
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=38511; -- Sally "Salvager" Sandscrew
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=38441; -- Ace
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=38409; -- Goblin Survivor
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=38124; -- Assistant Greely
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=38120; -- Hobart Grapplehammer
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=37710; -- Gobber
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=37708; -- Izzy
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=36615; -- Doc Zapnozzle
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=36578; -- Bastia
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=36471; -- Foreman Dampwick
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=36470; -- Foreman Dampwick
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=36464; -- Chawg
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=36425; -- Sassy Hardwrench
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=36117; -- Kilag Gorefang
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=36115; -- Aggra
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=36104; -- Orc Battlesworn
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=36103; -- SI:7 Operative
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=35769; -- Foreman Dampwick
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=35650; -- Sassy Hardwrench
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=34874; -- Megs Dreadshredder
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=34872; -- Foreman Dampwick
UPDATE `creature_template` SET `unit_flags2`=33556480 WHERE `entry`=34668; -- Sassy Hardwrench
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=56144; -- Portent of Twilight
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=56143; -- Force of Destruction
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=56142; -- Time Warden
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=56141; -- Arcane Warden
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=56140; -- Dream Warden
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=56139; -- Life Warden
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=55969; -- Harbinger of Twilight
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=55967; -- Harbinger of Destruction
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=55914; -- Champion of the Emerald Dream
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=55913; -- Champion of Time
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=55912; -- Champion of Magic
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=55911; -- Champion of Life
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=54666; -- Stormcaller Jalara
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=54665; -- Hargoth Dimblaze
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=54664; -- Tawn Winterbluff
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=54663; -- Earthcaller Torunscar
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=47799; -- Vermillion Ashmaw
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=47798; -- Vermillion Slayer
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=47685; -- Highbank Marine
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=46885; -- High Shaman MacKilligan
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=35163; -- Krom'gar Demolisher
UPDATE `creature_template` SET `unit_flags2`=33554432 WHERE `entry`=35150; -- Darnassian Glaive Thrower
UPDATE `creature_template` SET `unit_flags2`=32768 WHERE `entry`=43388; -- Doomshroom
UPDATE `creature_template` SET `unit_flags2`=32, `dynamicflags`=140 WHERE `entry`=48304; -- Training Dummy
UPDATE `creature_template` SET `unit_flags2`=32, `dynamicflags`=0 WHERE `entry`=44848; -- Training Dummy
UPDATE `creature_template` SET `unit_flags2`=32 WHERE `entry`=48304; -- Training Dummy
UPDATE `creature_template` SET `unit_flags2`=32 WHERE `entry`=44848; -- Training Dummy
UPDATE `creature_template` SET `unit_flags2`=32 WHERE `entry`=44548; -- Training Dummy
UPDATE `creature_template` SET `unit_flags2`=32 WHERE `entry`=44171; -- Training Dummy
UPDATE `creature_template` SET `unit_flags2`=2176 WHERE `entry`=55783; -- Ravenholdt Sentry
UPDATE `creature_template` SET `unit_flags2`=2064 WHERE `entry`=37107; -- Spiritual Reflection
UPDATE `creature_template` SET `unit_flags2`=2050, `dynamicflags`=0 WHERE `entry`=24171; -- [DNT] Darkmoon Faire Target Bunny
UPDATE `creature_template` SET `unit_flags2`=2050 WHERE `entry`=58570; -- [DNT] Darkmoon Faire Whack-a-Gnoll Bunny
UPDATE `creature_template` SET `unit_flags2`=2050 WHERE `entry`=46985; -- [DNT] Generic Target Bunny
UPDATE `creature_template` SET `unit_flags2`=2050 WHERE `entry`=43359; -- ELM General Purpose Bunny Infinite Hide Body
UPDATE `creature_template` SET `unit_flags2`=2050 WHERE `entry`=35009; -- North Sea Kraken Bunny
UPDATE `creature_template` SET `unit_flags2`=2050 WHERE `entry`=24288; -- ELM General Purpose Bunny Hide Body
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=8016; -- Barrens Guard
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=56894; -- Splintertree Guard
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=54507; -- Time-Twisted Scourge Beast
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=54489; -- Abomination
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=54488; -- Wailer
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=54486; -- Emberwyrm
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=5419; -- Glasshide Basilisk
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=52161; -- Foulweald Pathfinder
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=52000; -- Astranaar Sentinel
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=51196; -- Schnottz's Skeleton
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=49115; -- Schnottz Infantryman Corpse
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=48488; -- Schnottz Elite Trooper Corpse
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=48185; -- Whale Shark
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=48148; -- Sparkleshell Snapper
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=48147; -- Sparkleshell Tortoise
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=47871; -- Sludge Guard
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=47870; -- Twinkles
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=47762; -- Neferset Ritualist
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=47729; -- Neferset Savage
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=47720; -- Camel
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=47219; -- Dead Trooper
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=47216; -- Dead Trooper
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=47213; -- Dead Trooper
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=47207; -- Dead Trooper
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=46838; -- Subjugated Firestarter
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=46837; -- Drowned Wildhammer Smith
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=46810; -- Doyle Gryphon Rider
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=46809; -- Doyle Gryphon Rider
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=46629; -- Butchered Drake
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=46610; -- Twilight Miner
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=46579; -- Depths Overseer
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=46578; -- Twilight Miner
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=46441; -- Neferset Overlord
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=46003; -- Prophet Hadassi
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=45874; -- Schnottz Scout
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=45571; -- Slaughtered Trogg
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=45517; -- Ravaged Dire Wolf
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=45439; -- Cockroach
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=45372; -- Slaughtered Dragonmaw Warrior
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=45364; -- Twilight's Hammer Corpse
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=45251; -- Orc Demolisher
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=45197; -- Veteran Forsaken Trooper
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=45186; -- Sand Pygmy Corpse
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=45129; -- Lurid
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=44593; -- Fallen Human
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=44592; -- Fallen Human
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=43971; -- Stonescale Drake
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=43681; -- Moody's Blood
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=43480; -- Temperamental Rumbler
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=43261; -- Crushcog Battle Suit 1
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=4320; -- Caelyb
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=43115; -- Dormant Stonebound Elemental
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=43048; -- Captain Skullshatter
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=43032; -- Slain Cannoneer
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=42945; -- GS-9x Prototype
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=42851; -- Revenant of Neptulon
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=42682; -- Slain Crew Member
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=42681; -- Slain Crew Member
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=42381; -- Overloaded Harvest Golem
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=42259; -- Dead Thief
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=41899; -- Dark Iron Invader (Corpse)
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=41894; -- Goblin Heavy Gun
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=41158; -- Nethergarde Defender
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=41109; -- Saltstone Gazer
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=41104; -- Sparkleshell Tortoise
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=41100; -- Scorpid Reaver
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=41099; -- Saltstone Crystalhide
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=41097; -- Saltstone Basilisk
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=40662; -- Steamwheedle Victim
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=3960; -- Ulthaan
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=3956; -- Harklan Moongrove
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=3955; -- Shandrina
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=39464; -- Drowned Thunder Lizard
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=39449; -- Southsea Mercenary
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=39087; -- Slain Scarlet Friar
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=38855; -- Volcanoth
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=38696; -- Yngwie
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=36354; -- Gyrochoppa Pilot
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=36348; -- SI:7 Operative
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=36342; -- Smart Mining Monkey
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=35929; -- Poison Spitter
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=35928; -- Freezya
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=35837; -- Dead Orc Scout
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=35237; -- Pirate Party Crasher
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=35235; -- Kezan Partygoer
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=35097; -- Sacrificed Aspirant
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=34843; -- Dwarven Excavator
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=34426; -- Laughing Sister
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=34232; -- Envoy Sheelah
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=34030; -- Dark Strand Victim
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=33183; -- Bathran's Corpse
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=33040; -- Frenzied Cyclone Transform
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=33039; -- Enraged Hippogryph
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=33037; -- Caylais Moonfeather
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=33035; -- Taldan
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=33033; -- Sentinel Elissa Starbreeze
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=33001; -- Thundris Windweaver
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=31281; -- Dead Alliance Soldier
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=31177; -- Slain Alliance Soldier
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=30674; -- Frostbrood Destroyer
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=30673; -- Forgotten Depths Slayer
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=29917; -- Field Corpse (Type B)
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=29916; -- Field Corpse (Type A)
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=29454; -- Burr
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=25680; -- Marsh Caribou
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=25385; -- William Allerton
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=25343; -- Dead Caravan Worker
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=25342; -- Dead Caravan Guard
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=2346; -- Dun Garok Priest
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=2345; -- Dun Garok Rifleman
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=2344; -- Dun Garok Mountaineer
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=1835; -- Scarlet Invoker
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=17062; -- Fel Orc Corpse
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=14901; -- Peon
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=11749; -- Feran Strongwind
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=11682; -- Warsong Grunt
UPDATE `creature_template` SET `unit_flags2`=16779264 WHERE `entry`=45809; -- Swampshore Makrura
UPDATE `creature_template` SET `unit_flags2`=16779264 WHERE `entry`=43532; -- Muckdweller
UPDATE `creature_template` SET `unit_flags2`=134219776 WHERE `entry`=46141; -- Obsidian Pyrewing
UPDATE `creature_template` SET `unit_flags2`=133120 WHERE `entry`=47203; -- Creeper Egg
UPDATE `creature_template` SET `unit_flags2`=100696064 WHERE `entry`=49693; -- Rocknut
UPDATE `creature_template` SET `unit_flags2`=100665344 WHERE `entry`=55971; -- Deathwing
UPDATE `creature_template` SET `unit_flags2`=1 WHERE `entry`=47399; -- Dead Miner
UPDATE `creature_template` SET `unit_flags2`=1 WHERE `entry`=47344; -- Doyle Gryphon
UPDATE `creature_template` SET `unit_flags2`=1 WHERE `entry`=46609; -- Dunwald Victim
UPDATE `creature_template` SET `unit_flags2`=1 WHERE `entry`=46100; -- Salvageable Shredder
UPDATE `creature_template` SET `unit_flags2`=1 WHERE `entry`=43150; -- Impaled Blackrock Orc
UPDATE `creature_template` SET `unit_flags2`=0, `dynamicflags`=4 WHERE `entry`=47221; -- Schnottz Supply Chopper
UPDATE `creature_template` SET `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=39596; -- Teeming Waterguard
UPDATE `creature_template` SET `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=39595; -- Furious Earthguard
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=6172; -- Henze Faulk
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=55779; -- Thrall
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=55085; -- Peroth'arn
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=54971; -- Thrall
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=54643; -- Enemy MiniZep
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=54642; -- Enemy Tonk
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=54634; -- Thrall
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=54548; -- Thrall
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=54518; -- Injured Carnie
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=50525; -- Chris Miller
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=49570; -- Wounded Axebite Warrior
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=48428; -- Myzerian
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=48305; -- Injured Employee
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=48201; -- Blackrock Sergeant
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=47686; -- SI:7 Marksman
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=47395; -- Injured Miner
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=47221; -- Schnottz Supply Chopper
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=47204; -- Infested Bear
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=46977; -- Mullan Gryphon
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=46969; -- Mullan Gryphon
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=46968; -- Mullan Gryphon
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=46939; -- Mullan Gryphon
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=46416; -- Twilight Skyterror
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=45866; -- Novrastrasz
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=45857; -- Celastrasza
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=45560; -- Acridostrasz
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=45199; -- Wounded Brave
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=45196; -- Orc Sea Dog
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=44564; -- Wounded Trainee
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=44057; -- Riverboat
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=43229; -- Injured Earthen
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=42907; -- Cocooned Victim
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=42673; -- Hellscream Demolisher
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=42501; -- Wounded Infantry
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=42098; -- Invisible Stalker (Cataclysm Boss, Ignore Combat, Floating)
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=40604; -- Steamwheedle Rescue Balloon
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=3920; -- Anilia
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=39081; -- Hazzali Cocoon
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=39039; -- Gnomeregan Stealth Fighter
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=38805; -- Wounded Defender
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=35444; -- The Black Knight
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=34925; -- North Sea Kraken
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=33780; -- Argent Watchman
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=33698; -- Argent Peacekeeper
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=32661; -- SOTA Alliance Gun 2
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=32656; -- SOTA Horde Gun 1
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=32654; -- SOTA Alliance Gun 1
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=32223; -- Skybreaker Transport Pilot
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=32222; -- Skybreaker Infiltrator
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=31891; -- Kor'kron Transport Pilot
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=31882; -- Kor'kron Infiltrator
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=31833; -- Kor'kron Squad Leader
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=31832; -- Kor'kron Infantry
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=31737; -- Skybreaker Squad Leader
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=31701; -- Skybreaker Infantry
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=28801; -- Argent Stand Defender
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=28408; -- Primordial Drake Egg
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=27894; -- Antipersonnel Cannon
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=26355; -- [DND] Midsummer Bonfire Faction Bunny - H
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=26258; -- [DND] Midsummer Bonfire Faction Bunny - A
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=22431; -- Anchorite Barada
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=12858; -- Torek
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=12423; -- Guard Roberts
UPDATE `creature_template` SET `unit_class`=1, `dynamicflags`=0 WHERE `entry`=4834; -- Theramore Infiltrator
UPDATE `creature_template` SET `unit_class`=1, `dynamicflags`=0 WHERE `entry`=1425; -- Grizlak
UPDATE `creature_template` SET `speed_walk`=5.714286, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25849; -- Fezzix Geartwist
UPDATE `creature_template` SET `speed_walk`=5.714286, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23805; -- Vengeance Landing Cannon Controller
UPDATE `creature_template` SET `speed_walk`=5, `speed_run`=4.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23051; -- Monstrous Kaliri
UPDATE `creature_template` SET `speed_walk`=4.285714, `speed_run`=12, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22317; -- Netherwing Drake Escape Dummy
UPDATE `creature_template` SET `speed_walk`=4.285714, `speed_run`=12, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21310; -- Shadowmoon Valley Invisible Trigger (Tiny)
UPDATE `creature_template` SET `speed_walk`=4.285714, `speed_run`=12, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21052; -- Camera Shaker - Altar of Damnation
UPDATE `creature_template` SET `speed_walk`=3.714286, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23346; -- Wing Commander Mulverick
UPDATE `creature_template` SET `speed_walk`=3.571429, `speed_run`=4.8, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=10 WHERE `entry`=24770; -- Nexus Watcher
UPDATE `creature_template` SET `speed_walk`=3.571429, `speed_run`=3.6, `rangeattacktime`=2000, `unit_flags`=32768, `unit_flags2`=0, `dynamicflags`=0, `HoverHeight`=5.2 WHERE `entry`=30275; -- Wild Wyrm
UPDATE `creature_template` SET `speed_walk`=3.571429, `speed_run`=10, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=30466; -- Weathered Flying Machine
UPDATE `creature_template` SET `speed_walk`=3.571429, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=23335; -- Skyguard Khatie
UPDATE `creature_template` SET `speed_walk`=3.428571, `speed_run`=4, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=15 WHERE `entry`=31393; -- Crystal Wyrm
UPDATE `creature_template` SET `speed_walk`=3.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26572; -- Kor'kron War Rider
UPDATE `creature_template` SET `speed_walk`=3.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23345; -- Wing Commander Ichman
UPDATE `creature_template` SET `speed_walk`=3.142857, `speed_run`=6, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=2.25 WHERE `entry`=29798; -- Hyldsmeet Proto-Drake
UPDATE `creature_template` SET `speed_walk`=3.142857, `speed_run`=6, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=2.25 WHERE `entry`=29625; -- Hyldsmeet Proto-Drake
UPDATE `creature_template` SET `speed_walk`=3.142857, `speed_run`=6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30707; -- [DND] Icecrown Airship (H) - Cannon Controller 01
UPDATE `creature_template` SET `speed_walk`=3.142857, `speed_run`=6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30700; -- [DND] Icecrown Airship (H) - Cannon, Neutral
UPDATE `creature_template` SET `speed_walk`=3.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28614; -- Scarlet Gryphon
UPDATE `creature_template` SET `speed_walk`=3.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23344; -- Corlok the Vet
UPDATE `creature_template` SET `speed_walk`=3, `speed_run`=8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27869; -- Wintergrasp Detection Unit
UPDATE `creature_template` SET `speed_walk`=3, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25765; -- Fizzcrank Bomber
UPDATE `creature_template` SET `speed_walk`=2.857143, `speed_run`=8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30302; -- Helm Sparkle Bunny
UPDATE `creature_template` SET `speed_walk`=2.857143, `speed_run`=6.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21075; -- Infernal Target (Hyjal)
UPDATE `creature_template` SET `speed_walk`=2.857143, `speed_run`=4, `rangeattacktime`=2000, `unit_flags`=256, `dynamicflags`=0 WHERE `entry`=32185; -- Infinite Eradicator
UPDATE `creature_template` SET `speed_walk`=2.857143, `speed_run`=4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32186; -- Infinite Timebreaker
UPDATE `creature_template` SET `speed_walk`=2.857143, `speed_run`=3.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30335; -- Shadow Vault Gryphon
UPDATE `creature_template` SET `speed_walk`=2.857143, `speed_run`=2.8, `rangeattacktime`=2000, `unit_flags`=256, `dynamicflags`=0 WHERE `entry`=24882; -- Brutallus
UPDATE `creature_template` SET `speed_walk`=2.857143, `speed_run`=2, `rangeattacktime`=2000, `unit_flags`=256, `dynamicflags`=0 WHERE `entry`=26231; -- Saragosa
UPDATE `creature_template` SET `speed_walk`=2.857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23342; -- Trope the Filth-Belcher
UPDATE `creature_template` SET `speed_walk`=2.857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22268; -- Leokk
UPDATE `creature_template` SET `speed_walk`=2.857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22112; -- Karynaku
UPDATE `creature_template` SET `speed_walk`=2.857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21657; -- Neltharaku
UPDATE `creature_template` SET `speed_walk`=2.857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18418; -- Nethrandamus
UPDATE `creature_template` SET `speed_walk`=2.571429, `speed_run`=7.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16598; -- Eye of Thrallmar
UPDATE `creature_template` SET `speed_walk`=2.571429, `speed_run`=4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27542; -- Ruby Watcher
UPDATE `creature_template` SET `speed_walk`=2.571429, `speed_run`=4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19849; -- Scrap Reaver X6000
UPDATE `creature_template` SET `speed_walk`=2.571429, `speed_run`=2.8, `rangeattacktime`=2000, `unit_flags`=33024, `dynamicflags`=0 WHERE `entry`=27249; -- Alystros the Verdant Keeper
UPDATE `creature_template` SET `speed_walk`=2.571429, `speed_run`=2.8, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=27530; -- Ruby Keeper
UPDATE `creature_template` SET `speed_walk`=2.571429, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26286; -- Emberwyrm
UPDATE `creature_template` SET `speed_walk`=2.571429, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15242; -- Bat Rider Guard
UPDATE `creature_template` SET `speed_walk`=2.571429, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=2 WHERE `entry`=29501; -- Scourge Gryphon
UPDATE `creature_template` SET `speed_walk`=2.571429, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=24844; -- Kalecgos
UPDATE `creature_template` SET `speed_walk`=2.571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=5 WHERE `entry`=23557; -- Dragonflayer Raider
UPDATE `creature_template` SET `speed_walk`=2.571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25817; -- Oiled Fledgeling
UPDATE `creature_template` SET `speed_walk`=2.571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25748; -- Oil-covered Hawk
UPDATE `creature_template` SET `speed_walk`=2.571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24747; -- Fjord Hawk
UPDATE `creature_template` SET `speed_walk`=2.571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23340; -- Murg "Oldie" Muckjaw
UPDATE `creature_template` SET `speed_walk`=2.428571, `speed_run`=3.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27682; -- Azure Drake
UPDATE `creature_template` SET `speed_walk`=2.428571, `speed_run`=3.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26925; -- Wyrmrest Temple Drake
UPDATE `creature_template` SET `speed_walk`=2.285714, `speed_run`=3.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18102; -- Kalandrios
UPDATE `creature_template` SET `speed_walk`=2.285714, `speed_run`=3.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18101; -- Aborius
UPDATE `creature_template` SET `speed_walk`=2.285714, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15250; -- Qiraji Slayer
UPDATE `creature_template` SET `speed_walk`=2.285714, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23269; -- Barash the Den Mother
UPDATE `creature_template` SET `speed_walk`=2.285714, `speed_run`=1.6, `rangeattacktime`=2000, `unit_flags`=832, `dynamicflags`=0 WHERE `entry`=37126; -- Sister Svalna
UPDATE `creature_template` SET `speed_walk`=2.285714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=832, `dynamicflags`=0 WHERE `entry`=26247; -- Lady Liadrin
UPDATE `creature_template` SET `speed_walk`=2.285714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=21153; -- Kor'kron Wyvern Rider
UPDATE `creature_template` SET `speed_walk`=2.285714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=19364; -- Kor'kron Rider
UPDATE `creature_template` SET `speed_walk`=2.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27224; -- Forgotten Knight
UPDATE `creature_template` SET `speed_walk`=2.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24172; -- Daggercap Hawk
UPDATE `creature_template` SET `speed_walk`=2.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22441; -- Teribus the Cursed
UPDATE `creature_template` SET `speed_walk`=2.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19003; -- Allerian Horseman
UPDATE `creature_template` SET `speed_walk`=2.285714, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21648; -- Mature Netherwing Drake
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32534; -- Scalesworn Elite
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.8, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0, `HoverHeight`=7.5 WHERE `entry`=26933; -- Wyrmrest Guardian
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=4 WHERE `entry`=27629; -- Wyrmrest Defender
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=12.5 WHERE `entry`=27608; -- Azure Dragon
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27608; -- Azure Dragon
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.8, `baseattacktime`=1600, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15984; -- Sartura's Royal Guard
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.8, `baseattacktime`=1200, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15516; -- Battleguard Sartura
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.4, `rangeattacktime`=2000, `unit_flags`=66, `dynamicflags`=0 WHERE `entry`=15263; -- The Prophet Skeram
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.4, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=15262; -- Obsidian Eradicator
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=12 WHERE `entry`=15249; -- Qiraji Lasher
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=12 WHERE `entry`=15236; -- Vekniss Wasp
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15544; -- Vem
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15543; -- Princess Yauj
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15511; -- Lord Kri
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15510; -- Fankriss the Unyielding
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15509; -- Princess Huhuran
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15249; -- Qiraji Lasher
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15236; -- Vekniss Wasp
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2.4, `baseattacktime`=1300, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=15299; -- Viscidus
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=12 WHERE `entry`=15240; -- Vekniss Hive Crawler
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23772; -- Spotted Hippogryph
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15240; -- Vekniss Hive Crawler
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=12, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=25966; -- Shaman Beam Bunny 002
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15277; -- Anubisath Defender
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=19157; -- Captured Halaani Vindicator
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `unit_flags2`=0, `dynamicflags`=4 WHERE `entry`=18256; -- Alliance Halaani Guard
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=18256; -- Alliance Halaani Guard
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26422; -- Budd
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26174; -- Carrion Condor
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23257; -- Skyguard Windcharger
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21931; -- Avian Flyer
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19152; -- Interrogator Khan
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19151; -- Captured Halaani Blood Knight
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15276; -- Emperor Vek'lor
UPDATE `creature_template` SET `speed_walk`=2.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15275; -- Emperor Vek'nilash
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=2.8, `rangeattacktime`=2000, `unit_flags`=33024, `dynamicflags`=0 WHERE `entry`=25881; -- Moria
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31291; -- (Wrathgate Monster) Forsaken Catapult
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=2.4, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=29664; -- Ragemane
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=2.4, `rangeattacktime`=2000, `unit_class`=2, `dynamicflags`=0, `HoverHeight`=7.5 WHERE `entry`=26858; -- Sarathstra
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1.6, `rangeattacktime`=2000 WHERE `entry`=25332; -- Stitched Warsong Horror
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=3.75 WHERE `entry`=26841; -- Reanimated Frost Wyrm
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27213; -- Onslaught Warhorse
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33429; -- Boneguard Lieutenant
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30002; -- Duke Lankral
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29343; -- Baron Sliver
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28821; -- Mine Car
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25596; -- Infected Kodo Beast
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24518; -- Talonshrike
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18069; -- Mogor
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=4 WHERE `entry`=18402; -- Warmaul Champion
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1, `baseattacktime`=1818, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=34127; -- Boneguard Commander
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=0.8333319, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25390; -- En'kilah Hatchling
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=0.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21903; -- Nether Cloud01
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=0.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20771; -- Razaani Light Orb - Mini
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=0.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20635; -- Razaani Light Orb
UPDATE `creature_template` SET `speed_walk`=1.857143, `speed_run`=2, `rangeattacktime`=2000 WHERE `entry`=25333; -- Undying Aggressor
UPDATE `creature_template` SET `speed_walk`=1.857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27220; -- Forgotten Captain
UPDATE `creature_template` SET `speed_walk`=1.857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24142; -- Camp Winterhoof Wind Rider
UPDATE `creature_template` SET `speed_walk`=1.857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15380; -- Arygos
UPDATE `creature_template` SET `speed_walk`=1.857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15379; -- Caelestrasz
UPDATE `creature_template` SET `speed_walk`=1.857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15378; -- Merithra of the Dream
UPDATE `creature_template` SET `speed_walk`=1.828571 WHERE `entry`=37207; -- Plains Pridemane
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=3.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=36808; -- Deathspeaker Zealot
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=3.2, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=36829; -- Deathspeaker High Priest
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=3.2, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=36811; -- Deathspeaker Attendant
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=3.2, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=36807; -- Deathspeaker Disciple
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=3.2, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=36805; -- Deathspeaker Servant
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=2.8, `rangeattacktime`=2000, `unit_flags`=33024, `dynamicflags`=0 WHERE `entry`=18707; -- Torgos
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32540; -- Lillehoff
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30455; -- Frostworg
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30294; -- Frostworg Denmother
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30262; -- Son of Hodir
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30105; -- King Jokkum
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21404; -- Legion Hold Fel Reaver
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=12 WHERE `entry`=15235; -- Vekniss Stinger
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25509; -- Priestess of Torment
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15235; -- Vekniss Stinger
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24850; -- Kalecgos
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=2, `rangeattacktime`=2000 WHERE `entry`=36597; -- The Lich King
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=12, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=25965; -- Shaman Beam Bunny 001
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28357; -- Instructor Razuvious
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1.6, `rangeattacktime`=2000, `unit_flags`=2147516480, `dynamicflags`=0 WHERE `entry`=18731; -- Ambassador Hellmaw
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31251; -- Shadow Vault Skirmisher
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25707; -- Magic-bound Ancient
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21879; -- Vilewing Chimaera
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15264; -- Anubisath Sentinel
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15252; -- Qiraji Champion
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15247; -- Qiraji Brainwasher
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15246; -- Qiraji Mindslayer
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15233; -- Vekniss Guardian
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15230; -- Vekniss Warrior
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=36678; -- Professor Putricide
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33280, `dynamicflags`=0 WHERE `entry`=17765; -- Alliance Silithyst Sentinel
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30174; -- Hyldsmeet Warbear
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26418; -- Longhoof Grazer
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22980; -- Skyguard Scout
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18978; -- Heckling Fel Sprite
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15229; -- Vekniss Soldier
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=18401; -- Skra'gath
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33600, `dynamicflags`=0 WHERE `entry`=37200; -- Muradin Bronzebeard
UPDATE `creature_template` SET `speed_walk`=1.714286, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=37187; -- High Overlord Saurfang
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26725; -- Wind Tamer Oril
UPDATE `creature_template` SET `speed_walk`=1.5873, `speed_run`=2.8, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=30163; -- Dead Iron Giant
UPDATE `creature_template` SET `speed_walk`=1.5873, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=9 WHERE `entry`=37534; -- Spinestalker
UPDATE `creature_template` SET `speed_walk`=1.5873, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=9 WHERE `entry`=37533; -- Rimefang
UPDATE `creature_template` SET `speed_walk`=1.5873, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37528; -- Spire Frostwyrm (Ambient)
UPDATE `creature_template` SET `speed_walk`=1.5873, `speed_run`=1.444444, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=4 WHERE `entry`=31265; -- Savage Proto-Drake
UPDATE `creature_template` SET `speed_walk`=1.5873, `speed_run`=1.444444, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=4 WHERE `entry`=29590; -- Blighted Proto-Drake
UPDATE `creature_template` SET `speed_walk`=1.5873, `speed_run`=1.444444, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23750; -- Proto-Whelp Hatchling
UPDATE `creature_template` SET `speed_walk`=1.5873, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29984; -- Iron Sentinel
UPDATE `creature_template` SET `speed_walk`=1.5873, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29974; -- Niffelem Forefather
UPDATE `creature_template` SET `speed_walk`=1.5873, `speed_run`=0.888888, `baseattacktime`=1500, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=36627; -- Rotface
UPDATE `creature_template` SET `speed_walk`=1.5873, `speed_run`=0.888888, `baseattacktime`=1500, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=36626; -- Festergut
UPDATE `creature_template` SET `speed_walk`=1.571429, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29350; -- Torseg the Exiled
UPDATE `creature_template` SET `speed_walk`=1.571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26369; -- Imperial Eagle
UPDATE `creature_template` SET `speed_walk`=1.428571, `unit_flags`=8388864 WHERE `entry`=32322; -- Gold Warrior
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=3.2, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=4 WHERE `entry`=29753; -- Stormpeak Wyrm
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21497; -- Blackscale
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2.4, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=15727; -- C'Thun
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25851; -- Volatile Fiend
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25599; -- Cataclysm Hound
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25597; -- Oblivion Mage
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25595; -- Chaos Gazer
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25593; -- Apocalypse Guard
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25592; -- Doomfire Destroyer
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25591; -- Painbringer
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15300; -- Vekniss Drone
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2, `rangeattacktime`=2000, `unit_flags`=33587520, `dynamicflags`=0 WHERE `entry`=37007; -- Deathbound Ward
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31323; -- Lithe Stalker
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29928; -- Gymer Lock Dummy
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29647; -- Gymer
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27244; -- Emerald Skytalon
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25508; -- Shadowsword Guardian
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25507; -- Sunblade Protector
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21166; -- Illidari Dreadlord
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=2, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=12 WHERE `entry`=37038; -- Vengeful Fleshreaper
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=4 WHERE `entry`=37955; -- Blood-Queen Lana'thel
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=4 WHERE `entry`=23689; -- Proto-Drake
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29409; -- Garm Watcher
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28709; -- Acherus Geist
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27292; -- Flamebringer
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27005; -- Chilltusk
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25867; -- Sunblade Dragonhawk
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22843; -- Rook
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22842; -- Corvax
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22204; -- Fear Fiend
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22195; -- Wrath Speaker
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22181; -- Aether Ray
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21326; -- Raven's Wood Leafbeard
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21033; -- Bladewing Bloodletter
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19973; -- Abyssal Flamebringer
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags2`=1, `dynamicflags`=32 WHERE `entry`=37973; -- Prince Taldaram
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags2`=1, `dynamicflags`=32 WHERE `entry`=37972; -- Prince Keleseth
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags2`=1, `dynamicflags`=32 WHERE `entry`=37970; -- Prince Valanar
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=37540; -- The Skybreaker
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=37215; -- Orgrim's Hammer
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=38004; -- Blood-Queen Lana'thel
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21123; -- Felsworn Scalewing
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.6, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20749; -- Scalewing Serpent
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.444444, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=1.2 WHERE `entry`=29755; -- Stormpeak Hatchling
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.4, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=9167; -- Frenzied Pterrordax
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.4, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=23501; -- Netherwing Ray
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.4, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=21901; -- Netherskate
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=9166; -- Pterrordax
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=6554; -- Gorishi Stinger
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=6551; -- Gorishi Wasp
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24673; -- Frostwing Chimaera
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21324; -- Spirit Raven
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.2, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=31293; -- (Wrathgate Monster) Angrathar Aberration
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26126; -- Bone Warrior
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25660; -- Festering Ghoul
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25393; -- En'kilah Ghoul
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24027; -- Sergeant Gorth
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23264; -- Overmine Flayer
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21042; -- Dire Raven
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1.2, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31266; -- Shadow Vault Assaulter
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=26540; -- Drenk Spannerspark
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=570590016, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=37127; -- Ymirjar Frostbinder
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=5056; -- Deviate Dreadfang
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=39371; -- King Varian Wrynn
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37190; -- Alliance Commander
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32476; -- Copperpot Goon
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31900; -- Scourge Banner-Bearer
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31267; -- Ymirjar Element Shaper
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30074; -- The Leaper
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30046; -- Yulda the Stormspeaker
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30041; -- Thyra Kvinnshal
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30010; -- Fylla Ingadottir
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29981; -- Earthen Warder
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29980; -- Earthen Elite
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29975; -- Lok'lira the Crone
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29960; -- Earthen Stoneguard
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29808; -- Stormcrest Hatchling
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29331; -- Sifreldar Runekeeper
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26370; -- Arcanimus
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25992; -- Big Bruiser
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25396; -- Naxxanar Skeletal Mage
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25372; -- Sunblade Scout
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25371; -- Sunblade Dawn Priest
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25370; -- Sunblade Dusk Priest
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25369; -- Sunblade Vindicator
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25368; -- Sunblade Slayer
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25367; -- Sunblade Arch Mage
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25363; -- Sunblade Cabalist
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23977; -- Abandoned Pack Mule
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22497; -- V'eru
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22323; -- Incandescent Fel Spark
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21659; -- Floaty Flavor Eye
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21519; -- Death's Might
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20485; -- Area 52 Bruiser
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20484; -- Area 52 Big Bruiser
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19667; -- Consortium Nether Runner
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18924; -- Artificer Andren
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18921; -- Artificer Drenin
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18800; -- Worker
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18528; -- Xi'ri
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18525; -- G'eras
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18481; -- A'dal
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18469; -- Royal Teromoth
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18468; -- Teromoth
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18437; -- Vicious Teromoth
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17538; -- O'ros
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16734; -- Funaam
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16349; -- Ghostclaw Ravager
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16348; -- Ghostclaw Lynx
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16347; -- Starving Ghostclaw
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15317; -- Qiraji Scorpion
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15316; -- Qiraji Scarab
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000 WHERE `entry`=32273; -- Infinite Corruptor
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=12 WHERE `entry`=37023; -- Plague Scientist
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=37830; -- Skybreaker Marine
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=0.888888, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27654; -- Drakos the Interrogator
UPDATE `creature_template` SET `speed_walk`=1.428571, `speed_run`=0.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17201; -- Moongraze Buck
UPDATE `creature_template` SET `speed_walk`=1.428571 WHERE `entry`=33643; -- Silver Covenant Guardian
UPDATE `creature_template` SET `speed_walk`=1.388889, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=16951; -- Terrorfiend
UPDATE `creature_template` SET `speed_walk`=1.388889, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21314; -- Terrormaster
UPDATE `creature_template` SET `speed_walk`=1.388889, `speed_run`=0.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24933; -- Suspended Terrorguard
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32201; -- Orgrim's Hammer Scout
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=2, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17129; -- Greater Windroc
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=22410; -- Expedition Outrider
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=19068; -- Garadar Wolf Rider
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=21427; -- Strider Jock
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=34179; -- Argent Peacekeeper
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=31153; -- Tactical Officer Ahbramis
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=31036; -- Commander Zanneth
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0, `VehicleId`=25 WHERE `entry`=28446; -- Fury
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=39172; -- Marshal Magruder
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=38500; -- Argent Warhorse
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=34125; -- Stabled Campaign Warhorse
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32609; -- Hansen's Warhorse
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30263; -- Silver Covenant Horseman
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28611; -- Scarlet Captain
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28530; -- Scarlet Commander
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28444; -- Highlord Darion Mograine
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28014; -- Transformed Warhorse
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27922; -- Ranger Captain Areiel
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27783; -- Scout Captain Carter
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27550; -- Conquest Hold Champion
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27549; -- Westfall Brigade Elite
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27367; -- Onslaught Death Knight
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27074; -- Bor'gorok Wolf
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27028; -- Hansel Bauer
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26907; -- Tisha Longbridge
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26426; -- Arctic Ram
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25326; -- Overlord Bor'gorok
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24768; -- Deathstalker Hayward
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24653; -- Flying Machine
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23998; -- Deathstalker Razael
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23740; -- Frosthorn Ram
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23466; -- Voranaku
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23465; -- Zoya
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23464; -- Malfas
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23463; -- Onyxien
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23462; -- Jorus
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23461; -- Suraku
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23188; -- Dragonmaw Transporter
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22987; -- Skyguard Nether Ray
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22364; -- Scout Navrin
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22274; -- Dragonmaw Skybreaker
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22018; -- Eclipsion Cavalier
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21979; -- Val'zareq the Conqueror
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21719; -- Dragonmaw Drake-Rider
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20850; -- Great Purple Elekk
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20849; -- Great Green Elekk
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20848; -- Great Blue Elekk
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20847; -- Purple Elekk
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20846; -- Gray Elekk
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20509; -- Swift Blue Riding Gryphon
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20508; -- Swift Red Riding Gryphon
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20507; -- Swift Purple Riding Gryphon
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20506; -- Swift Green Riding Gryphon
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20505; -- Snowy Gryphon Mount
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20504; -- Golden Gryphon
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20503; -- Ebon Gryphon
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19806; -- Eclipsion Bloodwarder
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19795; -- Eclipsion Blood Knight
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19687; -- Shattrath City Peacekeeper
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19659; -- Great Elite Elekk
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19658; -- Brown Elekk
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19635; -- Captain Arathyn
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19607; -- Grek's Riding Wolf
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19390; -- Mounted Neophyte
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19379; -- Sky'ree
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18549; -- Aldor Vindicator
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18238; -- Murkblood Invader
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15545; -- Cenarion Outrider
UPDATE `creature_template` SET `speed_walk`=1.385714, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37586; -- Fury
UPDATE `creature_template` SET `speed_walk`=1.385714 WHERE `entry`=41870; -- Krom'gar Enforcer
UPDATE `creature_template` SET `speed_walk`=1.385714 WHERE `entry`=33543; -- Sunreaver Guardian
UPDATE `creature_template` SET `speed_walk`=1.385714 WHERE `entry`=32597; -- Dalaran Visitor
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=27944; -- Johan
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=12 WHERE `entry`=10404; -- Pustulating Horror
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31224; -- Icefury
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31150; -- Plagued Fiend
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30846; -- Glacial Spirit
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28793; -- Darmuk
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28641; -- Blighted Corpse
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28612; -- Knight of the Silver Hand
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28510; -- Scourge Commander Thalanor
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26948; -- Hulking Atrocity
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26585; -- Bloodmist
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26202; -- Ziggurat Defender
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26103; -- Darkfallen Deathblade
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25750; -- Oil-soaked Caribou
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25611; -- Warsong Aberration
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23780; -- High Executor Anselm
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21728; -- Skettis Surger
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21059; -- Enraged Water Spirit
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20090; -- Bloodscale Sentry
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20079; -- Darkcrest Sentry
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17358; -- Fouled Water Spirit
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17155; -- Lake Surger
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17154; -- Muck Spawn
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17153; -- Lake Spirit
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16570; -- Crazed Water Spirit
UPDATE `creature_template` SET `speed_walk`=1.289683, `speed_run`=1, `baseattacktime`=5000, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=31309; -- (Wrathgate Scourge) Plague Eruptor
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28599; -- Plagueroach
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=2, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=25387; -- En'kilah Gargoyle
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25387; -- En'kilah Gargoyle
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=12, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=25964; -- Shaman Beam Bunny 000
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=570590016, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=37134; -- Ymirjar Huntress
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=25973; -- Shaman Bonfire Bunny 002
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=25972; -- Shaman Bonfire Bunny 001
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=25971; -- Shaman Bonfire Bunny 000
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=134219776, `dynamicflags`=0 WHERE `entry`=29694; -- Hyldsmeet Drakerider
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30876; -- Earthbound Revenant
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30574; -- Arion
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30573; -- Duke
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30175; -- Hyldsmeet Bear Rider
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30160; -- Brittle Revenant
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30012; -- Victorious Challenger
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30006; -- Warsmith Sigfinna
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29857; -- Frostbite
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29569; -- Valkyrion Aspirant
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29551; -- Brunnhildar Bearhandler
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29436; -- Icetouched Earthrager
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29366; -- Brunnhildar Challenger
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29328; -- Arctic Hare
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29323; -- Sifreldar Storm Maiden
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28008; -- Galakrond Spell Dummy
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28006; -- Grand Necrolord Antiok
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27912; -- Pepper
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27911; -- Nell
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27259; -- Dragonflayer Flamebinder
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26663; -- Winterskorn Hunter
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26472; -- Highland Mustang
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=1, `baseattacktime`=2400, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=4 WHERE `entry`=30025; -- Erathius, King of Dirt
UPDATE `creature_template` SET `speed_walk`=1.285714, `speed_run`=0.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28005; -- Wastes Scavenger
UPDATE `creature_template` SET `speed_walk`=1.214286, `speed_run`=1, `baseattacktime`=1000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=36612; -- Lord Marrowgar
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1.111112, `rangeattacktime`=2000, `unit_flags`=570720512, `unit_flags2`=1, `dynamicflags`=32 WHERE `entry`=28113; -- Mosswalker Victim
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=28025; -- Rainspeaker Oracle
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=28024; -- Rainspeaker Warrior
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=29618; -- Snowblind Follower
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31910; -- Geen
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29461; -- Icetip Crawler
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29412; -- Crystalweb Spitter
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29411; -- Crystalweb Weaver
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29407; -- Snowblind Devotee
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29404; -- Savage Hill Scavenger
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29121; -- Soo-yum
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29037; -- Soo-jam
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29006; -- Oracle Soo-nee
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28653; -- Salanar the Horseman
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28140; -- Gorloc Hatchling
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28027; -- High-Oracle Soo-say
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27701; -- Gjalerhorn Worker
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27699; -- Gjalerhorn Scavenger
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27362; -- Smoldering Construct
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25701; -- Gorloc Dredger
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25700; -- Gorloc Hunter
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25699; -- Gorloc Mud Splasher
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25428; -- Magmoth Shaman
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25427; -- Kaganishu
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22180; -- Shard-Hide Boar
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21878; -- Felboar
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=1, `baseattacktime`=1000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37011; -- The Damned
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31404; -- Azure Manabeast
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26281; -- Moonrest Stalker
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25718; -- Coldarra Mage Slayer
UPDATE `creature_template` SET `speed_walk`=1.190476, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23930; -- Trained Plaguehound
UPDATE `creature_template` SET `speed_walk`=1.190476, `dynamicflags`=0 WHERE `entry`=8917; -- Quarry Slave
UPDATE `creature_template` SET `speed_walk`=1.142857, `unit_flags`=33587200 WHERE `entry`=28221; -- Trapdoor Crawler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=3.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27496; -- Refurbished Shredder
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=2, `rangeattacktime`=2000, `unit_flags`=536871744, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=26291; -- Crystalline Ice Giant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=20611; -- Shimmerwing Moth
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24899; -- "Scoodles"
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=22995; -- Chort
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=22941; -- Mog'dorg the Wizened
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=20757; -- Fingrom
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=20600; -- Maggoc
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=18880; -- Nether Ray
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=6508; -- Venomhide Ravasaur
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=6507; -- Ravasaur Hunter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22940; -- Grok
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22384; -- Bloodmaul Soothsayer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22160; -- Bloodmaul Taskmaster
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20887; -- Deathforge Imp
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20765; -- Bladespire Crusher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20731; -- Droggam
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20730; -- Glumdor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20726; -- Mugdorg
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20723; -- Korgaah
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19994; -- Bloodmaul Warlock
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19993; -- Bloodmaul Mauler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19948; -- Bloodmaul Skirmisher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18879; -- Phase Hunter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23362; -- Torki
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23347; -- Tork
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.555556, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30849; -- Chilled Earth Elemental
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.555556, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29124; -- Lifeblood Elemental
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.555556, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28411; -- Frozen Earth
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.555556, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28387; -- Zim'Torga Defender
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.555556, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26316; -- Crystalline Ice Elemental
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.555556, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25715; -- Frozen Elemental
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.555556, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22313; -- Rumbling Earth-Heart
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.555556, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21050; -- Enraged Earth Spirit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.555556, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18881; -- Sundered Rumbler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.555556, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18062; -- Enraged Crusher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.555556, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17157; -- Shattered Rumbler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.555556, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17156; -- Tortured Earth Spirit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19378; -- Anchorite Nindumen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.388888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29794; -- Sirana Iceshriek
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.388888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29793; -- Frostfeather Witch
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.388888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29792; -- Frostfeather Screecher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.388888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26577; -- Coldwind Witch
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.388888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26575; -- Coldwind Waste Huntress
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.2, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=28150; -- Destroyed Siege Tank
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29623; -- Savage Hill Brute
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23875; -- Blacksouled Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=20126; -- Sylvanaar Ancient Protector
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=18077; -- Umbrafen Oracle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=8816; -- Deathly Usher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29133; -- Disturbed Soul
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26455; -- Moonrest Highborne
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24638; -- Keeper Witherleaf
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22307; -- Rotting Forest-Rager
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22130; -- Baron Sablemane's Blackwhelp
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22108; -- Blackwhelp
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22053; -- Mosswood the Ancient
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20270; -- Feralfen Druid
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19162; -- Lost One Refugee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18457; -- Tuurem Hunter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18456; -- Tuurem Scavenger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18197; -- Elder Kuruti
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18114; -- Feralfen Mystic
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18113; -- Feralfen Hunter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18079; -- Umbrafen Seer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17589; -- Veridian Broodling
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17588; -- Veridian Whelp
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17141; -- Windyreed Wretch
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17139; -- Windyreed Scavenger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1.111112, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=13698; -- Keeper Marandis
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `unit_flags`=0 WHERE `entry`=51674; -- Sand-Husk Scarab
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=36208; -- Xerash Fireblade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=26558; -- Nutaaq
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=26425; -- Drakkari Warrior
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=26371; -- Squire Walter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=25610; -- Scourge Prisoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=21277; -- Vindicator Vuuleen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=15066; -- Cleo
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=15065; -- Lady
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768 WHERE `entry`=25465; -- Kel'Thuzad
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=67141632, `dynamicflags`=4 WHERE `entry`=18124; -- Withered Giant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=67108864, `dynamicflags`=4 WHERE `entry`=17131; -- Talbuk Thorngrazer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=67108864, `dynamicflags`=132 WHERE `entry`=24547; -- Hozzer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=8277; -- Rekk'tilac
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=23136; -- Eagle Spirit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=23135; -- Falcon Spirit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=23134; -- Hawk Spirit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=18320; -- Time-Lost Shadowmage
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=14476; -- Krellack
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=570721024, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=23670; -- Winterskorn Elder
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=570720256, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=28394; -- Death Knight Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=570720256, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=28391; -- Death Knight Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=537166592, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=28156; -- Defeated Argent Footman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=537166592, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=26870; -- Darkspear Dragon Hunter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=537166592, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=22859; -- Shadowhoof Summoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=537165824, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=24008; -- Fallen Combatant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=537133824, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=18035; -- Scout Jyoba
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=537133824, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=17133; -- Aged Clefthoof
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=536904448, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=26965; -- Tormented Drakkari
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=8115; -- Witch Doctor Uzer'i
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=7875; -- Hadoken Swiftstrider
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=5390; -- Sage Palerunner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=28090; -- Crusade Recruit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=19837; -- Daga Ramba
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=19479; -- Orgatha
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=19333; -- Grokom Deatheye
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=18947; -- Solanin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=18926; -- Sleyin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=18426; -- Terellia
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=16862; -- Silanna
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=16860; -- Jilanne
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=16397; -- Ardeyn Riverwind
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=16289; -- Advisor Valwyn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=16268; -- Eralan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=16231; -- Dame Auriferous
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=16213; -- Ranger Lethvalin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=15946; -- Apprentice Veya
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=15945; -- Apprentice Meledor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=15942; -- Ranger Sareyn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=15941; -- Apprentice Ralen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=15940; -- Ranger Selron
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=15939; -- Ranger Degolien
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=15417; -- Velan Brightoak
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=15405; -- Ley-Keeper Caidanis
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=12340; -- Drulzegar Skraghook
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=11715; -- Talendria
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33600, `dynamicflags`=0 WHERE `entry`=26246; -- Prophet Velen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33588032, `dynamicflags`=0 WHERE `entry`=22083; -- Lord Illidan Stormrage
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33587968, `dynamicflags`=0 WHERE `entry`=22288; -- Terokkar Quest Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33587968, `dynamicflags`=0 WHERE `entry`=20804; -- Netherstorm Moarg Work Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33587968, `dynamicflags`=0 WHERE `entry`=19784; -- Coilskar Cobra
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=28567; -- Water Spout
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=28459; -- Mosswalker Village Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=26264; -- Boulder Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=26254; -- Inert Portal
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=25672; -- Warsong Slaughterhouse Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=25671; -- Torp's Farm Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=25669; -- Warsong Grainery Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=24913; -- Sister Mercy Cannon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=24902; -- Abdul Relay
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=24888; -- Isuldof Quest Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=23382; -- Simon Game Summon Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=14645; -- Warsong Gulch Herald
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554944, `dynamicflags`=0 WHERE `entry`=28320; -- Servant of Freya
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554944, `dynamicflags`=0 WHERE `entry`=23923; -- Halgrind Torch Bunny 03
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=32427; -- Plague Cauldron Target 01
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=24194; -- Baleheim Fire Bunny Large
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=24185; -- Winterskorn Bridge Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=24184; -- Winterskorn Barracks Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=24183; -- Winterskorn Watchtower Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=24182; -- Winterskorn Dwelling Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=23424; -- Ethereal Ring Control Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=21443; -- Bone Wastes - Orb Waypoint 01
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=12 WHERE `entry`=25746; -- [PH] Ahune Loot Loc Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=30990; -- Metal Post Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=26230; -- Snow Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=26121; -- Wisp Source Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=26120; -- Wisp Dest Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=25952; -- Slippery Floor Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=25746; -- [PH] Ahune Loot Loc Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=25745; -- [PH] Ahune Summon Loc Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=27804; -- Golluck Rockfist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=26447; -- Drakkari Shaman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=26259; -- Shattered Sun Soldier
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25947; -- Zangarmarsh Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25944; -- The Hinterlands Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25943; -- The Barrens Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25942; -- Terokkar Forest Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25941; -- Swamp of Sorrows Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25940; -- Stonetalon Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25939; -- Silverpine Forest Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25937; -- Nagrand Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25935; -- Hillsbrad Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25934; -- Hellfire Peninsula Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25932; -- Feralas Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25930; -- Dustwallow Marsh Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25928; -- Desolace Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25927; -- Burning Steppes Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25925; -- Badlands Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25923; -- Arathi Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25922; -- Winterspring Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25920; -- Stranglethorn Vale Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25917; -- Winterspring Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25915; -- Stranglethorn Vale Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25906; -- Teldrassil Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25902; -- Loch Modan Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25900; -- Hellfire Peninsula Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25897; -- Dustwallow Marsh Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25894; -- Desolace Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25893; -- Darkshore Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25890; -- Blasted Lands Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25887; -- Arathi Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25884; -- Ashenvale Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25883; -- Ashenvale Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=24897; -- "Tiny" Jimb
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=24884; -- Padwai, Son of Orfus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=23334; -- Sky Commander Keller
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=23120; -- Sky Sergeant Vanderlip
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=22453; -- Injured Sha'tar Vindicator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=22073; -- Marcus Auralion
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=21905; -- Veynna Dawnstar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=21295; -- Coilskar Commander
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=20920; -- Magister Theledorn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=19840; -- Caledis Brightdawn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=19839; -- Lariel Sunrunner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=19720; -- "Dirty" Larry
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=19140; -- Mag'har Pitfighter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=18688; -- Ancient Orc Ancestor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=18471; -- Gurgthock
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33280, `dynamicflags`=0 WHERE `entry`=2698; -- George Candarte
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33280, `dynamicflags`=0 WHERE `entry`=24090; -- Captured Valgarde Paladin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33280, `dynamicflags`=0 WHERE `entry`=24088; -- Captured Valgarde Mage
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33280, `dynamicflags`=0 WHERE `entry`=11752; -- Blaise Montgomery
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33024, `dynamicflags`=0 WHERE `entry`=18141; -- Greatmother Geyah
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33024, `dynamicflags`=0 WHERE `entry`=18063; -- Garrosh
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=19380; -- Guard Untula
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=10204; -- Misha
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=4 WHERE `entry`=24713; -- "Crowleg" Dan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=4 WHERE `entry`=24016; -- Ulf the Bloodletter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37148; -- Skybreaker Summoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37146; -- Kor'kron Sniper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37035; -- Kor'kron Vanquisher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37034; -- Kor'kron Templar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37029; -- Kor'kron Reaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37028; -- Kor'kron Stalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37027; -- Skybreaker Hierophant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37026; -- Skybreaker Sorcerer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37016; -- Skybreaker Luminary
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37003; -- Skybreaker Vindicator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=32472; -- Ebon Blade Gargoyle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=31257; -- Ebon Blade Winged Defender
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=30830; -- Underking Talonox
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=30202; -- Reanimated Crusader
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=29922; -- Corig the Cunning
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=29687; -- Crusader Lord Lantinga
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=28812; -- Lapu Stormhorn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=28811; -- Brady Ironcrock
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=28810; -- Lessien
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=28809; -- Vincent Huber
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=28806; -- Chad Carter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=28117; -- Argent Footman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=27933; -- Alanya
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=27267; -- Quartermaster Bartlett
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=27236; -- Stable Master Mercer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=27118; -- Conquest Hold Raider
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=26965; -- Tormented Drakkari
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=26962; -- Jonathan Lewis
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=26957; -- Angelina Soren
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=26955; -- Jamesina Watterly
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=26953; -- Thomas Kolichio
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=26280; -- Dragonblight Mage Hunter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24886; -- Exorcist Vaisha
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24881; -- Karrtog
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24811; -- Donny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24810; -- Anuniaq
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24788; -- Jack Adams
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24784; -- Scuttle Frostprow
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24763; -- Akiaruk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24755; -- Elder Atuik
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24754; -- Iskaal Refugee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24742; -- "Mad" Jonah Sterling
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24741; -- Annie Bonn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24714; -- Seasoned Buccaneer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24644; -- Harpoon Master Yavus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24642; -- Drunken Northsea Pirate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24628; -- Northsea Duelist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24543; -- Tattooed Marcy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24542; -- Red-Eyed Ben
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24541; -- Taruk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24539; -- "Silvermoon" Harry
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24537; -- Handsome Terry
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24525; -- Zeh'gehn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24349; -- Jessica Evans
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24347; -- Alexis Walker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24343; -- Brock Olson
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24015; -- Winterskorn Defender
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23809; -- Vengeance Landing Cannoneer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23655; -- Winterskorn Bonegrinder
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23653; -- Winterskorn Spearman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23638; -- Longtusk Fisherman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23428; -- Jho'nass
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23413; -- Skyguard Handler Irena
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23283; -- Lady Sinestra
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23208; -- Skyguard Pyrotechnician
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=22893; -- Wodin the Troll-Servant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=22481; -- Dwarfowitz
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=22464; -- Explorers' League Researcher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=22458; -- Chief Archaeologist Letoll
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=22456; -- Oakun
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=22446; -- Commander Ra'vaj
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=22291; -- Furnace Guard
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=22199; -- Slaag
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=21771; -- Warcaller Sardon Truslice
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=21485; -- Aldraan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=21291; -- Grom'tor, Son of Oronok
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=21193; -- Gralga
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=21192; -- Kugnar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=21147; -- Tor'chunk Twoclaws
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=20393; -- Foreman Sundown
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=20102; -- Goblin Commoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=19606; -- Grek
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=19355; -- Shadowmoon Peon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=19158; -- Garadar Guard Captain
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=19133; -- Ohlorn Farstrider
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=19048; -- Stonebreaker Peon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18927; -- Human Commoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18913; -- Matron Tikkit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18822; -- Quartermaster Davian Vaclav
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18817; -- Chief Researcher Kartos
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18588; -- Floon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18447; -- Tooki
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18417; -- Altruis the Sufferer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18415; -- Elder Ungriz
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18414; -- Elder Yorley
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18407; -- Warden Bullrok
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18302; -- Matron Drakia
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18301; -- Matron Celestine
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18300; -- Elkay'gan the Mystic
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18273; -- Kilrath
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18229; -- Saurfang the Younger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18106; -- Jorin Deadeye
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18068; -- Farseer Margadesh
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18067; -- Farseer Corhuk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18066; -- Farseer Kurkush
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=17986; -- Vindicator Corin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=17926; -- Scout Loryi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=17712; -- Captain Edward Hanes
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=17637; -- Mack Diver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=17080; -- Marshal Bluewall
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=17068; -- Chief Expeditionary Requisitioner Enkles
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=16210; -- Magistrix Landra Dawnstrider
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=15444; -- Arcanist Nozzlespring
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=15442; -- Ironforge Brigade Footman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=14991; -- League of Arathor Emissary
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=14373; -- Sage Korolusk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=256, `dynamicflags`=0 WHERE `entry`=9119; -- Muigin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=256, `dynamicflags`=0 WHERE `entry`=9118; -- Larion
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=256, `dynamicflags`=0 WHERE `entry`=7997; -- Captured Sprite Darter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=256, `dynamicflags`=0 WHERE `entry`=27711; -- Technician Halmaha
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=256, `dynamicflags`=0 WHERE `entry`=26170; -- Thassarian
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=256, `dynamicflags`=0 WHERE `entry`=23730; -- Harold Lagras
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=23777; -- Proto-Drake Egg
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=34951; -- Isle of Conquest Envoy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=34950; -- Isle of Conquest Emissary
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=34949; -- Isle of Conquest Envoy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=34948; -- Isle of Conquest Emissary
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=30740; -- Valiance Expedition Champion
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=27859; -- Vanthryn the Merciless
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=25143; -- Shattered Sun Veteran
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=25142; -- Shattered Sun Marksman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=25137; -- Shattered Sun Trainee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=25136; -- Shattered Sun Trainee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=25135; -- Shattered Sun Trainee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=25134; -- Shattered Sun Trainee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=22013; -- Eye of the Storm Emissary
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=21471; -- Stormer Ewan Wildwing
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=21441; -- Station Sharpshooter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=21359; -- Blood Guard Gulmok
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=21118; -- Razak Ironsides
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=19673; -- Consortium Engineer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=19571; -- Innkeeper Remi Dodoso
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=19312; -- Drillmaster Zurok
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=19038; -- Supply Officer Mills
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18351; -- Lump
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18290; -- Tusker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18281; -- Boglash
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18259; -- Banthar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18258; -- Bach'lor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18248; -- Nekthar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18029; -- Defender Kajad
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18026; -- Defender Haqi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18021; -- Defender Kaegan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18017; -- Seer Janidi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18016; -- Magasha
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18015; -- Gambarinka
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18014; -- Witch Doctor Tor'gash
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18013; -- Shadow Hunter Denjai
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18012; -- Reavij
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18007; -- Ruam
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18006; -- Noraani
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18005; -- Haalrun
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18004; -- Vindicator Idaar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18003; -- Anchorite Ahuurn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=17901; -- Keleth
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=17834; -- Lethyn Moonfire
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=17642; -- Tracker Lyceon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=17634; -- K. Lee Smallfry
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=17599; -- Aonar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=17433; -- Vindicator Aalesia
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=17424; -- Anchorite Paetheus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=17423; -- Harbinger Mikolaas
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=16575; -- Shadow Hunter Ty'jin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=16574; -- Far Seer Regulkut
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=16551; -- Technician Dyvuun
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=16252; -- High Executor Mavren
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=16251; -- Deathstalker Maltendis
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=15991; -- Lady Dena Kennedy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=15938; -- Eversong Ranger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=15441; -- Ironforge Brigade Rifleman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=15103; -- Stormpike Emissary
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=13699; -- Selendra
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=13656; -- Willow
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=11877; -- Roon Wildmane
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=34816, `dynamicflags`=0 WHERE `entry`=39509; -- Aronen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2080, `dynamicflags`=0 WHERE `entry`=27702; -- Horde Lumberboat
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2080, `dynamicflags`=0 WHERE `entry`=27689; -- Alliance Lumberboat Explosions
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2080, `dynamicflags`=0 WHERE `entry`=27688; -- Alliance Lumberboat
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2050, `dynamicflags`=0 WHERE `entry`=31690; -- Infra-Green Flight Master
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2050, `dynamicflags`=0 WHERE `entry`=27723; -- [DND] Aldor Mailbox Malfunction Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=31298; -- (Wrathgate Alliance) Fordragon Battle-Mage
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=31294; -- (Wrathgate Horde) Taunka Huntsman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=31285; -- (Wrathgate Horde) Warsong Elite
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=28393; -- Death Knight Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=28392; -- Death Knight Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=28390; -- Death Knight Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=27787; -- Venomspite Riding Bat
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=27479; -- Slain Trapper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=26172; -- Slain Cultist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=26160; -- Taunka'le Pack Kodo
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=25841; -- Fizzcrank Recon Pilot
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=24678; -- Slain Tuskarr
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=24196; -- Trapped Animal
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=24122; -- Pulroy the Archaeologist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=21859; -- Slain Sha'tar Vindicator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=21846; -- Slain Auchenai Warrior
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=20158; -- Slime-Covered Corpse
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=18490; -- Fallen Druid
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=0 WHERE `entry`=31786; -- Oil Slick
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=0 WHERE `entry`=29811; -- Frostborn Scout
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=0 WHERE `entry`=29751; -- Drom Frostgrip
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049 WHERE `entry`=30292; -- Dead Icemaw Bear
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049 WHERE `entry`=28260; -- Defeated Argent Footman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049 WHERE `entry`=27613; -- Slaughtered Drakkari
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049 WHERE `entry`=27481; -- Westfall Infantry Corpse
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049 WHERE `entry`=26516; -- Drakkari Warrior Corpse
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049 WHERE `entry`=26513; -- Drakkari Shaman Corpse
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=1, `dynamicflags`=32 WHERE `entry`=24145; -- Zedd
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=37125; -- Captain Rupert
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=37124; -- Captain Grondel
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=37123; -- Captain Brandon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=37122; -- Captain Arnath
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=29220; -- Cenarion Scout
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=27758; -- Westfall Brigade Defender
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=25661; -- Shattered Sun Soldier
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=21419; -- Infernal Attacker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=20284; -- Dr. Boom
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=20196; -- Bloodthirsty Marshfang
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=19161; -- Neophyte Combatant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=18131; -- Marshfang Slicer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=18130; -- Marshfang Ripper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=9164; -- Elder Diemetradon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=30865; -- Shandaral Warrior Spirit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=26222; -- Twilight Cryomancer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=21854; -- Ironspine Petrifier
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=19443; -- Tagar Spinebreaker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=19411; -- Shattered Hand Warlock
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=18470; -- Bonelasher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=17604; -- Sunhawk Spy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=17346; -- Mutated Tangler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=17330; -- Blacksilt Seer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=17328; -- Blacksilt Shorestriker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=17135; -- Boulderfist Mystic
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=16977; -- Arch Mage Xintor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=16876; -- Bonechewer Mutant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=20 WHERE `entry`=31334; -- Korialstrasz
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=2 WHERE `entry`=25711; -- Spirit of the North
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=10 WHERE `entry`=26949; -- Torastrasza
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=9998; -- Shizzle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=9618; -- Karna Remtravel
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=9164; -- Elder Diemetradon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=9163; -- Diemetradon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=9162; -- Young Diemetradon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=8402; -- Enslaved Archaeologist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=7956; -- Kindal Moonweaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=7949; -- Xylinnia Starshine
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=6559; -- Glutinous Ooze
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=6557; -- Primal Ooze
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=6553; -- Gorishi Reaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=6552; -- Gorishi Worker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=6510; -- Bloodpetal Flayer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=6019; -- Hornizz Brimbuzzle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=5768; -- Ebru
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=5767; -- Nalpak
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=5752; -- Corporal Melkins
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=5642; -- Vahlarriel Demonslayer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=5641; -- Takata Steelblade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=5638; -- Kreldig Ungor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=5396; -- Captain Pentigast
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=4696; -- Scorpashi Snapper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=4667; -- Burning Blade Shadowmage
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=4666; -- Burning Blade Felsworn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=4665; -- Burning Blade Adept
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=4664; -- Burning Blade Reaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=4663; -- Burning Blade Augur
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=4544; -- Krueg Skullsplitter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=4498; -- Maurin Bonesplitter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=38309; -- Slimy Tentacle Stalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=38308; -- Ooze Covered Tentacle Stalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37149; -- Kor'kron Necrolyte
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37129; -- Crok Scourgebane
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37033; -- Kor'kron Invoker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37032; -- Kor'kron Defender
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37031; -- Kor'kron Oracle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37030; -- Kor'kron Primalist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37012; -- Ancient Skeletal Soldier
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=34951; -- Isle of Conquest Envoy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=34950; -- Isle of Conquest Emissary
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=34949; -- Isle of Conquest Envoy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=34948; -- Isle of Conquest Emissary
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=34180; -- Crusader Maran
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33704; -- Frigid Abomination
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33684; -- Weaver Aoa
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33682; -- Fono
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33677; -- Technician Mihila
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33640; -- Hanlir
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33586; -- Binkie Brightgear
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33550; -- Boneguard Scout
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33546; -- The Black Knight
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33499; -- Skeletal Woodcutter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33498; -- Maloric
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32815; -- Crystalsong Forest Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32814; -- Storm Peaks Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32810; -- Sholazar Basin Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32809; -- Borean Tundra Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32807; -- Crystalsong Forest Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32806; -- Storm Peaks Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32802; -- Sholazar Basin Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32801; -- Borean Tundra Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32773; -- Logistics Officer Brighton
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32763; -- Sairuk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32741; -- Conjurer Weinhaus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32739; -- Baroness Zildjia
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32736; -- Scribe Whitman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32718; -- Disidra Stormglory
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32709; -- Hunaka Greenhoof
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32695; -- Donavan Bale
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32599; -- Surveyor Hansen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32548; -- Corastrasza
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32538; -- Duchess Mynx
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32533; -- Cielstrasza
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32507; -- Cultist Acolyte
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32488; -- Ebon Blade Vindicator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32486; -- Scourge Death Knight
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32479; -- Bone Guard
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32478; -- Slosh
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32468; -- Ebon Blade Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32375; -- Warmage Yurias
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32374; -- Librarian Belleford
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32373; -- Gatekeeper Melindra
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32372; -- Warmage Ilsudria
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32371; -- Warmage Halister
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32369; -- Warmage Sarina
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32349; -- Cultist Shard Watcher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32324; -- Green Mage
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32323; -- Aldur'thar Sentry
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=3230; -- Nazgrel
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32298; -- Cloak Dome Bunny, Large
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32280; -- Corp'rethar Guardian
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32278; -- Harbinger of Horror
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32255; -- Converted Hero
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32238; -- Bitter Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32236; -- Dark Subjugator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31916; -- Tanaika
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31915; -- Horde Transport Dropoff Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31843; -- Reanimated Miner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31798; -- Athan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31764; -- First Mate Kacy Dishon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31763; -- Captain John Brookman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31762; -- Navigator Marcus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31761; -- Sailor Davies
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31760; -- Sailor Berg
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31759; -- Sailor Jansen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31401; -- Azure Manashaper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31400; -- Azure Front Channel Stalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31358; -- (Wrath Gate) Dummy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31330; -- Fleeing Horde Soldier
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31327; -- Death Knight Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31325; -- Death Knight Adept
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31324; -- Iceskin Sentry
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31321; -- Skeletal Runesmith
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31316; -- Ebon Blade Reaper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31247; -- Roxi Ramrocket
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31226; -- Lumbering Atrocity
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31160; -- Rokir
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31159; -- Baelok
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31127; -- Agitated Stratholme Resident
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31126; -- Agitated Stratholme Citizen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31123; -- Shandaral Spirit Wolf
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31109; -- Senior Demolitionist Legoso
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31108; -- Siege Master Stouthandle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31068; -- Malykriss Blood Forge Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31065; -- Malykriss Altar of Sacrifice Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31064; -- Malykriss Icy Lookout Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31057; -- Mechanical Greeter RY7R
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31054; -- Anchorite Tessa
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31052; -- Bowyer Randolph
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31051; -- Sorceress Kaylana
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31049; -- Geist Return Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31028; -- Patricia O'Reilly
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31027; -- Leeka Turner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31024; -- Brock Thriss
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31023; -- Brandon Eiredeck
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31021; -- Sophie Aaren
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31020; -- Olivia Zenith
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31019; -- Stephanie Sindree
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31018; -- Edward Orrick
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31017; -- Mal Corricks
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30994; -- Magistrate Barthilas
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30947; -- Eidolon Watcher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30946; -- Keritose Bloodblade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30889; -- Data Scan Target Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30877; -- Water Revenant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30873; -- Flame Revenant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30865; -- Shandaral Warrior Spirit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30863; -- Shandaral Druid Spirit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30848; -- Whispering Wind
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30847; -- Raging Flame
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30826; -- Great Reaver Mulga
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30824; -- Sky-Reaver Korm Blackscar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30739; -- Warsong Champion
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30571; -- Michael Belfast
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30570; -- Emery Neill
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30565; -- Joseph Redpath
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30561; -- Gryan Stoutmantle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30557; -- Pamela Redpath
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30556; -- Marlene Redpath
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30555; -- Carlin Redpath
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30554; -- Footman Maxwell
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30553; -- Footman James
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30552; -- Fras Siabi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30551; -- Hearthsinger Forresten
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30547; -- Postmaster Malown
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30499; -- Gnomish Engineer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30489; -- Morgan Day
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30488; -- Travis Day
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30469; -- Tracker Val'zij
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30464; -- "Honest" Max
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30353; -- Duronn the Runewrought
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30336; -- Runesmith Balehammer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30326; -- Rotclaw
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30325; -- Viscous Oil
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30316; -- Temple of Life Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30311; -- Mangled
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30308; -- Initiate Brenners
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30307; -- Sarhule the Risen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30261; -- Scout Captain Daelin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30255; -- Aniduria
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30254; -- Marisalira
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30246; -- Dun Niffelem Spear Chain Bunny (Phase 2)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30244; -- Miura Brightweaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30241; -- Lanudal Silverhart
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30238; -- Silver Covenant Scout
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30218; -- Vaelen the Flayed
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30216; -- Vile
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30212; -- South Lightning Forge
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30211; -- Central Lightning Forge
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30209; -- North Lightning Forge
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30156; -- [DND] Anguish Spectator Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30151; -- Orb Lightning
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30144; -- Restless Frostborn Ghost
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30135; -- Restless Frostborn Warrior
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30103; -- Valkyrion Fire Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30078; -- [DND]Wyrmrest Temple Beam Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30058; -- Warden of the Chamber
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30056; -- Vaelen the Flayed
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30051; -- Librarian Tiare
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30009; -- Wodin the Troll-Servant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30001; -- Blackmaw
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29996; -- Snorts
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29993; -- Frostfang
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29926; -- Gunda Boldhammer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29923; -- Dagni Oregleam
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29909; -- Nilika Blastbeaker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29907; -- Xark Bolthammer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29905; -- Grillix Bonesaw
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29904; -- Smilin' Slirk Brassknob
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29881; -- An Unknown Voice
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29855; -- Khaliisi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29795; -- Koltira Deathweaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29752; -- Databank Core
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29745; -- Imogen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29744; -- Rork Sharpchin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29743; -- Lagnus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29732; -- Fjorlin Frostbrow
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29729; -- Frostborn Axemaster
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29727; -- Glorthal Stiffbeard
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29692; -- Hut Fire
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29689; -- Crusader MacKellar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29688; -- Engineer Reed
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29655; -- Malygos
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29650; -- Archaeologist Andorin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29583; -- Pan'ya
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29581; -- Teleport - Heart -> Hall
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29580; -- Teleport - Hall -> Heart
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29567; -- Unworthy Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29566; -- Unworthy Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29565; -- Unworthy Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29558; -- Frost Giant Target Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29525; -- Zeev Fizzlespark
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29521; -- Unworthy Initiate Anchor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29520; -- Unworthy Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29519; -- Unworthy Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29487; -- Wild Shoveltusk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29486; -- Tamed Shoveltusk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29485; -- Dolomite Giant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29479; -- Shoveltusk Forager
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29473; -- Gretchen Fizzlespark
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29468; -- Crusader Dargath
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29466; -- Goblin Prisoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29433; -- Goblin Sapper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29431; -- Jeer Sparksocket
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29430; -- Tore Rumblewrench
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29428; -- Ricket
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29424; -- Stormforged Lightning Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29382; -- Stormforged Reaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29380; -- Stormforged War Golem
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29327; -- Frost Leopard
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29285; -- Westfall Brigade Scout
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29269; -- Aspen Grove Trapper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29252; -- Jason Riggins
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29244; -- Jesse Masters
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29211; -- Drakkari Native
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29162; -- Magister Tyr'ganal
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29161; -- Magistrix Haelenai
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29160; -- Magistrix Phaelista
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29156; -- Archmage Celindra
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29137; -- Sergeant Riannah
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29129; -- Lost Drakkari Spirit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29057; -- Mosslight Pillar Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29036; -- Servant of Freya
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29026; -- Kolramas Slime
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28958; -- Jessa Weaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28956; -- Warcaster Fanoraithe
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28856; -- Scarlet Fleet Guardian
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28855; -- Ba'kari
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28848; -- Prophet of Har'koa
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28832; -- Chin'ika
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28831; -- Yamuna
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28829; -- Saree
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28828; -- Ansari
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28827; -- Co'man
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28822; -- Scarlet Miner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28815; -- Civilian Transformation Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28799; -- Alanna
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28798; -- Claudia Bloodraven
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28797; -- Haley Copperturn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28796; -- Arlen Brighthammer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28794; -- Kevin Weaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28766; -- Scarlet Farm Hound
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28746; -- Pilot Vic
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28739; -- Blight Cauldron Bunny 00
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28699; -- Charles Worth
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28693; -- Enchanter Nalthanis
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28658; -- Gothik the Harvester
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28655; -- Sky Darkener Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28647; -- Orithos the Sky Darkener
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28642; -- Scourge Sky Darkener
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28627; -- Wood Pile Dummy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28616; -- Scarlet Gryphon Rider
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28609; -- Scarlet Infantryman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28608; -- Scarlet Medic
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28600; -- Heb'Drakkar Headhunter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28594; -- Scarlet Preacher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28568; -- Tamara Wobblesprocket
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28558; -- High Abbot Landgren
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28557; -- Scarlet Peasant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28548; -- High General Abbendis
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28544; -- Chapel of the Crimson Flame
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28543; -- New Avalon Town Hall
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28542; -- Scarlet Hold
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28529; -- Scarlet Crusader
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28527; -- Chronicler To'kini
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28525; -- New Avalon Forge
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28504; -- Jin'Alai Medicine Man
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28494; -- Kutube'sa
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28484; -- Scalper Ahunae
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28480; -- Element-Tamer Dagoda
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28479; -- Witch Doctor Khufu
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28474; -- Amal'thazad
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28472; -- Lord Thorval
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28463; -- River's Heart Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28455; -- Rainspeaker Canopy Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28452; -- Elemental Rift
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28449; -- Thassarian
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28448; -- Orbaz Bloodbane
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28447; -- Koltira Deathweaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28445; -- Baron Rivendare
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28442; -- Prophet of Rhunok
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28417; -- Priest of Rhunok
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28403; -- Har'koan Subduer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28394; -- Death Knight Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28388; -- Jin'Alai Warrior
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28383; -- Acherus Necromancer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28367; -- Acherus Dummy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28352; -- Nethurbian Crater KC Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28348; -- (Wrathgate Monster) Forsaken Blightspreader (Gas Mask)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28330; -- Ancient Dirt KC Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28324; -- Crusader Whathah
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28309; -- Sub-Lieutenant Jax
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28305; -- Drakkari Pedestal 03
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28304; -- Drakkari Pedestal 02
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28303; -- Drakkari Water Binder
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28263; -- Birmingheim
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28262; -- Montegue Krole
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28261; -- Crag Steelbeard
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28228; -- Crusader Valus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28201; -- Bile Golem
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28141; -- Crusader Lamoof
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28137; -- Leave No One Behind Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28133; -- Crusader Jonathan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28086; -- Sapphire Hive Wasp
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28064; -- Drakkari Pedestal 01
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28043; -- Captain Grondel
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28011; -- Emperor Cobra
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28010; -- Stranded Thresher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27990; -- Krasus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27950; -- Demestrasz
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27943; -- Dalormi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27938; -- Trizormu
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27935; -- Ferithos
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27930; -- Emilune Winterwind
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27927; -- Dragonflayer Guardian
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27926; -- Thorvald
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27913; -- Lordaeron Crier
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27907; -- Bartleby Battson
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27906; -- Warmage Hollister
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27904; -- Warmage Watkins
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27903; -- Roger Owens
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27892; -- Scruffy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27891; -- Malcolm Moore
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27885; -- Jena Anderson
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27884; -- Martha Goslin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27877; -- Sergeant Morigan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27876; -- Silvio Perelli
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27856; -- Chromie
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27851; -- Thel'zan Spell Dummy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27842; -- Fenrick Barlowe
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27830; -- Venture Co. Evacuee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27827; -- Grain Crate Helper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27803; -- Lauriel Trueblade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27785; -- Lord Itharius
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27765; -- Nalice
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27763; -- Vargastrasz
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27760; -- "Grizzly" D. Adams
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27759; -- Commander Howser
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27752; -- High Elf Sorceress
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27751; -- Captain Drayzen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27749; -- Horde Conscript
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27747; -- High Elf Mage-Priest
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27746; -- Lordaeron Knight
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27745; -- Lordaeron Footman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27734; -- Crypt Fiend
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27732; -- Master Necromancer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27731; -- Acolyte
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27720; -- Bookie Vel'jen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27719; -- Grennix Shivwiggle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27698; -- Defending Wyrmrest Temple Kill Credit Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27687; -- Frigid Necromancer Attacker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27680; -- Dahlia Suntouch
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27667; -- Anwehu
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27666; -- Ontuvo
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27628; -- Bubb Lazarr
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27627; -- Tatjana
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27617; -- River Thresher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27615; -- Scourge Deathspeaker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27602; -- Sergeant Downey
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27589; -- Ruby Strafe Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27582; -- Private Arun
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27581; -- Ruuna the Blind
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27575; -- Lord Afrasastrasz
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27572; -- Ruby Controller Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27570; -- Venture Co. Straggler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27567; -- Captain Iskandar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27564; -- Alliance Conscript
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27563; -- Centurion Kaggrum
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27562; -- Lieutenant Stuart
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27555; -- Drakkari Witch Doctor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27554; -- Injured Drakkari Refugee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27539; -- Frigid Necromancer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27532; -- General Khazgar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27520; -- Baron Freeman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27511; -- Captain Zorna
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27509; -- Captain Brightwater
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27506; -- Ceristrasz
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27501; -- Westfall Brigade Marine
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27500; -- Conquest Hold Berserker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27495; -- Barblefink
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27484; -- Rheanna
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27475; -- Westfall Brigade Infantry
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27462; -- Westfall Brigade Hunter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27452; -- Invisible Stalker Grizzly Hills
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27450; -- Neltharion's Flame Control Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27449; -- Neltharion's Flame Fire Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27418; -- Rothin's Spell Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27402; -- Bone Target Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27391; -- Woodsman Drake
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27388; -- Sergeant Nazgrim
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27381; -- Chancellor Amai
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27379; -- Engineer Burke
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27378; -- Senior Scrivener Barriga
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27377; -- Thane Torvald Eriksson
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27376; -- Deathguard Schneider
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27369; -- Necromantic Rune Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27360; -- Smoldering Skeleton
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27356; -- Burning Depths Necrolyte
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27355; -- Rothin the Decaying
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27350; -- Agent Skully
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27349; -- Scarlet Onslaught Prisoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27337; -- Spy Mistress Repine
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27333; -- Onslaught Mason
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27331; -- Bombard the Ballistae Kill Credit Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27330; -- Onslaught Infantry
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27326; -- Outhouse Bunny - Grizzly
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27320; -- Deathguard Molder
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27306; -- Transitus Shield Invisible Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27295; -- Hierophant Thayreen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27294; -- Tundra Scavenger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27293; -- Amberpine Woodsman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27277; -- Master Woodsman Anderhol
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27266; -- Sergeant Thurkin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27265; -- Vordrassil's Tears Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27264; -- Vordrassil's Limb Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27262; -- Windseer Grayhorn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27260; -- Dragonflayer Huscarl
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27255; -- Nishera the Garden Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27254; -- Emerald Lasher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27251; -- Moa'ki Fisherman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27250; -- Junior Apothecary Schlemiel
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27248; -- Apothecary Vicky Levine
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27247; -- Devout Bodyguard
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27245; -- High Abbot Landgren
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27243; -- High Executor Wroth
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27234; -- Blacksmith Goodman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27229; -- Forgotten Footman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27226; -- Forgotten Peasant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27225; -- Forgotten Rifleman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27223; -- Archery Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27222; -- Archery Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27209; -- Torturer LeCraft
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27207; -- Onslaught Workman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27206; -- Onslaught Knight
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27204; -- Captain Bonemaw
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27203; -- Onslaught Footman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27202; -- Onslaught Raven Priest
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27198; -- Brote
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27191; -- Skrotee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27185; -- Kuk'uq
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27184; -- Imnek
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27181; -- Qannik
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27180; -- Jintha'kalar Invisible Stalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27176; -- Mystic Makittuq
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27174; -- Caregiver Mumik
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27173; -- Warmage Calandra
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27172; -- Chief Plaguebringer Middleton
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27151; -- Deniigi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27149; -- Arrluk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27148; -- Caregiver Iqniq
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27146; -- Uukkarnit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27144; -- Noatak
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27134; -- Smith Prigka
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27133; -- Seer Yagnar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27132; -- Sani'i
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27125; -- Barracks Master Rhekku
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27122; -- Overseer Deathgaze
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27117; -- Amberpine Scout
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27102; -- Gorgonna
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27089; -- Saffron Reynolds
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27088; -- Yolanda Haymer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27070; -- Lisa Philbrook
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27069; -- Matron Magah
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27067; -- Drigoth
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27066; -- Jennifer Bell
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27063; -- Vrok
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27062; -- Brom Armstrong
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27033; -- Duncan Fallers
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27032; -- Lovely Liddia
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27031; -- Apothecary Rose
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27030; -- Bradley Towns
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27027; -- Mrs. Winterby
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27026; -- Rohesia Werner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26985; -- Barracks Master Harga
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26984; -- Stephan Franks
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26983; -- Aurastrasza
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26979; -- Kontokanis
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26942; -- Decrepit Necromancer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26912; -- Grumbol Stoutpick
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26909; -- Byron Welwick
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26908; -- Helen Fairchild
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26905; -- Brom Brewbaster
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26889; -- The End of the Line Area Trigger Kill Credit Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26875; -- Lieutenant Dumont
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26869; -- Pit-Fighting Spectator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26863; -- Sethyel
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26862; -- Anthis
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26860; -- Conqueror Krenna
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26859; -- Rokhan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26856; -- North Stone
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26854; -- Earthwarden Grife
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26816; -- Focus Wizard
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26804; -- Fizzcrank Bomber Invisible Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26785; -- Directional Rune
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26720; -- Danook Stormwhisper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26709; -- Pahu Frosthoof
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26706; -- Infected Grizzly Bear
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26704; -- Drakkari Defender
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26697; -- Tewah Chillmane
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26655; -- High Cultist Zangus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26649; -- Messenger Torvus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26645; -- Fizzcrank Engineering Crew
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26634; -- Fizzcrank Watcher Rupert Keeneye
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26619; -- Fizzcrank Paratrooper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26605; -- Anub'ar Underlord
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26604; -- Mack Fearsen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26600; -- Chief Engineer Galpen Rolltie
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26599; -- Willis Wobblewheel
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26598; -- Mistie Flitterdawn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26596; -- "Charlie" Northtop
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26595; -- Toalu'u the Mystic
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26593; -- Serinar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26591; -- Pacer Bunny - Drak Theron Exterior
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26582; -- Horrified Drakkari Warrior
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26559; -- Drakuru's Bunny 02
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26557; -- Kanosak
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26549; -- Nelno Copperbeam
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26544; -- Warlord Zim'bo
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26530; -- Salramm the Fleshcrafter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26529; -- Meathook
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26528; -- Uther the Lightbringer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26527; -- Chromie
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26519; -- Prigmon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26511; -- Moa'ki Bottom Thresher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26506; -- Jennings
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26494; -- Griselda
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26493; -- Wastes Taskmaster
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26485; -- Orphan Matron Twinbreeze
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26482; -- Arctic Grizzly
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26474; -- Ameenah
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26471; -- Image of Archmage Aethas Sunreaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26443; -- Tariolstrasz
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26441; -- Envoy Ripfang
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26440; -- Emissary Skyhaven
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26424; -- Samir
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26423; -- Drakuru
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26392; -- Private Molsen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26389; -- Solstice Hunter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26387; -- Father Michaels
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26382; -- Balfour Blackblade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26381; -- Gar'mak
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26380; -- Lak'tuk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26379; -- Overlord Agmar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26375; -- Quartermaster McCarty
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26374; -- Maevin Farmoon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26373; -- Coldarra Spell FX InvisMan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26361; -- Torthen Deepdig
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26245; -- Tua'kea
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26236; -- Private Jansen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26235; -- Private Furlbrow
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26234; -- Sergeant Daelian
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26233; -- Sergeant Tyric
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26229; -- Tiernan Anvilheart
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26228; -- Trapper Mau'i
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26226; -- Brugar Stoneshear
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26205; -- "Buckets" Cleary
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26194; -- Elder Ko'nani
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26189; -- Fleeing Cultist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26188; -- [PH] Torch Catching Target Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26175; -- Coldarra - Drake Hunt Invisman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26173; -- Tanathal
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26171; -- High Deathpriest Isidorus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26162; -- Transborea Generator 001
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=2615; -- Air Force Alarm Bot (Horde)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26158; -- Mother Tauranook
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26117; -- Raelorasz
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26115; -- Darkfallen Bloodbearer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26112; -- Bor'gorok Peon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26104; -- Iron Eyes
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26103; -- Darkfallen Deathblade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26094; -- Naxxanar Caster
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26076; -- High Priest Naferset
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26057; -- Anveena Marker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26041; -- Lightning Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25983; -- Dorain Frosthoof
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25982; -- Sage Earth and Sky
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25979; -- Loot Crazed Hunter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25967; -- Zephyr
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25921; -- Tanaris Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25919; -- Silithus Flame Keeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25916; -- Tanaris Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25914; -- Silithus Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25911; -- Wetlands Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25910; -- Westfall Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25898; -- Elwynn Forest Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25896; -- Duskwood Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25895; -- Dun Morogh Flame Warden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25885; -- Whirligig Wafflefry
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25880; -- Minion of Kaw
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25847; -- East Crash
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25846; -- South Crash
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25845; -- Northwest Crash
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25802; -- Kaw the Mammoth Destroyer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25793; -- 55-D Collect-a-tron
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25780; -- Abner Fizzletorque
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25767; -- Fizzcrank Pilot
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25766; -- Rig Hauler AC-9
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25758; -- Defendo-tank 66D
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25752; -- Scavenge-bot 004-A8
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25747; -- Jinky Wingnut
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25736; -- Supply Master Taz'ishi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25721; -- Arcane Serpent
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25720; -- Inquisitor Caleras
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25719; -- Coldarra Spellbinder
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25714; -- Tinky Wickwhistle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25713; -- Blue Drakonid Supplicant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25709; -- Glacial Ancient
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25702; -- Mordle Cogspinner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25684; -- Talramas Abomination
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25682; -- Lich-Lord Chillwinter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25678; -- Doctor Razorgrin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25666; -- Northwest Sinkhole
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25665; -- Northeast Sinkhole
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25658; -- Longrunner Bristlehorn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25652; -- Nerub'ar Scarab
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25644; -- Neophyte Narama
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25609; -- En'kilah Necrolord
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25602; -- Greatmother Taiga
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25600; -- Unliving Swine
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25594; -- Beryl Point InvisMan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25590; -- Fizzcrank Fullthrottle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25584; -- Inquisitor Salrand
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25536; -- [DNT] Torch Tossing Target Bunny Controller
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25535; -- [DNT] Torch Tossing Target Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25516; -- Snow Tracker Grumm
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25493; -- West En'kilah Cauldron
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25492; -- Central En'kilah Cauldron
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25490; -- East En'kilah Cauldron
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25477; -- Crafty Wobblesprocket
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25473; -- Temple C
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25472; -- Temple B
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25471; -- Temple A
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25443; -- West Platform
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25416; -- Simmer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25386; -- En'kilah Crypt Fiend
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25383; -- En'kilah Abomination
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25378; -- En'kilah Necromancer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25374; -- Ortrosh
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25339; -- Spirit Talker Snarlfang
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25316; -- Beryl Sorcerer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25314; -- Archmage Berinand
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25308; -- Borean - Westrift Chasm Anomaly
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25201; -- Winterfin Tadpole
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25167; -- General Tiras'alan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25155; -- Shattered Sun Cleric
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25153; -- Shattered Sun Magi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25141; -- Commander Steele
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25140; -- Lord Torvos
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25138; -- Captain Dranarus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25115; -- Shattered Sun Warrior
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24973; -- Ellis Crew Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24957; -- Cult Plaguebringer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24938; -- Shattered Sun Marksman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24936; -- Sunwell Daily Bunny x 0.01
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24932; -- Exarch Nasuun
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24928; -- Sunwell Daily Bunny x 1.00
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24911; -- Cursed Sea Dog
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24910; -- Captain Ellis
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24893; -- Auchindoun Daily Quest Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24885; -- Exorcist Sullivan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24791; -- Shoveltusk Calf
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24789; -- Forlorn Soul
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24733; -- Snow Tracker Junek
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24730; -- Wind Tamer Barah
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24728; -- Dusky
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24727; -- Caylee Dak
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24709; -- Sage Aeire
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24707; -- Buoy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24706; -- Durm Icehide
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24703; -- Chieftain Wintergale
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24702; -- Greatfather Mahan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24681; -- Island Shoveltusk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24635; -- Dragonflayer Harpooner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24634; -- Lieutenant Icehammer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24633; -- Rabid Brown Bear
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24601; -- Steam Rager
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24544; -- Old Icefin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24540; -- Necrotech
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24485; -- Servitor Shade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24478; -- Fjord Crawler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24473; -- Lead Archaeologist Malzie
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24460; -- Chillmere Tidehunter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24436; -- Gargoth
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24416; -- Grisy Spicecrackle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24400; -- Steel Gate Archaeologist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24399; -- Steel Gate Chief Archaeologist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24398; -- Steel Gate Excavator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24393; -- The Rokk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24390; -- Sage Edan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24370; -- Nether-Stalker Mah'duun
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24369; -- Wind Trader Zhareem
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24362; -- Longrunner Pembe
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24330; -- Orson Locke
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24313; -- Celina Summers
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24290; -- New Agamand Plague Tank Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24273; -- Watcher Moonleaf
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24260; -- Val'kyr Soul Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24256; -- Wind Tamer Kagan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24255; -- Dragonflayer Prisoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24254; -- Dragonflayer Prisoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24253; -- Dragonflayer Prisoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24252; -- "Hacksaw" Jenny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24251; -- Chief Plaguebringer Harris
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24236; -- Wind Tamer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24235; -- Cyclothar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24234; -- Junat the Wanderer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24233; -- Cleric of the Crusade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24227; -- Engineer Feknut
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24221; -- Dragonflayer Berserker Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24218; -- Apothecary Grick
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24216; -- Dragonflayer Berserker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24197; -- Westguard Rifleman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24193; -- Baleheim Fire Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24191; -- Lord Irulon Trueblade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24189; -- Ares the Oathbound
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24158; -- Dragonflayer Oracle Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24157; -- Plaguebringer Tillinghast
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24152; -- Apothecary Malthus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24151; -- Daegarn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24150; -- Glorenfeld
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24149; -- Basil Osgood
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24148; -- David Marks
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24147; -- Tara Cooper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24135; -- Greatmother Ankha
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24129; -- Chieftain Ashtotem
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24127; -- Ahota Whitefrost
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24126; -- Apothecary Lysander
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24125; -- Cormath the Courier
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24123; -- Nokoma Snowseer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24114; -- Dragonflayer Thane Corpse
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24106; -- Scout Valory
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24089; -- Captured Valgarde Warrior
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24086; -- Captured Valgarde Priest
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24077; -- Impaled Valgarde Scout
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24051; -- Dragonflayer Invader
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24033; -- Bori Wintertotem
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23994; -- Dragonflayer Hunting Hound
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23975; -- Thoralius the Wise
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23972; -- Westguard Cannon Credit Trigger West
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23957; -- Westguard Cannon Credit Trigger East
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23948; -- Apprentice Tasserel
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23947; -- Westguard Ranged Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23946; -- North Fleet Marksman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23940; -- Skeld Drakeson
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23934; -- North Fleet Salvager
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23932; -- Yanis the Mystic
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23929; -- Giant Tidecrawler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23917; -- Cannon Source Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23916; -- Westguard Cannon Trigger (Water)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23915; -- Westguard Cannon Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23891; -- Overseer Irena Stonemantle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23885; -- Lyana Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23884; -- Vengeance Landing Crossbow Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23883; -- Forsaken Crossbowman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23871; -- Dragonflayer Handler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23870; -- Ember Clutch Ancient
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23867; -- Vengeance Landing Combatant Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23866; -- North Fleet Sailor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23865; -- Vengeance Bringer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23821; -- Valgarde Harpoon Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23816; -- Bat Handler Camille
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23803; -- Vengeance Landing Cannon Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23793; -- North Fleet Soldier
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23785; -- Daggercap Hammerhead
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23783; -- Injured Defender
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23781; -- Apothecary Celestine
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23778; -- Dark Ranger Lyana
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23764; -- Marge
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23762; -- Brend
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23760; -- Forsaken Plaguebringer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23745; -- Garg
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23738; -- Foreman Miles McMoody
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23737; -- Coot "The Stranger" Albertson
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23735; -- Bartleby Armorfist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23732; -- Sorely Twitchblade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23731; -- Innkeeper Hazel Lagras
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23729; -- Baron Ulrik von Stromhearth
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23728; -- Guard Captain Zorek
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23699; -- Kevin Browning
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23693; -- Duskwing Eagle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23691; -- Shoveltusk Stag
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23690; -- Shoveltusk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23658; -- Dragonflayer Death Weaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23657; -- Winterskorn Skald
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23656; -- Dragonflayer Rune-Seer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23654; -- Dragonflayer Warrior
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23645; -- Mur'ghoul Corrupter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23644; -- Mur'ghoul Flesheater
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23643; -- Unstable Mur'ghoul
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23569; -- Renn McGill
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23565; -- Turgore
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23551; -- Valgarde Cannoneer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23550; -- Valgarde Yeoman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23549; -- Rowan Helfgot
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23548; -- Beltrand McSorf
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23547; -- Macalroy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23546; -- Vice Admiral Keller
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23512; -- Crystalforge Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23449; -- Yuula
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23443; -- Dragonmaw Raid Credit Marker (Scryers)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23434; -- Commander Hobb
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23433; -- Barthamus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23415; -- Skyguard Handler Deesak
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23396; -- Krixel Pinchwhistle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23378; -- Simon Game Bunny Large
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23367; -- Grella
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23311; -- Disobedient Dragonmaw Peon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23306; -- Hazzik
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23286; -- Black Blood of Draenor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23272; -- Arcanist Savan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23271; -- Vindicator Kaan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23270; -- Vindicator Aeus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23265; -- Seer Nakha
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23263; -- Brendan Turner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23225; -- Netherwing Drake Escape Point
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23169; -- Nethermine Flayer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23155; -- Invisible Stalker (Scale x3)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23150; -- Dragonmaw Pitfighter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23146; -- Dragonmaw Enforcer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23142; -- Goblin Merc
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23141; -- Yarzill the Merc
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23131; -- Blood Knight Honor Guard
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23094; -- Minion of Sar'this
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23048; -- Sky Sergeant Doryn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23042; -- Severin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23038; -- Sky Commander Adaris
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23022; -- Gordunni Soulreaper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23016; -- Skyguard Handler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23007; -- Paulsta'ats
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22986; -- Skettis - Invis Raven Stone
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22982; -- Skyguard Navigator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22934; -- Black Temple Battle Sensor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22922; -- Innkeeper Aelerya
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22918; -- Gronn Showdown Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22899; -- Protectorate Advisor Rahim
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22864; -- Fyra Dawnstar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22863; -- Seasoned Magister
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22862; -- Anchorite Caalen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22861; -- Lightsworn Vindicator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22857; -- Illidari Ravager
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22851; -- Outland Children's Week Exodar 01 Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22831; -- Outland Children's Week Auchindoun Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22819; -- Orphan Matron Mercy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22801; -- [DND]Prophecy 4 Quest Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22800; -- [DND]Prophecy 3 Quest Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22799; -- [DND]Prophecy 2 Quest Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22502; -- Death's Door Warp-Gate Explosion Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22500; -- Void Hound
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22495; -- Death's Door Fel Cannon Target Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22489; -- Grunt Grahk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22488; -- Sentinel Moonwhisper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22472; -- Death's Door South Warp-Gate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22471; -- Death's Door North Warp-Gate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22465; -- Natasha
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22442; -- Lonika Stillblade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22429; -- Vekax
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22427; -- Zarevhi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22422; -- Blade's Edge - Legion - Anger Camp - Invis Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22420; -- Lakotae
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22417; -- [PH]Altar of Shadows caster
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22395; -- [PH]Altar of Shadows target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22373; -- Defender Grashna
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22365; -- Ethan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22326; -- Redeemed Avian
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22314; -- Captive Child
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22311; -- Raging Fire-Soul
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22310; -- Storming Wind-Ripper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22306; -- Skittering Cavern Crawler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22292; -- Rilak the Redeemed
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22280; -- Soren
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22279; -- Nadja
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22278; -- High Priest Orglum
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22272; -- Kirrik the Awakened
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22254; -- Wrath Corruptor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22252; -- Dragonmaw Peon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22244; -- Unbound Ethereal
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22243; -- Bash'ir Arcanist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22242; -- Bash'ir Spell-Thief
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22241; -- Bash'ir Raider
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22225; -- Reagan Mancuso
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22215; -- Treebole
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22211; -- Battlemage Vyara
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22151; -- Ruuan Weald Sister
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22150; -- Lieutenant Fairweather
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22149; -- Commander Haephus Stonewall
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22148; -- Gordunni Head-Splitter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22146; -- Summoning Voidstorm
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22144; -- Gordunni Elementalist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22143; -- Gordunni Back-Breaker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22139; -- Invis Arakkoa Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22138; -- Dark Conclave Ritualist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22132; -- Mature Cavern Crawler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22126; -- Air Force Trip Wire - Rooftop (Cenarion Expedition)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22125; -- Air Force Guard Post (Cenarion - Stormcrow)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22103; -- Baron Sablemane
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22100; -- Scorpid Bonecrawler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22095; -- Infested Root-Walker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22093; -- Illidari Watcher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22090; -- Air Force Guard Post (Toshley's Station - Flying Machine)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22082; -- Shadowmoon Slayer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22070; -- Air Force Trip Wire - Rooftop (Scryer)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22068; -- Air Force Trip Wire - Rooftop (Ethereal - Stormspire)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22066; -- Air Force Guard Post (Scryer - Dragonhawk)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22065; -- Air Force Guard Post (Ethereal - Stormspire)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22063; -- Air Force Trip Wire - Rooftop (Goblin - Area 52)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22052; -- Daggermaw Blackhide
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22044; -- Cavern Crawler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22042; -- Gryphonrider Kieran
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22039; -- [PH] bat target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22024; -- Parshah
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22019; -- Kolphis Darkscale
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22017; -- Eclipsion Spellbinder
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22016; -- Eclipsion Soldier
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22015; -- Eye of the Storm Envoy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22013; -- Eye of the Storm Emissary
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22012; -- Chancellor Bloodleaf
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22011; -- Corok the Mighty
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22007; -- Tree Warden Chawn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22002; -- Air Force Trip Wire - Ground (Horde)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22001; -- Air Force Trip Wire - Rooftop (Horde)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21997; -- Air Force Guard Post (Goblin - Area 52 - Zeppelin)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21993; -- Air Force Guard Post (Horde - Bat Rider)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21983; -- Samia Inkling
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21967; -- Auchenai Death-Spirit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21957; -- Terokkar Forest - Shadow Council Invisible Stalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21956; -- Rema
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21955; -- Arcanist Thelis
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21954; -- Larissa Sunstrike
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21953; -- Varen the Reclaimer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21907; -- Cabal Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21906; -- Kelara
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21902; -- Cabal Spell-weaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21893; -- Altruis Conversation Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21854; -- Ironspine Petrifier
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21847; -- Fel Guard Hound
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21837; -- Summoned Wrath Hound
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21824; -- Dizzy Dina
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21819; -- Blade's Edge - Toshley's - Invisible Stalker - Def Gun Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21816; -- Ironspine Chomper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21797; -- Ancient Shadowmoon Spirit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21782; -- Timeon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21777; -- Gnomus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21775; -- Warcaller Beersnout
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21774; -- Zorus the Judicator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21773; -- Thane Yoregar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21757; -- Big Electromental Flavor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21755; -- Nickwinkle the Metro-Gnome
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21751; -- Chubis
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21749; -- Shadowmoon Scout
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21743; -- Sunfury Blood Lord
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21742; -- Sunfury Eradicator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21736; -- Wildhammer Defender
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21721; -- Enslaved Netherwing Whelp
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21720; -- Dragonmaw Shaman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21718; -- Dragonmaw Subjugator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21717; -- Dragonmaw Wrangler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21691; -- Toshley
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21662; -- Cabal Tomb-Raider
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21661; -- Cabal Skirmisher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21660; -- Cabal Abjurist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21639; -- Illidari Slayer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21515; -- Trachela
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21477; -- Rocknail Flayer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21472; -- Gryphonrider Nordin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21462; -- Greater Felfire Diemetradon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21450; -- Skethyl Owl
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21447; -- Blade's Edge - Toshley's - Def Gun Attack Origin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21434; -- Gordie
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21432; -- Almaador
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21426; -- Gnome Defender - 209
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21422; -- Blade's Edge - Toshley's - Invisible Stalker - Atk Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21417; -- Invis Infernal Caster
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21408; -- Felfire Diemetradon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21403; -- Invis Legion Hold Caster
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21400; -- Eckert
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21399; -- Erick Nateson
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21398; -- Theine Brightsong
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21397; -- Aeman Brightsong
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21386; -- Dark Conclave Hawkeye
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21385; -- Dark Conclave Scorncrow
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21384; -- Dark Conclave Harbinger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21381; -- Young Crust Burster
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21370; -- Ethereal Nethermancer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21368; -- Ethereal Plunderer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21357; -- Wing Commander Nuainn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21352; -- Ogre Building Bunny Summoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21348; -- Shadowmoon Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21330; -- Kurdran Wildhammer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21313; -- Dead Clefthoof
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21300; -- Fel Corrupter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21293; -- Borak, Son of Oronok
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21285; -- Auchenai Doomsayer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21284; -- Auchenai Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21262; -- Goblin Equipment Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21261; -- Big Wagon Full of Explosives Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21259; -- Crash Bigbomb
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21256; -- Vurtok Axebreaker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21242; -- Auchenai Death-Speaker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21237; -- Invis Horde Siege Engine - East 02
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21234; -- Blade's Edge Invisible Stalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21203; -- Blade's Edge - Rock Flayer Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21200; -- Screeching Spirit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21198; -- Deathtalon Spirit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21175; -- Magister Bloodhawk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21159; -- Containment Beam
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21152; -- Station Bot-Jock
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21145; -- Little Azimi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21142; -- Dire Timber Wolf Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21114; -- Station Technician
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21096; -- Credit Marker: Air
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21089; -- Sunfury Blood Knight
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21080; -- Dormant Infernal
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21074; -- Living Grove Defender Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21061; -- Enraged Fire Spirit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21053; -- Blade's Edge - Orb Trigger 03
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21049; -- Spirit of the Past
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21040; -- Outraged Raven's Wood Sapling
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21024; -- Earthmender Torlok
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21023; -- Stronglimb Deeproot
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21021; -- Scorch Imp
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21006; -- Lieutenant Meridian
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20989; -- Dealer Sadaqat
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20981; -- Dealer Najeeb
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20980; -- Dealer Rashaad
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20925; -- Scalded Basilisk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20924; -- Grishnath Basilisk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20921; -- Shauly Pore
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20917; -- Zinyen Swiftstrider
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20894; -- Miihi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20891; -- Skraa
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20890; -- Siflaed Coldhammer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20878; -- Deathforge Guardian
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20877; -- Shattrath Refugee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20876; -- Human Refugee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20874; -- Skettis Refugee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20872; -- Deathforge Summoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20871; -- Aurine Moonblaze
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20856; -- Blade's Edge - Deadsoul Orb Flight 05
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20855; -- Blade's Edge - Deadsoul Orb Flight 04
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20853; -- Blade's Edge - Deadsoul Orb Flight 03
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20852; -- Blade's Edge - Deadsoul Orb Flight 02
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20851; -- Blade's Edge - Deadsoul Orb Flight 01
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20811; -- Ghabar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20810; -- Mehrdad
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20808; -- Scribe Veredis
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20807; -- Scribe Saalyn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20793; -- Field Marshal Brock
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20791; -- Iorioa
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20780; -- Kaylaan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20777; -- Talbuk Sire
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20775; -- Markaru
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20774; -- Farahlon Lasher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20773; -- Barbscale Crocolisk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20772; -- Netherock
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20751; -- Daggermaw Lashtail
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20748; -- Thunderlord Dire Wolf
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20736; -- Blade's Edge - Legion - Invis Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20722; -- Herald Bran'daan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20713; -- Fey Drake
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20670; -- Blade's Edge - Flesh Beast Zap Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20666; -- Blade's Edge - Orb Trigger 01
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20616; -- Asuur
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20614; -- Razaani Spell-Thief
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20613; -- Arodis Sunblade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20610; -- Talbuk Doe
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20609; -- Razaani Nexus Stalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20601; -- Razaani Raider
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20563; -- Grand Commander Ruusk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20562; -- Invisible Stalker (Scale x5)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20514; -- Searing Elemental
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20511; -- Ilsa Blusterbrew
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20510; -- Brunn Flamebeard
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20502; -- Eclipsion Dragonhawk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20471; -- Nether-Stalker Nauthis
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20470; -- Zephyrion
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20431; -- Eclipse Point - Bloodcrystal Spell Orgin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20397; -- Overseer Seylanna
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20389; -- Lee Sparks
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20341; -- Nether-Stalker Oazul
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20338; -- Western Pipe Credit Marker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20337; -- Southern Pipe Credit Marker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20336; -- Eastern Pipe Credit Marker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20331; -- G'eras Vindicator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20296; -- Teleporter Explosion Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20285; -- Gan'arg Warp-Tinker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20283; -- Marshrock Stomper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20250; -- Rashere Pridehoof
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20248; -- Sunfury Nethermancer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20242; -- Karaaz
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20241; -- Provisioner Nasela
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20230; -- Blade's Edge - Bladespire Trigger 01
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20226; -- Manaforge Visual Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20205; -- Audi the Needle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20204; -- Action Jaxon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20203; -- Nether Technician
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20197; -- Bogflare Needler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20162; -- Veronia
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20136; -- Sunfury Researcher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20135; -- Sunfury Arch Mage
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20134; -- Sunfury Arcanist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20113; -- Lashh'an Matriarch
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20112; -- Wind Trader Tuluman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20102; -- Goblin Commoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20096; -- Uriku
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20093; -- Blade's Edge - Arakkoa Spell Origin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20088; -- Bloodscale Overseer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20084; -- Image of Nexus-Prince Haramad
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20068; -- Zuben Eschamali
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20067; -- Zuben Elgenubi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20066; -- Gahruj
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20058; -- Bloodmaul Dire Wolf
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20024; -- Blade's Edge Kneel Target 03
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20023; -- Blade's Edge Kneel Target 02
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20003; -- Blade's Edge Kneel Target 01
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19990; -- Grishna Scorncrow
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19989; -- Grishna Harbinger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19988; -- Grishna Falconwing
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19979; -- Deathforge Technician
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19961; -- Doomforge Attendant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19946; -- Darkcrest Slaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19945; -- Lashh'an Windwalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19944; -- Lashh'an Wing Guard
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19943; -- Lashh'an Talonite
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19880; -- Nether-Stalker Khay'ji
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19845; -- Area 52 Fireworks Controller
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19844; -- Nitrin the Learned
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19832; -- Doctor Vomisa, Ph.T.
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19831; -- Commander Dawnforge
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19827; -- Dark Conclave Ravenguard
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19826; -- Dark Conclave Shadowmancer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19825; -- Dark Conclave Talonite
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19802; -- Illidari Shocktrooper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19799; -- Illidari Dreadbringer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19796; -- Eclipsion Archmage
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19792; -- Eclipsion Centurion
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19789; -- Coilskar Waterkeeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19780; -- Off-Duty Engineer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19779; -- Sunfury Geologist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19773; -- Spirit Sage Zran
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19772; -- Spirit Sage Gartok
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19766; -- Jakk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19762; -- Coilskar Defender
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19759; -- Newly Crafted Infernal
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19754; -- Deathforge Tinkerer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19740; -- Wrathwalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19734; -- Fungal Giant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19728; -- Mama Wheeler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19726; -- "Creepjack"
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19725; -- "Epic" Malone
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19722; -- Muheru the Weaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19715; -- Ezekiel
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19709; -- Chief Engineer Trep
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19706; -- Marshrock Threshalisk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19702; -- Aldor Acolyte
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19697; -- Ha'lei
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19686; -- Nether Anomaly
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19684; -- Haggard War Veteran
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19680; -- Aldor Spawn Controller
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19677; -- Consortium Spell Marker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19676; -- "Captain" Kaftiz
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19674; -- Nexus-Prince Haramad
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19672; -- Consortium Laborer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19664; -- Muffin Man Moser
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19663; -- Madame Ruby
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19662; -- Aaron Hollman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19661; -- Viggz Shinesparked
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19660; -- Garrosh's Buff Bots
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19656; -- Invisible Location Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19655; -- Area 52 Ethereal Technology Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19654; -- Area 52 Analyzer Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19651; -- Seasoned Vindicator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19646; -- Thrall Event Dummy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19645; -- Papa Wheeler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19643; -- Sunfury Astromancer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19642; -- Zaxxis Stalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19634; -- Lead Sapper Blastfizzle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19628; -- Furan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19627; -- Sulamin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19626; -- Belanna
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19623; -- Doc
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19621; -- Bill
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19620; -- Arcanist Ardonis Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19619; -- Commander Dawnforge Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19618; -- Warpmaster Lyssendra Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19610; -- Irradiated Worker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19593; -- Spellbinder Maryana
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19576; -- Xyrol
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19570; -- Rocket-Chief Fuselage
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19569; -- Netherologist Coppernickels
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19538; -- Dealer Senzik
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19537; -- Dealer Malij
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19536; -- Dealer Jadyan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19533; -- Dealer Aljaan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19521; -- Arrond
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19520; -- Lelagar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19517; -- Alorra
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19497; -- Caoileann
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19485; -- Magister Falris
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19484; -- Netherstorm Repair Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19483; -- Netherstorm Use Standing Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19482; -- Sagan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19475; -- Harbinger Haronem
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19469; -- Magistrix Larynna
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19468; -- Spymaster Thalodien
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19467; -- Anchorite Karja
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19466; -- Exarch Orelis
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19453; -- Sunfury Captain
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19443; -- Tagar Spinebreaker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19439; -- Netherstorm Work Mining Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19437; -- Netherstorm Kneel Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19434; -- Dreadcaller
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19421; -- Netherstorm Crystal Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19411; -- Shattered Hand Warlock
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19410; -- Shattered Hand Neophyte
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19402; -- Withered Bog Lord
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19395; -- Bron Goldhammer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19394; -- Barimoke Wildbeard
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19388; -- Wildhammer Stronghold Target Dummy Right
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19387; -- Wildhammer Stronghold Target Dummy Left
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19384; -- Wildhammer Scout
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19377; -- Neophyte Nemarn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19373; -- Mari Stonehand
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19372; -- Oran Blusterbrew
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19371; -- Dalin Stouthammer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19370; -- Ordinn Thunderfist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19369; -- Celie Steelwing
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19367; -- "Screaming" Screed Luckheed
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19359; -- Legion Transporter: Beta (Alliance)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19349; -- Thornfang Ravager
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19346; -- Harbinger Erothem
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19344; -- Legassi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19337; -- Aldor Marksman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19335; -- Subjugator Yalqiz
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19331; -- Quartermaster Enuril
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19330; -- Lisrythe Bloodwatch
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19329; -- Legion Antenna: Mageddon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19326; -- Legion Antenna: Oblivion
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19321; -- Quartermaster Endarin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19309; -- Sergeant Altumus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19299; -- Deathwhisperer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19298; -- Warbringer Arix'Amal
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19296; -- Innkeeper Biribi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19294; -- Earthbinder Galandria Nightbreeze
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19292; -- Legion Transporter: Beta
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19289; -- Vagabond
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19283; -- Vagrant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19271; -- Albert Quarksprocket
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19270; -- Shattrath Saul
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19261; -- Infernal Warbringer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19258; -- Bloodmage
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19257; -- Arcanist Torseldori
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19256; -- Sergeant Shatterskull
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19255; -- General Krakork
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19252; -- High Enchanter Bardolan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19251; -- Enchantress Volali
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19250; -- Enchanter Aeldron
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19249; -- Enchantress Metura
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19248; -- Enchanter Salias
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19244; -- Trader Endernor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19242; -- Olodam Farhollow
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19240; -- Selanam the Blade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19239; -- Mahir Redstroke
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19238; -- Urumir Stavebright
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19236; -- Quelama Lightblade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19234; -- Yurial Soulwater
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19232; -- Innkeeper Haelthol
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19223; -- Granny Smith
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19217; -- Ravandwyr
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19216; -- Grand Anchorite Almonen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19202; -- Emissary Mordin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19196; -- Cro Threadstrong
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19195; -- Jim Saltit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19194; -- Ernie Packwell
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19185; -- Jack Trapper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19184; -- Mildred Fletcher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19181; -- Lemla Hopewing
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19176; -- Tauren Commoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19172; -- Gnome Commoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19170; -- Peasant Refugee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19169; -- Blood Elf Commoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19164; -- Refugee Child
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19163; -- Refugee Kid
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19159; -- Allerian Peasant Cosmetic
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19154; -- Soot
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19153; -- Aldor Neophyte
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19150; -- Orc Refugee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19148; -- Dwarf Commoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19147; -- Allerian Peasant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19144; -- Mag'har Refugee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19142; -- Aldor Anchorite
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19138; -- Anchorite Attendant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19137; -- "Shotgun" Jones
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19136; -- Flamewaker Imp
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19077; -- Dwarf Refugee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19076; -- High Elf Refugee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19075; -- Skettis Outcast
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19074; -- Skreah
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19073; -- Nibblet
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19065; -- Inessera
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19064; -- Leatei
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19056; -- Cecil Meyers
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19051; -- Araac
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19050; -- Garul
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19049; -- Karokka
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19047; -- Lissaf
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19046; -- Minalei
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19045; -- Oloraak
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19043; -- Ahemen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19042; -- Leeli Longhaggle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19041; -- Jump-a-tron 4000
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19033; -- Nicole Bartlett
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19009; -- Invis Horde Siege Engine - West
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19008; -- Invis Alliance Siege Engine - West
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19000; -- High Elf Ranger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18993; -- Naka
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18977; -- Felguard Destroyer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18964; -- Injured Talbuk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18956; -- Lakka
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18911; -- Juno Dufrain
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18893; -- Spymistress Mehlisah Highcrown
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18891; -- Spy To'gun
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18883; -- Mana Snapper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18875; -- Zaxxis Raider
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18873; -- Disembodied Protector
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18872; -- Disembodied Vindicator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18865; -- Warp Aberration
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18864; -- Mana Wraith
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18860; -- Daughter of Destiny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18857; -- Sunfury Warp-Master
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18856; -- Arcane Annihilator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18855; -- Sunfury Magister
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18853; -- Sunfury Bloodwarder
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18852; -- Sunfury Warp-Engineer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18850; -- Sunfury Guardsman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18843; -- Bleeding Hollow Clan Ruins Credit Marker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18842; -- Garadar Credit Marker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18841; -- Laughing Skull Clan Ruins Credit Marker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18840; -- Sunspring Post Credit Marker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18818; -- Invis Horde Siege Engine - East
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18796; -- Fel Overseer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18793; -- Invisible Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18762; -- Tinkerbell
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18759; -- Zangarmarsh PvP Beam (Blue)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18752; -- Zebig
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18747; -- Krugosh
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18745; -- Captain Auric Sunchaser
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18719; -- Shadowy Advisor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18717; -- Shadowy Laborer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18716; -- Shadowy Initiate
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18715; -- Private Weeks
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18714; -- Scout Neftis
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18713; -- Lieutenant Gravelhammer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18704; -- Taela Everstride
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18653; -- Seth
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18652; -- Zahlia
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18622; -- Iz'zard
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18600; -- Injured Refugee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18597; -- Sha'nir
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18596; -- Arcanist Adyria
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18594; -- Dathris Sunstriker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18593; -- Scryer Retainer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18581; -- Alliance Field Scout
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18568; -- Scryer Arcane Guardian
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18564; -- Horde Field Scout
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18548; -- Firewing Courier
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18547; -- Scryer Arcanist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18538; -- Ishanah
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18537; -- Adyen the Lightwarden
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18531; -- Magistrix Fyalenn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18492; -- Tavgren's Kodo
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18484; -- Wind Trader Lathrai
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18477; -- Timber Worg Alpha
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18476; -- Timber Worg
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18470; -- Bonelasher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18467; -- Dreadfang Widow
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18466; -- Dreadfang Lurker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18465; -- Warp Hunter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18464; -- Warp Stalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18463; -- Dampscale Devourer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18460; -- Lost Spirit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18459; -- Jenai Starwhisper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18453; -- Skithian Windripper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18452; -- Skithian Dreadhawk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18450; -- Shienor Sorcerer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18449; -- Shienor Talonite
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18446; -- Earthbinder Tavgren
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18438; -- Naphthal'ar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18427; -- Fazu
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18424; -- Warden Treelos
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18416; -- Huntress Kima
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18395; -- Warmaul Pyre Credit Marker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18393; -- Warmaul Ogre Credit Marker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18391; -- Giselda the Crone
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18390; -- Ros'eleth
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18389; -- Thander
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18388; -- Shadow Council Credit Marker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18387; -- Bertelm
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18354; -- Lump's Quest Credit
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18353; -- Huntress Bintook
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18352; -- Boulderfist Hunter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18350; -- Jaela
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18349; -- Iressa
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18348; -- Fanin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18346; -- Consortium Claviger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18335; -- Consortium Recruiter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18334; -- Wild Elekk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18333; -- Shadrek
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18332; -- Talut
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18307; -- Burning Blade Pyre (03)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18306; -- Burning Blade Pyre (02)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18297; -- Gankly Rottenfist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18289; -- Bull Elekk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18286; -- Mragesh
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18276; -- Zerid
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18274; -- Consortium Overseer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18272; -- Consortium Gemcutter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18267; -- Battlecryer Blackeye
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18265; -- Gezhe
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18262; -- Unkor the Ruthless
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18261; -- Lantresor of the Blade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18260; -- Boulderfist Invader
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18252; -- Andarl
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18234; -- Elementalist Yal'hah
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18228; -- Garadar Event Controller (Farseer)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18220; -- Ravenous Windroc
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18218; -- Harold Lane
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18215; -- Murkblood Target Dummy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18214; -- Fenclaw Thrasher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18213; -- Mire Hydra
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18212; -- Mudfin Frenzy
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18205; -- Clefthoof
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18173; -- Bloodmyst Elekk Dismounter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18166; -- Khadgar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18144; -- Windyreed Quest Credit (Hut 03)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18143; -- Windyreed Quest Credit (Hut 02)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18138; -- Umbrafen Eel
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18134; -- Fen Strider
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18132; -- Umbraglow Stinger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18124; -- Withered Giant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18110; -- Windyreed Quest Credit (Big Hut)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18089; -- Bloodscale Slavedriver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18086; -- Darkcrest Taskmaster
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18064; -- Warmaul Shaman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18034; -- Defender Katroi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18033; -- Dark Worg
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18032; -- Defender Ashoon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18031; -- Defender Zaibach
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18030; -- Knight-Defender Zunade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18028; -- Defender Akee
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18027; -- Defender Kadithuul
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18000; -- Serpent Steam Pump Credit Marker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17988; -- Grand Finale Event Manager
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17985; -- As the Crow Flies Credit Marker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17981; -- Voidspawn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17974; -- Captured Sunhawk Agent Invisible Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17930; -- Nabek
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17929; -- Kioni
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17909; -- Lauranna Thar'well
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17904; -- Fedryen Swiftspear
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17900; -- Ashyen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17883; -- Velen Event Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17843; -- Vindicator Kuros
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17841; -- Ysiel Windsinger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17825; -- Interrogator Elysia
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17824; -- Captured Sunhawk Agent
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17773; -- Ossco
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17713; -- Bloodcursed Naga
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17703; -- Messenger Hermesius
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17684; -- Vindicator Boros
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17676; -- Achelus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17674; -- Prince Toreth
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17673; -- Stinkhorn Striker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17667; -- Beega
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17663; -- Jessera of Mac'Aree
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17661; -- Deathclaw
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17658; -- Exarch Admetius
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17636; -- Kalynna Lathred
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17586; -- Vorkhan the Elekk Herder
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17585; -- Quartermaster Urgronn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17550; -- Void Anomaly
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17530; -- Elekk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17514; -- Bati
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17513; -- Harnan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17486; -- Ziz
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17481; -- Semid
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17475; -- Murgurgula
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17352; -- Corrupted Treant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17350; -- Royal Blue Flutterer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17348; -- Elder Brown Bear
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17347; -- Grizzled Brown Bear
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17345; -- Brown Bear
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17344; -- Mutated Constrictor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17343; -- Thistle Lasher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17342; -- Axxarien Hellcaller
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17340; -- Axxarien Shadowstalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17330; -- Blacksilt Seer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17328; -- Blacksilt Shorestriker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17326; -- Blacksilt Scout
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17325; -- Blacksilt Forager
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17323; -- Contaminated Wildkin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17268; -- Image of Technician Zhanaa
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17232; -- Cryptographer Aurren
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17214; -- Anchorite Fateema
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17203; -- Nightstalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17202; -- Infected Nightstalker Runt
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17197; -- Root Thresher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17196; -- Root Trapper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17192; -- Siltfin Hunter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17191; -- Siltfin Oracle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17190; -- Siltfin Murloc
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17160; -- Living Cyclone
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17159; -- Storm Rager
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17158; -- Dust Howler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17148; -- Kil'sorrow Deathsworn
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17147; -- Kil'sorrow Cultist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17146; -- Kil'sorrow Spellbinder
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17138; -- Warmaul Reaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17137; -- Boulderfist Mage
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17136; -- Boulderfist Warrior
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17135; -- Boulderfist Mystic
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17134; -- Boulderfist Crusher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17133; -- Aged Clefthoof
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17132; -- Clefthoof Bull
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17131; -- Talbuk Thorngrazer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17130; -- Talbuk Stag
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17128; -- Windroc
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17117; -- Injured Night Elf Priestess
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17116; -- Exarch Menelaous
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17090; -- Silithus Dust Turnin Quest Doodad
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17088; -- Shadowy Summoner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17082; -- Rifleman Torrig
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17081; -- Scout Bloodfist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17074; -- Cenarion Scout
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17008; -- Gul'dan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16978; -- Lieutenant Commander Thalvos
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16977; -- Arch Mage Xintor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16973; -- Bonestripper Vulture
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16972; -- Bonestripper Buzzard
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16960; -- Sister of Grief
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16959; -- Dread Tactician
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16954; -- Forge Camp Legionnaire
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16952; -- Anger Guard
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16947; -- Gan'arg Servant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16933; -- Razorfang Ravager
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16906; -- Unyielding Knight
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16905; -- Unyielding Sorcerer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16904; -- Unyielding Footman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16876; -- Bonechewer Mutant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16870; -- Shattered Hand Captain
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16846; -- Mag'har Grunt
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16818; -- Festival Talespinner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16817; -- Festival Loremaster
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16805; -- Broken Skeleton
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16772; -- Bonechewer Devastator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16768; -- Nurguni
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16766; -- Issca
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16765; -- Ellomin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16755; -- Lunaraa
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16749; -- Edirah
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16739; -- Caregiver Breel
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16718; -- Phea
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16710; -- Kellag
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16709; -- Cuzi
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16707; -- Eoch
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16706; -- Musal
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16632; -- Oss
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16591; -- Thrallmar Peon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16589; -- Guard Captain Cragtar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16584; -- Watch Commander Krunk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16579; -- Falcon Watch Sentinel
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16578; -- Blood Elf Pilgrim
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16577; -- Martik Tor'seldori
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16553; -- Caregiver Chellan
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16528; -- Provisioner Vredigar
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16476; -- Jaeleil
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16353; -- Mistbat
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16352; -- Greater Spindleweb
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16318; -- Deatholme Darkmage
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16316; -- Stonewing Tracker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16301; -- Risen Hungerer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16300; -- Risen Creeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16200; -- Deathstalker Rathiel
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16199; -- Magister Darenis
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16198; -- Apothecary Renzithen
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16196; -- Apothecary Thedra
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16183; -- Courier Dawnstrider
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16091; -- Dirk Thunderwood
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15695; -- Vek Twins Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15693; -- Jonathan the Revelator
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15631; -- Spotlight
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15611; -- Cenarion Scout Jalia
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15609; -- Cenarion Scout Landion
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15540; -- Windcaller Kaldon
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15504; -- Vethsera
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15503; -- Kandrostrasz
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15502; -- Andorgos
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15500; -- Keyl Swiftclaw
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15454; -- Anachronos Quest Trigger Invisible
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15426; -- Ahn'Qiraj Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15420; -- Prospector Anvilward
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15419; -- Kania
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15282; -- Aurel Goldleaf
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15270; -- Huum Wildmane
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15222; -- Rutgar Invisible Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15221; -- Frankal Invisible Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15183; -- Geologist Larksbane
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15182; -- Vish Kozus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15181; -- Commander Mar'alith
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15180; -- Baristolth of the Shifting Sands
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15179; -- Mishta
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15176; -- Vargus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15175; -- Khur Hornstriker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15172; -- Glibb
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15171; -- Frankal Stonebridge
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15170; -- Rutgar Glyphshaper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15169; -- Ralo'shan the Eternal Watcher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=14637; -- Zorbin Fandazzle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=14634; -- Lookout Captain Lolo Longstriker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=14628; -- Evonice Sootsmoker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=14627; -- Hansel Heavyhands
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=14626; -- Taskmaster Scrange
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=14390; -- Expeditionary Mountaineer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=1433; -- Corbett Schneider
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=13737; -- Marandis' Sister
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=1322; -- Maxton Strang
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=11818; -- Orik'ando
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=11735; -- Stonelash Scorpid
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=11717; -- Bethan Bluewater
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=11596; -- Smeed Scrabblescrew
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=11562; -- Drysnap Crawler
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=11438; -- Bibbly F'utzbuckle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=11103; -- Innkeeper Lyshaerya
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=10924; -- Ivy Leafrunner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=10923; -- Tenell Leafrunner
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=10921; -- Taronn Redfeather
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=10541; -- Krakle's Thermometer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000 WHERE `entry`=27110; -- Injured Warsong Engineer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000 WHERE `entry`=27106; -- Injured Warsong Warrior
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=5000, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=31308; -- (Wrathgate Monster) Abomination
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=5000, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=31292; -- (Wrathgate Monster) Frail Construct
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2280, `rangeattacktime`=2000, `unit_class`=4, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37017; -- Skybreaker Assassin
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2280, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37544; -- Spire Gargoyle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768 WHERE `entry`=55249; -- Bodie
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768 WHERE `entry`=55248; -- Wallace
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=12 WHERE `entry`=37022; -- Blighted Abomination
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=536904448, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=18240; -- Sunspring Villager
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=19339; -- Korthul
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=18208; -- Murkblood Event Controller
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554944, `VehicleId`=705 WHERE `entry`=39789; -- Kristoff's Chain Vehicle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=38463; -- Empowering Orb Visual Stalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=37824; -- Abomination Wing Mad Scientist Stalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=36934; -- Empowering Orb Controller Stalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=36659; -- Abomination Wing Orange Gas Stalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554688 WHERE `entry`=53662; -- Solar Core Channel Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554688 WHERE `entry`=53388; -- Ember Pool Pulse Pre-Load
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554688 WHERE `entry`=52976; -- Chain Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=38319; -- Blood Queen Door
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=38317; -- Tear Gas Target Stalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554432 WHERE `entry`=47308; -- Felwood Honey Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554432 WHERE `entry`=35592; -- Invisible Stalker (Float, Uninteractible, GiganticAOI)
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=19698; -- Greatfather Aldrimus
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=37663; -- Darkfallen Noble
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=17144; -- Goretooth
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37665; -- Darkfallen Lieutenant
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37664; -- Darkfallen Archmage
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37662; -- Darkfallen Commander
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37595; -- Darkfallen Blood Knight
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37571; -- Darkfallen Advisor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37144; -- Skybreaker Marksman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37004; -- Skybreaker Dreadblade
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=36998; -- Skybreaker Protector
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24676; -- Crazed Northsea Slaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24215; -- Jlarborn the Strategist
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23300; -- Gahk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23253; -- Kronk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23233; -- Chu'a'lor
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18046; -- Rajah Haghazed
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51755; -- Human Child
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=256 WHERE `entry`=53013; -- Crimson Lasher
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags2`=2050, `dynamicflags`=0 WHERE `entry`=37181; -- The Lich King
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=1, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=37666; -- Darkfallen Tactician
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=24250; -- Dragonflayer Fleshripper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=12 WHERE `entry`=38228; -- Plagued Insect
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=38858; -- Goodman the "Closer"
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=38231; -- Blood Parasite
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=38229; -- Frozen Insect
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=38194; -- Torgo the Elder
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37996; -- Ebon Champion
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37928; -- Argent Champion
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37782; -- Flesh-eating Insect
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37744; -- Frost Freeze Trap
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37687; -- Alchemist Finklestein
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37231; -- Rope Beam Stalker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37119; -- Highlord Tirion Fordring
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=36855; -- Lady Deathwhisper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=35460; -- Kor'kron Elite
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=35368; -- Thrall
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27639; -- Ring-Lord Sorceress
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24919; -- Wrath Herald
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24249; -- Dragonflayer Soulreaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23660; -- Dragonflayer Thane
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23652; -- Dragonflayer Vrykul
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23489; -- Drake Dealer Hurlunk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23370; -- Dragonmaw Tower Controller
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22924; -- Arthorn Windsong
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21211; -- Invis Deathforge Target
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21210; -- Invis Deathforge Caster
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21124; -- Felsworn Daggermaw
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19719; -- Ricole Nichie
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=48457; -- Tainted Squirrel
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=38205; -- Newborn Bloodpetal
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=1500, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=26212; -- Captain Gryan Stoutmantle
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=1500, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37689; -- Commander Kunz
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=1500, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28125; -- Dr. Rogers
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=1000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37546; -- Frenzied Abomination
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.888888, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=31403; -- Azure Spellweaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33438; -- Boneguard Footman
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32281; -- Guardian of Time
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26349; -- Goramosh
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26185; -- Lurid
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25724; -- Ascended Mage Hunter
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25722; -- Coldarra Spellweaver
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16303; -- Dreadbone Skeleton
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.8, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=26239; -- Ghost of Ahune
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.8, `rangeattacktime`=2000, `unit_flags`=0, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=23876; -- Spore
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.8, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=22127; -- Wildlord Antelarion
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.8, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=5 WHERE `entry`=29746; -- Databank
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30309; -- Shambles
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29123; -- Monstrous Wight
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27230; -- Silvercoat Stag
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26616; -- Blighted Elk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26615; -- Snowfall Elk
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26363; -- Tallhorn Stag
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23102; -- Terokkar Trigger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22133; -- Faradrella
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.777776, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=25026; -- Mutinous Sea Dog
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.777776, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30306; -- Bileblow
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.777776, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27729; -- Enraging Ghoul
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.777776, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16309; -- Gangled Cannibal
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.666668, `rangeattacktime`=2000, `unit_flags`=536903936, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=26943; -- Battered Drakkari Berserker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.666668, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=21004; -- Lesser Nether Drake
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29656; -- Drakuru Berserker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27941; -- Drakkari Plague Spreader
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26458; -- Drakkari Plaguebringer
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23874; -- Thornvine Creeper
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21722; -- Enslaved Netherwing Drake
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18137; -- Marsh Dredger
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18136; -- Marsh Lurker
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17373; -- Timberstrider
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=13717; -- Centaur Pariah
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.666668, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18282; -- Lord Klaq
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.6, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=16197; -- Arcanist Vandril
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24359; -- Apothecary Anastasia
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16903; -- Blistering Oozeling
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16901; -- Blistering Rot
UPDATE `creature_template` SET `speed_walk`=1.142857, `speed_run`=0.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24412; -- Daily Dungeon Image Bunny
UPDATE `creature_template` SET `speed_walk`=1.142857, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26583; -- Horrified Drakkari Shaman
UPDATE `creature_template` SET `speed_walk`=1.142857, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25392; -- High Priest Andorath
UPDATE `creature_template` SET `speed_walk`=1.142857, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23308; -- Dragonmaw Peon Work Node
UPDATE `creature_template` SET `speed_walk`=1.142857, `dynamicflags`=4 WHERE `entry`=42231; -- Captain Metlek
UPDATE `creature_template` SET `speed_walk`=1.142857 WHERE `entry`=42218; -- Stormwind Royal Guard
UPDATE `creature_template` SET `speed_walk`=1.142857 WHERE `entry`=35234; -- Hired Looter
UPDATE `creature_template` SET `speed_walk`=1.142857 WHERE `entry`=29202; -- Knight of the Ebon Blade
UPDATE `creature_template` SET `speed_walk`=1.142857 WHERE `entry`=12996; -- Mounted Ironforge Mountaineer
UPDATE `creature_template` SET `speed_walk`=1.111111, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29875; -- Icemane Yeti
UPDATE `creature_template` SET `speed_walk`=1.111111, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29352; -- Kirgaraak
UPDATE `creature_template` SET `speed_walk`=1.071429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=4 WHERE `entry`=28487; -- Val'kyr Battle-maiden
UPDATE `creature_template` SET `speed_walk`=1.071429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=3 WHERE `entry`=24258; -- Val'kyr Overseer
UPDATE `creature_template` SET `speed_walk`=1.071429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31853; -- Cruel Overseer
UPDATE `creature_template` SET `speed_walk`=1.071429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31320; -- Umbral Brute
UPDATE `creature_template` SET `speed_walk`=1.071429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24992; -- The Big Gun
UPDATE `creature_template` SET `speed_walk`=1.071429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24272; -- Val'kyr Watcher
UPDATE `creature_template` SET `speed_walk`=1.071429, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=12 WHERE `entry`=37098; -- Val'kyr Herald
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.2, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=30177; -- Ravaged Cavedweller Worg
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.2, `rangeattacktime`=2000, `unit_flags2`=2049 WHERE `entry`=32569; -- Corpse of the Fallen Worg
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30560; -- The RP-GG
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30164; -- Cavedweller Worg
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30005; -- Lodge-Matron Embla
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25791; -- Oil-stained Wolf
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25739; -- Steam Vent
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25675; -- Tundra Wolf
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24677; -- Spearfang Worg
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24475; -- Bloodthirsty Worg
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24439; -- Sack of Relics
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24128; -- Wild Worg
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24113; -- Dragonflayer Worg Corpse
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24026; -- Fanggore Worg
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18562; -- Purple Ground Rune
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.2, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24063; -- Dragonflayer Worg
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1, `unit_flags`=67108864, `dynamicflags`=4 WHERE `entry`=43981; -- Jadecrest Basilisk
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33587968, `dynamicflags`=0 WHERE `entry`=19768; -- Coilskar Siren
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=21380; -- Greater Crust Burster
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20076; -- Naga Distiller (Coilskar Point)
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18088; -- Bloodscale Enchantress
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15652; -- Elder Springpaw
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=10415; -- Ash'ari Crystal
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=0.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28274; -- Plague Sprayer
UPDATE `creature_template` SET `speed_walk`=1, `dynamicflags`=0 WHERE `entry`=14872; -- Trok
UPDATE `creature_template` SET `speed_walk`=1, `dynamicflags`=0 WHERE `entry`=14860; -- Flik
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27686; -- Frigid Geist Attacker
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27533; -- Frigid Geist
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=2.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27363; -- Smoldering Geist
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=1, `unit_flags2`=33556480 WHERE `entry`=43871; -- War Construct
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18586; -- Coosh'coosh
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22377; -- Akuno
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22175; -- Apexis Flayer
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22021; -- O'Mally's Instrument Bunny
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21942; -- Gnome Cannon Shooter #Singing Ridge
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21872; -- The Voice of Gorefiend
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21478; -- Rocknail Ripper
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21026; -- Earthmender Gorboto
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20671; -- Ripfang Lynx
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18204; -- Ortor of Murkblood
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23326; -- Nethermine Ravager
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.888888, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=31402; -- Azure Scalebane
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32572; -- Dragonblight Mage Hunter
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26917; -- Alexstrasza the Life-Binder
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25728; -- Coldarra Wyrmkin
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25717; -- Coldarra Scalesworn
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25716; -- General Cerulean
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25585; -- Beryl Mage Hunter
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24918; -- Felblood Initiate
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.888888, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27633; -- Azure Inquisitor
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.8333319, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28258; -- Hath'ar Skimmer
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.8333319, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25622; -- Nerub'ar Tunneler
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=29733; -- Elder Shaman Moky
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=29690; -- Chief Rageclaw
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=26827; -- Howling Wolvar Lookout
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18803; -- Stillpine Ambassador Frasaboo
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29686; -- Captured Rageclaw
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29439; -- Rageclaw Hunter
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29438; -- Rageclaw Primalist
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29437; -- Rageclaw Berserker
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28315; -- Shaman Vekjik
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26825; -- Howling Wolvar Shaman
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26823; -- Howling Wolvar Trainer
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26436; -- Redfang Elder
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26428; -- Frostpaw Shaman
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26357; -- Frostpaw Warrior
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26356; -- Redfang Hunter
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26201; -- Snowfall Glade Shaman
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26199; -- Snowfall Glade Den Mother
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26198; -- Snowfall Glade Wolvar
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26197; -- Snowfall Glade Reaver
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17321; -- Bristlelimb Warrior
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17320; -- Bristlelimb Shaman
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17114; -- Arugoo of the Stillpine
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=11554; -- Grazle
UPDATE `creature_template` SET `speed_walk`=0.9920629, `speed_run`=0.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28158; -- Withered Argent Footman
UPDATE `creature_template` SET `speed_walk`=0.9920629 WHERE `entry`=49161; -- Altered Beast
UPDATE `creature_template` SET `speed_walk`=0.9920571, `speed_run`=0.8, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37545; -- Spire Minion
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=67108864, `dynamicflags`=4 WHERE `entry`=20387; -- Young Sporebat
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=2 WHERE `entry`=24563; -- Nerub'ar Venomspitter
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=1.5 WHERE `entry`=26607; -- Anub'ar Blightbeast
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32294; -- Knight Dameron
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25434; -- Magmoth Crusher
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25432; -- Mate of Magmothregar
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20387; -- Young Sporebat
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18128; -- Sporebat
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=0.944444, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20326; -- Mo'arg Warp-Master
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=0.944444, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19960; -- Doomforge Engineer
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=0.944444, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19756; -- Deathforge Smith
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30448; -- Plains Mammoth
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30260; -- Stoic Mammoth
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29402; -- Ironwool Mammoth
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26273; -- Emaciated Mammoth Calf
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26272; -- Emaciated Mammoth
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25862; -- Khu'nok the Behemoth
UPDATE `creature_template` SET `speed_walk`=0.9523814, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25452; -- Scourged Mammoth
UPDATE `creature_template` SET `speed_walk`=0.9523801, `speed_run`=1.2, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37230; -- Spire Frostwyrm
UPDATE `creature_template` SET `speed_walk`=0.9285714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=0 WHERE `entry`=29434; -- Injured Goblin Miner
UPDATE `creature_template` SET `speed_walk`=0.9285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26589; -- Mr. Floppy
UPDATE `creature_template` SET `speed_walk`=0.9285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26588; -- Emily
UPDATE `creature_template` SET `speed_walk`=0.9285714, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17969; -- Kayra Longmane
UPDATE `creature_template` SET `speed_walk`=0.9285714, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17374; -- Greater Timberstrider
UPDATE `creature_template` SET `speed_walk`=0.9126986, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23427; -- Illidari Lord Balthas
UPDATE `creature_template` SET `speed_walk`=0.9126986, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21287; -- Warbringer Razuun
UPDATE `creature_template` SET `speed_walk`=0.9126986, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19847; -- Levixus
UPDATE `creature_template` SET `speed_walk`=0.9126986, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19747; -- Baelmon the Hound-Master
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25679; -- Steam Frog
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27009; -- Drakegore
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=537133056, `unit_flags2`=1, `dynamicflags`=32 WHERE `entry`=54504; -- Damaged Tonk
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27408; -- Duskhowl Prowler
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26592; -- Graymist Hunter
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=29151; -- Cricket
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=24767; -- Molly
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=31296; -- (Wrathgate Alliance) Fordragon Footman
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=32467; -- Skeletal Reaver
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=60; -- Ruklar the Trapper
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=3232; -- Bristleback Interloper
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31754; -- Glacial Bonelord
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30152; -- Bruor Ironbane
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27849; -- Patchy
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27461; -- Bambina
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27460; -- Mother of Bambina
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27459; -- Thudder
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27458; -- Flora
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27421; -- Fern Feeder Moth
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26503; -- Scalawag Frog
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26366; -- Entropic Ooze
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25677; -- Borean Frog
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25668; -- Vengeful Taunka Spirit
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25482; -- Sand Turtle
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25481; -- Landing Crawler
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25209; -- Claximus
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24270; -- Devouring Maggot
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23945; -- Fjord Crow
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23900; -- Theramore Marksman
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23766; -- Morgom
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22046; -- [PH] Cave Bat
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21810; -- Wyrmcult Hewer
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21637; -- Wyrmcult Scout
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21382; -- Wyrmcult Zealot
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21064; -- Red Dragonhawk Hatchling
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21063; -- Silver Dragonhawk Hatchling
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21055; -- Golden Dragonhawk Hatchling
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20330; -- Bloodmaul Battle Worg
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20281; -- Drijya
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19665; -- Ewe
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19588; -- Maxx A. Million Mk. II
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18720; -- Shadowmaster Grieve
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18718; -- Shadowy Hunter
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18595; -- Warped Peon
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18151; -- Gargle
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18150; -- Gurgle
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17189; -- Crazed Wildkin
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16810; -- Bonechewer Backbreaker
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16519; -- Shadowy Executioner
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15657; -- Darkwraith
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15651; -- Springpaw Stalker
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15649; -- Feral Dragonhawk Hatchling
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=11564; -- Gizelton Caravan Kodo
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=10017; -- Tainted Cockroach
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=10016; -- Tainted Rat
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=0.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17200; -- Moongraze Stag
UPDATE `creature_template` SET `speed_walk`=0.8571429, `speed_run`=0.777776, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15658; -- Rotlimb Marauder
UPDATE `creature_template` SET `speed_walk`=0.7936503, `speed_run`=0.8, `unit_flags2`=33556480 WHERE `entry`=43233; -- Stonehearth Geomaster
UPDATE `creature_template` SET `speed_walk`=0.7936503, `speed_run`=0.8, `unit_flags2`=33556480 WHERE `entry`=43232; -- Earthen Champion
UPDATE `creature_template` SET `speed_walk`=0.7857143, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=24168; -- Micah Stonebreaker
UPDATE `creature_template` SET `speed_walk`=0.7857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24081; -- Assistant Apothecary
UPDATE `creature_template` SET `speed_walk`=0.7142857, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25377; -- Brittle Skeleton
UPDATE `creature_template` SET `speed_walk`=0.7142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=14732; -- PvP CTF Credit Marker
UPDATE `creature_template` SET `speed_walk`=0.7142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25753; -- Sentry-bot 57-K
UPDATE `creature_template` SET `speed_walk`=0.7142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24174; -- Fjord Rat
UPDATE `creature_template` SET `speed_walk`=0.7142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22474; -- Unstable Fel-Imp
UPDATE `creature_template` SET `speed_walk`=0.7142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22282; -- Witness of Doom
UPDATE `creature_template` SET `speed_walk`=0.7142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22134; -- Shadowmoon Eye of Kilrogg
UPDATE `creature_template` SET `speed_walk`=0.7142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21690; -- R-3D0
UPDATE `creature_template` SET `speed_walk`=0.6785714, `speed_run`=0.5, `unit_flags`=536903680, `unit_flags2`=33556480 WHERE `entry`=45838; -- Twilight Ettin
UPDATE `creature_template` SET `speed_walk`=0.6285715, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18815; -- Exodar Proselyte
UPDATE `creature_template` SET `speed_walk`=0.5952386, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30875; -- Tempest Revenant
UPDATE `creature_template` SET `speed_walk`=0.5952386, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29624; -- Stormrider
UPDATE `creature_template` SET `speed_walk`=0.5952386, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27382; -- Deathbringer Revenant
UPDATE `creature_template` SET `speed_walk`=0.5714286, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27354; -- Broken-down Shredder
UPDATE `creature_template` SET `speed_walk`=0.5714286, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=31438; -- Shadow Vault Abomination
UPDATE `creature_template` SET `speed_walk`=0.5714286, `speed_run`=0.64, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27737; -- Risen Zombie
UPDATE `creature_template` SET `speed_walk`=0.5714286, `speed_run`=0.5, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15545; -- Cenarion Outrider
UPDATE `creature_template` SET `speed_walk`=0.5714286, `speed_run`=0.5, `dynamicflags`=0 WHERE `entry`=5629; -- Theramore Commando
UPDATE `creature_template` SET `speed_walk`=0.5714286, `speed_run`=0.5, `dynamicflags`=0 WHERE `entry`=1713; -- Elder Shadowmaw Panther
UPDATE `creature_template` SET `speed_walk`=0.5714286, `speed_run`=0.5, `baseattacktime`=1250, `unit_flags`=536903936 WHERE `entry`=18966; -- Justinius the Harbinger
UPDATE `creature_template` SET `speed_walk`=0.4285714, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27641; -- Centrifuge Construct
UPDATE `creature_template` SET `speed_walk`=0.3571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19692; -- Boom Bot
UPDATE `creature_template` SET `speed_walk`=0.3, `speed_run`=0.3 WHERE `entry`=46647; -- Training Dummy
UPDATE `creature_template` SET `speed_walk`=0.2857143, `speed_run`=0.8, `unit_flags`=536903744, `dynamicflags`=132 WHERE `entry`=46646; -- Obsidian Colossus
UPDATE `creature_template` SET `speed_walk`=0.25, `speed_run`=0.7, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19731; -- Nether Beast
UPDATE `creature_template` SET `speed_walk`=0.2142857, `speed_run`=0.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17407; -- Felmist
UPDATE `creature_template` SET `speed_walk`=0.2142857, `speed_run`=0.4, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=24177; -- Decomposing Ghoul
UPDATE `creature_template` SET `speed_walk`=0.1428571, `speed_run`=0.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24222; -- Windy Cloud
UPDATE `creature_template` SET `speed_walk`=0.1428571, `speed_run`=0.4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17378; -- Swamp Gas
UPDATE `creature_template` SET `speed_run`=2.8, `rangeattacktime`=2000, `unit_flags`=33588032, `dynamicflags`=0 WHERE `entry`=22196; -- Wrath Reaver
UPDATE `creature_template` SET `speed_run`=1.2, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=24196; -- Trapped Animal
UPDATE `creature_template` SET `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24925; -- Boss Portal: Purple (3.00)
UPDATE `creature_template` SET `speed_run`=1.2, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=35189; -- Skoll
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=23285; -- Nethermine Burster
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=5756; -- Deviate Venomwing
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=3674; -- Skum
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=3673; -- Lord Serpentis
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=3671; -- Lady Anacondra
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=3678; -- Disciple of Naralex
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=25601; -- Prince Valanar
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2080, `dynamicflags`=0 WHERE `entry`=26533; -- Mal'Ganis
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=23287; -- Murkblood Miner
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=28656; -- Hourglass (CoT Stratholme)
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=26216; -- Glacial Templar
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=5055; -- Deviate Lasher
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=5053; -- Deviate Crocolisk
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=3840; -- Druid of the Fang
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30447; -- Romping Rhino
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30066; -- Valkyrion Harpoon Gun
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29754; -- Column Ornament
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29691; -- Reed's Steam Tank
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29218; -- Portal to the Shadow Realm
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28476; -- Runebladed Sword
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28409; -- Time Rift (CoT Stratholme)
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26570; -- Famished Scourge Troll
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26497; -- Lady Jaina Proudmoore
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26216; -- Glacial Templar
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26048; -- Storm Totem
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25534; -- En'kilah Blood Globe
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25391; -- En'kilah Focus Crystal
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23309; -- Murkblood Overseer
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21902; -- Cabal Spell-weaver
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21660; -- Cabal Abjurist
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21423; -- Gore-Scythe Ravager
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19164; -- Refugee Child
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19163; -- Refugee Kid
UPDATE `creature_template` SET `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19149; -- Telaari Citizen
UPDATE `creature_template` SET `speed_run`=1, `dynamicflags`=0 WHERE `entry`=842; -- Lumberjack
UPDATE `creature_template` SET `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=832, `dynamicflags`=0 WHERE `entry`=36725; -- Nerub'ar Broodkeeper
UPDATE `creature_template` SET `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=15963; -- The Master's Eye
UPDATE `creature_template` SET `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768 WHERE `entry`=55247; -- Poot
UPDATE `creature_template` SET `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=12 WHERE `entry`=36880; -- Decaying Colossus
UPDATE `creature_template` SET `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33600, `dynamicflags`=0 WHERE `entry`=37188; -- Lady Jaina Proudmoore
UPDATE `creature_template` SET `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=37880; -- Stormwind Portal
UPDATE `creature_template` SET `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33555200 WHERE `entry`=51865; -- Coconut
UPDATE `creature_template` SET `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51758; -- Draenei Child
UPDATE `creature_template` SET `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51757; -- Orc Child
UPDATE `creature_template` SET `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=36724; -- Servant of the Throne
UPDATE `creature_template` SET `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=35372; -- Garrosh Hellscream
UPDATE `creature_template` SET `speed_run`=1 WHERE `entry`=29019; -- Dockhand
UPDATE `creature_template` SET `speed_run`=1 WHERE `entry`=17878; -- Scourge Siege Engineer
UPDATE `creature_template` SET `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0, `HoverHeight`=1 WHERE `entry`=27789; -- Ysera
UPDATE `creature_template` SET `speed_run`=0.666668, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=5775; -- Verdan the Everliving
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=31280; -- Ymirheim Spear Gun
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=67108928, `dynamicflags`=4 WHERE `entry`=32447; -- Zul'drak Sentinel
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=537166592, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=23674; -- Iron Rune Sage
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=537133056, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=30170; -- Mechagnome Attendant
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=29979; -- Iron Dwarf Magus
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=33686272, `dynamicflags`=0 WHERE `entry`=1921; -- Combat Dummy
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=33587200, `dynamicflags`=0 WHERE `entry`=21413; -- Gnome Cannon Shooter #1
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=36171; -- World Trigger (Infinite AOI)
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=29475; -- Improved Land Mine
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=27064; -- Abandoned Fuel Tank
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=4 WHERE `entry`=23711; -- Iron Rune Laborer
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=30541; -- Forgotten Depths Underking
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=26360; -- Rattlebore
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24797; -- Reef Cow
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24786; -- Reef Bull
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23676; -- Iron Rune Destroyer
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18584; -- Sal'salabim
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18369; -- Corki
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18044; -- Rajis Fyashe
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=256, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=22443; -- Death's Door Fel Cannon
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=2147746560, `dynamicflags`=0 WHERE `entry`=33623; -- Fishing
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=2147746560, `dynamicflags`=0 WHERE `entry`=33621; -- First Aid
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=2147746560, `dynamicflags`=0 WHERE `entry`=33619; -- Cooking
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=2147746560, `dynamicflags`=0 WHERE `entry`=33618; -- Skinning
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=2147746560, `dynamicflags`=0 WHERE `entry`=33617; -- Mining
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=2147746560, `dynamicflags`=0 WHERE `entry`=33616; -- Herbalism
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=2147746560, `dynamicflags`=0 WHERE `entry`=33615; -- Inscription
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=2147746560, `dynamicflags`=0 WHERE `entry`=33614; -- Jewelcrafting
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=2147746560, `dynamicflags`=0 WHERE `entry`=33613; -- Tailoring
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=2147746560, `dynamicflags`=0 WHERE `entry`=33612; -- Leatherworking
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=2147746560, `dynamicflags`=0 WHERE `entry`=33611; -- Engineering
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=2147746560, `dynamicflags`=0 WHERE `entry`=33610; -- Enchanting
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=2147746560, `dynamicflags`=0 WHERE `entry`=33609; -- Blacksmithing
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=2147746560, `dynamicflags`=0 WHERE `entry`=33608; -- Alchemy
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=4 WHERE `entry`=19188; -- Raging Colossus
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=28255; -- Malas the Corrupter
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=19188; -- Raging Colossus
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18010; -- Maktu
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18009; -- Puluu
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18008; -- Ikuti
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=29584; -- Dead Warmaiden
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=29571; -- Dead Drakerider
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags2`=2049 WHERE `entry`=25781; -- Oil Pool
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=30035; -- Fallen Earthen Defender
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=28413; -- Nerubian Cocoon
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=23076; -- Legion Flak Cannon
UPDATE `creature_template` SET `rangeattacktime`=2000, `unit_flags2`=0 WHERE `entry`=25349; -- Scourge Plague Spreader
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=32541; -- Initiate's Training Dummy
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0, `VehicleId`=105 WHERE `entry`=28288; -- Farunn
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37947; -- Deathwhisper Spawn Stalker
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33303; -- Maiden of Winter's Breath Lake
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32541; -- Initiate's Training Dummy
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32482; -- Pustulent Colossus
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32469; -- Ebon Blade Geist
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32284; -- Scourge Soulbinder
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31780; -- Fallen Spiderlord
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31322; -- Saronite Shaper
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31263; -- Carrion Hunter
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30422; -- Roaming Jormungar
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30341; -- Eisenfaust
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30291; -- Ravenous Jormungar
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30148; -- Infesting Jormungar
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30096; -- Dry Haystack
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29997; -- Iva the Vengeful
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29979; -- Iron Dwarf Magus
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29978; -- Iron Dwarf Assailant
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29966; -- Kamagua Turtle Rider
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29964; -- Dargum Hammerdeep
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29963; -- Magorn
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29961; -- Brangrimm
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29953; -- Moa'ki Turtle Rider
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29843; -- Stormforged Loreseeker
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29700; -- Drakuru Shackles
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29652; -- Stormforged Tracker
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29586; -- Stormforged Pillager
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29570; -- Nascent Val'kyr
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29477; -- Earthen Defender
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29440; -- Goblin Sapper Backpack
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29390; -- Snowdrift Jormungar
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29389; -- Mechagnome Laborer
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29384; -- Captive Mechagnome
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29377; -- Stormforged Raider
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29376; -- Stormforged Artificer
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29369; -- Stormforged Taskmaster
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29047; -- Olrun the Battlecaller
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28765; -- The Lich King
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28760; -- Hargus the Gimp
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28412; -- Hath'ar Broodmaster
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28407; -- Fjord Penguin
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28401; -- Har'koa
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28377; -- Prince Valanar
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28356; -- Prince Keleseth
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28257; -- Hath'ar Necromagus
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28018; -- Thiassi the Lightning Bringer
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27993; -- Vrykul Harpoon Gun
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27992; -- Vrykul Harpoon Gun
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27270; -- Rotting Storm Giant
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26653; -- Kilix the Unraveler
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26457; -- Diseased Drakkari
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26417; -- Runed Giant
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26365; -- Taunka Orphan
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26359; -- Ice Heart Jormungar Spawn
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26358; -- Ice Heart Jormungar Feeder
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25814; -- Fizzcrank Mechagnome
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25712; -- Warbringer Goredrak
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25619; -- Nerub'ar Warrior
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25462; -- The Lich King
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25455; -- Snarlfang's Totem
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24701; -- Large Vrykul Harpoon Gun
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24694; -- Vrykul Harpoon Gun (Wyrmskull)
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24464; -- Scourging Crystal
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24418; -- Steel Gate Flying Machine
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23268; -- Seer Jovar
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22517; -- World Trigger (Large AOI)
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22461; -- Fel Cannon MKI
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22370; -- Mekeda
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22253; -- Dragonmaw Ascendant
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22137; -- Summoned Old God
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22123; -- Rip-Blade Ravager
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21944; -- Gnome Cannon Shooter #Ruuan
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21937; -- Earthmender Sophurus
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21935; -- Gnome Cannon Shooter #Shattrath
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21930; -- Gnome Cannon Shooter #0
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21849; -- Bone Crawler
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21655; -- Nakodu
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21516; -- Death's Watch
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21499; -- Overseer Ripsaw
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21411; -- Tobias the Filth Gorger
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21393; -- Cannon Channeler
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21317; -- Aimi
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21233; -- Legion Fel Cannon
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21189; -- Crystal Flayer
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20895; -- Miiji
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20240; -- Trader Narasu
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20210; -- Shaleskin Flayer
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20089; -- Bloodscale Wavecaller
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20028; -- Doba
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19978; -- Deathforge Over-Smith
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19947; -- Darkcrest Sorceress
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19824; -- Son of Corok
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19755; -- Mo'arg Weaponsmith
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19678; -- Fantei
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19350; -- Thornfang Venomspitter
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19213; -- Eiin
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19182; -- Shaarubo
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19156; -- Telaari Jailor
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19155; -- Sporeling Refugee
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19141; -- Kurenai Pitfighter
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19139; -- Nagrand Target Dummy
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19120; -- Broken Refugee
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18976; -- Urga'zz
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18912; -- Sporelok
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18675; -- Soolaveen
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18483; -- Empoor's Bodyguard
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18408; -- Warden Moi'bff Jill
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18224; -- Poli'lukluk the Wiser
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18223; -- Mo'mor the Breaker
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18222; -- Otonbu the Sage
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18211; -- Murkblood Brute
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18207; -- Murkblood Scavenger
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18203; -- Murkblood Raider
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18202; -- Murkblood Putrifier
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18123; -- Wrekt Slave
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18122; -- Dreghood Drudge
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18087; -- Darkcrest Siren
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17956; -- Ikeyen
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17525; -- Bloodmyst Hatchling
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17360; -- Totem of Akida
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17199; -- Ravager Specimen
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17143; -- Wrekt Seer
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17142; -- Wrekt Warrior
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17060; -- Hellfire Combat Dummy Small
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17059; -- Hellfire Combat Dummy
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16946; -- Mo'arg Forgefiend
UPDATE `creature_template` SET `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16932; -- Razorfang Hatchling
UPDATE `creature_template` SET `rangeattacktime`=2000 WHERE `entry`=49410; -- Aaron "Sandy Toes" Williamson
UPDATE `creature_template` SET `rangeattacktime`=2000 WHERE `entry`=49409; -- "Chesty" Jake
UPDATE `creature_template` SET `rangeattacktime`=2000 WHERE `entry`=48239; -- Armadillo
UPDATE `creature_template` SET `rangeattacktime`=2000 WHERE `entry`=48028; -- Adarrah
UPDATE `creature_template` SET `rangeattacktime`=2000 WHERE `entry`=47930; -- Asaq
UPDATE `creature_template` SET `rangeattacktime`=2000 WHERE `entry`=47594; -- Advisor Kathem
UPDATE `creature_template` SET `rangeattacktime`=2000 WHERE `entry`=47005; -- Adarrah
UPDATE `creature_template` SET `minlevel`=88, `maxlevel`=88, `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=21984; -- Rexxar
UPDATE `creature_template` SET `minlevel`=88, `maxlevel`=88, `speed_walk`=1.142857, `speed_run`=1.111112, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40773; -- Cenarius
UPDATE `creature_template` SET `minlevel`=88, `maxlevel`=88, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17468; -- Prophet Velen
UPDATE `creature_template` SET `minlevel`=88, `maxlevel`=88, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40772; -- Commander Jarod Shadowsong
UPDATE `creature_template` SET `minlevel`=88, `maxlevel`=88, `faction_A`=83, `faction_H`=83, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=576 WHERE `entry`=39656; -- Orhan Ogreblade
UPDATE `creature_template` SET `minlevel`=88, `maxlevel`=88, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=52135; -- Malfurion Stormrage
UPDATE `creature_template` SET `minlevel`=88, `maxlevel`=88, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_run`=0.888888, `baseattacktime`=3000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33024, `unit_flags2`=34816 WHERE `entry`=40289; -- Ysera
UPDATE `creature_template` SET `minlevel`=88, `maxlevel`=88, `faction_A`=16, `faction_H`=16, `speed_walk`=2, `speed_run`=3.2, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33600, `unit_flags2`=134219776, `HoverHeight`=14 WHERE `entry`=54097; -- Alysrazor
UPDATE `creature_template` SET `minlevel`=88, `maxlevel`=88, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=4 WHERE `entry`=50009; -- Mobus
UPDATE `creature_template` SET `minlevel`=88, `maxlevel`=88, `faction_A`=124, `faction_H`=124, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=3936; -- Shandris Feathermoon
UPDATE `creature_template` SET `minlevel`=87, `maxlevel`=87, `faction_A`=1998, `faction_H`=1998, `speed_walk`=1.142857, `speed_run`=0.8, `rangeattacktime`=2000, `unit_flags`=64, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=25740; -- Ahune
UPDATE `creature_template` SET `minlevel`=86, `maxlevel`=86, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53025; -- Bloodslayer Vaena
UPDATE `creature_template` SET `minlevel`=86, `maxlevel`=86, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53024; -- Bloodslayer Zala
UPDATE `creature_template` SET `minlevel`=86, `maxlevel`=86, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53023; -- Bloodslayer T'ara
UPDATE `creature_template` SET `minlevel`=86, `maxlevel`=86, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=1500, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=11946; -- Drek'Thar
UPDATE `creature_template` SET `minlevel`=86, `maxlevel`=86, `faction_A`=7, `faction_H`=7, `speed_walk`=1.142857, `speed_run`=0.777776, `baseattacktime`=3000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=53271; -- Fah Jarakk
UPDATE `creature_template` SET `minlevel`=86, `maxlevel`=86, `faction_A`=16, `faction_H`=16, `speed_walk`=1.428571, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832 WHERE `entry`=52606; -- Gurubashi Warmonger
UPDATE `creature_template` SET `minlevel`=86, `maxlevel`=86, `faction_A`=16, `faction_H`=16, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=64 WHERE `entry`=52442; -- Florawing Hive Queen
UPDATE `creature_template` SET `minlevel`=86, `maxlevel`=86, `faction_A`=16, `faction_H`=16, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=64 WHERE `entry`=52380; -- Venomancer Mauri
UPDATE `creature_template` SET `minlevel`=86, `maxlevel`=86, `faction_A`=14, `faction_H`=14, `speed_walk`=1.428571, `speed_run`=1.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832 WHERE `entry`=52418; -- Lost Offspring of Gahz'ranka
UPDATE `creature_template` SET `minlevel`=86, `maxlevel`=86 WHERE `entry`=13797; -- Mountaineer Boombellow
UPDATE `creature_template` SET `minlevel`=85, `unit_flags2`=1 WHERE `entry`=46609; -- Dunwald Victim
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=4, `speed_run`=5.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52596; -- Forest Owl
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=4, `speed_run`=5.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52595; -- Alpine Songbird
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=4, `speed_run`=5.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52594; -- Goldwing Hawk
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=2, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=13236; -- Primalist Thurloga
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.714286, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32571; -- Halvdan
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.714286, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15184; -- Cenarion Hold Infantry
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19541; -- Netherstorm Agent
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16733; -- Exodar Peacekeeper
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.428571, `speed_run`=0.888888, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30312; -- Shadow Vault Boneguard
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1.555556, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=28863; -- Zim'Torga Guardian
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=29262; -- Gorgril Rigspark
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=28197; -- Kip Trawlskip
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=13798; -- Jotek
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=13176; -- Smith Regzar
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=12122; -- Duros
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=12121; -- Drakan
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=11947; -- Captain Galvangar
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=576, `dynamicflags`=0 WHERE `entry`=35025; -- Lynette Bracer
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=576, `dynamicflags`=0 WHERE `entry`=35017; -- Gorom Warfang
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=576, `dynamicflags`=0 WHERE `entry`=20383; -- Enlae
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33280, `dynamicflags`=0 WHERE `entry`=16189; -- Skymaster Sunwing
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=28818; -- Light's Breach Defender
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=31250; -- Ebon Blade Defender
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=26876; -- Samuel Clearbook
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18807; -- Kerna
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18791; -- Du'ga
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=22216; -- Fhyn Leafshadow
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=21766; -- Alieshor
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=19583; -- Grennik
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18938; -- Krexcil
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18808; -- Gursha
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=17555; -- Stephanos
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=17554; -- Laando
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=14186; -- Ravak Grimtotem
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=11949; -- Captain Balinda Stonehearth
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_class`=2, `dynamicflags`=0 WHERE `entry`=14031; -- Trigger Vipore
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_class`=2, `dynamicflags`=0 WHERE `entry`=14030; -- Trigger Slidore
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_class`=2, `dynamicflags`=0 WHERE `entry`=14029; -- Trigger Ichman
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_class`=2, `dynamicflags`=0 WHERE `entry`=14026; -- Trigger Guse
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=26848; -- Kimbiza
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=35026; -- Marsa Keybrand
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=35002; -- Asara Dawnblaze
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=35001; -- Saeld Brightflare
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=35000; -- Mijiri
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=34999; -- Jonru
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30578; -- Bethany Aldire
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30314; -- Morlia Doomwing
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30271; -- Galendror Whitewing
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29951; -- Shavalius the Fancy
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29750; -- Faldorf Bitterchill
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29721; -- Skizzle Slickslide
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28624; -- Maaka
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28618; -- Danica Saint
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28574; -- Marvin Wobblesprocket
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28196; -- Cid Flounderfix
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27953; -- Wyrmrest Protector
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26880; -- Vana Grey
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26852; -- Kragh
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26851; -- Nethestrasz
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26850; -- Numo Spiritbreeze
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26848; -- Kimbiza
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26847; -- Omu Spiritbreeze
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26845; -- Junter Weiss
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26844; -- Lilleth Radescu
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26602; -- Kara Thricestar
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26566; -- Narzun Skybreaker
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26298; -- ELM General Purpose Bunny (scale x0.01) Large
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24155; -- Tobias Sarkhoff
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24032; -- Celea Frozenmane
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22931; -- Gorrim
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22485; -- Halu
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22407; -- Caravan Defender
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21107; -- Rip Pedalslam
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20384; -- Yula the Fair
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20362; -- Iravar
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19529; -- Stormspire Nexus-Guard
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19504; -- Scryer Guardian
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18940; -- Nutral
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18939; -- Brubeck Stormfoot
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18809; -- Furnan Skysoar
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18789; -- Furgu
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18788; -- Munci
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17855; -- Expedition Warden
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16587; -- Barley
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15178; -- Runk Windtamer
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15177; -- Cloud Skydancer
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33587968 WHERE `entry`=53269; -- Fall Recovery Secondary Controller
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33587968 WHERE `entry`=53261; -- Fall Recovery Primary Controller
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33555200 WHERE `entry`=54515; -- Thermal Pocket Bunny
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33555200 WHERE `entry`=53866; -- Fire Torrent Channel Bunny
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33555200 WHERE `entry`=53353; -- Thermal Pocket Bunny
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33555200 WHERE `entry`=53230; -- Thermal Pocket Bunny
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33555200 WHERE `entry`=53228; -- Thermal Pocket Bunny
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33555200 WHERE `entry`=52985; -- Thermal Pocket Bunny
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33555200 WHERE `entry`=52162; -- Thermal Pocket Bunny
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53044; -- Blackwater Ruffian
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53043; -- Briney Boltcutter
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53022; -- Siame-Quashi
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=512 WHERE `entry`=36337; -- Image of Archmage Xylem
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=1500, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=14777; -- West Frostwolf Warmaster
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=1500, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=14776; -- Tower Point Warmaster
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=1500, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=14773; -- Iceblood Warmaster
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=1500, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=14772; -- East Frostwolf Warmaster
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=52177; -- Child of Tortolla
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29950; -- Breck Rockbrow
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=8195, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27344; -- Bat Handler Adeline
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=8193, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=6706; -- Baritanas Skyriver
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=8193, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=3305; -- Grisha
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=8193, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=2941; -- Lanie Reed
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=8192, `speed_walk`=1.5873, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27046; -- Warmage Adami
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=8192, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768 WHERE `entry`=47927; -- Doug Deepdown
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=8192, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33280 WHERE `entry`=43079; -- Chyella Hushglade
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=7808, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53040; -- Vehini
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=53196; -- Ricket
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=3, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=38504; -- Un'Goro Examinant
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=2, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=13437; -- Wing Commander Ichman
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=1, `speed_walk`=3.571429, `speed_run`=4.8, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=53408; -- Blue Drake
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=832, `dynamicflags`=0 WHERE `entry`=13437; -- Wing Commander Ichman
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51946; -- Resort Guest
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51945; -- Resort Guest
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51943; -- Resort Guest
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51942; -- Resort Guest
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51941; -- Resort Guest
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51935; -- Resort Guest
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=52562; -- Johnny Awesome
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=91, `faction_H`=91, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=256 WHERE `entry`=54251; -- Fireball
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=85, `faction_H`=85, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=12 WHERE `entry`=51911; -- Razor Hill Grunt
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=834, `faction_H`=834, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768, `dynamicflags`=132 WHERE `entry`=52300; -- Seething Pyrelord
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=834, `faction_H`=834, `speed_walk`=1.142857, `speed_run`=0.777776, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=52289; -- Fiery Behemoth
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=83, `faction_H`=83, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33587456, `unit_flags2`=33556480 WHERE `entry`=42053; -- Forsaken Plaguebearer
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=83, `faction_H`=83, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33587456, `unit_flags2`=33556480 WHERE `entry`=41914; -- Forsaken Reaver
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=83, `faction_H`=83, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51849; -- Stonemaul Ogre
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=80, `faction_H`=80, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18937; -- Amerun Leafshade
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=80, `faction_H`=80, `npcflag`=8193, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512 WHERE `entry`=41383; -- Irela Moonfeather
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=80, `faction_H`=80, `npcflag`=8193, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33280 WHERE `entry`=40367; -- Seyala Nightwisp
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=80, `faction_H`=80, `npcflag`=8192, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=41580; -- Aryenda
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=80, `faction_H`=80, `npcflag`=8192, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40966; -- Selor
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=71, `faction_H`=71, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=12 WHERE `entry`=51842; -- Dreadguard
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=71, `faction_H`=71, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=12 WHERE `entry`=51323; -- Tirisfal Deathguard
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=7, `faction_H`=7, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52089; -- Gurubashi Worker
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=7, `faction_H`=7, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=52377; -- Florawing Needler
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=7, `faction_H`=7, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=52376; -- Florawing Needler
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=7, `faction_H`=7, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=52375; -- Florawing Needler
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=7, `faction_H`=7, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=52373; -- Florawing Needler
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=694, `faction_H`=694, `npcflag`=1048577, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=44012; -- Wildhammer Emissary
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=635, `faction_H`=635, `speed_walk`=1.142857, `speed_run`=1.111112, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=35450; -- Cenarion Ancient of Lore
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=57, `faction_H`=57, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51922; -- Menethil Guard
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=474, `faction_H`=474, `npcflag`=8192, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512 WHERE `entry`=39175; -- Flizzy Coilspanner
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=29, `faction_H`=29, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51919; -- Brackenwall Enforcer
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=29, `faction_H`=29, `npcflag`=8192, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512 WHERE `entry`=41605; -- Mergek
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=28, `faction_H`=28, `speed_walk`=0.5714286, `speed_run`=1.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=64 WHERE `entry`=52077; -- Gurubashi Berserker
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2379, `faction_H`=2379, `npcflag`=4224, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=54401; -- Naresir Stormfury
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2379, `faction_H`=2379, `npcflag`=128, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=54402; -- Lurah Wrathvine
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2372, `faction_H`=2372, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=54362; -- Scarred Acolyte
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2371, `faction_H`=2371, `speed_walk`=1.5873, `speed_run`=1.444444, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52661; -- Druid of the Flame
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2371, `faction_H`=2371, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=32768 WHERE `entry`=54343; -- Druid of the Flame
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2371, `faction_H`=2371, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=32768 WHERE `entry`=52871; -- Druid of the Flame
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2369, `faction_H`=2369, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33587456 WHERE `entry`=52195; -- Angry Little Squirrel
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2369, `faction_H`=2369, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52703; -- Hyjal Enforcer
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2369, `faction_H`=2369, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52500; -- Hyjal Defender
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2369, `faction_H`=2369, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=52467; -- Rayne Feathersong
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2364, `faction_H`=2364, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=14622; -- Thorium Brotherhood Lookout
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2337, `faction_H`=2337, `speed_walk`=1.357143, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=537166592, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=47317; -- Keeland Doyle
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2309, `faction_H`=2309, `speed_walk`=1.984126, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=163840, `unit_flags2`=33556480 WHERE `entry`=50083; -- Druid of the Talon
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2309, `faction_H`=2309, `speed_walk`=1.714286, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=43427; -- Furious Hyjal Warden
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2309, `faction_H`=2309, `speed_walk`=1.714286, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=38915; -- Hyjal Warden
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2309, `faction_H`=2309, `speed_walk`=1.385714, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53823; -- Hyjal Warden
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2309, `faction_H`=2309, `speed_walk`=1.385714, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=4, `unit_flags`=32768 WHERE `entry`=53805; -- Ystelle Oaksong
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2309, `faction_H`=2309, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52670; -- Defender of Malorne
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2309, `faction_H`=2309, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768, `unit_flags2`=33556480 WHERE `entry`=50083; -- Druid of the Talon
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2309, `faction_H`=2309, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53842; -- Mardant Strongoak
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2308, `faction_H`=2308, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `unit_flags2`=33554432 WHERE `entry`=46493; -- Warlord Halthar
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2279, `faction_H`=2279, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=294912 WHERE `entry`=54339; -- Ancient Charhound
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2263, `faction_H`=2263, `npcflag`=8193, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=10583; -- Gryfe
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `speed_walk`=1.142857, `speed_run`=1.111112, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=52547; -- Ancient Hyjal Protector
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=52341; -- Druid of the Talon
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33280, `unit_flags2`=0 WHERE `entry`=52834; -- Wounded Hyjal Defender
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52986; -- Dorda'en Nightweaver
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=537166592, `unit_flags2`=1 WHERE `entry`=53243; -- Injured Druid of the Talon
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=53327; -- Druid of the Talon
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=8192, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768 WHERE `entry`=54393; -- Ranela Featherglen
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=8192, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768 WHERE `entry`=53783; -- Elizil Wintermoth
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=8192, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768 WHERE `entry`=50084; -- Dinorae Swiftfeather
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=8192, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768 WHERE `entry`=41861; -- Fayran Elthas
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=8192, `speed_walk`=0.3571429, `speed_run`=0.944444, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768, `HoverHeight`=4.5 WHERE `entry`=43549; -- Althera
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=4226, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=52822; -- Zen'Vorka
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=52134; -- Commander Jarod Shadowsong
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33280 WHERE `entry`=52488; -- Elderlimb
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52824; -- General Taldris Moonfall
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=52825; -- Theresa Barkskin
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=52477; -- Tholo Whitehoof
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=52489; -- Avrilla
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=130, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=53882; -- Varlan Highbough
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=130, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=53881; -- Ayla Shadowstorm
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2234, `faction_H`=2234, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=53055; -- Ancient Charscale
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2234, `faction_H`=2234, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52504; -- Charred Soldier
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2234, `faction_H`=2234, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52503; -- Charred Vanquisher
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2234, `faction_H`=2234, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52633; -- Lava Burster
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2233, `faction_H`=2233, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52502; -- Hyjal Marksman
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2233, `faction_H`=2233, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768, `VehicleId`=1685 WHERE `entry`=53741; -- Hyjal Scout
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2233, `faction_H`=2233, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=52501; -- Hyjal Druid
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2233, `faction_H`=2233, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=52490; -- Skylord Omnuron
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2233, `faction_H`=2233, `npcflag`=3, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=52493; -- Captain Saynna Stormrunner
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2233, `faction_H`=2233, `npcflag`=3, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52495; -- Shalis Darkhunter
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2201, `faction_H`=2201, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33587456, `unit_flags2`=33556480 WHERE `entry`=41911; -- Forsaken Invader
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2170, `faction_H`=2170, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `unit_flags2`=134219776, `VehicleId`=1631 WHERE `entry`=53085; -- Flamewaker Sentinel
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2170, `faction_H`=2170, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53152; -- Charhound
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2170, `faction_H`=2170, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=53143; -- Flamewaker Hunter
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2170, `faction_H`=2170, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=53093; -- Flamewaker Shaman
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2163, `faction_H`=2163, `npcflag`=1048577, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=44000; -- Gilnean Emissary
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2156, `faction_H`=2156, `speed_walk`=1.142857, `speed_run`=1.111112, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `unit_flags2`=134219776 WHERE `entry`=52981; -- Cinderweb Spinner
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2156, `faction_H`=2156, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53240; -- Emberspit Scorpion
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2156, `faction_H`=2156, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=262144 WHERE `entry`=52992; -- Cinderweb Cocoon
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2156, `faction_H`=2156, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=262144 WHERE `entry`=52991; -- Cinderweb Cocoon
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2156, `faction_H`=2156, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=262144 WHERE `entry`=52989; -- Cinderweb Cocoon
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2156, `faction_H`=2156, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=262144 WHERE `entry`=52784; -- Cinderweb Cocoon
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2156, `faction_H`=2156, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=262144 WHERE `entry`=52783; -- Cinderweb Cocoon
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2156, `faction_H`=2156, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=262144 WHERE `entry`=52751; -- Cinderweb Cocoon
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2135, `faction_H`=2135, `speed_walk`=1.428571, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=43889; -- Karnum's Warden
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2028, `faction_H`=2028, `npcflag`=128, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=52820; -- Helpful Jungle Monkey
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2024, `faction_H`=2024, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51887; -- Vengeance Landing Deathguard
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=2022, `faction_H`=2022, `speed_walk`=2.857143, `speed_run`=4, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33587712 WHERE `entry`=52176; -- Spirit of Malorne
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1998, `faction_H`=1998, `speed_walk`=1.142857, `speed_run`=0.8, `rangeattacktime`=2000, `unit_flags`=33554688, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=25865; -- Frozen Core
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1927, `faction_H`=1927, `npcflag`=8193, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=35481; -- Moira Steelwing
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1923, `faction_H`=1923, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=12 WHERE `entry`=51883; -- Camp Winterhoof Brave
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1897, `faction_H`=1897, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=12 WHERE `entry`=51872; -- Venomspite Deathguard
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1891, `faction_H`=1891, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=51893; -- Westfall Brigade Footman
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=189, `faction_H`=189, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=52441; -- Curious Jungle Monkey
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1878, `faction_H`=1878, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=1200, `rangeattacktime`=2000, `unit_flags`=32832 WHERE `entry`=52417; -- Shredtooth Frenzy
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1874, `faction_H`=1874, `speed_walk`=1.142857, `speed_run`=1.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23115; -- Ogri'la Peacekeeper
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1806, `faction_H`=1806, `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29910; -- K3 Bruiser
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1806, `faction_H`=1806, `speed_walk`=1.142857, `speed_run`=1.111112, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=47844; -- Whisperwind Protector
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1806, `faction_H`=1806, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=47434; -- Iron Summit Guard
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1802, `faction_H`=1802, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51879; -- Station Guard
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1801, `faction_H`=1801, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51910; -- Kor'kron Defender
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1694, `faction_H`=1694, `npcflag`=8195, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=43991; -- Zaldaan
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1668, `faction_H`=1668, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51903; -- Thrallmar Grunt
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1639, `faction_H`=1639, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51507; -- Forest Song Peacekeeper
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1604, `faction_H`=1604, `npcflag`=8195, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=44036; -- Skymaster Brightdawn
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1603, `faction_H`=1603, `speed_walk`=1.428571, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=12 WHERE `entry`=51796; -- Silvermoon City Guardian
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1603, `faction_H`=1603, `speed_walk`=1.428571, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=12 WHERE `entry`=51536; -- Reliquary Overseer
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1603, `faction_H`=1603, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51902; -- Ghostlands Guardian
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=16, `faction_H`=16, `speed_walk`=1.428571, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32832 WHERE `entry`=52088; -- Gurubashi Cauldron-Mixer
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=16, `faction_H`=16, `speed_walk`=1.142857, `speed_run`=1.111112, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832 WHERE `entry`=54323; -- Kirix
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=16, `faction_H`=16, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=52379; -- Venomtip Needler
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=150, `faction_H`=150, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=51825; -- Northwatch Guard
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1475, `faction_H`=1475, `npcflag`=4227, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=53214; -- Damek Bloombeard
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.5873, `speed_run`=1.444444, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53245; -- Fire Hawk
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.5873, `speed_run`=1.444444, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52660; -- Fire Hawk
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1.555556, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52794; -- Brimstone Destroyer
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1.555556, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52219; -- Flame Terror
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1.111112, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53753; -- Cinderweb Broodling
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1.111112, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52648; -- Cinderweb Creeper
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33555200 WHERE `entry`=52531; -- Fire Attacker Portal
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554944 WHERE `entry`=54040; -- Furnace Bunny, Fire B, 1.6 scale
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554944 WHERE `entry`=54039; -- Furnace Bunny, Fire C, 0.8 scale
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554944 WHERE `entry`=54038; -- Furnace Bunny, Fire B, 0.8 scale
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554944 WHERE `entry`=54037; -- Furnace Bunny, Fire C, 1.0 scale
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554944 WHERE `entry`=54036; -- Furnace Bunny, Fire B, 1.0 scale
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554944 WHERE `entry`=53213; -- Furnace Bunny, Fire A, 0.8 scale
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554944 WHERE `entry`=53212; -- Furnace Bunny, Fire A, 1.6 scale
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554944 WHERE `entry`=52948; -- Furnace Bunny, Fire A, 1.0 scale
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554944 WHERE `entry`=52893; -- Molten Splash Origin Bunny
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554432, `unit_flags2`=0 WHERE `entry`=52332; -- Toxic Venomspitter
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554432, `unit_flags2`=0 WHERE `entry`=52331; -- Mutated Overgrowth
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554432 WHERE `entry`=53099; -- Wave Genesis Bunny
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554432 WHERE `entry`=52062; -- Zanzil's Toxic Gas
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52816; -- Charred Invader
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52795; -- Brimstone Hound
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=52791; -- Charred Flamewaker
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=0.8571429, `speed_run`=1.2, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52107; -- Obsidium Punisher
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=0.7142857, `speed_run`=1.2, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=53249; -- Fire Hawk Matriarch
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=14, `faction_H`=14, `speed_walk`=0.5714286, `speed_run`=1.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=16384 WHERE `entry`=52552; -- Molten Behemoth
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1315, `faction_H`=1315, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33587456, `unit_flags2`=33556480 WHERE `entry`=41915; -- Worgen Warrior
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=1315, `faction_H`=1315, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33587456, `unit_flags2`=33556480 WHERE `entry`=41913; -- Gilneas Citizen
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=11, `faction_H`=11, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51519; -- Elwynn Guard
UPDATE `creature_template` SET `minlevel`=85, `maxlevel`=85, `faction_A`=104, `faction_H`=104, `npcflag`=8193, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512 WHERE `entry`=39898; -- Shyn
UPDATE `creature_template` SET `minlevel`=84, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=13359; -- Frostwolf Bowman
UPDATE `creature_template` SET `minlevel`=84, `maxlevel`=84, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=14185; -- Najak Hexxen
UPDATE `creature_template` SET `minlevel`=84, `maxlevel`=84, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=832, `dynamicflags`=0 WHERE `entry`=13439; -- Wing Commander Vipore
UPDATE `creature_template` SET `minlevel`=84, `maxlevel`=84, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=832, `dynamicflags`=0 WHERE `entry`=13179; -- Wing Commander Guse
UPDATE `creature_template` SET `minlevel`=84, `maxlevel`=84, `faction_A`=2147, `faction_H`=2147, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=44120; -- Sauranok the Mystic
UPDATE `creature_template` SET `minlevel`=84 WHERE `entry`=51713; -- Longstrider Gazelle
UPDATE `creature_template` SET `minlevel`=84 WHERE `entry`=51673; -- Venomscale Spitter
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=84, `faction_A`=2156, `faction_H`=2156, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=51714; -- King Crawler
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=84, `faction_A`=14, `faction_H`=14, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=51752; -- Oil Slime
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=84 WHERE `entry`=48393; -- Horde Spectator
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=83, `speed_walk`=1.714286, `speed_run`=1, `baseattacktime`=1500, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=36939; -- High Overlord Saurfang
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=83, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=13284; -- Frostwolf Shaman
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=83, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=13218; -- Grunnda Wolfheart
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=83, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=64 WHERE `entry`=40140; -- Arch Druid Fandral Staghelm
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=83, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=38569; -- Martyr Stalker (IGB/Saurfang)
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=83, `speed_walk`=0.5714286, `speed_run`=0.5, `rangeattacktime`=2000, `unit_flags`=536870912, `dynamicflags`=0 WHERE `entry`=13078; -- Umi Thorson
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=83, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37519; -- Safe Area (IGB)
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=83, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=33536 WHERE `entry`=51682; -- Hyjal Flame Guardian
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=83, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=832, `dynamicflags`=0 WHERE `entry`=13438; -- Wing Commander Slidore
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=83, `faction_A`=83, `faction_H`=83, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=51651; -- Twilight Highlands Flame Keeper
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=83, `faction_A`=474, `faction_H`=474, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51733; -- Lasha Gearwheel
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=83, `faction_A`=2339, `faction_H`=2339, `speed_walk`=1.385714, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512, `unit_flags2`=0 WHERE `entry`=46451; -- Captured Gryphon
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=83, `faction_A`=2233, `faction_H`=2233, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=40149; -- Telessra
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=83, `faction_A`=2233, `faction_H`=2233, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=40148; -- Galrond of the Claw
UPDATE `creature_template` SET `minlevel`=83, `maxlevel`=83, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=40147; -- Baron Geddon
UPDATE `creature_template` SET `minlevel`=83 WHERE `entry`=49567; -- Dragonmaw Worker
UPDATE `creature_template` SET `minlevel`=83 WHERE `entry`=46868; -- Stillwater Slitherer
UPDATE `creature_template` SET `minlevel`=82, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32482; -- Pustulent Colossus
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `speed_walk`=1.428571, `speed_run`=2, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28921; -- Hadronox
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=16, `dynamicflags`=0 WHERE `entry`=13448; -- Sergeant Yazra Bloodsnarl
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=12051; -- Frostwolf Legionnaire
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37855; -- Malygos Image
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1.388888, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=41308; -- Aviana
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `faction_A`=2309, `faction_H`=2309, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=39637; -- Goldrinn Defender
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `faction_A`=2253, `faction_H`=2253, `speed_walk`=8.571428, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=67141632, `dynamicflags`=4 WHERE `entry`=40974; -- Desperiona
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `faction_A`=2253, `faction_H`=2253, `speed_walk`=8.571428, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=40687; -- Young Twilight Drake
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `faction_A`=2252, `faction_H`=2252, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=41497; -- Logram
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `faction_A`=2252, `faction_H`=2252, `npcflag`=65536, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53779; -- Salirn Moonbear
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `faction_A`=2252, `faction_H`=2252, `npcflag`=4224, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53782; -- Jalin Lakedeep
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `faction_A`=2252, `faction_H`=2252, `npcflag`=4224, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=53075; -- Inoho Stronghide
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `faction_A`=2252, `faction_H`=2252, `npcflag`=3200, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=53781; -- Tomo
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `faction_A`=2252, `faction_H`=2252, `npcflag`=3200, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=53076; -- Nenduil Meadowshade
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1.111112, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=52476; -- Keeper Krothis
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `faction_A`=2252, `faction_H`=2252, `npcflag`=129, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53780; -- Limiah Whitebranch
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `faction_A`=2234, `faction_H`=2234, `speed_walk`=1.142857, `speed_run`=0.777776, `baseattacktime`=2400, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=40998; -- King Moltron
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `faction_A`=2234, `faction_H`=2234, `speed_walk`=1.142857, `speed_run`=0.777776, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=40998; -- King Moltron
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `faction_A`=2233, `faction_H`=2233, `speed_walk`=1.428571, `speed_run`=1.2, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=52931; -- Cenarius
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `faction_A`=2233, `faction_H`=2233, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512 WHERE `entry`=40999; -- Tortolla
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `faction_A`=2146, `faction_H`=2146, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40814; -- Azralon the Gatekeeper
UPDATE `creature_template` SET `minlevel`=82, `maxlevel`=82, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28684; -- Krik'thir the Gatewatcher
UPDATE `creature_template` SET `minlevel`=82, `dynamicflags`=0 WHERE `entry`=45988; -- Twilight Bloodsmith
UPDATE `creature_template` SET `minlevel`=82 WHERE `entry`=31139; -- Pustulent Horror
UPDATE `creature_template` SET `minlevel`=81, `unit_flags2`=1 WHERE `entry`=46609; -- Dunwald Victim
UPDATE `creature_template` SET `minlevel`=81, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27736; -- Patchwork Construct
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29117; -- Anub'ar Champion
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28734; -- Anub'ar Skirmisher
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37547; -- Gunship Hull
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37488; -- Teleport Exit
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2253, `faction_H`=2253, `speed_walk`=8.571428, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=33587200 WHERE `entry`=40575; -- Twilight Stormwaker
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2253, `faction_H`=2253, `speed_walk`=8.571428, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768, `VehicleId`=759 WHERE `entry`=40573; -- Twilight Stormwaker
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2253, `faction_H`=2253, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=32768 WHERE `entry`=41502; -- Twilight Field Captain
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2253, `faction_H`=2253, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=32768 WHERE `entry`=41500; -- Twilight Scorchlord
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2252, `faction_H`=2252, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=50079; -- Borun Thundersky
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2252, `faction_H`=2252, `npcflag`=65538, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=50068; -- Isara Riverstride
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2252, `faction_H`=2252, `npcflag`=4224, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=50071; -- Nunaha Grasshoof
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2252, `faction_H`=2252, `npcflag`=3200, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=50070; -- Jandunel Reedwind
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=41507; -- Niden
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2252, `faction_H`=2252, `npcflag`=129, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=50069; -- Oltarin Graycloud
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2252, `faction_H`=2252, `npcflag`=128, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=50314; -- Provisioner Whitecloud
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2234, `faction_H`=2234, `speed_walk`=1.142857, `speed_run`=1.555556, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=40844; -- Cindermaul
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2234, `faction_H`=2234, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8 WHERE `entry`=41563; -- Shadowflame Master
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2234, `faction_H`=2234, `speed_walk`=1.142857, `speed_run`=0.777776, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=40464; -- Magma Giant
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2233, `faction_H`=2233, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33280 WHERE `entry`=40278; -- Tholo Whitehoof
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2233, `faction_H`=2233, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33280 WHERE `entry`=40254; -- Injured Druid
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2233, `faction_H`=2233, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33280 WHERE `entry`=40096; -- Scout Larandia
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2233, `faction_H`=2233, `npcflag`=65665, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=40843; -- Sebelia
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2232, `faction_H`=2232, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40463; -- Twilight Subjugator
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2232, `faction_H`=2232, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=40709; -- Flame Ascendant
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2146, `faction_H`=2146, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40767; -- Twilight Retainer
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2146, `faction_H`=2146, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40755; -- Emissary of Flame
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2146, `faction_H`=2146, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40713; -- Twilight Augur
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2146, `faction_H`=2146, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=39846; -- Leyden Copperkleist
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=2057, `faction_H`=2057, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=39646; -- Gar'gol
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=1925, `faction_H`=1925, `speed_walk`=2.142857, `speed_run`=6, `baseattacktime`=2000, `rangeattacktime`=2000, `VehicleId`=769 WHERE `entry`=40650; -- Twilight Firebird
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `faction_A`=1925, `faction_H`=1925, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33587200 WHERE `entry`=40660; -- Twilight Lancer
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28731; -- Watcher Silthik
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28730; -- Watcher Gashra
UPDATE `creature_template` SET `minlevel`=81, `maxlevel`=81, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28729; -- Watcher Narjil
UPDATE `creature_template` SET `minlevel`=80, `speed_walk`=1.714286, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30456; -- Oloh
UPDATE `creature_template` SET `minlevel`=80, `speed_walk`=1.714286, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30252; -- Lorekeeper Randvir
UPDATE `creature_template` SET `minlevel`=80, `speed_walk`=1.5873, `speed_run`=2.8, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=29544; -- Dead Frost Giant
UPDATE `creature_template` SET `minlevel`=80, `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29796; -- Gretta the Arbiter
UPDATE `creature_template` SET `minlevel`=80, `speed_walk`=1.385714 WHERE `entry`=32597; -- Dalaran Visitor
UPDATE `creature_template` SET `minlevel`=80, `speed_walk`=1.190476, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31747; -- Necrotic Webspinner
UPDATE `creature_template` SET `minlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=29731; -- Frostborn Iceshaper
UPDATE `creature_template` SET `minlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29880; -- Jotunheim Warrior
UPDATE `creature_template` SET `minlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28200; -- Dark Necromancer
UPDATE `creature_template` SET `minlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28199; -- Tomb Stalker
UPDATE `creature_template` SET `minlevel`=80, `speed_walk`=1.142857, `speed_run`=0.888888, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=31403; -- Azure Spellweaver
UPDATE `creature_template` SET `minlevel`=80, `speed_walk`=1.142857, `speed_run`=0.777776, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28249; -- Devouring Ghoul
UPDATE `creature_template` SET `minlevel`=80, `speed_walk`=1.142857 WHERE `entry`=32602; -- Dalaran Visitor
UPDATE `creature_template` SET `minlevel`=80, `speed_walk`=1, `speed_run`=2.8, `rangeattacktime`=2000, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=29543; -- Frostworg Carcass
UPDATE `creature_template` SET `minlevel`=80, `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29801; -- Bouldercrag the Rockshaper
UPDATE `creature_template` SET `minlevel`=80, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29549; -- Brunnhildar Riding Bear
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=81, `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28734; -- Anub'ar Skirmisher
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=81, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29335; -- Anub'ar Webspinner
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=81, `faction_A`=2233, `faction_H`=2233, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=40150; -- Arch Druid of Hyjal
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=81, `faction_A`=2233, `faction_H`=2233, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=38934; -- Barrow Deeps Watcher
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=81, `faction_A`=14, `faction_H`=14, `speed_walk`=1.388889, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2 WHERE `entry`=48725; -- Horrorguard
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=81, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28733; -- Anub'ar Shadowcaster
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=81, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28732; -- Anub'ar Warrior
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29118; -- Anub'ar Crypt Fiend
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29117; -- Anub'ar Champion
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.428571, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28922; -- Anub'ar Crusher
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=30317; -- Temple of Winter Bunny
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=27072; -- Amberpine Footman
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=26839; -- Conquest Hold Legionnaire
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=26217; -- Westfall Brigade Footman
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=3343; -- Grelkor
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=2225; -- Zora Guthrek
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31797; -- Ancient Sentinel
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30318; -- Temple of Order Bunny
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=30315; -- Temple of Invention Bunny
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512, `unit_flags2`=34816, `VehicleId`=1614 WHERE `entry`=52676; -- Climbing Tree
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=38879; -- Putricide's Trap
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554432, `dynamicflags`=0 WHERE `entry`=37013; -- Puddle Stalker
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags2`=67110912 WHERE `entry`=52687; -- Soft Target
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `dynamicflags`=0 WHERE `entry`=37183; -- Highlord Bolvar Fordragon
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2 WHERE `entry`=39921; -- Faerie Dragon
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512, `unit_flags2`=34816 WHERE `entry`=39738; -- Crucible of Water
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512, `unit_flags2`=34816 WHERE `entry`=39737; -- Crucible of Earth
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512, `unit_flags2`=34816 WHERE `entry`=39736; -- Crucible of Air
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512, `unit_flags2`=34816 WHERE `entry`=39730; -- Crucible of Fire
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=41557; -- Child of Tortolla
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37948; -- Deathwhisper Controller
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=33554432, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=32655; -- SOTA Horde Gun 2
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=29335; -- Anub'ar Webspinner
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `npcflag`=640, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=3625; -- Rarck
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `npcflag`=640, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=10367; -- Shrye Ragefist
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `npcflag`=3715, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=12097; -- Frostwolf Quartermaster
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `npcflag`=3200, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=10364; -- Yaelika Farclaw
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `npcflag`=16777216, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512, `unit_flags2`=67110912, `VehicleId`=1616 WHERE `entry`=52682; -- Treetop
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=294912, `unit_flags2`=0 WHERE `entry`=41499; -- Lost Warden
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=7, `faction_H`=7, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=42664; -- Hyjal Huntress
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=7, `faction_H`=7, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=42663; -- Hyjal Owl
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=7, `faction_H`=7, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=42660; -- Hyjal Darkhawk
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=7, `faction_H`=7, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=42659; -- Hyjal Screecher
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=7, `faction_H`=7, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=42658; -- Hyjal Roc
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=7, `faction_H`=7, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=42657; -- Hyjal Eagle
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=475, `faction_H`=475, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=54228; -- Resort Staff
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=475, `faction_H`=475, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53418; -- Resort Staff
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=475, `faction_H`=475, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51722; -- Resort Staff
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=474, `faction_H`=474, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51750; -- Trip Hullbolt
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=29, `faction_H`=29, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40971; -- Scratchfever
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=29, `faction_H`=29, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40970; -- Tednug
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=29, `faction_H`=29 WHERE `entry`=31768; -- Stabled Hunter Pet
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=29, `faction_H`=29 WHERE `entry`=31758; -- Stabled Hunter Pet
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2367, `faction_H`=2367, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52008; -- Resort Staff
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2254, `faction_H`=2254, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `unit_flags2`=0 WHERE `entry`=40564; -- Fiery Instructor
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2254, `faction_H`=2254, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768, `unit_flags2`=0 WHERE `entry`=40562; -- Twilight Initiate
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2253, `faction_H`=2253, `npcflag`=2, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=32768 WHERE `entry`=40123; -- Twilight Overseer
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2252, `faction_H`=2252, `npcflag`=4224, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=43554; -- Ildrin Farglade
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2252, `faction_H`=2252, `npcflag`=4224, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=43548; -- Berin Connad
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2252, `faction_H`=2252, `npcflag`=4224, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=43410; -- Toron Rockhoof
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2252, `faction_H`=2252, `npcflag`=3200, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=43555; -- Motah Tallhorn
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2252, `faction_H`=2252, `npcflag`=3200, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=43547; -- Mirala Fawnsinger
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2252, `faction_H`=2252, `npcflag`=3200, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=43411; -- Lenedil Moonwing
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.385714, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=52478; -- Anren Shadowseeker
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2252, `faction_H`=2252, `npcflag`=129, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=43408; -- Aili Greenwillow
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2234, `faction_H`=2234, `speed_walk`=1.142857, `speed_run`=1.555556, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=38896; -- Blazebound Elemental
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2234, `faction_H`=2234, `speed_walk`=1.142857, `speed_run`=1.555556, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=4 WHERE `entry`=40229; -- Scalding Rock Elemental
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2234, `faction_H`=2234, `speed_walk`=1.142857, `speed_run`=1.555556, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=41565; -- Molten Tormentor
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2234, `faction_H`=2234, `speed_walk`=1.142857, `speed_run`=1.555556, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=40229; -- Scalding Rock Elemental
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2234, `faction_H`=2234, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=38913; -- Twilight Vanquisher
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2234, `faction_H`=2234, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=32768 WHERE `entry`=38926; -- Twilight Flamecaller
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2234, `faction_H`=2234, `speed_walk`=0.5714286, `speed_run`=0.777778, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=536870912 WHERE `entry`=40229; -- Scalding Rock Elemental
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2233, `faction_H`=2233, `speed_walk`=2.142857, `speed_run`=6, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=40723; -- Aviana's Guardian
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2233, `faction_H`=2233, `speed_walk`=2.142857, `speed_run`=6, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=40720; -- Aviana's Guardian
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2233, `faction_H`=2233, `speed_walk`=1.5873, `speed_run`=1.2, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=40780; -- Emerald Drake
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2233, `faction_H`=2233, `speed_walk`=1.385714, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33280 WHERE `entry`=39925; -- Anren Shadowseeker
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2233, `faction_H`=2233, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=40816; -- Aronus
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2233, `faction_H`=2233, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=41509; -- Irontree Warden
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2233, `faction_H`=2233, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=38902; -- Ironbark Ancient
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2233, `faction_H`=2233, `npcflag`=3, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40139; -- Captain Saynna Stormrunner
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2233, `faction_H`=2233, `npcflag`=2, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=40833; -- Tiala Whitemane
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2232, `faction_H`=2232, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=4, `unit_flags`=32768 WHERE `entry`=38951; -- Twilight Assassin
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2156, `faction_H`=2156, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554432 WHERE `entry`=40708; -- Falling Boulder
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2146, `faction_H`=2146, `speed_walk`=1.142857, `speed_run`=1.555556, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=39844; -- Howling Riftdweller
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2146, `faction_H`=2146, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512 WHERE `entry`=39436; -- Twilight Proveditor
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2146, `faction_H`=2146, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33280 WHERE `entry`=39438; -- Twilight Slavedriver
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2146, `faction_H`=2146, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=32768 WHERE `entry`=39843; -- Twilight Stormcaller
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2146, `faction_H`=2146, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2 WHERE `entry`=39437; -- Twilight Hunter
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2146, `faction_H`=2146, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=40838; -- Dark Iron Laborer
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2057, `faction_H`=2057, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=39642; -- Hovel Brute
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=2057, `faction_H`=2057, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=32768 WHERE `entry`=39643; -- Hovel Shadowcaster
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=1999, `faction_H`=1999, `speed_walk`=1.142857, `speed_run`=0.8, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=39588; -- Hyjal Stag
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=1779, `faction_H`=1779, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768, `unit_flags2`=34816 WHERE `entry`=52408; -- Coridormi
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=1720, `faction_H`=1720, `speed_walk`=1.142857, `speed_run`=1.555556, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40841; -- Searing Guardian
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832 WHERE `entry`=40446; -- Skar'this the Summoner
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `faction_A`=1214, `faction_H`=1214, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=13099; -- Irondeep Explorer
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28733; -- Anub'ar Shadowcaster
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80 WHERE `entry`=31787; -- Citadel Watcher
UPDATE `creature_template` SET `minlevel`=80, `maxlevel`=80 WHERE `entry`=31758; -- Stabled Hunter Pet
UPDATE `creature_template` SET `minlevel`=80, `faction_H`=16, `speed_walk`=0.9920629, `speed_run`=4, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32487; -- Putridus the Ancient
UPDATE `creature_template` SET `minlevel`=80 WHERE `entry`=32597; -- Dalaran Visitor
UPDATE `creature_template` SET `minlevel`=80 WHERE `entry`=32290; -- Cult Alchemist
UPDATE `creature_template` SET `minlevel`=80 WHERE `entry`=32289; -- Damned Apothecary
UPDATE `creature_template` SET `minlevel`=80 WHERE `entry`=31756; -- Stabled Hunter Pet
UPDATE `creature_template` SET `gossip_menu_id`=9879, `npcflag`=145, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33679; -- Recorder Lidio
UPDATE `creature_template` SET `gossip_menu_id`=9868, `minlevel`=50, `maxlevel`=50, `npcflag`=66177, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512 WHERE `entry`=48599; -- Innkeeper Teenycaugh
UPDATE `creature_template` SET `gossip_menu_id`=9868, `minlevel`=50, `maxlevel`=50, `npcflag`=66177, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512 WHERE `entry`=48215; -- Innkeeper Wylaria
UPDATE `creature_template` SET `gossip_menu_id`=9821, `npcflag`=129, `speed_walk`=2.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23392; -- Skyguard Stable Master
UPDATE `creature_template` SET `gossip_menu_id`=9821, `npcflag`=129, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22469; -- Fiskal Shadowsong
UPDATE `creature_template` SET `gossip_menu_id`=9821, `npcflag`=129, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21517; -- Ilthuril
UPDATE `creature_template` SET `gossip_menu_id`=9821, `npcflag`=129, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17666; -- Astur
UPDATE `creature_template` SET `gossip_menu_id`=9821, `minlevel`=64, `maxlevel`=64, `npcflag`=129, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24905; -- Leassian
UPDATE `creature_template` SET `gossip_menu_id`=9821, `minlevel`=57, `maxlevel`=57, `npcflag`=129, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17896; -- Kameel Longstride
UPDATE `creature_template` SET `gossip_menu_id`=9821, `minlevel`=50, `maxlevel`=50, `npcflag`=129, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=48216; -- Hurah
UPDATE `creature_template` SET `gossip_menu_id`=9821, `minlevel`=35, `maxlevel`=35, `faction_A`=994, `faction_H`=994, `npcflag`=129, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=43877; -- Fina Stillgrove
UPDATE `creature_template` SET `gossip_menu_id`=9821, `dynamicflags`=0 WHERE `entry`=9984; -- Ulbrek Firehand
UPDATE `creature_template` SET `gossip_menu_id`=9821 WHERE `entry`=44252; -- Karin
UPDATE `creature_template` SET `gossip_menu_id`=9821 WHERE `entry`=43019; -- Teldorae
UPDATE `creature_template` SET `gossip_menu_id`=9794 WHERE `entry`=29196; -- Lord Thorval
UPDATE `creature_template` SET `gossip_menu_id`=9793, `faction_A`=2050, `faction_H`=2050 WHERE `entry`=29195; -- Lady Alistra
UPDATE `creature_template` SET `gossip_menu_id`=9792 WHERE `entry`=29194; -- Amal'thazad
UPDATE `creature_template` SET `gossip_menu_id`=9653, `npcflag`=0, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26499; -- Arthas
UPDATE `creature_template` SET `gossip_menu_id`=9613, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27915; -- Chromie
UPDATE `creature_template` SET `gossip_menu_id`=9610, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27915; -- Chromie
UPDATE `creature_template` SET `gossip_menu_id`=9596, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26527; -- Chromie
UPDATE `creature_template` SET `gossip_menu_id`=9419, `speed_walk`=1.714286, `speed_run`=2, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=25319; -- Kalecgos
UPDATE `creature_template` SET `gossip_menu_id`=9298, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16818; -- Festival Talespinner
UPDATE `creature_template` SET `gossip_menu_id`=9293, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25632; -- Vindicator Moorba
UPDATE `creature_template` SET `gossip_menu_id`=9290, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25638; -- Captain Selana
UPDATE `creature_template` SET `gossip_menu_id`=9260, `minlevel`=72, `maxlevel`=73, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_class`=2, `dynamicflags`=0 WHERE `entry`=25754; -- Earthen Ring Flamecaller
UPDATE `creature_template` SET `gossip_menu_id`=9260, `minlevel`=70, `maxlevel`=75, `npcflag`=1, `speed_run`=1, `rangeattacktime`=2000, `unit_class`=2, `dynamicflags`=0 WHERE `entry`=25754; -- Earthen Ring Flamecaller
UPDATE `creature_template` SET `gossip_menu_id`=9260, `minlevel`=70, `maxlevel`=74, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_class`=2, `dynamicflags`=0 WHERE `entry`=25754; -- Earthen Ring Flamecaller
UPDATE `creature_template` SET `gossip_menu_id`=9204, `minlevel`=69, `maxlevel`=69, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25975; -- Master Fire Eater
UPDATE `creature_template` SET `gossip_menu_id`=9204, `minlevel`=68, `maxlevel`=68, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26113; -- Master Flame Eater
UPDATE `creature_template` SET `gossip_menu_id`=9204, `minlevel`=63, `maxlevel`=70, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25975; -- Master Fire Eater
UPDATE `creature_template` SET `gossip_menu_id`=9204, `minlevel`=58, `maxlevel`=58 WHERE `entry`=25962; -- Fire Eater
UPDATE `creature_template` SET `gossip_menu_id`=9204, `minlevel`=49, `maxlevel`=49 WHERE `entry`=25962; -- Fire Eater
UPDATE `creature_template` SET `gossip_menu_id`=9204, `minlevel`=47, `maxlevel`=47 WHERE `entry`=25962; -- Fire Eater
UPDATE `creature_template` SET `gossip_menu_id`=9204, `minlevel`=42, `maxlevel`=60 WHERE `entry`=25962; -- Fire Eater
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25917; -- Winterspring Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25915; -- Stranglethorn Vale Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25908; -- The Hinterlands Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25906; -- Teldrassil Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25904; -- Redridge Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25902; -- Loch Modan Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25900; -- Hellfire Peninsula Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25897; -- Dustwallow Marsh Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25894; -- Desolace Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25893; -- Darkshore Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25890; -- Blasted Lands Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25887; -- Arathi Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25883; -- Ashenvale Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32807; -- Crystalsong Forest Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32806; -- Storm Peaks Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32802; -- Sholazar Basin Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32801; -- Borean Tundra Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25916; -- Tanaris Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25914; -- Silithus Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25911; -- Wetlands Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25910; -- Westfall Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25898; -- Elwynn Forest Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25896; -- Duskwood Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25895; -- Dun Morogh Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=77, `maxlevel`=77, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=32808; -- Zul'Drak Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=75, `maxlevel`=75, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=32805; -- Grizzly Hills Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=70, `maxlevel`=70, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25913; -- Netherstorm Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=70, `maxlevel`=70, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25905; -- Shadowmoon Valley Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=70, `maxlevel`=70, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25903; -- Nagrand Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=65, `maxlevel`=65, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25899; -- Feralas Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=65, `maxlevel`=65, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25912; -- Zangarmarsh Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=65, `maxlevel`=65, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25909; -- Western Plaguelands Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=65, `maxlevel`=65, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25907; -- Terokkar Forest Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=65, `maxlevel`=65, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25889; -- Blade's Edge Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=55, `maxlevel`=55, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=51606; -- Un'Goro Crater Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=50, `maxlevel`=50, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25892; -- Burning Steppes Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=50, `maxlevel`=50, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=51585; -- Badlands Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=40, `maxlevel`=40, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=51602; -- Swamp of Sorrows Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=40, `maxlevel`=40, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=51588; -- Stonetalon Mountains Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=40, `maxlevel`=40, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=51586; -- Southern Barrens Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=30, `maxlevel`=30, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=51574; -- Northern Stranglethorn Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=25, `maxlevel`=25, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25888; -- Azuremyst Isle Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203, `minlevel`=20, `maxlevel`=20, `faction_A`=84, `faction_H`=84, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=25891; -- Bloodmyst Isle Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9203 WHERE `entry`=51653; -- Uldum Flame Warden
UPDATE `creature_template` SET `gossip_menu_id`=9157, `faction_A`=1735, `faction_H`=1735, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26221; -- Earthen Ring Elder
UPDATE `creature_template` SET `gossip_menu_id`=9157, `faction_A`=1732, `faction_H`=1732, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26221; -- Earthen Ring Elder
UPDATE `creature_template` SET `gossip_menu_id`=9148, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18927; -- Human Commoner
UPDATE `creature_template` SET `gossip_menu_id`=9148, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19176; -- Tauren Commoner
UPDATE `creature_template` SET `gossip_menu_id`=9148, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19173; -- Night Elf Commoner
UPDATE `creature_template` SET `gossip_menu_id`=9148, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=20102; -- Goblin Commoner
UPDATE `creature_template` SET `gossip_menu_id`=9148, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19171; -- Draenei Commoner
UPDATE `creature_template` SET `gossip_menu_id`=9148, `minlevel`=41, `maxlevel`=70 WHERE `entry`=16781; -- Midsummer Celebrant
UPDATE `creature_template` SET `gossip_menu_id`=9148, `minlevel`=41, `maxlevel`=56, `faction_A`=1734, `faction_H`=1734 WHERE `entry`=16781; -- Midsummer Celebrant
UPDATE `creature_template` SET `gossip_menu_id`=9148, `minlevel`=40 WHERE `entry`=16781; -- Midsummer Celebrant
UPDATE `creature_template` SET `gossip_menu_id`=9113, `npcflag`=66177, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19352; -- Dreg Cloudsweeper
UPDATE `creature_template` SET `gossip_menu_id`=9108 WHERE `entry`=25081; -- Grunt Ounda
UPDATE `creature_template` SET `gossip_menu_id`=9095 WHERE `entry`=25083; -- Deathguard Lawson
UPDATE `creature_template` SET `gossip_menu_id`=9095 WHERE `entry`=25079; -- Deathguard Fowles
UPDATE `creature_template` SET `gossip_menu_id`=9092 WHERE `entry`=25074; -- Crewman Sparkfly
UPDATE `creature_template` SET `gossip_menu_id`=9091 WHERE `entry`=25076; -- Navigator Fairweather
UPDATE `creature_template` SET `gossip_menu_id`=9090 WHERE `entry`=25070; -- Chief Officer Coppernut
UPDATE `creature_template` SET `gossip_menu_id`=9089 WHERE `entry`=25077; -- Sky-Captain Cloudkicker
UPDATE `creature_template` SET `gossip_menu_id`=9083 WHERE `entry`=25093; -- First Mate Masker
UPDATE `creature_template` SET `gossip_menu_id`=9044, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=23804; -- Orfus of Kamagua
UPDATE `creature_template` SET `gossip_menu_id`=9030, `npcflag`=3, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24866; -- Lakoor
UPDATE `creature_template` SET `gossip_menu_id`=900 WHERE `entry`=5594; -- Alchemist Pestlezugg
UPDATE `creature_template` SET `gossip_menu_id`=8950, `minlevel`=70, `maxlevel`=70, `npcflag`=129, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512 WHERE `entry`=58152; -- Tini Smalls
UPDATE `creature_template` SET `gossip_menu_id`=8950, `minlevel`=70, `maxlevel`=70, `npcflag`=129, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512 WHERE `entry`=54648; -- Leeni "Smiley" Smalls
UPDATE `creature_template` SET `gossip_menu_id`=8903, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22922; -- Innkeeper Aelerya
UPDATE `creature_template` SET `gossip_menu_id`=8903, `minlevel`=35, `maxlevel`=35, `faction_A`=994, `faction_H`=994, `npcflag`=65537, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33280 WHERE `entry`=43872; -- Innkeeper Dessina
UPDATE `creature_template` SET `gossip_menu_id`=8865, `dynamicflags`=0 WHERE `entry`=23988; -- Michael Schweitzer
UPDATE `creature_template` SET `gossip_menu_id`=8808, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23732; -- Sorely Twitchblade
UPDATE `creature_template` SET `gossip_menu_id`=8803, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23737; -- Coot "The Stranger" Albertson
UPDATE `creature_template` SET `gossip_menu_id`=8751, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23484; -- Haldor the Compulsive
UPDATE `creature_template` SET `gossip_menu_id`=8646, `npcflag`=145, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33680; -- Nemiha
UPDATE `creature_template` SET `gossip_menu_id`=8614, `faction_A`=1797, `faction_H`=1797, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=22919; -- Image of Commander Ameer
UPDATE `creature_template` SET `gossip_menu_id`=8567, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22836; -- Jheel
UPDATE `creature_template` SET `gossip_menu_id`=8566, `minlevel`=71, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22832; -- Morthis Whisperwing
UPDATE `creature_template` SET `gossip_menu_id`=8555, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22278; -- High Priest Orglum
UPDATE `creature_template` SET `gossip_menu_id`=8535, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22420; -- Lakotae
UPDATE `creature_template` SET `gossip_menu_id`=8526, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22370; -- Mekeda
UPDATE `creature_template` SET `gossip_menu_id`=8522, `maxlevel`=64, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=22477; -- Anchorite Ensham
UPDATE `creature_template` SET `gossip_menu_id`=8433, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19340; -- Mi'irku Farstep
UPDATE `creature_template` SET `gossip_menu_id`=8433, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19340; -- Mi'irku Farstep
UPDATE `creature_template` SET `gossip_menu_id`=8343, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21494; -- Smiles O'Byron
UPDATE `creature_template` SET `gossip_menu_id`=83 WHERE `entry`=39660; -- Spirit Healer
UPDATE `creature_template` SET `gossip_menu_id`=8298, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=17712; -- Captain Edward Hanes
UPDATE `creature_template` SET `gossip_menu_id`=8252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21197; -- Bronwyn Stouthammer
UPDATE `creature_template` SET `gossip_menu_id`=8251, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21151; -- Borgrim Stouthammer
UPDATE `creature_template` SET `gossip_menu_id`=8247, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21158; -- Commander Skyshadow
UPDATE `creature_template` SET `gossip_menu_id`=8236, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18098; -- Kialon Nightblade
UPDATE `creature_template` SET `gossip_menu_id`=8235, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21066; -- Rina Moonspring
UPDATE `creature_template` SET `gossip_menu_id`=8158, `minlevel`=15, `maxlevel`=15, `speed_walk`=1.428571, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18038; -- Azuremyst Peacekeeper
UPDATE `creature_template` SET `gossip_menu_id`=8080 WHERE `entry`=17310; -- Gnarl
UPDATE `creature_template` SET `gossip_menu_id`=8047, `npcflag`=4225, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=19879; -- Horvon the Armorer
UPDATE `creature_template` SET `gossip_menu_id`=8031, `npcflag`=2689, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19718; -- Provisioner Tsaalt
UPDATE `creature_template` SET `gossip_menu_id`=8029, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19417; -- Ramdor the Mad
UPDATE `creature_template` SET `gossip_menu_id`=8028, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19693; -- Clarissa
UPDATE `creature_template` SET `gossip_menu_id`=8022, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19676; -- "Captain" Kaftiz
UPDATE `creature_template` SET `gossip_menu_id`=7993, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=15991; -- Lady Dena Kennedy
UPDATE `creature_template` SET `gossip_menu_id`=7973, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19375; -- Eli Thunderstrike
UPDATE `creature_template` SET `gossip_menu_id`=7943, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19156; -- Telaari Jailor
UPDATE `creature_template` SET `gossip_menu_id`=7940, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19137; -- "Shotgun" Jones
UPDATE `creature_template` SET `gossip_menu_id`=7896, `minlevel`=63, `npcflag`=65537, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18251; -- Caregiver Abidaar
UPDATE `creature_template` SET `gossip_menu_id`=7891, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=19035; -- Wazat
UPDATE `creature_template` SET `gossip_menu_id`=7835, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=17927; -- Scout Jorli
UPDATE `creature_template` SET `gossip_menu_id`=7833, `npcflag`=19, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18804; -- Prospector Nachlan
UPDATE `creature_template` SET `gossip_menu_id`=7815, `npcflag`=17, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19063; -- Hamanar
UPDATE `creature_template` SET `gossip_menu_id`=7814, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18745; -- Captain Auric Sunchaser
UPDATE `creature_template` SET `gossip_menu_id`=7773, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18713; -- Lieutenant Gravelhammer
UPDATE `creature_template` SET `gossip_menu_id`=7753, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18387; -- Bertelm
UPDATE `creature_template` SET `gossip_menu_id`=7752, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18390; -- Ros'eleth
UPDATE `creature_template` SET `gossip_menu_id`=7745, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18704; -- Taela Everstride
UPDATE `creature_template` SET `gossip_menu_id`=7743, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18389; -- Thander
UPDATE `creature_template` SET `gossip_menu_id`=7741, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18675; -- Soolaveen
UPDATE `creature_template` SET `gossip_menu_id`=7738, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18252; -- Andarl
UPDATE `creature_template` SET `gossip_menu_id`=7737, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18538; -- Ishanah
UPDATE `creature_template` SET `gossip_menu_id`=7700, `npcflag`=1 WHERE `entry`=39034; -- Dr. Dealwell
UPDATE `creature_template` SET `gossip_menu_id`=7698, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18459; -- Jenai Starwhisper
UPDATE `creature_template` SET `gossip_menu_id`=7695, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18416; -- Huntress Kima
UPDATE `creature_template` SET `gossip_menu_id`=7691, `npcflag`=17 WHERE `entry`=812; -- Alma Jainrose
UPDATE `creature_template` SET `gossip_menu_id`=7683, `maxlevel`=60, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18295; -- Prospector Conall
UPDATE `creature_template` SET `gossip_menu_id`=7628, `npcflag`=4225, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18278; -- Pilot Marsha
UPDATE `creature_template` SET `gossip_menu_id`=7613, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=18007; -- Ruam
UPDATE `creature_template` SET `gossip_menu_id`=7578, `faction_A`=495, `faction_H`=495, `npcflag`=0, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18180; -- Hemet Nesingwary
UPDATE `creature_template` SET `gossip_menu_id`=7531, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17824; -- Captured Sunhawk Agent
UPDATE `creature_template` SET `gossip_menu_id`=7512, `npcflag`=19, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=17634; -- K. Lee Smallfry
UPDATE `creature_template` SET `gossip_menu_id`=7471, `maxlevel`=15, `npcflag`=643, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=17421; -- Clopper Wizbang
UPDATE `creature_template` SET `gossip_menu_id`=7464, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17703; -- Messenger Hermesius
UPDATE `creature_template` SET `gossip_menu_id`=7463, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17676; -- Achelus
UPDATE `creature_template` SET `gossip_menu_id`=7462, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=17649; -- Kessel
UPDATE `creature_template` SET `gossip_menu_id`=7461, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=17599; -- Aonar
UPDATE `creature_template` SET `gossip_menu_id`=7459, `npcflag`=19, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=17434; -- Morae
UPDATE `creature_template` SET `gossip_menu_id`=7455, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=17424; -- Anchorite Paetheus
UPDATE `creature_template` SET `gossip_menu_id`=7357, `minlevel`=70, `maxlevel`=70, `faction_A`=1743, `faction_H`=1743, `npcflag`=1, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=50019; -- Darahu
UPDATE `creature_template` SET `gossip_menu_id`=7357, `minlevel`=25, `maxlevel`=25, `faction_A`=1638, `faction_H`=1638, `npcflag`=1, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33280 WHERE `entry`=49964; -- Adrihi
UPDATE `creature_template` SET `gossip_menu_id`=7265, `minlevel`=70, `maxlevel`=70, `faction_A`=1743, `faction_H`=1743, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=0.9, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=33536 WHERE `entry`=50024; -- Salha
UPDATE `creature_template` SET `gossip_menu_id`=7265, `minlevel`=25, `maxlevel`=25, `faction_A`=1638, `faction_H`=1638, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=0.9, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=33280 WHERE `entry`=49962; -- Andrenatol
UPDATE `creature_template` SET `gossip_menu_id`=7264, `minlevel`=70, `maxlevel`=70, `faction_A`=1743, `faction_H`=1743, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=768 WHERE `entry`=50021; -- Raluhi
UPDATE `creature_template` SET `gossip_menu_id`=7264, `minlevel`=25, `maxlevel`=25, `faction_A`=1638, `faction_H`=1638, `npcflag`=49, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=512 WHERE `entry`=49959; -- Lennah
UPDATE `creature_template` SET `gossip_menu_id`=7263, `minlevel`=70, `maxlevel`=70, `faction_A`=1743, `faction_H`=1743, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=50025; -- Bratu
UPDATE `creature_template` SET `gossip_menu_id`=7263, `minlevel`=25, `maxlevel`=25, `faction_A`=1638, `faction_H`=1638, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33280 WHERE `entry`=49961; -- Viik
UPDATE `creature_template` SET `gossip_menu_id`=7262, `minlevel`=70, `maxlevel`=70, `faction_A`=1743, `faction_H`=1743, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=50020; -- Irva
UPDATE `creature_template` SET `gossip_menu_id`=7262, `minlevel`=25, `maxlevel`=25, `faction_A`=1638, `faction_H`=1638, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33280 WHERE `entry`=49966; -- Shaniri
UPDATE `creature_template` SET `gossip_menu_id`=7260, `minlevel`=70, `maxlevel`=70, `faction_A`=1743, `faction_H`=1743, `npcflag`=49, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=50023; -- Ordo
UPDATE `creature_template` SET `gossip_menu_id`=699 WHERE `entry`=43723; -- Jamie Crester
UPDATE `creature_template` SET `gossip_menu_id`=6944, `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=22931; -- Gorrim
UPDATE `creature_template` SET `gossip_menu_id`=6944, `minlevel`=85, `maxlevel`=85, `faction_A`=994, `faction_H`=994, `npcflag`=8193, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2 WHERE `entry`=35478; -- Lastrea Greengale
UPDATE `creature_template` SET `gossip_menu_id`=6944, `minlevel`=85, `maxlevel`=85, `faction_A`=1927, `faction_H`=1927, `npcflag`=8193, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=35481; -- Moira Steelwing
UPDATE `creature_template` SET `gossip_menu_id`=6944 WHERE `entry`=7823; -- Bera Stonehammer
UPDATE `creature_template` SET `gossip_menu_id`=6944 WHERE `entry`=4407; -- Teloren
UPDATE `creature_template` SET `gossip_menu_id`=6944 WHERE `entry`=4267; -- Daelyshia
UPDATE `creature_template` SET `gossip_menu_id`=6925, `minlevel`=57, `maxlevel`=57, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15499; -- Warden Haro
UPDATE `creature_template` SET `gossip_menu_id`=685 WHERE `entry`=1299; -- Lisbeth Schneider
UPDATE `creature_template` SET `gossip_menu_id`=6795, `speed_walk`=1.857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15378; -- Merithra of the Dream
UPDATE `creature_template` SET `gossip_menu_id`=6794, `speed_walk`=1.857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15379; -- Caelestrasz
UPDATE `creature_template` SET `gossip_menu_id`=6793, `speed_walk`=1.857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15380; -- Arygos
UPDATE `creature_template` SET `gossip_menu_id`=6765, `speed_walk`=1.857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15379; -- Caelestrasz
UPDATE `creature_template` SET `gossip_menu_id`=6655, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15504; -- Vethsera
UPDATE `creature_template` SET `gossip_menu_id`=6645, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15503; -- Kandrostrasz
UPDATE `creature_template` SET `gossip_menu_id`=6644, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15502; -- Andorgos
UPDATE `creature_template` SET `gossip_menu_id`=6585, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=15169; -- Ralo'shan the Eternal Watcher
UPDATE `creature_template` SET `gossip_menu_id`=6565, `dynamicflags`=0 WHERE `entry`=2943; -- Ransin Donner
UPDATE `creature_template` SET `gossip_menu_id`=6506, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=14991; -- League of Arathor Emissary
UPDATE `creature_template` SET `gossip_menu_id`=6469, `minlevel`=85, `maxlevel`=85, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=576, `dynamicflags`=0 WHERE `entry`=7410; -- Thelman Slatefist
UPDATE `creature_template` SET `gossip_menu_id`=646 WHERE `entry`=5482; -- Stephen Ryback
UPDATE `creature_template` SET `gossip_menu_id`=6212, `dynamicflags`=0 WHERE `entry`=14822; -- Sayge
UPDATE `creature_template` SET `gossip_menu_id`=6202, `dynamicflags`=0 WHERE `entry`=14847; -- Professor Thaddeus Paleo
UPDATE `creature_template` SET `gossip_menu_id`=6094 WHERE `entry`=14743; -- Jhordy Lapforge
UPDATE `creature_template` SET `gossip_menu_id`=5855 WHERE `entry`=2329; -- Michelle Belle
UPDATE `creature_template` SET `gossip_menu_id`=5853, `minlevel`=10, `maxlevel`=10, `dynamicflags`=0 WHERE `entry`=1355; -- Cook Ghilm
UPDATE `creature_template` SET `gossip_menu_id`=5763 WHERE `entry`=7207; -- Doc Mixilpixil
UPDATE `creature_template` SET `gossip_menu_id`=5665, `dynamicflags`=0 WHERE `entry`=1700; -- Paxton Ganter
UPDATE `creature_template` SET `gossip_menu_id`=5665 WHERE `entry`=56068; -- Steven Stagnaro
UPDATE `creature_template` SET `gossip_menu_id`=5627 WHERE `entry`=13257; -- Murgot Deepforge
UPDATE `creature_template` SET `gossip_menu_id`=5142 WHERE `entry`=13442; -- Arch Druid Renferal
UPDATE `creature_template` SET `gossip_menu_id`=5141 WHERE `entry`=13443; -- Druid of the Grove
UPDATE `creature_template` SET `gossip_menu_id`=5081 WHERE `entry`=13447; -- Corporal Noreg Stormpike
UPDATE `creature_template` SET `gossip_menu_id`=4862 WHERE `entry`=6771; -- Ravenholdt Assassin
UPDATE `creature_template` SET `gossip_menu_id`=4823, `npcflag`=49, `dynamicflags`=0 WHERE `entry`=2489; -- Milstaff Stormeye
UPDATE `creature_template` SET `gossip_menu_id`=4783, `dynamicflags`=0 WHERE `entry`=10090; -- Belia Thundergranite
UPDATE `creature_template` SET `gossip_menu_id`=4783 WHERE `entry`=44251; -- Alma Deering
UPDATE `creature_template` SET `gossip_menu_id`=4742, `dynamicflags`=0 WHERE `entry`=5161; -- Grimnur Stonebrand
UPDATE `creature_template` SET `gossip_menu_id`=4667, `npcflag`=1 WHERE `entry`=906; -- Maximillian Crowe
UPDATE `creature_template` SET `gossip_menu_id`=4667 WHERE `entry`=906; -- Maximillian Crowe
UPDATE `creature_template` SET `gossip_menu_id`=4666, `npcflag`=3 WHERE `entry`=377; -- Priestess Josetta
UPDATE `creature_template` SET `gossip_menu_id`=4661, `npcflag`=3 WHERE `entry`=328; -- Zaldimar Wefhellt
UPDATE `creature_template` SET `gossip_menu_id`=4570, `npcflag`=3, `dynamicflags`=0 WHERE `entry`=5113; -- Kelv Sternhammer
UPDATE `creature_template` SET `gossip_menu_id`=4560, `npcflag`=1, `dynamicflags`=0 WHERE `entry`=5143; -- Toldren Deepiron
UPDATE `creature_template` SET `gossip_menu_id`=4558, `npcflag`=1, `dynamicflags`=0 WHERE `entry`=5142; -- Braenna Flintcrag
UPDATE `creature_template` SET `gossip_menu_id`=4556, `npcflag`=1, `dynamicflags`=0 WHERE `entry`=5148; -- Beldruk Doombrow
UPDATE `creature_template` SET `gossip_menu_id`=4553, `dynamicflags`=0 WHERE `entry`=7312; -- Dink
UPDATE `creature_template` SET `gossip_menu_id`=4551, `npcflag`=1, `dynamicflags`=0 WHERE `entry`=5117; -- Regnus Thundergranite
UPDATE `creature_template` SET `gossip_menu_id`=4550, `npcflag`=3, `dynamicflags`=0 WHERE `entry`=5116; -- Olmin Burningbeard
UPDATE `creature_template` SET `gossip_menu_id`=4549, `npcflag`=3, `dynamicflags`=0 WHERE `entry`=5115; -- Daera Brightspear
UPDATE `creature_template` SET `gossip_menu_id`=4463, `dynamicflags`=0 WHERE `entry`=5497; -- Jennea Cannon
UPDATE `creature_template` SET `gossip_menu_id`=4463, `dynamicflags`=0 WHERE `entry`=5145; -- Juli Stormkettle
UPDATE `creature_template` SET `gossip_menu_id`=4463, `dynamicflags`=0 WHERE `entry`=5144; -- Bink
UPDATE `creature_template` SET `gossip_menu_id`=4463, `dynamicflags`=0 WHERE `entry`=1228; -- Magis Sparkmantle
UPDATE `creature_template` SET `gossip_menu_id`=4463 WHERE `entry`=50499; -- Myriam Spellwaker
UPDATE `creature_template` SET `gossip_menu_id`=4461, `dynamicflags`=0 WHERE `entry`=928; -- Lord Grayson Shadowbreaker
UPDATE `creature_template` SET `gossip_menu_id`=4461, `dynamicflags`=0 WHERE `entry`=5492; -- Katherine the Pure
UPDATE `creature_template` SET `gossip_menu_id`=4461, `dynamicflags`=0 WHERE `entry`=5491; -- Arthur the Faithful
UPDATE `creature_template` SET `gossip_menu_id`=4360, `dynamicflags`=0 WHERE `entry`=1573; -- Gryth Thurden
UPDATE `creature_template` SET `gossip_menu_id`=4182, `dynamicflags`=0 WHERE `entry`=1466; -- Gretta Finespindle
UPDATE `creature_template` SET `gossip_menu_id`=4154, `dynamicflags`=0 WHERE `entry`=11065; -- Thonys Pillarstone
UPDATE `creature_template` SET `gossip_menu_id`=4152 WHERE `entry`=8736; -- Buzzek Bracketswing
UPDATE `creature_template` SET `gossip_menu_id`=4150, `npcflag`=19, `dynamicflags`=0 WHERE `entry`=5174; -- Springspindle Fizzlegear
UPDATE `creature_template` SET `gossip_menu_id`=4147, `dynamicflags`=0 WHERE `entry`=11029; -- Trixie Quikswitch
UPDATE `creature_template` SET `gossip_menu_id`=4137, `dynamicflags`=0 WHERE `entry`=11028; -- Jemma Quikswitch
UPDATE `creature_template` SET `gossip_menu_id`=4123, `npcflag`=19, `dynamicflags`=0 WHERE `entry`=5177; -- Tally Berryfizz
UPDATE `creature_template` SET `gossip_menu_id`=4004, `npcflag`=129 WHERE `entry`=43694; -- Katie Stokx
UPDATE `creature_template` SET `gossip_menu_id`=3961, `npcflag`=1, `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=11625; -- Cork Gizelton
UPDATE `creature_template` SET `gossip_menu_id`=3841, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=12136; -- Snurk Bucksquick
UPDATE `creature_template` SET `gossip_menu_id`=381, `npcflag`=3 WHERE `entry`=917; -- Keryn Sylvius
UPDATE `creature_template` SET `gossip_menu_id`=3642, `npcflag`=3, `dynamicflags`=0 WHERE `entry`=11406; -- High Priest Rohan
UPDATE `creature_template` SET `gossip_menu_id`=3621, `speed_walk`=0.9920629, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=11554; -- Grazle
UPDATE `creature_template` SET `gossip_menu_id`=345 WHERE `entry`=44237; -- Maegan Tillman
UPDATE `creature_template` SET `gossip_menu_id`=345 WHERE `entry`=44235; -- Thaegra Tillstone
UPDATE `creature_template` SET `gossip_menu_id`=342 WHERE `entry`=44334; -- Donna Berrymore
UPDATE `creature_template` SET `gossip_menu_id`=2748 WHERE `entry`=10278; -- Thrag Stonehoof
UPDATE `creature_template` SET `gossip_menu_id`=267, `dynamicflags`=0 WHERE `entry`=6119; -- Tog Rustsprocket
UPDATE `creature_template` SET `gossip_menu_id`=2322, `dynamicflags`=0 WHERE `entry`=4262; -- Darnassus Sentinel
UPDATE `creature_template` SET `gossip_menu_id`=2304, `npcflag`=3, `dynamicflags`=0 WHERE `entry`=5149; -- Brandur Ironhammer
UPDATE `creature_template` SET `gossip_menu_id`=2242 WHERE `entry`=5411; -- Krinkle Goodsteel
UPDATE `creature_template` SET `gossip_menu_id`=1621 WHERE `entry`=8962; -- Hilary
UPDATE `creature_template` SET `gossip_menu_id`=1581, `npcflag`=66177, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19495; -- Innkeeper Shaunessy
UPDATE `creature_template` SET `gossip_menu_id`=1581, `minlevel`=35, `maxlevel`=35, `faction_A`=80, `faction_H`=80, `npcflag`=66177, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40968; -- Andoril
UPDATE `creature_template` SET `gossip_menu_id`=1503, `npcflag`=3 WHERE `entry`=459; -- Drusilla La Salle
UPDATE `creature_template` SET `gossip_menu_id`=1503 WHERE `entry`=459; -- Drusilla La Salle
UPDATE `creature_template` SET `gossip_menu_id`=1468, `npcflag`=3, `dynamicflags`=0 WHERE `entry`=7944; -- Tinkmaster Overspark
UPDATE `creature_template` SET `gossip_menu_id`=13352 WHERE `entry`=57850; -- Teleportologist Fozlebub
UPDATE `creature_template` SET `gossip_menu_id`=13348 WHERE `entry`=57800; -- Thaumaturge Rafir
UPDATE `creature_template` SET `gossip_menu_id`=13147, `minlevel`=77, `maxlevel`=77, `faction_A`=2016, `faction_H`=2016, `npcflag`=3, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33024 WHERE `entry`=55564; -- Reclaimer A'zak
UPDATE `creature_template` SET `gossip_menu_id`=13131 WHERE `entry`=55402; -- Korgol Crushskull
UPDATE `creature_template` SET `gossip_menu_id`=13124 WHERE `entry`=55382; -- Darkmoon Faire Mystic Mage
UPDATE `creature_template` SET `gossip_menu_id`=13082, `dynamicflags`=0 WHERE `entry`=10445; -- Selina Dourman
UPDATE `creature_template` SET `gossip_menu_id`=13076 WHERE `entry`=54345; -- Darkmoon Faire Greeter
UPDATE `creature_template` SET `gossip_menu_id`=13064, `dynamicflags`=0 WHERE `entry`=14841; -- Rinling
UPDATE `creature_template` SET `gossip_menu_id`=13052, `minlevel`=70, `maxlevel`=70, `faction_A`=1818, `faction_H`=1818, `npcflag`=3, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=54890; -- Field Commander Mahfuun
UPDATE `creature_template` SET `gossip_menu_id`=13051, `minlevel`=70, `maxlevel`=70, `faction_A`=1818, `faction_H`=1818, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=54891; -- Spy Grik'tha
UPDATE `creature_template` SET `gossip_menu_id`=13045, `minlevel`=85, `maxlevel`=85, `npcflag`=8195, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23736; -- Pricilla Winterwind
UPDATE `creature_template` SET `gossip_menu_id`=13041, `minlevel`=65, `maxlevel`=65, `faction_A`=1731, `faction_H`=1731, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=512, `unit_flags2`=34816 WHERE `entry`=54847; -- Dealer Vijaad
UPDATE `creature_template` SET `gossip_menu_id`=13040, `minlevel`=67, `maxlevel`=67, `faction_A`=1818, `faction_H`=1818, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=1200, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32832 WHERE `entry`=54840; -- Isfar
UPDATE `creature_template` SET `gossip_menu_id`=13035, `minlevel`=66, `maxlevel`=66, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768 WHERE `entry`=54725; -- Draenei Spirit
UPDATE `creature_template` SET `gossip_menu_id`=13031, `minlevel`=64, `maxlevel`=64, `faction_A`=1731, `faction_H`=1731, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=54694; -- Mamdy the "Ologist"
UPDATE `creature_template` SET `gossip_menu_id`=13030, `minlevel`=64, `maxlevel`=64, `faction_A`=1731, `faction_H`=1731, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=54692; -- Artificer Morphalius
UPDATE `creature_template` SET `gossip_menu_id`=13002, `minlevel`=88, `maxlevel`=88, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=52135; -- Malfurion Stormrage
UPDATE `creature_template` SET `gossip_menu_id`=12992 WHERE `entry`=54334; -- Darkmoon Faire Mystic Mage
UPDATE `creature_template` SET `gossip_menu_id`=12983, `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52824; -- General Taldris Moonfall
UPDATE `creature_template` SET `gossip_menu_id`=12978, `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768, `unit_flags2`=34816, `dynamicflags`=4 WHERE `entry`=52444; -- Thisalee Crow
UPDATE `creature_template` SET `gossip_menu_id`=12976, `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=52134; -- Commander Jarod Shadowsong
UPDATE `creature_template` SET `gossip_menu_id`=12970, `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=52825; -- Theresa Barkskin
UPDATE `creature_template` SET `gossip_menu_id`=12968, `minlevel`=80, `maxlevel`=80, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.385714, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=52478; -- Anren Shadowseeker
UPDATE `creature_template` SET `gossip_menu_id`=12966, `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=52477; -- Tholo Whitehoof
UPDATE `creature_template` SET `gossip_menu_id`=12941 WHERE `entry`=8719; -- Auctioneer Fitch
UPDATE `creature_template` SET `gossip_menu_id`=12939, `minlevel`=85, `maxlevel`=85, `faction_A`=2233, `faction_H`=2233, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53074; -- Witherbranch
UPDATE `creature_template` SET `gossip_menu_id`=12917, `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53073; -- Captain Soren Moonfall
UPDATE `creature_template` SET `gossip_menu_id`=12912, `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52671; -- Mylune
UPDATE `creature_template` SET `gossip_menu_id`=12911, `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=52669; -- Matoclaw
UPDATE `creature_template` SET `gossip_menu_id`=12907, `minlevel`=85, `maxlevel`=85, `faction_A`=2233, `faction_H`=2233, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=52490; -- Skylord Omnuron
UPDATE `creature_template` SET `gossip_menu_id`=12906, `minlevel`=85, `maxlevel`=85, `faction_A`=2233, `faction_H`=2233, `npcflag`=3, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52495; -- Shalis Darkhunter
UPDATE `creature_template` SET `gossip_menu_id`=12901, `minlevel`=85, `maxlevel`=85, `faction_A`=2233, `faction_H`=2233, `npcflag`=3, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=52493; -- Captain Saynna Stormrunner
UPDATE `creature_template` SET `gossip_menu_id`=12900, `minlevel`=82, `maxlevel`=82, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1.111112, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=52476; -- Keeper Krothis
UPDATE `creature_template` SET `gossip_menu_id`=12899, `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=53080; -- Captain Irontree
UPDATE `creature_template` SET `gossip_menu_id`=12898, `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33280 WHERE `entry`=52488; -- Elderlimb
UPDATE `creature_template` SET `gossip_menu_id`=12889, `minlevel`=85, `maxlevel`=85, `npcflag`=1, `speed_walk`=3.571429, `speed_run`=4.8, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=53408; -- Blue Drake
UPDATE `creature_template` SET `gossip_menu_id`=12839, `minlevel`=85, `maxlevel`=85, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=53196; -- Ricket
UPDATE `creature_template` SET `gossip_menu_id`=12823, `minlevel`=85, `maxlevel`=85, `faction_A`=1475, `faction_H`=1475, `npcflag`=4227, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=53214; -- Damek Bloombeard
UPDATE `creature_template` SET `gossip_menu_id`=12822, `minlevel`=85, `maxlevel`=85, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=52489; -- Avrilla
UPDATE `creature_template` SET `gossip_menu_id`=12820, `minlevel`=85, `maxlevel`=85, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=53151; -- Overseer Blingbang
UPDATE `creature_template` SET `gossip_menu_id`=12763, `minlevel`=80, `maxlevel`=80, `faction_A`=1779, `faction_H`=1779, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768, `unit_flags2`=34816 WHERE `entry`=52408; -- Coridormi
UPDATE `creature_template` SET `gossip_menu_id`=12762, `minlevel`=85, `maxlevel`=85, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=52425; -- Tooga
UPDATE `creature_template` SET `gossip_menu_id`=12740, `minlevel`=85, `maxlevel`=85, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51717; -- Resort Guest
UPDATE `creature_template` SET `gossip_menu_id`=12739, `minlevel`=85, `maxlevel`=85, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51936; -- Resort Guest
UPDATE `creature_template` SET `gossip_menu_id`=12733, `minlevel`=85, `maxlevel`=85, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51734; -- Gordon Tramsay
UPDATE `creature_template` SET `gossip_menu_id`=12720, `minlevel`=85, `maxlevel`=85, `faction_A`=474, `faction_H`=474, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=51735; -- Gott Weedlespan
UPDATE `creature_template` SET `gossip_menu_id`=12718, `minlevel`=85, `maxlevel`=85, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=51944; -- Resort Guest
UPDATE `creature_template` SET `gossip_menu_id`=12709, `minlevel`=83, `maxlevel`=83, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=33536 WHERE `entry`=51682; -- Hyjal Flame Guardian
UPDATE `creature_template` SET `gossip_menu_id`=12670 WHERE `entry`=6374; -- Cylina Darkheart
UPDATE `creature_template` SET `gossip_menu_id`=12670 WHERE `entry`=6373; -- Dane Winslow
UPDATE `creature_template` SET `gossip_menu_id`=12670 WHERE `entry`=5520; -- Spackle Thornberry
UPDATE `creature_template` SET `gossip_menu_id`=12643 WHERE `entry`=737; -- Kebok
UPDATE `creature_template` SET `gossip_menu_id`=12588, `unit_flags2`=33589248 WHERE `entry`=38518; -- Warrior-Matic NX-01
UPDATE `creature_template` SET `gossip_menu_id`=12586, `npcflag`=1, `unit_flags2`=33556480 WHERE `entry`=38517; -- Slinky Sharpshiv
UPDATE `creature_template` SET `gossip_menu_id`=12584, `npcflag`=1, `unit_flags2`=33556480 WHERE `entry`=38516; -- Sister Goldskimmer
UPDATE `creature_template` SET `gossip_menu_id`=12581, `npcflag`=1, `unit_flags2`=33556480 WHERE `entry`=38387; -- Sassy Hardwrench
UPDATE `creature_template` SET `gossip_menu_id`=12579, `npcflag`=1, `unit_flags2`=33556480 WHERE `entry`=38515; -- Maxx Avalanche
UPDATE `creature_template` SET `gossip_menu_id`=12576, `npcflag`=1, `unit_flags2`=33556480 WHERE `entry`=38513; -- Evol Fingers
UPDATE `creature_template` SET `gossip_menu_id`=12575, `npcflag`=3, `unit_flags2`=33556480 WHERE `entry`=38122; -- Bamm Megabomb
UPDATE `creature_template` SET `gossip_menu_id`=12574, `npcflag`=3, `unit_flags2`=33556480 WHERE `entry`=38122; -- Bamm Megabomb
UPDATE `creature_template` SET `gossip_menu_id`=12520 WHERE `entry`=49750; -- Warchief's Herald
UPDATE `creature_template` SET `gossip_menu_id`=12519 WHERE `entry`=49748; -- Hero's Herald
UPDATE `creature_template` SET `gossip_menu_id`=12467, `unit_flags2`=33556480 WHERE `entry`=48494; -- Hobart Grapplehammer
UPDATE `creature_template` SET `gossip_menu_id`=12467, `npcflag`=1, `unit_flags2`=33556480 WHERE `entry`=48494; -- Hobart Grapplehammer
UPDATE `creature_template` SET `gossip_menu_id`=12466, `unit_flags2`=33556480 WHERE `entry`=48496; -- Assistant Greely
UPDATE `creature_template` SET `gossip_menu_id`=12466, `npcflag`=1, `unit_flags2`=33556480 WHERE `entry`=48496; -- Assistant Greely
UPDATE `creature_template` SET `gossip_menu_id`=12428, `minlevel`=85, `maxlevel`=85, `npcflag`=8193, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33280 WHERE `entry`=43073; -- Hanah Southsong
UPDATE `creature_template` SET `gossip_menu_id`=12398, `minlevel`=48, `maxlevel`=48, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2 WHERE `entry`=47842; -- Arch Druid Navarax
UPDATE `creature_template` SET `gossip_menu_id`=12358 WHERE `entry`=47715; -- Sun Priest Asaris
UPDATE `creature_template` SET `gossip_menu_id`=12293, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=14625; -- Overseer Oilfist
UPDATE `creature_template` SET `gossip_menu_id`=12240 WHERE `entry`=47320; -- Kaellin Tarvane
UPDATE `creature_template` SET `gossip_menu_id`=1221, `dynamicflags`=0 WHERE `entry`=6928; -- Innkeeper Grosk
UPDATE `creature_template` SET `gossip_menu_id`=1221 WHERE `entry`=42473; -- Grimy Greasefingers
UPDATE `creature_template` SET `gossip_menu_id`=12193, `npcflag`=17 WHERE `entry`=47396; -- Wembil Taskwidget
UPDATE `creature_template` SET `gossip_menu_id`=12188, `npcflag`=17 WHERE `entry`=47384; -- Lien Farner
UPDATE `creature_template` SET `gossip_menu_id`=12185, `npcflag`=17 WHERE `entry`=47418; -- Runda
UPDATE `creature_template` SET `gossip_menu_id`=12180, `npcflag`=17 WHERE `entry`=47384; -- Lien Farner
UPDATE `creature_template` SET `gossip_menu_id`=12004, `npcflag`=3 WHERE `entry`=45306; -- Chief Surgeon Gashweld
UPDATE `creature_template` SET `gossip_menu_id`=11909 WHERE `entry`=2439; -- Major Samuelson
UPDATE `creature_template` SET `gossip_menu_id`=11888, `minlevel`=82, `maxlevel`=82, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1.388888, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=41308; -- Aviana
UPDATE `creature_template` SET `gossip_menu_id`=11880 WHERE `entry`=44774; -- Genevieve
UPDATE `creature_template` SET `gossip_menu_id`=11860, `npcflag`=3 WHERE `entry`=43278; -- Ashley Blank
UPDATE `creature_template` SET `gossip_menu_id`=11829, `npcflag`=3 WHERE `entry`=44395; -- Celestine of the Harvest
UPDATE `creature_template` SET `gossip_menu_id`=11828, `minlevel`=35, `maxlevel`=35, `faction_A`=80, `faction_H`=80, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40035; -- Erina Willowborn
UPDATE `creature_template` SET `gossip_menu_id`=11817, `npcflag`=3 WHERE `entry`=44247; -- Wulf Hansreim
UPDATE `creature_template` SET `gossip_menu_id`=11817, `npcflag`=1 WHERE `entry`=43277; -- Don Omar
UPDATE `creature_template` SET `gossip_menu_id`=11814 WHERE `entry`=44267; -- Logistics Officer Salista
UPDATE `creature_template` SET `gossip_menu_id`=11776, `minlevel`=21, `maxlevel`=21, `faction_A`=122, `faction_H`=122, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=36378; -- Dumti
UPDATE `creature_template` SET `gossip_menu_id`=11775, `minlevel`=22, `maxlevel`=22, `faction_A`=122, `faction_H`=122, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=36378; -- Dumti
UPDATE `creature_template` SET `gossip_menu_id`=11731 WHERE `entry`=43418; -- Sprinkle Noggenfogger
UPDATE `creature_template` SET `gossip_menu_id`=11635, `npcflag`=1, `unit_flags`=33024, `dynamicflags`=0 WHERE `entry`=42384; -- Homeless Stormwind Citizen
UPDATE `creature_template` SET `gossip_menu_id`=11615 WHERE `entry`=42288; -- Robby Flay
UPDATE `creature_template` SET `gossip_menu_id`=11611 WHERE `entry`=240; -- Marshal Dughan
UPDATE `creature_template` SET `gossip_menu_id`=11543, `minlevel`=80, `maxlevel`=80, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=39433; -- Ian Duran
UPDATE `creature_template` SET `gossip_menu_id`=11541, `minlevel`=81, `maxlevel`=81, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=39432; -- Takrik Ragehowl
UPDATE `creature_template` SET `gossip_menu_id`=11528, `minlevel`=82, `maxlevel`=82, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=41498; -- Garunda Mountainpeak
UPDATE `creature_template` SET `gossip_menu_id`=11526, `minlevel`=83, `maxlevel`=83, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=41492; -- Captain Irontree
UPDATE `creature_template` SET `gossip_menu_id`=11451, `minlevel`=88, `maxlevel`=88, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_run`=0.888888, `baseattacktime`=3000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33024, `unit_flags2`=34816 WHERE `entry`=40289; -- Ysera
UPDATE `creature_template` SET `gossip_menu_id`=11447, `minlevel`=81, `maxlevel`=81, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40834; -- Jordan Olafson
UPDATE `creature_template` SET `gossip_menu_id`=11446, `minlevel`=81, `maxlevel`=81, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40837; -- Yargra Blackscar
UPDATE `creature_template` SET `gossip_menu_id`=11441, `minlevel`=81, `maxlevel`=81, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=39869; -- Windspeaker Tamila
UPDATE `creature_template` SET `gossip_menu_id`=11440, `minlevel`=88, `maxlevel`=88, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33024, `unit_flags2`=34816 WHERE `entry`=39857; -- Malfurion Stormrage
UPDATE `creature_template` SET `gossip_menu_id`=11437, `minlevel`=81, `maxlevel`=81, `faction_A`=2233, `faction_H`=2233, `npcflag`=65665, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=40843; -- Sebelia
UPDATE `creature_template` SET `gossip_menu_id`=11425, `minlevel`=45, `maxlevel`=45, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8 WHERE `entry`=40712; -- Mazoga's Spirit
UPDATE `creature_template` SET `gossip_menu_id`=11417, `minlevel`=76, `maxlevel`=76, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25697; -- Luma Skymother
UPDATE `creature_template` SET `gossip_menu_id`=11416, `minlevel`=82, `maxlevel`=82, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=40578; -- Farden Talonshrike
UPDATE `creature_template` SET `gossip_menu_id`=11401, `minlevel`=84, `maxlevel`=84, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=41504; -- Tortolla
UPDATE `creature_template` SET `gossip_menu_id`=11384, `minlevel`=50, `maxlevel`=50, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33024 WHERE `entry`=40436; -- Earthen Ring Pathfinder
UPDATE `creature_template` SET `gossip_menu_id`=11362, `minlevel`=37, `maxlevel`=37, `faction_A`=80, `faction_H`=80, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=32768 WHERE `entry`=40132; -- Vestia Moonspear
UPDATE `creature_template` SET `gossip_menu_id`=11361, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=14637; -- Zorbin Fandazzle
UPDATE `creature_template` SET `gossip_menu_id`=11357, `minlevel`=36, `maxlevel`=36, `faction_A`=2164, `faction_H`=2164, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=39653; -- Silvia
UPDATE `creature_template` SET `gossip_menu_id`=11353, `minlevel`=36, `maxlevel`=36, `faction_A`=80, `faction_H`=80, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=40078; -- Handler Tessina
UPDATE `creature_template` SET `gossip_menu_id`=11347, `minlevel`=36, `maxlevel`=36, `faction_A`=80, `faction_H`=80, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=17152 WHERE `entry`=40036; -- Karonas
UPDATE `creature_template` SET `gossip_menu_id`=11315, `minlevel`=35, `maxlevel`=35, `faction_A`=80, `faction_H`=80, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=32768 WHERE `entry`=40032; -- Telaron Windflight
UPDATE `creature_template` SET `gossip_menu_id`=11297, `minlevel`=80, `maxlevel`=80, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=39435; -- Royce Duskwhisper
UPDATE `creature_template` SET `gossip_menu_id`=11284, `minlevel`=88, `maxlevel`=88, `faction_A`=124, `faction_H`=124, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=3936; -- Shandris Feathermoon
UPDATE `creature_template` SET `gossip_menu_id`=11280, `minlevel`=80, `maxlevel`=80, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=39434; -- Rio Duran
UPDATE `creature_template` SET `gossip_menu_id`=11279, `minlevel`=74, `maxlevel`=75, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33280 WHERE `entry`=39644; -- Twilight Servitor
UPDATE `creature_template` SET `gossip_menu_id`=11261 WHERE `entry`=38510; -- Grimy Greasefingers
UPDATE `creature_template` SET `gossip_menu_id`=11258, `npcflag`=1, `unit_flags2`=33556480 WHERE `entry`=36471; -- Foreman Dampwick
UPDATE `creature_template` SET `gossip_menu_id`=11257, `unit_flags2`=33556480 WHERE `entry`=36615; -- Doc Zapnozzle
UPDATE `creature_template` SET `gossip_menu_id`=11254, `npcflag`=1, `unit_flags2`=33556480 WHERE `entry`=38432; -- Megs Dreadshredder
UPDATE `creature_template` SET `gossip_menu_id`=11244, `unit_flags2`=33556480 WHERE `entry`=38387; -- Sassy Hardwrench
UPDATE `creature_template` SET `gossip_menu_id`=11170, `npcflag`=1, `unit_flags2`=33556480 WHERE `entry`=38514; -- Fizz Lighter
UPDATE `creature_template` SET `gossip_menu_id`=11158 WHERE `entry`=39084; -- Mizzy Pistonhammer
UPDATE `creature_template` SET `gossip_menu_id`=11147 WHERE `entry`=38986; -- Ambassador Gaines
UPDATE `creature_template` SET `gossip_menu_id`=11146, `unit_flags2`=33556480 WHERE `entry`=38387; -- Sassy Hardwrench
UPDATE `creature_template` SET `gossip_menu_id`=11142 WHERE `entry`=38935; -- Thrall
UPDATE `creature_template` SET `gossip_menu_id`=11090, `unit_flags`=33280, `unit_flags2`=33556480 WHERE `entry`=38120; -- Hobart Grapplehammer
UPDATE `creature_template` SET `gossip_menu_id`=11088, `npcflag`=3, `unit_flags2`=33556480 WHERE `entry`=38124; -- Assistant Greely
UPDATE `creature_template` SET `gossip_menu_id`=11085, `unit_flags2`=33556480 WHERE `entry`=36471; -- Foreman Dampwick
UPDATE `creature_template` SET `gossip_menu_id`=11083, `unit_flags2`=33556480 WHERE `entry`=38387; -- Sassy Hardwrench
UPDATE `creature_template` SET `gossip_menu_id`=11081 WHERE `entry`=38738; -- Coach Crosscheck
UPDATE `creature_template` SET `gossip_menu_id`=11075, `npcflag`=1 WHERE `entry`=38738; -- Coach Crosscheck
UPDATE `creature_template` SET `gossip_menu_id`=11074, `npcflag`=1 WHERE `entry`=38738; -- Coach Crosscheck
UPDATE `creature_template` SET `gossip_menu_id`=11009 WHERE `entry`=38381; -- Brett "Coins" McQuid
UPDATE `creature_template` SET `gossip_menu_id`=10966, `npcflag`=3, `unit_flags2`=33556480 WHERE `entry`=38124; -- Assistant Greely
UPDATE `creature_template` SET `gossip_menu_id`=10965, `unit_flags2`=33556480 WHERE `entry`=38120; -- Hobart Grapplehammer
UPDATE `creature_template` SET `gossip_menu_id`=10943 WHERE `entry`=37597; -- Lady Jaina Proudmoore
UPDATE `creature_template` SET `gossip_menu_id`=10933, `npcflag`=1, `speed_walk`=1.714286, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33600, `dynamicflags`=0 WHERE `entry`=37200; -- Muradin Bronzebeard
UPDATE `creature_template` SET `gossip_menu_id`=10885, `npcflag`=1, `speed_walk`=1.714286, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=37184; -- Zafod Boombox
UPDATE `creature_template` SET `gossip_menu_id`=10875, `minlevel`=83, `maxlevel`=83, `npcflag`=1, `speed_walk`=1.714286, `speed_run`=1, `baseattacktime`=1500, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=36948; -- Muradin Bronzebeard
UPDATE `creature_template` SET `gossip_menu_id`=10805 WHERE `entry`=36496; -- Grimy Greasefingers
UPDATE `creature_template` SET `gossip_menu_id`=10791 WHERE `entry`=36403; -- Trade Prince Gallywix
UPDATE `creature_template` SET `gossip_menu_id`=10779, `minlevel`=38, `maxlevel`=38, `faction_A`=1927, `faction_H`=1927, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=36329; -- Thargad
UPDATE `creature_template` SET `gossip_menu_id`=10778, `minlevel`=35, `maxlevel`=35, `faction_A`=635, `faction_H`=635, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=36060; -- Botanist Ferrah
UPDATE `creature_template` SET `gossip_menu_id`=10735, `minlevel`=45, `maxlevel`=45, `faction_A`=994, `faction_H`=994, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2 WHERE `entry`=36034; -- Karnum Marshweaver
UPDATE `creature_template` SET `gossip_menu_id`=10711 WHERE `entry`=35917; -- Kilag Gorefang
UPDATE `creature_template` SET `gossip_menu_id`=10649 WHERE `entry`=35477; -- Little Adeline
UPDATE `creature_template` SET `gossip_menu_id`=10624 WHERE `entry`=35130; -- Missa Spekkies
UPDATE `creature_template` SET `gossip_menu_id`=10622 WHERE `entry`=35128; -- Szabo
UPDATE `creature_template` SET `gossip_menu_id`=10620 WHERE `entry`=35126; -- Gappy Silvertooth
UPDATE `creature_template` SET `gossip_menu_id`=10606, `dynamicflags`=0 WHERE `entry`=35007; -- Lixa Felflinger
UPDATE `creature_template` SET `gossip_menu_id`=10606, `dynamicflags`=0 WHERE `entry`=34991; -- Borim Goldhammer
UPDATE `creature_template` SET `gossip_menu_id`=10562 WHERE `entry`=34715; -- Sky-Captain "Dusty" Blastnut
UPDATE `creature_template` SET `gossip_menu_id`=10561 WHERE `entry`=34718; -- Crewman Deadbolt
UPDATE `creature_template` SET `gossip_menu_id`=10559 WHERE `entry`=34717; -- Crewman Pipewrench
UPDATE `creature_template` SET `gossip_menu_id`=10557 WHERE `entry`=34730; -- Navigator Zippik
UPDATE `creature_template` SET `gossip_menu_id`=10541, `minlevel`=40, `maxlevel`=40, `faction_A`=1934, `faction_H`=1934, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33024 WHERE `entry`=34604; -- Big Baobob
UPDATE `creature_template` SET `gossip_menu_id`=10453 WHERE `entry`=33738; -- Darnassus Champion
UPDATE `creature_template` SET `gossip_menu_id`=10440 WHERE `entry`=33447; -- Squire David
UPDATE `creature_template` SET `gossip_menu_id`=10401 WHERE `entry`=33974; -- Valis Windchaser
UPDATE `creature_template` SET `gossip_menu_id`=10371 WHERE `entry`=29196; -- Lord Thorval
UPDATE `creature_template` SET `gossip_menu_id`=10365, `npcflag`=2193, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33676; -- Zurii
UPDATE `creature_template` SET `gossip_menu_id`=10364, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33636; -- Miralisse
UPDATE `creature_template` SET `gossip_menu_id`=10363, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33677; -- Technician Mihila
UPDATE `creature_template` SET `gossip_menu_id`=10363, `npcflag`=145, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33634; -- Engineer Sinbei
UPDATE `creature_template` SET `gossip_menu_id`=10362, `npcflag`=145, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33631; -- Barien
UPDATE `creature_template` SET `gossip_menu_id`=10351, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=33682; -- Fono
UPDATE `creature_template` SET `gossip_menu_id`=10209, `maxlevel`=79, `speed_walk`=1.714286, `speed_run`=2.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=32594; -- Calder
UPDATE `creature_template` SET `gossip_menu_id`=10188, `minlevel`=45, `maxlevel`=45, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=44929; -- Tran'rek
UPDATE `creature_template` SET `gossip_menu_id`=1017 WHERE `entry`=2998; -- Karn Stonehoof
UPDATE `creature_template` SET `gossip_menu_id`=10105 WHERE `entry`=32733; -- Joboba Mezbreaker
UPDATE `creature_template` SET `gossip_menu_id`=10098 WHERE `entry`=32733; -- Joboba Mezbreaker
UPDATE `creature_template` SET `gossip_menu_id`=10098 WHERE `entry`=32728; -- Illusionist Karina
UPDATE `creature_template` SET `gossip_menu_id`=10098 WHERE `entry`=32726; -- The Chooch
UPDATE `creature_template` SET `gossip_menu_id`=10085 WHERE `entry`=32685; -- Kitz Proudbreeze
UPDATE `creature_template` SET `gossip_menu_id`=10082 WHERE `entry`=32677; -- Whirt the All-Knowing
UPDATE `creature_template` SET `gossip_menu_id`=10081 WHERE `entry`=32689; -- Adorean Lew
UPDATE `creature_template` SET `gossip_menu_id`=10081 WHERE `entry`=32684; -- Mona Everspring
UPDATE `creature_template` SET `gossip_menu_id`=10076 WHERE `entry`=32684; -- Mona Everspring
UPDATE `creature_template` SET `gossip_menu_id`=10050 WHERE `entry`=32684; -- Mona Everspring
UPDATE `creature_template` SET `gossip_menu_id`=10050 WHERE `entry`=32677; -- Whirt the All-Knowing
UPDATE `creature_template` SET `gossip_menu_id`=10045 WHERE `entry`=32677; -- Whirt the All-Knowing
UPDATE `creature_template` SET `gossip_menu_id`=10043 WHERE `entry`=32684; -- Mona Everspring
UPDATE `creature_template` SET `faction_H`=974, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=27860; -- Luthion the Vile
UPDATE `creature_template` SET `faction_H`=68 WHERE `entry`=33996; -- William Saldean
UPDATE `creature_template` SET `faction_H`=634, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26093; -- Naxxanar Target
UPDATE `creature_template` SET `faction_H`=1978 WHERE `entry`=25338; -- Warsong Caravan Guard
UPDATE `creature_template` SET `faction_H`=1921 WHERE `entry`=25335; -- Longrunner Proudhoof
UPDATE `creature_template` SET `faction_H`=1610, `npcflag`=0, `unit_flags2`=0 WHERE `entry`=28781; -- Battleground Demolisher
UPDATE `creature_template` SET `faction_H`=14, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=25422; -- Mystical Webbing
UPDATE `creature_template` SET `faction_H`=14 WHERE `entry`=33785; -- The Black Knight
UPDATE `creature_template` SET `faction_H`=11 WHERE `entry`=29295; -- Meghan Dawson
UPDATE `creature_template` SET `faction_H`=11 WHERE `entry`=29294; -- Candace Thomas
UPDATE `creature_template` SET `faction_H`=11 WHERE `entry`=29293; -- Daniel Kramer
UPDATE `creature_template` SET `faction_H`=11 WHERE `entry`=29292; -- Art Peshkov
UPDATE `creature_template` SET `faction_H`=1, `npcflag`=0, `speed_walk`=0.6857143, `speed_run`=0.48, `baseattacktime`=2400, `unit_flags2`=0 WHERE `entry`=28781; -- Battleground Demolisher
UPDATE `creature_template` SET `faction_A`=974, `faction_H`=974, `npcflag`=0, `speed_run`=1, `rangeattacktime`=2000, `unit_class`=8, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=25301; -- Counselor Talbot
UPDATE `creature_template` SET `faction_A`=90, `faction_H`=90, `speed_walk`=1.388889, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21961; -- Cataclysm Overseer
UPDATE `creature_template` SET `faction_A`=90, `faction_H`=90, `speed_walk`=1.142857, `speed_run`=1.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=22381; -- Hathyss the Wicked
UPDATE `creature_template` SET `faction_A`=90, `faction_H`=90, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=21754; -- Shadow Council Zealot
UPDATE `creature_template` SET `faction_A`=90, `faction_H`=90, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=21753; -- Shadow Council Felsworn
UPDATE `creature_template` SET `faction_A`=90, `faction_H`=90, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21960; -- Gan'arg Technician
UPDATE `creature_template` SET `faction_A`=84, `faction_H`=84, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=832, `dynamicflags`=0 WHERE `entry`=36970; -- Skybreaker Deckhand
UPDATE `creature_template` SET `faction_A`=84, `faction_H`=84, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=37182; -- High Captain Justin Bartlett
UPDATE `creature_template` SET `faction_A`=83, `faction_H`=83, `speed_walk`=1.428571, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=37117; -- Kor'kron Battle-Mage
UPDATE `creature_template` SET `faction_A`=83, `faction_H`=83, `speed_walk`=1.428571, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=36982; -- Kor'kron Rocketeer
UPDATE `creature_template` SET `faction_A`=83, `faction_H`=83, `speed_walk`=1.428571, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=36968; -- Kor'kron Axethrower
UPDATE `creature_template` SET `faction_A`=83, `faction_H`=83, `speed_walk`=1.428571, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=36960; -- Kor'kron Sergeant
UPDATE `creature_template` SET `faction_A`=83, `faction_H`=83, `speed_walk`=1.428571, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=36957; -- Kor'kron Reaver
UPDATE `creature_template` SET `faction_A`=83, `faction_H`=83, `npcflag`=0 WHERE `entry`=3084; -- Bluffwatcher
UPDATE `creature_template` SET `faction_A`=775, `faction_H`=775, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27814; -- Brew Vendor
UPDATE `creature_template` SET `faction_A`=775, `faction_H`=775, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=27814; -- Brew Vendor
UPDATE `creature_template` SET `faction_A`=774, `faction_H`=774, `npcflag`=129, `dynamicflags`=0 WHERE `entry`=27815; -- Brew Vendor
UPDATE `creature_template` SET `faction_A`=774, `faction_H`=774, `dynamicflags`=0 WHERE `entry`=27815; -- Brew Vendor
UPDATE `creature_template` SET `faction_A`=7, `faction_H`=7, `unit_flags`=33024, `dynamicflags`=0 WHERE `entry`=42384; -- Homeless Stormwind Citizen
UPDATE `creature_template` SET `faction_A`=7, `faction_H`=7, `speed_walk`=1.571429, `speed_run`=1.2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20668; -- Fiendling Flesh Beast
UPDATE `creature_template` SET `faction_A`=7, `faction_H`=7, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33555200, `unit_flags2`=67110912 WHERE `entry`=52704; -- Cinderweb Egg
UPDATE `creature_template` SET `faction_A`=7, `faction_H`=7, `npcflag`=0 WHERE `entry`=42386; -- Homeless Stormwind Citizen
UPDATE `creature_template` SET `faction_A`=7, `faction_H`=7, `npcflag`=0 WHERE `entry`=42383; -- Transient
UPDATE `creature_template` SET `faction_A`=7, `faction_H`=7 WHERE `entry`=42391; -- West Plains Drifter
UPDATE `creature_template` SET `faction_A`=634, `faction_H`=634, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=6503; -- Spiked Stegodon
UPDATE `creature_template` SET `faction_A`=634, `faction_H`=634, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=6501; -- Stegodon
UPDATE `creature_template` SET `faction_A`=495, `faction_H`=495, `npcflag`=0, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18200; -- Shado 'Fitz' Farstrider
UPDATE `creature_template` SET `faction_A`=475, `faction_H`=475, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768 WHERE `entry`=38354; -- Un'Goro Pit Bunny
UPDATE `creature_template` SET `faction_A`=411, `faction_H`=411, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=16354; -- Vampiric Mistbat
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=5, `npcflag`=0, `unit_flags2`=0 WHERE `entry`=27894; -- Antipersonnel Cannon
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35, `unit_flags`=33555200 WHERE `entry`=23837; -- ELM General Purpose Bunny
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=11079; -- Wynd Nightchaser
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=10301; -- Jaron Stoneshaper
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35, `unit_flags2`=2049 WHERE `entry`=3225; -- Corrupted Mottled Boar
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35, `speed_walk`=1.428571, `speed_run`=1.6, `baseattacktime`=1000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37813; -- Deathbringer Saurfang
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=23968; -- Hanes Fire Trigger
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=18585; -- Raliq the Drunk
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=7407; -- Chief Engineer Bilgewhizzle
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18351; -- Lump
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=7750; -- Corporal Thund Splithoof
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35, `speed_walk`=0.9920629, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33024, `dynamicflags`=0 WHERE `entry`=23473; -- Aether-tech Apprentice
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35, `dynamicflags`=0 WHERE `entry`=3779; -- Syurana
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35, `dynamicflags`=0 WHERE `entry`=2303; -- Lyranne Feathersong
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35, `dynamicflags`=0 WHERE `entry`=2084; -- Natheril Raincaller
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35 WHERE `entry`=28486; -- Squire Edwards
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35 WHERE `entry`=27928; -- Siouxsie the Banshee
UPDATE `creature_template` SET `faction_A`=35, `faction_H`=35 WHERE `entry`=14848; -- Herald
UPDATE `creature_template` SET `faction_A`=310, `faction_H`=310, `speed_walk`=2.142857, `speed_run`=2.4, `unit_flags`=64, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=15312; -- Obsidian Nullifier
UPDATE `creature_template` SET `faction_A`=310, `faction_H`=310, `speed_walk`=1.714286, `speed_run`=1.6, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=15311; -- Anubisath Warder
UPDATE `creature_template` SET `faction_A`=31, `faction_H`=31, `speed_walk`=0.8571429, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=50419; -- Grotto Vole
UPDATE `creature_template` SET `faction_A`=31, `faction_H`=31, `speed_walk`=0.8571429, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=49734; -- Spotted Bell Frog
UPDATE `creature_template` SET `faction_A`=31, `faction_H`=31, `speed_walk`=0.7142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=50485; -- Carrion Rat
UPDATE `creature_template` SET `faction_A`=29, `faction_H`=29, `unit_flags`=33280, `unit_flags2`=33556480 WHERE `entry`=39067; -- Scout Brax
UPDATE `creature_template` SET `faction_A`=29, `faction_H`=29, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19175; -- Orc Commoner
UPDATE `creature_template` SET `faction_A`=29, `faction_H`=29, `npcflag`=1, `unit_flags`=33280, `unit_flags2`=33556480 WHERE `entry`=39067; -- Scout Brax
UPDATE `creature_template` SET `faction_A`=29, `faction_H`=29, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19175; -- Orc Commoner
UPDATE `creature_template` SET `faction_A`=2468, `faction_H`=2468, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=14355; -- Azj'Tordin
UPDATE `creature_template` SET `faction_A`=2263, `faction_H`=2263, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=9997; -- Spraggle Frock
UPDATE `creature_template` SET `faction_A`=2263, `faction_H`=2263, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=9271; -- Hol'anyee Marshal
UPDATE `creature_template` SET `faction_A`=2263, `faction_H`=2263, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=9270; -- Williden Marshal
UPDATE `creature_template` SET `faction_A`=2263, `faction_H`=2263, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=9117; -- J.D. Collie
UPDATE `creature_template` SET `faction_A`=2263, `faction_H`=2263, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=3000; -- Gibbert
UPDATE `creature_template` SET `faction_A`=2263, `faction_H`=2263, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=10977; -- Quixxil
UPDATE `creature_template` SET `faction_A`=2263, `faction_H`=2263, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=10302; -- Krakle
UPDATE `creature_template` SET `faction_A`=2263, `faction_H`=2263, `npcflag`=640, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=0, `dynamicflags`=0 WHERE `entry`=12959; -- Nergal
UPDATE `creature_template` SET `faction_A`=2263, `faction_H`=2263 WHERE `entry`=42367; -- Rockpool Gladiator
UPDATE `creature_template` SET `faction_A`=2231, `faction_H`=2231, `unit_flags`=32768, `unit_flags2`=33556480 WHERE `entry`=38746; -- Gobber
UPDATE `creature_template` SET `faction_A`=2231, `faction_H`=2231, `unit_flags2`=33556480 WHERE `entry`=38511; -- Sally "Salvager" Sandscrew
UPDATE `creature_template` SET `faction_A`=2231, `faction_H`=2231, `npcflag`=0, `unit_flags`=32768, `unit_flags2`=33556480 WHERE `entry`=38647; -- Izzy
UPDATE `creature_template` SET `faction_A`=2231, `faction_H`=2231, `npcflag`=0, `unit_flags`=32768, `unit_flags2`=33556480 WHERE `entry`=38441; -- Ace
UPDATE `creature_template` SET `faction_A`=2209, `faction_H`=2209, `speed_walk`=1.190476, `speed_run`=1, `baseattacktime`=1000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=37011; -- The Damned
UPDATE `creature_template` SET `faction_A`=2184, `faction_H`=2184, `speed_walk`=1.428571, `speed_run`=0.666668, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=4640; -- Magram Wrangler
UPDATE `creature_template` SET `faction_A`=2184, `faction_H`=2184, `speed_walk`=1.428571, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=4640; -- Magram Wrangler
UPDATE `creature_template` SET `faction_A`=2183, `faction_H`=2183, `speed_walk`=1.428571, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=4648; -- Gelkis Stamper
UPDATE `creature_template` SET `faction_A`=2183, `faction_H`=2183, `speed_walk`=1.428571, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=4646; -- Gelkis Outrunner
UPDATE `creature_template` SET `faction_A`=2156, `faction_H`=2156, `speed_walk`=1.142857, `speed_run`=1.111112, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=53697; -- Cinderling
UPDATE `creature_template` SET `faction_A`=2138, `faction_H`=2138, `unit_flags`=32768 WHERE `entry`=28028; -- Argent Shieldman
UPDATE `creature_template` SET `faction_A`=2132, `faction_H`=2132 WHERE `entry`=30755; -- Kor'kron Reaver
UPDATE `creature_template` SET `faction_A`=2131, `faction_H`=2131 WHERE `entry`=38493; -- Argent Crusader
UPDATE `creature_template` SET `faction_A`=2113, `faction_H`=2113, `speed_walk`=1.714286, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=537133824, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=29585; -- Dead Warbear
UPDATE `creature_template` SET `faction_A`=2102, `faction_H`=2102, `speed_walk`=1.190476, `speed_run`=1, `baseattacktime`=1000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=37011; -- The Damned
UPDATE `creature_template` SET `faction_A`=2102, `faction_H`=2102, `npcflag`=0, `speed_walk`=1.142857 WHERE `entry`=35200; -- Pirate Party Crasher
UPDATE `creature_template` SET `faction_A`=21, `faction_H`=21, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=4 WHERE `entry`=31283; -- Orbaz Bloodbane
UPDATE `creature_template` SET `faction_A`=21, `faction_H`=21, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=31283; -- Orbaz Bloodbane
UPDATE `creature_template` SET `faction_A`=2096, `faction_H`=2096, `npcflag`=0, `speed_walk`=1.714286, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0, `VehicleId`=123 WHERE `entry`=28605; -- Havenshire Stallion
UPDATE `creature_template` SET `faction_A`=2093, `faction_H`=2093, `speed_walk`=0.9920629, `speed_run`=0.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28405; -- Acherus Ghoul
UPDATE `creature_template` SET `faction_A`=2083, `faction_H`=2083 WHERE `entry`=29208; -- Fester
UPDATE `creature_template` SET `faction_A`=2083, `faction_H`=2083 WHERE `entry`=29207; -- Gangrenus
UPDATE `creature_template` SET `faction_A`=2083, `faction_H`=2083 WHERE `entry`=29205; -- Corpulous
UPDATE `creature_template` SET `faction_A`=2083, `faction_H`=2083 WHERE `entry`=29203; -- Alchemist Karloff
UPDATE `creature_template` SET `faction_A`=2082, `faction_H`=2082, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28471; -- Lady Alistra
UPDATE `creature_template` SET `faction_A`=2082, `faction_H`=2082 WHERE `entry`=28512; -- Quartermaster Ozorg
UPDATE `creature_template` SET `faction_A`=2082, `faction_H`=2082 WHERE `entry`=28500; -- Master Siegesmith Corvus
UPDATE `creature_template` SET `faction_A`=2082, `faction_H`=2082 WHERE `entry`=28488; -- Coldwraith
UPDATE `creature_template` SET `faction_A`=2050, `faction_H`=2050 WHERE `entry`=29195; -- Lady Alistra
UPDATE `creature_template` SET `faction_A`=2028, `faction_H`=2028, `dynamicflags`=0 WHERE `entry`=34707; -- Theramore Deck Hand
UPDATE `creature_template` SET `faction_A`=2024, `faction_H`=2024 WHERE `entry`=23776; -- Dark Ranger
UPDATE `creature_template` SET `faction_A`=1993, `faction_H`=1993, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26236; -- Private Jansen
UPDATE `creature_template` SET `faction_A`=1974, `faction_H`=1974, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26170; -- Thassarian
UPDATE `creature_template` SET `faction_A`=1974, `faction_H`=1974, `npcflag`=0, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26170; -- Thassarian
UPDATE `creature_template` SET `faction_A`=1973, `faction_H`=1973 WHERE `entry`=25253; -- Valiance Keep Footman
UPDATE `creature_template` SET `faction_A`=1965, `faction_H`=1965, `speed_walk`=1.142857, `speed_run`=0.666668, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26943; -- Battered Drakkari Berserker
UPDATE `creature_template` SET `faction_A`=1959, `faction_H`=1959, `speed_walk`=1.714286, `speed_run`=2, `rangeattacktime`=2000, `unit_flags`=2147778624, `dynamicflags`=12 WHERE `entry`=24892; -- Sathrovarr the Corruptor
UPDATE `creature_template` SET `faction_A`=1956, `faction_H`=1956, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=24937; -- Magistrix Seyla
UPDATE `creature_template` SET `faction_A`=190, `faction_H`=190, `unit_flags`=570687488, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=46713; -- Stonevault Wanderer
UPDATE `creature_template` SET `faction_A`=190, `faction_H`=190, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21963; -- Enslaved Doomguard
UPDATE `creature_template` SET `faction_A`=190, `faction_H`=190, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33555200 WHERE `entry`=39834; -- Dream Portal Bunny
UPDATE `creature_template` SET `faction_A`=190, `faction_H`=190, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33555200 WHERE `entry`=39600; -- Twilight Proveditor Spawn Controller Bunny 02
UPDATE `creature_template` SET `faction_A`=190, `faction_H`=190, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33554944 WHERE `entry`=40868; -- Twilight Anvil Effects Bunny
UPDATE `creature_template` SET `faction_A`=190, `faction_H`=190, `speed_walk`=0.8571429, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=38232; -- Blood Spider
UPDATE `creature_template` SET `faction_A`=190, `faction_H`=190, `speed_walk`=0.8571429, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=49496; -- Ash Spiderling
UPDATE `creature_template` SET `faction_A`=190, `faction_H`=190, `speed_walk`=0.7857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28169; -- Stratholme Resident
UPDATE `creature_template` SET `faction_A`=190, `faction_H`=190, `speed_walk`=0.2142857, `speed_run`=0.6, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=17408; -- Arcane Vortex
UPDATE `creature_template` SET `faction_A`=190, `faction_H`=190 WHERE `entry`=33127; -- Moonstalker
UPDATE `creature_template` SET `faction_A`=1891, `faction_H`=1891 WHERE `entry`=30352; -- Skybreaker Marine
UPDATE `creature_template` SET `faction_A`=1888, `faction_H`=1888, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=24900; -- Abdul the Insane
UPDATE `creature_template` SET `faction_A`=188, `faction_H`=188, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=50003; -- Tainted Moth
UPDATE `creature_template` SET `faction_A`=188, `faction_H`=188, `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=7386; -- White Kitten
UPDATE `creature_template` SET `faction_A`=188, `faction_H`=188, `speed_walk`=0.8571429, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=50481; -- Rock Viper
UPDATE `creature_template` SET `faction_A`=188, `faction_H`=188, `speed_walk`=0.8571429, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=49742; -- Hairy Armadillo
UPDATE `creature_template` SET `faction_A`=188, `faction_H`=188, `speed_walk`=0.8571429, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=49780; -- Fire-Proof Roach
UPDATE `creature_template` SET `faction_A`=188, `faction_H`=188, `speed_walk`=0.8571429, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=49759; -- Death's Head Cockroach
UPDATE `creature_template` SET `faction_A`=188, `faction_H`=188, `speed_walk`=0.8571429, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=49746; -- Scarab Hatchling
UPDATE `creature_template` SET `faction_A`=188, `faction_H`=188, `speed_walk`=0.5714286, `speed_run`=0.4, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=50478; -- Ash Lizard
UPDATE `creature_template` SET `faction_A`=188, `faction_H`=188, `speed_walk`=0.5714286, `speed_run`=0.4, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=49839; -- Horny Toad
UPDATE `creature_template` SET `faction_A`=1865, `faction_H`=1865, `npcflag`=4227, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23144; -- Gug
UPDATE `creature_template` SET `faction_A`=1865, `faction_H`=1865, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23291; -- Chief Overseer Mudlump
UPDATE `creature_template` SET `faction_A`=1865, `faction_H`=1865, `npcflag`=2, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23148; -- Forgus
UPDATE `creature_template` SET `faction_A`=1863, `faction_H`=1863, `npcflag`=643, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23143; -- Horus
UPDATE `creature_template` SET `faction_A`=1855, `faction_H`=1855, `speed_walk`=1.385714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33024, `dynamicflags`=0 WHERE `entry`=22967; -- Scryer Cavalier
UPDATE `creature_template` SET `faction_A`=1847, `faction_H`=1847, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31327; -- Death Knight Initiate
UPDATE `creature_template` SET `faction_A`=1847, `faction_H`=1847, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=31326; -- Death Knight Initiate
UPDATE `creature_template` SET `faction_A`=1843, `faction_H`=1843, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=22860; -- Illidari Succubus
UPDATE `creature_template` SET `faction_A`=1843, `faction_H`=1843, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=22858; -- Shadowhoof Assassin
UPDATE `creature_template` SET `faction_A`=1829, `faction_H`=1829, `speed_walk`=2.571429, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=23173; -- Felhound Defender
UPDATE `creature_template` SET `faction_A`=1829, `faction_H`=1829, `speed_walk`=2, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=23278; -- Portable Fel Cannon
UPDATE `creature_template` SET `faction_A`=1829, `faction_H`=1829, `speed_walk`=2, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=23212; -- Mo'arg Tormenter
UPDATE `creature_template` SET `faction_A`=1829, `faction_H`=1829, `speed_walk`=2, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=23078; -- Fel Imp Defender
UPDATE `creature_template` SET `faction_A`=1829, `faction_H`=1829, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=23228; -- Eye of Shartuul
UPDATE `creature_template` SET `faction_A`=1829, `faction_H`=1829, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33554688, `dynamicflags`=0 WHERE `entry`=23199; -- Gan'arg Underling
UPDATE `creature_template` SET `faction_A`=18, `faction_H`=18, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=24461; -- Chillmere Oracle
UPDATE `creature_template` SET `faction_A`=1797, `faction_H`=1797, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33555200, `dynamicflags`=0 WHERE `entry`=20889; -- Ethereum Prisoner (Group Energy Ball)
UPDATE `creature_template` SET `faction_A`=1780, `faction_H`=1780, `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=20756; -- Bladespire Chef
UPDATE `creature_template` SET `faction_A`=1780, `faction_H`=1780, `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=19997; -- Bladespire Enforcer
UPDATE `creature_template` SET `faction_A`=1780, `faction_H`=1780, `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=19996; -- Bladespire Battlemage
UPDATE `creature_template` SET `faction_A`=1780, `faction_H`=1780, `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21975; -- Bladespire Sober Defender
UPDATE `creature_template` SET `faction_A`=1780, `faction_H`=1780, `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21296; -- Bladespire Champion
UPDATE `creature_template` SET `faction_A`=1780, `faction_H`=1780, `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20334; -- Bladespire Cook
UPDATE `creature_template` SET `faction_A`=1780, `faction_H`=1780, `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19998; -- Bladespire Shaman
UPDATE `creature_template` SET `faction_A`=1780, `faction_H`=1780, `speed_walk`=1.142857, `speed_run`=1.6, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19995; -- Bladespire Brute
UPDATE `creature_template` SET `faction_A`=1780, `faction_H`=1780, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=20729; -- Bladespire Ravager
UPDATE `creature_template` SET `faction_A`=1780, `faction_H`=1780, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=20728; -- Bladespire Raptor
UPDATE `creature_template` SET `faction_A`=1770, `faction_H`=1770, `speed_walk`=2.857143, `speed_run`=2, `rangeattacktime`=2000, `unit_flags`=33600, `dynamicflags`=0 WHERE `entry`=24895; -- Madrigosa
UPDATE `creature_template` SET `faction_A`=1756, `faction_H`=1756, `unit_flags`=33536 WHERE `entry`=16842; -- Honor Hold Defender
UPDATE `creature_template` SET `faction_A`=1754, `faction_H`=1754, `unit_flags`=33280 WHERE `entry`=18944; -- Fel Soldier
UPDATE `creature_template` SET `faction_A`=1754, `faction_H`=1754 WHERE `entry`=19005; -- Wrath Master
UPDATE `creature_template` SET `faction_A`=1754, `faction_H`=1754 WHERE `entry`=18944; -- Fel Soldier
UPDATE `creature_template` SET `faction_A`=1744, `faction_H`=1744, `npcflag`=3217, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=33630; -- Aelthin
UPDATE `creature_template` SET `faction_A`=1744, `faction_H`=1744, `npcflag`=145, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=33639; -- Botanist Alaenra
UPDATE `creature_template` SET `faction_A`=1744, `faction_H`=1744, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=33642; -- Loremaster Skosiris
UPDATE `creature_template` SET `faction_A`=1743, `faction_H`=1743, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=537166592, `unit_flags2`=2049, `dynamicflags`=32 WHERE `entry`=20922; -- Fallen Vindicator
UPDATE `creature_template` SET `faction_A`=1735, `speed_walk`=0.8571429, `speed_run`=1, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=4 WHERE `entry`=28366; -- Wintergrasp Tower Cannon
UPDATE `creature_template` SET `faction_A`=1735, `faction_H`=1735, `unit_flags2`=0 WHERE `entry`=27894; -- Antipersonnel Cannon
UPDATE `creature_template` SET `faction_A`=1735, `faction_H`=1735, `speed_walk`=1.714286, `speed_run`=1.2, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=28781; -- Battleground Demolisher
UPDATE `creature_template` SET `faction_A`=1735, `faction_H`=1735, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26221; -- Earthen Ring Elder
UPDATE `creature_template` SET `faction_A`=1733, `faction_H`=1733, `speed_walk`=1.428571, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=768, `dynamicflags`=0 WHERE `entry`=37879; -- King Varian Wrynn
UPDATE `creature_template` SET `faction_A`=1732, `faction_H`=1732, `speed_walk`=1.714286, `speed_run`=1.2, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=28781; -- Battleground Demolisher
UPDATE `creature_template` SET `faction_A`=1732, `faction_H`=1732, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26221; -- Earthen Ring Elder
UPDATE `creature_template` SET `faction_A`=1732, `faction_H`=1732, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=38840; -- Jedebia
UPDATE `creature_template` SET `faction_A`=1732, `faction_H`=1732, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=38283; -- Malfus Grimfrost
UPDATE `creature_template` SET `faction_A`=1732, `faction_H`=1732, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=38182; -- Niby the Almighty
UPDATE `creature_template` SET `faction_A`=1732, `faction_H`=1732, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=37999; -- Alana Moonstrike
UPDATE `creature_template` SET `faction_A`=1732, `faction_H`=1732, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=37998; -- Talan Moonstrike
UPDATE `creature_template` SET `faction_A`=1732, `faction_H`=1732, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536, `dynamicflags`=0 WHERE `entry`=37997; -- Yili
UPDATE `creature_template` SET `faction_A`=1729, `faction_H`=1729, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=30735; -- Kul Inkspiller
UPDATE `creature_template` SET `faction_A`=1727, `faction_H`=1727, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26221; -- Earthen Ring Elder
UPDATE `creature_template` SET `faction_A`=1679, `faction_H`=1679, `speed_walk`=1.714286, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=18399; -- Murkblood Twin
UPDATE `creature_template` SET `faction_A`=1671, `faction_H`=1671, `unit_flags`=64 WHERE `entry`=16831; -- Nethergarde Infantry
UPDATE `creature_template` SET `faction_A`=1668, `faction_H`=1668, `unit_flags`=0 WHERE `entry`=16582; -- Thrallmar Marksman
UPDATE `creature_template` SET `faction_A`=1665, `faction_H`=1665, `npcflag`=16777216, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=4, `unit_flags`=16384, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=36838; -- Alliance Gunship Cannon
UPDATE `creature_template` SET `faction_A`=1621, `faction_H`=1621, `dynamicflags`=0 WHERE `entry`=4922; -- Guard Edward
UPDATE `creature_template` SET `faction_A`=1619, `faction_H`=1619, `unit_flags2`=33556480 WHERE `entry`=39591; -- Orc Battlesworn
UPDATE `creature_template` SET `faction_A`=1604, `faction_H`=1604, `npcflag`=3, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=16480; -- Apprentice Vor'el
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=3.857143, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23132; -- Brood of Anzu
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=2.857143, `speed_run`=0.888888, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=12 WHERE `entry`=25486; -- Shadowsword Vanquisher
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=2.857143, `speed_run`=0.888888, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=25373; -- Shadowsword Soulbinder
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=2.714286, `speed_run`=3.2, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=25484; -- Shadowsword Assassin
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=2.714286, `speed_run`=0.888888, `rangeattacktime`=2000, `unit_flags`=32832, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=25483; -- Shadowsword Manafiend
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=2.714286, `speed_run`=0.888888, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=25506; -- Shadowsword Lifeshaper
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=2, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=18402; -- Warmaul Champion
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=1.714286, `speed_run`=2, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=25166; -- Grand Warlock Alythess
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=1.714286, `speed_run`=2, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=25165; -- Lady Sacrolash
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=1.714286, `speed_run`=2, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26232; -- Saragosa
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=1.714286, `speed_run`=2, `baseattacktime`=3000, `rangeattacktime`=2000, `unit_flags`=33587264, `dynamicflags`=0 WHERE `entry`=25315; -- Kil'jaeden
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=1.714286, `speed_run`=1.6, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=25588; -- Hand of the Deceiver
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=1.428571, `speed_run`=2.4, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=15802; -- Flesh Tentacle
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=1.428571, `speed_run`=0.888888, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=25837; -- Shadowsword Commander
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=1.285714, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=512, `dynamicflags`=0 WHERE `entry`=30043; -- Fiend of Earth
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23154; -- Mana-debt Slave
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `unit_flags`=32768, `dynamicflags`=0 WHERE `entry`=23153; -- Bash'ir Surveyor
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_walk`=1.142857, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=64, `dynamicflags`=0 WHERE `entry`=18400; -- Rokdar the Sundered Lord
UPDATE `creature_template` SET `faction_A`=16, `faction_H`=16, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=25741; -- M'uru
UPDATE `creature_template` SET `faction_A`=1555, `faction_H`=1555, `unit_flags`=768 WHERE `entry`=29548; -- Aimee
UPDATE `creature_template` SET `faction_A`=1555, `faction_H`=1555, `unit_flags`=33536 WHERE `entry`=55261; -- Darkmoon Parade Creature
UPDATE `creature_template` SET `faction_A`=14, `faction_H`=14, `unit_flags`=570687744, `unit_flags2`=1, `dynamicflags`=32 WHERE `entry`=47204; -- Infested Bear
UPDATE `creature_template` SET `faction_A`=14, `faction_H`=14, `speed_walk`=1.428571, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `dynamicflags`=0 WHERE `entry`=23035; -- Anzu
UPDATE `creature_template` SET `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23246; -- Slavering Slave
UPDATE `creature_template` SET `faction_A`=14, `faction_H`=14, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=14621; -- Overseer Maltorius
UPDATE `creature_template` SET `faction_A`=14, `faction_H`=14, `speed_walk`=0.5714286, `speed_run`=1.6, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=25502; -- Shield Orb
UPDATE `creature_template` SET `faction_A`=14, `faction_H`=14, `dynamicflags`=4 WHERE `entry`=46042; -- Colossus of the Moon
UPDATE `creature_template` SET `faction_A`=126, `faction_H`=126, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19177; -- Troll Commoner
UPDATE `creature_template` SET `faction_A`=126, `faction_H`=126, `npcflag`=1, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=19177; -- Troll Commoner
UPDATE `creature_template` SET `faction_A`=114, `faction_H`=114, `speed_walk`=1.142857, `speed_run`=1, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18264; -- Nagrand Spawn Timer
UPDATE `creature_template` SET `faction_A`=113, `faction_H`=113, `npcflag`=0, `dynamicflags`=0 WHERE `entry`=4880; -- "Stinky" Ignatz
UPDATE `creature_template` SET `faction_A`=1074, `faction_H`=1074, `unit_flags`=33536, `unit_flags2`=33556480 WHERE `entry`=39147; -- Bastia
UPDATE `creature_template` SET `faction_A`=1074, `faction_H`=1074, `unit_flags`=33280, `unit_flags2`=33556480 WHERE `entry`=39066; -- Kilag Gorefang
UPDATE `creature_template` SET `faction_A`=1074, `faction_H`=1074, `unit_flags2`=33556480 WHERE `entry`=39065; -- Aggra
UPDATE `creature_template` SET `faction_A`=1074, `faction_H`=1074, `npcflag`=1, `unit_flags`=33280, `unit_flags2`=33556480 WHERE `entry`=39066; -- Kilag Gorefang
UPDATE `creature_template` SET `faction_A`=1074, `faction_H`=1074, `npcflag`=1, `unit_flags2`=33556480 WHERE `entry`=39065; -- Aggra
UPDATE `creature_template` SET `faction_A`=103, `faction_H`=103, `speed_walk`=3.571429, `speed_run`=4.8, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=26127; -- Nexus Drake Hatchling
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=98; -- Riverpaw Taskmaster
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=941; -- Kurzen Headshrinker
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=9043; -- Scarshield Grunt
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=898; -- Nightbane Worgen
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=890; -- Fawn
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=883; -- Deer
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=7453; -- Moontouched Owlbeast
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=730; -- Tethis
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=721; -- Rabbit
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=7049; -- Flamescale Broodling
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=7025; -- Blackrock Soldier
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=5990; -- Redstone Basilisk
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=525; -- Mangy Wolf
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=522; -- Mor'Ladim
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=5139; -- Kurdrum Barleybeard
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=50312; -- Mana-Compelled Shade
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=49540; -- Stormwind Rat
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=47782; -- Blackrock Whelper
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=47663; -- Scout Obrok
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=474; -- Defias Rogue Wizard
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=47226; -- Obsidian Stoneslave
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=471; -- Mother Fang
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=46322; -- Shaman of the Black
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=45681; -- Garginox
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=45321; -- Riverbed Crocolisk
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=4465; -- Vilebranch Warrior
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=44338; -- White Chicken
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=43992; -- Twilight Dragonstalker
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=4397; -- Mudrock Spikeshell
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=43910; -- Chief Anders
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=43350; -- Utroka the Keymistress
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=43158; -- Mercurial Ooze
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=4257; -- Lana Thunderbrew
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=42359; -- Okril'lon Infantry
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=40987; -- Gnash
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=4075; -- Rat
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=40728; -- Whale Shark
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=39022; -- Tidal Strider
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=38810; -- Teloch
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=38809; -- Malmo
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=3820; -- Wildthorn Venomspitter
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=37659; -- Horde Field Defender
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=35113; -- Doctor Kohler
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=34592; -- Silverwind Conqueror
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=33687; -- Chillmaw
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=3300; -- Adder
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=32860; -- Shatterspear Shaman
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=3284; -- Venture Co. Drudger
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=299; -- Diseased Young Wolf
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=2914; -- Snake
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=28243; -- Thrym
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=2640; -- Vilebranch Witch Doctor
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=24819; -- Anvilrage Enforcer
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=2442; -- Cow
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=212; -- Splinter Fist Warrior
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=1564; -- Bloodsail Warlock
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=1561; -- Bloodsail Raider
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=1424; -- Master Digger
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=1412; -- Squirrel
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=1251; -- Splinter Fist Firemonger
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=12127; -- Stormpike Guardsman
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=1197; -- Stonesplinter Shaman
UPDATE `creature_template` SET `dynamicflags`=4 WHERE `entry`=113; -- Stonetusk Boar
UPDATE `creature_template` SET `dynamicflags`=140 WHERE `entry`=33229; -- Melee Target
UPDATE `creature_template` SET `dynamicflags`=12 WHERE `entry`=51867; -- Silverwind Vanquisher
UPDATE `creature_template` SET `dynamicflags`=12 WHERE `entry`=4953; -- Moccasin
UPDATE `creature_template` SET `dynamicflags`=12 WHERE `entry`=12053; -- Frostwolf Guardian
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9990; -- Lanti'gah
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9989; -- Lina Hearthstove
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9988; -- Xon'cha
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9987; -- Shoja'my
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9984; -- Ulbrek Firehand
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9983; -- Kelsuwa
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9981; -- Sikwa
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9980; -- Shelby Stoneflint
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=98; -- Riverpaw Taskmaster
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=989; -- Banalash
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9859; -- Auctioneer Lympkin
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=984; -- Thralosh
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=983; -- Thultazor
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=982; -- Thultash
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=981; -- Hartash
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=980; -- Grimnal
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9779; -- Flamekin Rager
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9778; -- Flamekin Torcher
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9776; -- Flamekin Spitter
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9700; -- Lava Crab
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9699; -- Fire Beetle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9697; -- Giant Ember Worg
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9691; -- Venomtip Scorpid
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9690; -- Ember Worg
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9660; -- Agnar Beastamer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9616; -- Laris Geardawdle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9563; -- Ragged John
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9562; -- Helendis Riverhorn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9558; -- Grimble
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9552; -- Zanara
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9540; -- Enohar Thunderbrew
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9523; -- Kolkar Stormseer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9317; -- Rilli Greasygob
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=930; -- Black Widow Hatchling
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=928; -- Lord Grayson Shadowbreaker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=922; -- Silt Crawler
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9177; -- Oralius
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9099; -- Sraaz
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9046; -- Scarshield Quartermaster
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=9044; -- Scarshield Sentry
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8924; -- The Behemoth
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8917; -- Quarry Slave
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8879; -- Royal Historian Archesonus
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8738; -- Vazario Linkgrease
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8720; -- Auctioneer Redmuse
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8681; -- Outfitter Eric
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8671; -- Auctioneer Buckler
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=866; -- Stonard Grunt
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8665; -- Shylenai
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8659; -- Jes'rimon
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=864; -- Stonard Orc
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8609; -- Alexandra Constantine
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=858; -- Sorrow Spinner
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8517; -- Xiggs Fuselighter
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8508; -- Gretta Ganter
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8507; -- Tymor
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8496; -- Liv Rizzlefix
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8396; -- Sentinel Dalia Sunblade
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8256; -- Curator Thorius
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8178; -- Nina Lightbrew
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8177; -- Rartar
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8176; -- Gharash
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8119; -- Zikkel
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8026; -- Thyn'tel Bladeweaver
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=8022; -- Thadius Grimshade
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7999; -- Tyrande Whisperwind
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7978; -- Bimble Longberry
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7976; -- Thalgus Thunderfist
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7955; -- Milli Featherwhistle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7954; -- Binjy Featherwhistle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7951; -- Zas'Tysh
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7950; -- Master Mechanic Castpipe
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7944; -- Tinkmaster Overspark
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7936; -- Lyon Mountainheart
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7793; -- Ox
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7792; -- Aturk the Anvil
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7790; -- Orokk Omosh
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7744; -- Innkeeper Thulfram
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7714; -- Innkeeper Byula
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7623; -- Dispatch Commander Ruag
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=761; -- Lost One Seer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=760; -- Lost One Muckdweller
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=759; -- Lost One Hunter
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7572; -- Fallen Hero of the Horde
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7555; -- Hawk Owl
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7553; -- Great Horned Owl
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7524; -- Anguished Highborne
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7523; -- Suffering Highborne
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7506; -- Bloodmage Lynnore
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7505; -- Bloodmage Drazial
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7454; -- Berserk Owlbeast
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7452; -- Crazed Owlbeast
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7446; -- Rabid Shardtooth
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7433; -- Frostsaber Huntress
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7430; -- Frostsaber Cub
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7429; -- Frostmaul Preserver
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7379; -- Deadwind Ogre Mage
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7376; -- Sky Shadow
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7372; -- Deadwind Warlock
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7370; -- Restless Shade
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7369; -- Deadwind Brute
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7363; -- Kum'isha the Collector
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7312; -- Dink
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7298; -- Demnul Farmountain
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7296; -- Corand
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7292; -- Dinita Stonemantle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7166; -- Wrenix's Gizmotronic Apparatus
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7161; -- Wrenix the Wretched
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7055; -- Blackrock Worg
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7049; -- Flamescale Broodling
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7041; -- Black Wyrmkin
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7040; -- Black Dragonspawn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7039; -- War Reaver
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7038; -- Thaurissan Agent
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7037; -- Thaurissan Firewalker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7036; -- Thaurissan Spy
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7035; -- Firegut Brute
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7032; -- Greater Obsidian Elemental
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7031; -- Obsidian Elemental
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7028; -- Blackrock Warlock
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7027; -- Blackrock Slayer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7026; -- Blackrock Sorcerer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7025; -- Blackrock Soldier
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=7010; -- Zilzibin Drumlore
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6987; -- Malton Droffers
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6986; -- Dran Droffers
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6930; -- Innkeeper Karakul
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6929; -- Innkeeper Gryshka
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6928; -- Innkeeper Grosk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6826; -- Talvash del Kissel
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6806; -- Tannok Frosthammer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6791; -- Innkeeper Wiley
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6787; -- Yelnagi Blackarm
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6736; -- Innkeeper Keldamyr
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6735; -- Innkeeper Saelienne
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6734; -- Innkeeper Hearthstove
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6732; -- Amie Pierce
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6670; -- Westfall Woodworker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6569; -- Gnoarn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6567; -- Ghok'kah
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6466; -- Gamon
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6382; -- Jubahl Corpseseeker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6328; -- Dannie Fizzwizzle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6294; -- Krom Stoutarm
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6286; -- Zarrin
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6272; -- Innkeeper Janene
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6266; -- Menara Voidrender
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6254; -- Acolyte Wytula
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6253; -- Acolyte Fenrick
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6252; -- Acolyte Magaz
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6247; -- Doan Karhan
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6244; -- Takar the Seer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6181; -- Jordan Stilwell
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6179; -- Tiza Battleforge
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6178; -- Muiredon Battleforge
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6175; -- John Turner
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6142; -- Mathiel
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6120; -- Lago Blackwrench
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6119; -- Tog Rustsprocket
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6114; -- Muren Stormpike
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6034; -- Lotherias
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6031; -- Tormus Deepforge
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6027; -- Kitha
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6026; -- Breyk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6020; -- Slimeshell Makrura
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6009; -- Shadowsworn Dreadweaver
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6008; -- Shadowsworn Warlock
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6007; -- Shadowsworn Enforcer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6005; -- Shadowsworn Thug
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=6004; -- Shadowsworn Cultist
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5998; -- Nethergarde Foreman
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5997; -- Nethergarde Engineer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5996; -- Nethergarde Miner
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5992; -- Ashmane Boar
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5990; -- Redstone Basilisk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5985; -- Snickerfang Hyena
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5978; -- Dreadmaul Warlock
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5977; -- Dreadmaul Mauler
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5976; -- Dreadmaul Brute
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5975; -- Dreadmaul Ogre Mage
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5974; -- Dreadmaul Ogre
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5953; -- Razor Hill Grunt
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5943; -- Rawrk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5910; -- Zankaja
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5909; -- Cazul
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5892; -- Searn Firewarder
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5875; -- Gan'rul Bloodeye
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5871; -- Larhka
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5865; -- Dishu
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5863; -- Geopriest Gukk'rok
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5858; -- Greater Lava Spider
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5842; -- Takk the Leaper
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5834; -- Azzere the Skyblade
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5826; -- Geolord Mottle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5823; -- Death Flayer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5822; -- Felweaver Scornn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5817; -- Shimra
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5816; -- Katis
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5815; -- Kurgul
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5812; -- Tumi
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5811; -- Kamari
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5640; -- Keldran
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5639; -- Craven Drok
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5637; -- Roetten Stonehammer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5614; -- Sarok
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5613; -- Doyo'da
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5612; -- Gimrizz Shadowcog
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5611; -- Barkeep Morag
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5610; -- Kozish
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5609; -- Zazo
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5606; -- Goma
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5603; -- Grunt Mojka
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5597; -- Grunt Komak
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5595; -- Ironforge Guard
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5591; -- Dar
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5570; -- Bruuk Barleybeard
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5569; -- Fizzlebang Booms
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5568; -- Captured Leper Gnome
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5547; -- Grunt Tharlak
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5525; -- Caravan Packhorse
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5508; -- Strumner Flintheel
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5498; -- Elsharin
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5497; -- Jennea Cannon
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5492; -- Katherine the Pure
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5491; -- Arthur the Faithful
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5416; -- Infiltrator Marksen
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5393; -- Quartermaster Lungertz
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5392; -- Yarr Hammerstone
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5388; -- Ingo Woolybush
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5387; -- High Explorer Magellas
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5385; -- Watcher Mahar Ba
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5261; -- Enthralled Atal'ai
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5225; -- Murk Spitter
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5202; -- Archery Target
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5200; -- Medic Helaina
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5199; -- Medic Tamberlyn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5198; -- Arctic Riding Wolf
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5195; -- Brown Riding Wolf
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=51924; -- Theramore Guard
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5191; -- Shalumon
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5188; -- Garyl
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5178; -- Soolie Berryfizz
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5175; -- Gearcutter Cogspinner
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5174; -- Springspindle Fizzlegear
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5170; -- Hjoldir Stoneblade
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5169; -- Tynnus Venomsprout
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5163; -- Burbik Gearspanner
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5162; -- Tansy Puddlefizz
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5161; -- Grimnur Stonebrand
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5160; -- Emrul Riknussun
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=515; -- Murloc Raider
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5159; -- Daryl Riknussun
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5158; -- Tilli Thistlefuzz
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5157; -- Gimble Thistlefuzz
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5156; -- Maeva Snowbraid
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5155; -- Ingrys Stonebrow
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5154; -- Poranna Snowbraid
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5153; -- Jormund Stonebrow
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5152; -- Bingus
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5151; -- Ginny Longberry
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5150; -- Nissa Firestone
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5149; -- Brandur Ironhammer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5148; -- Beldruk Doombrow
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5147; -- Valgar Highforge
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5146; -- Nittlebur Sparkfizzle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5145; -- Juli Stormkettle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5144; -- Bink
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5140; -- Edris Barleybeard
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5138; -- Gwina Stonebranch
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5133; -- Harick Boulderdrum
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5132; -- Pithwick
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5130; -- Jondor Steelbrow
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5129; -- Lissyphus Finespindle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5128; -- Bombus Finespindle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5126; -- Olthran Craghelm
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5125; -- Dolkin Craghelm
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5124; -- Sognar Cliffbeard
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5123; -- Bretta Goldfury
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5122; -- Skolmin Goldfury
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5121; -- Kelomir Ironhand
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5120; -- Brenwyn Wintersteel
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5119; -- Hegnar Swiftaxe
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5112; -- Gwenna Firebrew
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5111; -- Innkeeper Firebrew
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5110; -- Barim Jurgenstaad
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5109; -- Myra Tyrngaarde
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5108; -- Raena Flinthammer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5107; -- Mangorn Flinthammer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5106; -- Bromiir Ormsen
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5103; -- Grenil Steelfury
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5102; -- Dolman Steelfury
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5101; -- Bryllia Ironbrand
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5100; -- Fillius Fizzlespinner
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5099; -- Soleil Stonemantle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5096; -- Captain Thomas
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5095; -- Captain Andrews
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5094; -- Guard Tark
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5093; -- Guard Narrisha
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5092; -- Guard Lana
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5090; -- Combat Master Szigeti
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5087; -- Do'gol
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5086; -- Captain Wymor
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5085; -- Sentry Point Guard
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5083; -- Clerk Lendry
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=506; -- Sergeant Brashclaw
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5049; -- Lyesa Steelbrow
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=5047; -- Ellaercia
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=50321; -- Xorothian Imp
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=501; -- Riverpaw Herbalist
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4983; -- Ogron
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4979; -- Theramore Guard
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4968; -- Lady Jaina Proudmoore
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4967; -- Archmage Tervosh
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4966; -- Private Hendel
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4965; -- Pained
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4964; -- Commander Samaul
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4952; -- Theramore Combat Dummy
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4951; -- Theramore Practicing Guard
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4950; -- Spot
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4948; -- Adjutant Tesoran
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4944; -- Captain Garran Vimes
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4941; -- Caz Twosprocket
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=49347; -- Coldlurk Burrower
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=49346; -- Coldlurk Creeper
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4926; -- Krog
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4924; -- Combat Master Criton
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4923; -- Guard Jarad
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4922; -- Guard Edward
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4921; -- Guard Byron
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4902; -- Mikal Pierce
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4901; -- Sara Pierce
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4899; -- Uma Bartulm
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4897; -- Helenia Olden
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4896; -- Charity Mipsy
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4895; -- Smiling Jim
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4894; -- Craig Nollward
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4893; -- Bartender Lillian
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4891; -- Dwane Wertle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4890; -- Piter Verance
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4889; -- Torq Ironblast
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4886; -- Hans Weston
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4885; -- Gregor MacVince
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4884; -- Zulrg
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4883; -- Krak
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4880; -- "Stinky" Ignatz
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4879; -- Ogg'marr
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=48629; -- Schnottz Infantryman
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4794; -- Morgan Stern
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4792; -- "Swamp Eye" Jarl
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4791; -- Nazeer Bloodpike
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4786; -- Dawnwatcher Shaedlass
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4784; -- Argent Guard Manados
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4783; -- Dawnwatcher Selgorm
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4782; -- Truk Wildbeard
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4772; -- Ultham Ironhorn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4752; -- Kildar
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=45755; -- Scion of Al'Akir
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=456; -- Murloc Minor Oracle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=453; -- Riverpaw Mystic
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=452; -- Riverpaw Bandit
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4521; -- Treshala Fallowbrook
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4503; -- Mudcrush Durtfeet
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4502; -- Tharg
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4501; -- Draz'Zilb
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4500; -- Overlord Mok'Morokk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=44967; -- Maziel
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=44936; -- Murkstone Trogg
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4485; -- Belgrom Rockmaul
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4423; -- Darnassian Protector
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=44183; -- Durango
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4415; -- Giant Darkfang Spider
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4414; -- Darkfang Venomspitter
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4412; -- Darkfang Creeper
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4404; -- Muckshell Scrabbler
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4403; -- Muckshell Pincer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4401; -- Muckshell Clacker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4397; -- Mudrock Spikeshell
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4394; -- Bubbling Swamp Ooze
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4393; -- Acidic Swamp Ooze
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4389; -- Murk Thresher
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4388; -- Young Murk Thresher
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4363; -- Mirefin Oracle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4362; -- Mirefin Coastrunner
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4361; -- Mirefin Muckdweller
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4359; -- Mirefin Murloc
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4352; -- Bloodfen Screecher
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4351; -- Bloodfen Raptor
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4347; -- Noxious Reaver
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4346; -- Noxious Flayer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4345; -- Drywallow Daggermaw
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4343; -- Drywallow Snapper
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4341; -- Drywallow Crocolisk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4334; -- Firemane Flamecaller
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4328; -- Firemane Scalebane
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4323; -- Searing Hatchling
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4321; -- Baldruc
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4316; -- Kolkar Packhound
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4311; -- Holgar Stormaxe
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=43106; -- Redridge Fox Kit
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=42879; -- Spawn of Shadra
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=42877; -- Morta'gya the Keeper
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=42814; -- Skeezy Whillzap
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=426; -- Redridge Brute
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4265; -- Nyoma
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4262; -- Darnassus Sentinel
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4259; -- Thurgrum Deepforge
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4256; -- Golnir Bouldertoe
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4254; -- Geofram Bouldertoe
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4242; -- Frostsaber Companion
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4241; -- Mydrannul
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4240; -- Caynrus
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4233; -- Mythidan
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4232; -- Glorandiir
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4231; -- Kieran
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4230; -- Yldan
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4229; -- Mythrin'dir
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4228; -- Vaean
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4226; -- Ulthir
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4225; -- Saenorion
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4223; -- Fyldan
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4222; -- Voloren
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=42228; -- Okril'lon Scout
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4221; -- Talaelar
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4220; -- Cyroen
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4216; -- Chardryn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4213; -- Taladan
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4211; -- Dannelor
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4210; -- Alegorn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4209; -- Garryeth
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4208; -- Lairn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4203; -- Ariyell Skyshadow
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4181; -- Fyrenna
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4180; -- Ealyshia Dewwhisper
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4177; -- Melea
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4175; -- Vinasia
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4173; -- Landria
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4171; -- Merelyssa
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4170; -- Ellandrieth
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4169; -- Jaeana
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4168; -- Elynna
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4167; -- Dendrythis
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4161; -- Lysheana
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4159; -- Me'lynn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4156; -- Astaia
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4155; -- Idriana
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=41423; -- Bloodwash Acolyte
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=41387; -- Bloodwash Enchantress
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4127; -- Hecklefang Hyena
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=41165; -- Shahandana
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4088; -- Elanaria
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4081; -- Lomac Gearstrip
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4049; -- Seereth Stonebreak
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4047; -- Zor Lonetree
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=4043; -- Galthuk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3979; -- Librarian Mae Paledust
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3948; -- Honni Goldenoat
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3934; -- Innkeeper Boorand Plainswind
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3881; -- Grimtak
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3842; -- Brombar Higgleby
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3835; -- Biletoad
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3771; -- Bleakheart Hellcaller
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3767; -- Bleakheart Trickster
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3708; -- Gruna
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=37072; -- Rogg
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3705; -- Gahroot
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3681; -- Wisp
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3672; -- Boahn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3665; -- Crane Operator Bigglefuzz
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3659; -- Jorb
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3658; -- Lizzarik
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3655; -- Mad Magglish
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3641; -- Deviate Lurker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3638; -- Devouring Ectoplasm
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3634; -- Deviate Stalker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3633; -- Deviate Slayer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3632; -- Deviate Creeper
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3631; -- Deviate Stinglash
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3630; -- Deviate Coiler
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3622; -- Grokor
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3620; -- Harruk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3615; -- Devrak
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3613; -- Meri Ironweave
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3612; -- Sinda
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3611; -- Brannol Eaglemoon
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3610; -- Jeena Featherbow
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3609; -- Shalomon
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3572; -- Zizzek
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=356; -- Black Wolf
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3562; -- Alaindia
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3546; -- Bernie Heisten
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=35364; -- Slahtz
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3517; -- Rellian Greenspyre
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=35168; -- Striped Dawnsaber
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3515; -- Corithras Moonrage
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=35073; -- Farseer Eannu
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=35068; -- Gotura Fourwinds
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3501; -- Horde Guard
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=35007; -- Lixa Felflinger
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3499; -- Ranik
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=34991; -- Borim Goldhammer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3498; -- Jazzik
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3497; -- Kilxx
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3496; -- Fuzruckle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3495; -- Gagsprocket
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3494; -- Tinkerwiz
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3493; -- Grazlix
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3492; -- Vexspindle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3491; -- Ironzar
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3490; -- Hula'mahi
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3489; -- Zargh
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3488; -- Uthrok
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3487; -- Kalyimah Stormcloud
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3486; -- Halija Whitestrider
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3485; -- Wrahk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3483; -- Jahan Hawkwing
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3482; -- Tari'qa
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3481; -- Barg
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3480; -- Moorane Hearthgrain
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3479; -- Nargal Deatheye
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3477; -- Hraq
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=34765; -- Zelli Hotnozzle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=34723; -- Watcher Tolwe
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=34721; -- Chief Officer Ograh
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=34719; -- Crewman Grit
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3465; -- Gilthares Firebough
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3464; -- Gazrog
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3461; -- Oasis Snapjaw
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3453; -- Wharfmaster Dizzywig
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3449; -- Darsok Swiftdagger
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3448; -- Tonga Runetotem
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3446; -- Mebok Mizzyrix
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3442; -- Sputtervalve
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3438; -- Kreenig Snarlsnout
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3433; -- Tatternack Steelforge
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3431; -- Grenthar
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3429; -- Thork
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3428; -- Korran
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=34281; -- [DND]Azeroth Children's Week Trigger
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3426; -- Zhevra Charger
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3425; -- Savannah Prowler
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3416; -- Savannah Matriarch
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3415; -- Savannah Huntress
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3413; -- Sovik
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3412; -- Nogg
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3409; -- Zendo'jian
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3405; -- Zeal'aya
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3398; -- Gesharahan
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3397; -- Kolkar Bloodcharger
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3394; -- Barak Kodobane
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3391; -- Gazlowe
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3390; -- Apothecary Helbrim
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3389; -- Regthar Deathgate
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3384; -- Southsea Privateer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3372; -- Sarlek
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3371; -- Tamaro
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3370; -- Urtrun Clanbringer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3369; -- Gotri
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3368; -- Borstan
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3367; -- Felika
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3366; -- Tamar
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3364; -- Borya
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3362; -- Ogunaro Wolfrunner
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3361; -- Shoma
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3360; -- Koru
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3359; -- Kiro
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3358; -- Gorina
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3357; -- Makaru
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3356; -- Sumi
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3351; -- Magenius
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3350; -- Asoran
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3346; -- Kithas
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3342; -- Shan'ti
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3339; -- Captain Thalo'thas Brightsun
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3336; -- Takrin Pathseeker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3335; -- Hagrus
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3334; -- Rekkul
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3333; -- Shankys
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3332; -- Lumak
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3331; -- Kareth
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3330; -- Muragus
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3329; -- Kor'jus
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=33272; -- Charge Target
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3323; -- Horthus
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3322; -- Kaja
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=33229; -- Melee Target
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3321; -- Morgum
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3319; -- Sana
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3317; -- Ollanus
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3316; -- Handor
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3315; -- Tor'phan
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3314; -- Urtharo
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3313; -- Trak'gen
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3312; -- Olvia
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3310; -- Doras
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3306; -- Keldas
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=33068; -- Darkmoon Faire - Cannon Target Bunny
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3298; -- Gabrielle Chase
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3294; -- Ophek
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3292; -- Brewmaster Drohn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3291; -- Greishan Ironstove
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3286; -- Venture Co. Overseer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3283; -- Venture Co. Enforcer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3275; -- Kolkar Marauder
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3274; -- Kolkar Pack Runner
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3273; -- Kolkar Stormer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3269; -- Razormane Geomancer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3268; -- Razormane Thornweaver
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3267; -- Razormane Water Seeker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3266; -- Razormane Defender
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=32667; -- Master's Training Dummy
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3265; -- Razormane Hunter
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=32642; -- Mojodishu
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=32641; -- Drix Blackwrench
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3261; -- Bristleback Thornweaver
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3255; -- Sunscale Screecher
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3254; -- Sunscale Lashtail
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3248; -- Barrens Giraffe
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3246; -- Fleeting Plainstrider
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3244; -- Greater Plainstrider
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3243; -- Savannah Highmane
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3242; -- Zhevra Runner
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3240; -- Stormsnout
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3234; -- Lost Barrens Kodo
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3216; -- Neeru Fireblade
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3204; -- Gazz'uz
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3198; -- Burning Blade Apprentice
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3197; -- Burning Blade Fanatic
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3196; -- Burning Blade Neophyte
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3191; -- Cook Torka
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3189; -- Kor'ghan
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3183; -- Yarrog Baneshadow
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3177; -- Turuk Amberstill
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3175; -- Krunn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3174; -- Dwukk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=31727; -- Grunt Grikee
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=31726; -- Grunt Gritch
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=31725; -- Sky-Captain LaFontaine
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=31724; -- Crewman Paltertop
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=31723; -- Crewman Barrowswizzle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=31720; -- Crewman Shubbscoop
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3169; -- Tarshaw Jaggedscar
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3168; -- Flakk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3167; -- Wuark
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3166; -- Cutac
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3165; -- Ghrawt
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3164; -- Jark
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3163; -- Uhgar
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3162; -- Burdrak Harglhelm
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3144; -- Eitrigg
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3142; -- Orgnil Soulscar
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3139; -- Gar'Thok
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3127; -- Venomtail Scorpid
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3126; -- Armored Scorpid
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3125; -- Clattering Scorpid
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3124; -- Scorpid Worker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3123; -- Bloodtalon Scythemaw
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3122; -- Bloodtalon Taillasher
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3115; -- Dustwind Harpy
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3112; -- Razormane Scout
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3111; -- Razormane Quilboar
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3110; -- Dreadmaw Crocolisk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3108; -- Encrusted Surf Crawler
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=3100; -- Elder Mottled Boar
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=307; -- Pinto
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=30733; -- Thargen Heavyquill
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=30731; -- Illianna Moonscribe
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=306; -- Palomino
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2988; -- Morin Cloudstalker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2979; -- Venture Co. Supervisor
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2951; -- Palemane Poacher
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2943; -- Ransin Donner
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2918; -- Advisor Belgrum
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2916; -- Historian Karnik
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=29143; -- Bebri Coifcurl
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=29142; -- Jelinek Sharpshear
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=29141; -- Pella Brassbrush
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2912; -- Chief Archaeologist Greywhisker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2878; -- Peria Lamenur
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2857; -- Thund
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2855; -- Snang
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=27946; -- Silvermoon Dragonhawk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2790; -- Grand Mason Marblesten
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2786; -- Gerrig Bonegrip
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=27815; -- Brew Vendor
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=27704; -- Horace Alder
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=27703; -- Ysuria
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=27489; -- Ray'ma
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=27478; -- Larkin Thunderbrew
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2739; -- Shadowforge Tunneler
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2737; -- Durtham Greldon
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2695; -- Sara Balloo
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=26537; -- Greeb Ramrocket
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2619; -- Hammerfall Grunt
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2618; -- Hammerfall Peon
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2616; -- Privateer Groy
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2574; -- Drywhisker Digger
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2573; -- Drywhisker Surveyor
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2561; -- Highland Fleshstalker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2554; -- Witherbark Axe Thrower
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=25355; -- Beryl Hound
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24843; -- Engineer Combs
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24842; -- Marine Anderson
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24841; -- Marine Halters
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24840; -- Sailor Vines
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24839; -- Sailor Wicks
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24838; -- Sailor Henders
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24837; -- Navigator Mehran
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24836; -- Abe the Cabin Boy
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24835; -- First Mate Kowalski
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24834; -- Galley Chief Grace
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24833; -- Captain "Stash" Torgoley
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24819; -- Anvilrage Enforcer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24818; -- Anvilrage Taskmaster
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2461; -- Bailey Stonemantle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2460; -- Barnum Stonemantle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24208; -- "Little" Logok
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24025; -- Invis Firework Helper
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24007; -- Mill Courier
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24006; -- Foreman Tionn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=24005; -- Mill Worker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=239; -- Grimbooze Thunderbrew
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23988; -- Michael Schweitzer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23979; -- Giant Marsh Frog
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23951; -- Lieutenant Aden
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23950; -- Lieutenant Khand
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23949; -- Lieutenant Nath
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23907; -- Theramore Cannon
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23905; -- Major Mills
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23896; -- "Dirty" Michael Crowe
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23869; -- Invis Zelfrax Origin
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23868; -- Invis Zelfrax Target
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23855; -- [DNT] L70ETC Chief Thunder-Skins Controller
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23854; -- [DNT] L70ETC Sig Controller
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23853; -- [DNT] L70ETC Samuro Controller
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23852; -- [DNT] L70ETC Mai'Kyl Controller
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23850; -- [DNT] L70ETC Concert Controller
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23845; -- [DNT] L70ETC Bergrisst Controller
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23843; -- Mordant Grimsby
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23841; -- Razorspine
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23835; -- Sergeant Amelyn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23832; -- Zeppelin Power Core
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23830; -- [DNT] L70ETC FX Controller
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23741; -- Captured Raptor
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23727; -- Invis Raptor Credit
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23721; -- Concert Bruiser
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23720; -- Theramore Prisoner
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23714; -- Grimtotem Elder
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23704; -- Cassa Crimsonwing
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23679; -- Garn Mathers
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23626; -- Sig Nicious
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23625; -- Samuro
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23624; -- Mai'Kyl
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23623; -- Chief Thunder-Skins
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23620; -- Privateer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23619; -- Bergrisst
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23602; -- Deserter Agitator
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23593; -- Grimtotem Spirit-Shifter
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23592; -- Grimtotem Breaker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23591; -- Defias Diver
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23590; -- Defias Conjuror
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23589; -- Defias Rummager
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23585; -- Witch Light
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23568; -- Captain Darill
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23555; -- Risen Husk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23554; -- Risen Spirit
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23536; -- Nagulon
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23535; -- Matero Zeshuwal
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2326; -- Thamner Pol
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=23128; -- Master Pyreanor
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2299; -- Borgus Stoutarm
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2162; -- Agal
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2155; -- Sentinel Shayla Nightbreeze
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2151; -- Moon Priestess Amara
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2092; -- Pilot Longbeard
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2081; -- Sentinel Kyra Starsong
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2080; -- Denalan
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=20797; -- Deviate Coiler Hatchling
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2078; -- Athridas Bearmantle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=20493; -- Green Wind Rider
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=20492; -- Swift Yellow Wind Rider
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=20491; -- Swift Red Wind Rider
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=20490; -- Swift Purple Wind Rider
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=20489; -- Swift Green Wind Rider
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=20488; -- Tawny Wind Rider
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=20486; -- Blue Wind Rider
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2043; -- Nightsaber Stalker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2042; -- Nightsaber
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2011; -- Gnarlpine Augur
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=2010; -- Gnarlpine Defender
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1998; -- Webwood Lurker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1996; -- Strigid Screecher
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1995; -- Strigid Owl
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=19850; -- Councilor Arial D'Anastasis
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1977; -- Senator Mehr Stonehallow
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1963; -- Vidra Hearthstove
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1960; -- Pilot Hammerfoot
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1959; -- Mountaineer Barleybrew
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=18945; -- Pit Commander
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=18739; -- Giraffe
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1872; -- Tharek Blackstone
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=18255; -- Apprentice Darius
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=18253; -- Archmage Leryda
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=18221; -- Holaaru
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=18162; -- Underground Pond Credit Marker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=18161; -- Underground Well Credit Marker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=17613; -- Archmage Alturus
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=17223; -- Ambassador Rualeth
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=17119; -- Ithania
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=17105; -- Emissary Valustraa
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=17098; -- Ambassador Dawnsinger
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1703; -- Uthrar Threx
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1702; -- Bronk Guzzlegear
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1701; -- Dank Drizzlecut
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1699; -- Gremlock Pilsnor
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1698; -- Frast Dokner
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1697; -- Keeg Gibn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1694; -- Loslor Rudge
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1693; -- Loch Crocolisk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1692; -- Golorn Frostbeard
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1691; -- Kreg Bilmn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1690; -- Thrawn Boltar
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1689; -- Scarred Crag Boar
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1682; -- Yanni Stoutheart
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=167; -- Morhan Coppertongue
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1679; -- Avarus Kharag
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=16418; -- Mupsi Shacklefridd
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=16416; -- Bronn Fitzwrench
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=16013; -- Deliana
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=15903; -- Sergeant Carnes
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1573; -- Gryth Thurden
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1572; -- Thorgrum Borrelson
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=15679; -- Auctioneer Cazarez
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=15678; -- Auctioneer Silva'las
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=15443; -- Janela Stouthammer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=15303; -- Maxima Blastenheimer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=15218; -- Faire Cannon Trigger
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=15188; -- Cenarion Emissary Blackhoof
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=15186; -- Murky
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14894; -- Swarm of bees
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14892; -- Fang
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14873; -- Okla
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14868; -- Hornsley
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14867; -- Jubjub
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14866; -- Flik's Frog
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14864; -- Khaz Modan Ram
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14857; -- Erk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14849; -- Darkmoon Faire Carnie
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14847; -- Professor Thaddeus Paleo
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14846; -- Lhara
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14845; -- Stamp Thunderhorn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14844; -- Sylannia
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14841; -- Rinling
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14833; -- Chronos
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14832; -- Kerri Hicks
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14829; -- Yebb Neblegear
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14828; -- Gelvas Grimegate
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14827; -- Burth
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14823; -- Silas Darkmoon
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14822; -- Sayge
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14742; -- Zap Farflinger
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1469; -- Vrok Blunderblast
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1466; -- Gretta Finespindle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1465; -- Drac Roughcut
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14551; -- Swift Yellow Mechanostrider
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14546; -- Swift Brown Ram
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14541; -- Swift Gray Wolf
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14540; -- Swift Brown Wolf
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14539; -- Swift Timber Wolf
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14499; -- Horde Orphan
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14498; -- Tosamina
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14463; -- Daio the Decrepit
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14451; -- Orphan Matron Battlewail
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14448; -- Molt Thorn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14437; -- Gorzeeki Wildeyes
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1442; -- Helgrum the Swift
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14392; -- Overlord Runthak
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14387; -- Lothos Riftwaker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14377; -- Scout Tharr
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14376; -- Scout Manslayer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14375; -- Scout Stronghand
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14367; -- Thief Catcher Thunderbrew
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14365; -- Thief Catcher Farmountain
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14363; -- Thief Catcher Shadowdelve
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14356; -- Sawfin Frenzy
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14304; -- Kor'kron Elite
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14230; -- Burgle Eye
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=14183; -- Artilleryman Sheldonore
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1405; -- Morris Lawry
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=13917; -- Izzy Coppergrab
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1388; -- Vagash
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=13843; -- Lieutenant Rotimer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1383; -- Snarl
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1378; -- Pilot Bellowfiz
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1377; -- Pilot Stonegear
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1376; -- Beldin Steelgrill
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1375; -- Marleth Barleybrew
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1374; -- Rejold Barleybrew
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1373; -- Jarven Thunderbrew
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1358; -- Miner Grothor
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1356; -- Prospector Stormpike
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1352; -- Fluffy
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1340; -- Mountaineer Kadrell
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=13277; -- Dahne Pierce
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=13177; -- Vahgruk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=13117; -- Horde Spirit Guide
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1296; -- Felder Stover
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12939; -- Doctor Gustaf VanHowzen
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12798; -- Grunt Bek'rah
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12797; -- Grunt Korf
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12796; -- Raider Bork
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12791; -- Chieftain Earthbind
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12790; -- Advisor Willington
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12789; -- Blood Guard Hini'wana
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1274; -- Senator Barin Redstone
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1273; -- Grawn Thromwyn
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=126; -- Murloc Coastrunner
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1269; -- Razzle Sprysprocket
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1268; -- Ozzie Togglevolt
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1267; -- Ragnar Thunderbrew
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1265; -- Rudra Amberstill
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1263; -- Yarlyn Amberstill
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1261; -- Veron Amberstill
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1256; -- Quarrymaster Thesten
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1254; -- Foreman Stonebrow
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1253; -- Father Gavin
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1252; -- Senir Whitebeard
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=124; -- Riverpaw Brute
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1247; -- Innkeeper Belm
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1246; -- Vosur Brakthel
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1240; -- Boran Ironclink
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1238; -- Gamili Frosthide
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12380; -- Unliving Resident
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1237; -- Kazan Mogosh
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12379; -- Unliving Caretaker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12378; -- Damned Soul
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12377; -- Wailing Spectre
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12367; -- Green Mechanostrider
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12365; -- Red Mechanostrider
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12353; -- Timber Riding Wolf
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12351; -- Dire Riding Wolf
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12336; -- Brother Crowley
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1232; -- Azar Stronghammer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1228; -- Magis Sparkmantle
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12047; -- Stormpike Mountaineer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=12034; -- Koiter
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1196; -- Ice Claw Bear
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1195; -- Forest Lurker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11943; -- Magga
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11942; -- Orenthil Whisperwind
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11941; -- Yori Crackhelm
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11899; -- Shardi
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11874; -- Masat T'andr
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1186; -- Elder Black Bear
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11857; -- Makaba Flathoof
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11814; -- Kali Remik
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11812; -- Claira Kindfeather
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11810; -- Howin Kindfeather
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11807; -- Tristane Shadowstone
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11757; -- Umaron Stragarelm
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11755; -- Harlo Wigglesworth
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11754; -- Meggi Peppinrocker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11753; -- Gogo
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1173; -- Tunnel Rat Scout
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1172; -- Tunnel Rat Vermin
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11709; -- Jareth Wildwoods
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1164; -- Stonesplinter Bonesnapper
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1162; -- Stonesplinter Scout
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1161; -- Stonesplinter Trogg
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11546; -- Jack Sterling
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1139; -- Magistrate Bluntnose
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1132; -- Timber
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1125; -- Crag Boar
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1119; -- Hammerspine
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11198; -- Broken Exile
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11191; -- Lilith the Lithe
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11190; -- Everlook Bruiser
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11189; -- Qia
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11188; -- Evie Whirlbrew
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11187; -- Himmik
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11186; -- Lunnix Sprocketslip
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11185; -- Xizzer Fizzbolt
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11184; -- Wixxrak
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11183; -- Blixxrak
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11182; -- Nixxrak
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1117; -- Rockjaw Bonesnapper
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11146; -- Ironus Coldsteel
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11145; -- Myolor Sunderfury
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11139; -- Yugrek
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11138; -- Maethrya
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11119; -- Azzleby
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11083; -- Darianna
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11081; -- Faldron
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11070; -- Lalina Summermoon
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11066; -- Jhag
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11065; -- Thonys Pillarstone
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11052; -- Timothy Worthington
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11050; -- Trianna
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11046; -- Whuut
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11042; -- Sylvanna Forestmoon
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11041; -- Milla Fairancora
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11029; -- Trixie Quikswitch
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11028; -- Jemma Quikswitch
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11025; -- Mukdrak
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=11017; -- Roxxik
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10920; -- Kelek Skykeeper
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1088; -- Monstrous Crawler
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10880; -- Warcaller Gorlach
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10877; -- Courier Hammerfall
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=1073; -- Ashlan Stonesmirk
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10685; -- Swine
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10637; -- Malyfous Darkhammer
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10619; -- Glacier
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10468; -- Felnok Steelspring
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10456; -- Prynne
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10455; -- Binny Springblade
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10445; -- Selina Dourman
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10305; -- Umi Rumplesnicker
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10277; -- Groum Stonebeard
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10276; -- Rotgath Stonebeard
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10266; -- Ug'thok
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10090; -- Belia Thundergranite
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10089; -- Silvaria
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10063; -- Reggifuz
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10061; -- Killium Bouldertoe
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10056; -- Alassin
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10051; -- Seriadne
UPDATE `creature_template` SET `dynamicflags`=0 WHERE `entry`=10047; -- Michael
UPDATE `creature_template` SET `baseattacktime`=4000 WHERE `entry`=18966; -- Justinius the Harbinger
UPDATE `creature_template` SET `baseattacktime`=2400 WHERE `entry`=46647; -- Training Dummy
UPDATE `creature_template` SET `baseattacktime`=2400 WHERE `entry`=31146; -- Heroic Training Dummy
UPDATE `creature_template` SET `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags2`=0, `dynamicflags`=0 WHERE `entry`=38008; -- Blood Orb Controller
UPDATE `creature_template` SET `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28731; -- Watcher Silthik
UPDATE `creature_template` SET `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28730; -- Watcher Gashra
UPDATE `creature_template` SET `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28729; -- Watcher Narjil
UPDATE `creature_template` SET `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=28684; -- Krik'thir the Gatewatcher
UPDATE `creature_template` SET `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=23801; -- Turkey
UPDATE `creature_template` SET `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18233; -- Elementalist Ioki
UPDATE `creature_template` SET `baseattacktime`=2000, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=18183; -- Arechron
UPDATE `creature_template` SET `baseattacktime`=2000, `dynamicflags`=4 WHERE `entry`=24818; -- Anvilrage Taskmaster
UPDATE `creature_template` SET `baseattacktime`=1942 WHERE `entry`=8383; -- Master Wood
UPDATE `creature_template` SET `baseattacktime`=1538 WHERE `entry`=18827; -- Gan'arg Sapper
UPDATE `creature_template` SET `baseattacktime`=1200, `rangeattacktime`=2000, `dynamicflags`=0 WHERE `entry`=21022; -- Grovestalker Lynx
UPDATE `creature_template` SET `VehicleId`=25 WHERE `entry`=45648; -- Twilight Abductor
UPDATE `creature_template` SET `VehicleId`=1126 WHERE `entry`=45642; -- Twilight Abductor
