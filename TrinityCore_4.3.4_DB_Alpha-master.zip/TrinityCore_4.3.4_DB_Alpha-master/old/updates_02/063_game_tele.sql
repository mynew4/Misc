UPDATE `game_tele` SET `position_x`=-5143.528, `position_y`=894.909, `position_z`=287.3936, `orientation`=2.268325 WHERE `id`=427; -- Gnomeregan
