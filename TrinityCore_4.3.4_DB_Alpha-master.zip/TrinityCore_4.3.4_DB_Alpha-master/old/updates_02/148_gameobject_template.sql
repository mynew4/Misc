UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187662; -- "Elder Kesuk"
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187664; -- "Elder Takret"
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191658; -- On Naxxramas
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191657; -- On Stratholme
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191656; -- On Scholomance
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191612; -- Eye of Acherus (Flavor)
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191613; -- Eye of Acherus (Flavor Trap)
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=19548; -- Eye of Azora
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185937; -- Furywing's Egg
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185938; -- Insidion's Egg
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185932; -- Obsidia's Egg
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191770; -- Eagle Egg
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191773; -- Eagle Egg
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=141931; -- Hippogryph Egg
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185936; -- Rivendark's Egg
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=190660; -- Roc Egg
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184840; -- Wyrmcult Egg
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191654; -- ATTENTION: Geists
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=164867; -- WANTED
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187766; -- Agamath, The First Gate
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=178553; -- Hive'Ashi Pod
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191088; -- Elder Kesuk
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191090; -- Elder Takret
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187765; -- Archonisus, The Third Gate
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=174858; -- Ironzar's Imported Weaponry
UPDATE `gameobject_template` SET `data20`=80, `WDBVerified`=15595 WHERE `entry`=201875; -- Gunship Armory
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185935; -- Dragon Egg Aura
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191555; -- Scourge Gryphon Roost Glow
UPDATE `gameobject_template` SET `data0`=1450, `WDBVerified`=15595 WHERE `entry`=185309; -- Altar of Goc
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184738; -- Altar of Shadows
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182165; -- Wanted Poster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183284; -- Wanted Poster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=181580; -- Central Beacon
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176311; -- Pew
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176312; -- Pew
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176313; -- Pew
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176314; -- Pew
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176315; -- Pew
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176316; -- Pew
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187206; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187207; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187214; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187215; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187216; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187217; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187218; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187219; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187220; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187221; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187222; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187223; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187224; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187225; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187226; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187227; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187228; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187229; -- Bench
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187577; -- Warsong Banner
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=179481; -- Alliance Banner
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=192425; -- Alliance Banner
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=192426; -- Alliance Banner
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=192428; -- Alliance Banner
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=178943; -- Horde Banner
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182527; -- Zangarmarsh Banner
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=181603; -- Sillithus Flag Stand, Alliance
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187277; -- Warsong Hold
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185083; -- Wildhammer Stronghold
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185086; -- Wildhammer Stronghold
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185609; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185617; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185625; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185637; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185647; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185649; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185652; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185659; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185665; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185669; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185673; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185770; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185772; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185780; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185784; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185791; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185796; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185807; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185808; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185832; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185836; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185840; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185848; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185853; -- Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185615; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185623; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185624; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185636; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185644; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185648; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185653; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185656; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185664; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185668; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185672; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185769; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185775; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185783; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185787; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185790; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185803; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185806; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185811; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185833; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185837; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185841; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185849; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185852; -- Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185613; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185621; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185626; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185638; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185645; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185650; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185655; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185657; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185666; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185670; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185674; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185771; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185773; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185782; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185785; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185788; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185797; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185804; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185809; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185835; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185839; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185843; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185851; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185854; -- Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185611; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185619; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185627; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185639; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185646; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185651; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185654; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185658; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185667; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185671; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185675; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185768; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185774; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185781; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185786; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185789; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185798; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185805; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185810; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185834; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185838; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185842; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185850; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185855; -- Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=143986; -- Mailbox
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=181236; -- Mailbox
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=181381; -- Mailbox
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183040; -- Mailbox
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184147; -- Mailbox
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184652; -- Mailbox
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185102; -- Mailbox
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185477; -- Mailbox
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185965; -- Mailbox
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=190914; -- Mailbox
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=113; -- Duskwood
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=190507; -- Offering Bowl
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183340; -- Imarion's Shield
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184296; -- Arcane Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184297; -- Arcane Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184298; -- Arcane Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182568; -- Burning Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182569; -- Burning Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183111; -- Burning Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183112; -- Burning Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183113; -- Burning Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183114; -- Burning Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183116; -- Burning Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183117; -- Burning Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183118; -- Burning Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183119; -- Burning Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184051; -- Burning Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184053; -- Burning Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184152; -- Burning Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176492; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176493; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183845; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183846; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185194; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185244; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185245; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185246; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185247; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185249; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185255; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185256; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185257; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185258; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185259; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185260; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185261; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185262; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185263; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185264; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185265; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185266; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185997; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=186089; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=186094; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=186097; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=74138; -- Brazier
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183903; -- Fierce Blaze
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183904; -- Fierce Blaze
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183905; -- Fierce Blaze
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183906; -- Fierce Blaze
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=152618; -- Kolkar's Booty
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=201584; -- Drink Me!
UPDATE `gameobject_template` SET `data1`=0, `WDBVerified`=15595 WHERE `entry`=2704; -- Cache of Explosives
UPDATE `gameobject_template` SET `data20`=80, `WDBVerified`=15595 WHERE `entry`=202241; -- Deathbringer's Cache
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=56; -- Rolf's corpse
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=190647; -- Corpses
UPDATE `gameobject_template` SET `data1`=0, `WDBVerified`=15595 WHERE `entry`=183941; -- Jakk's Cage
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187856; -- Scourge Cage
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187860; -- Scourge Cage
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187862; -- Scourge Cage
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187872; -- Scourge Cage
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187874; -- Scourge Cage
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185939; -- Nethermine Cargo
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=22649; -- Wooden Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=22650; -- Wooden Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=22651; -- Wooden Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=22652; -- Wooden Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=22654; -- Wooden Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=22658; -- Wooden Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=22664; -- Wooden Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=174880; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182867; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182868; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182869; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182870; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182871; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182872; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182873; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182874; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182875; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182876; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182877; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182878; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182879; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182880; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182881; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182882; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182883; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182884; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182885; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182886; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182887; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182888; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182889; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182890; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182891; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182892; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182893; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182894; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182895; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182896; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182897; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182898; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182899; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182900; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182901; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182902; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182903; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182904; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182905; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182906; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182907; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182908; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182909; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182910; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182911; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182912; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182913; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182914; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182915; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182916; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182917; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182918; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182919; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182920; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182921; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182922; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182923; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182924; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182925; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182926; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182927; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182928; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182929; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183022; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183023; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183024; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183025; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183026; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183027; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183028; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183029; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183030; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183032; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183033; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183035; -- Chair
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=192556; -- Cave Mushroom
UPDATE `gameobject_template` SET `data18`=67, `data19`=1, `WDBVerified`=15595 WHERE `entry`=181276; -- Flame Cap
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=190767; -- Inconspicuous Mine Car
UPDATE `gameobject_template` SET `data1`=15328, `data3`=11676, `data8`=1, `WDBVerified`=15595 WHERE `entry`=2076; -- Bubbling Cauldron
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=153124; -- Cauldron
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=153125; -- Cauldron
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183923; -- Cauldron
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183924; -- Cauldron
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183926; -- Cauldron
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183927; -- Cauldron
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183930; -- Cauldron
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184003; -- Cauldron
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191663; -- This is my Runeblade...
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=1562; -- Marshal Haggard's Chest
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=1765; -- Worn Wooden Chest
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184740; -- Wicker Chest
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185128; -- Lianthe's Strongbox
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191617; -- Compendium of Fallen Heroes
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=114; -- Lakeshire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184312; -- Ara Control Console
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185959; -- Proton Accelerator Controller
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185962; -- Proton Accelerator Controller
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185963; -- Proton Accelerator Controller
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185964; -- Proton Accelerator Controller
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185923; -- Crystalforge controller
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185924; -- Crystalforge controller
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=190917; -- Abandoned Mail
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=180454; -- Hive'Ashi Glyphed Crystal
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=180455; -- Hive'Zora Glyphed Crystal
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185919; -- Fel Crystalforge
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185920; -- Fel Crystalforge
UPDATE `gameobject_template` SET `data0`=0, `WDBVerified`=15595 WHERE `entry`=38927; -- Newman's Landing
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191533; -- Charred Wreckage
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185894; -- Relic Decharger
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=152586; -- Desolace
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=2032; -- Warning!!!! Plaguelands
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191659; -- On Undeath
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=116; -- Stonewatch Keep
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187339; -- Valiance Keep
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=194306; -- Duel Flag
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183356; -- Theatric Lightning
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=169968; -- Anvil
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=1796; -- Anvil
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182862; -- Anvil
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182863; -- Anvil
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183031; -- Anvil
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183034; -- Anvil
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183346; -- Anvil
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183348; -- Anvil
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184313; -- Anvil
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185602; -- Anvil
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191238; -- Anvil
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191503; -- Anvil
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191504; -- Anvil
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191506; -- Anvil
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191507; -- Anvil
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=190584; -- Battle-worn Sword
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183338; -- Imarion's Sword
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=186273; -- Damaged Diving Gear
UPDATE `gameobject_template` SET `data10`=1, `WDBVerified`=15595 WHERE `entry`=201709; -- Gunship Stairs
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=103727; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=103728; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=103729; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=142131; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=153350; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=153399; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=153482; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176226; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176230; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176276; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176792; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=179086; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182343; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183985; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184344; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184345; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184348; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184359; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=1892; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=1893; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191239; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191240; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191702; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191703; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191793; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=2667; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=41188; -- Campfire
UPDATE `gameobject_template` SET `size`=1.039999, `WDBVerified`=15595 WHERE `entry`=181635; -- Campfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=142090; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=148841; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=167285; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176279; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176281; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176285; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176286; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=180438; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=180439; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=180440; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=180444; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=1831; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183421; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183422; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183423; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183424; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183425; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183427; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183894; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183949; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184015; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184022; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184032; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184339; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184341; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184346; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184357; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184360; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185159; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185160; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=186180; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191194; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191396; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191627; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191629; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191700; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=24729; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=50986; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=50987; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=50988; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=50989; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=74146; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=94186; -- Bonfire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=165587; -- Fire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182864; -- Fire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182865; -- Fire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182866; -- Fire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183005; -- Fire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183006; -- Fire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183007; -- Fire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183008; -- Fire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183009; -- Fire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183010; -- Fire
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184727; -- Thunderlord Clan Arrow
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=190691; -- Saronite Arrow
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=142185; -- Flame of Byltan
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191746; -- Runeforge
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191747; -- Runeforge
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191748; -- Runeforge
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185911; -- Apexis Shard Formation
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185101; -- Dragonmaw Fortress
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=190569; -- Acherus Lightning
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=178784; -- Coldtooth Supplies
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=178785; -- Irondeep Supplies
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=175853; -- Meat Smoker
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183344; -- Fel Fire
UPDATE `gameobject_template` SET `data18`=45, `data19`=1, `WDBVerified`=15595 WHERE `entry`=123309; -- Ooze Covered Truesilver Deposit
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185604; -- Large Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185640; -- Large Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185660; -- Large Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185776; -- Large Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185795; -- Large Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185844; -- Large Blue Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185607; -- Large Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185643; -- Large Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185663; -- Large Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185779; -- Large Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185792; -- Large Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185847; -- Large Yellow Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185606; -- Large Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185642; -- Large Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185662; -- Large Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185778; -- Large Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185794; -- Large Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185845; -- Large Red Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185605; -- Large Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185641; -- Large Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185661; -- Large Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185777; -- Large Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185793; -- Large Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185846; -- Large Green Cluster
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187675; -- Borean Tundra Fire Large
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191650; -- Guide to the Side Effects of Reanimation
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185085; -- Eclipse Point
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182139; -- Feralfen Idol
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185120; -- O'Mally's Instrument
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=190509; -- Activation Switch Theta
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185608; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185616; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185630; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185634; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185678; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185681; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185686; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185690; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185692; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185698; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185702; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185706; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185708; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185715; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185719; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185723; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185726; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185730; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185732; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185752; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185756; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185763; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185764; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185800; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185614; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185622; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185629; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185633; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185677; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185680; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185685; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185689; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185693; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185697; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185701; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185705; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185711; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185712; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185718; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185722; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185725; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185729; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185735; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185755; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185759; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185760; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185766; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185801; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185612; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185620; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185631; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185635; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185679; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185682; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185687; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185691; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185695; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185699; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185703; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185707; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185710; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185714; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185716; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185720; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185727; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185731; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185733; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185753; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185757; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185762; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185767; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185802; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185610; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185618; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185628; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185632; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185676; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185683; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185684; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185688; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185694; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185696; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185700; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185704; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185709; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185713; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185717; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185721; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185724; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185728; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185734; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185754; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185758; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185761; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185765; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185799; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185872; -- Simon Game Aura Blue
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185875; -- Simon Game Aura Yellow
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185874; -- Simon Game Aura Red
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185873; -- Simon Game Aura Green
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=186272; -- Tool Kit
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191653; -- Unknown Crusader's Diary
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184969; -- The Fourth Prophecy
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184967; -- The Second Prophecy
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184968; -- The Third Prophecy
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191655; -- One Truth in Undeath
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191540; -- Alchemy Lab
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191541; -- Alchemy Lab
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=180768; -- Lantern
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=180633; -- Crystalline Tear
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=201598; -- The Skybreaker
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183485; -- The Circle of Blood
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=201581; -- Orgrim's Hammer
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185084; -- The Black Temple
UPDATE `gameobject_template` SET `data0`=1634, `data20`=80, `WDBVerified`=15595 WHERE `entry`=201710; -- The Captain's Chest
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191662; -- A Zombie's Guide to Proper Nutrition
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=192866; -- The Schools of Arcane Magic - Necromancy
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=152585; -- The Twin Colossals
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184150; -- Blade's Edge Mountains
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191634; -- The Death Knights of Acherus
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191664; -- The Decree of the Scourge 
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191649; -- The Memoirs of Lord Thorval
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185906; -- Kronk's Book
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=180503; -- Sandy Cookbook
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191609; -- Eye of Acherus Control Mechanism
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=65407; -- Graznab's Machine
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183256; -- Zangarmarsh
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182571; -- Cookpot
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183096; -- Cookpot
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183180; -- Cookpot
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183273; -- Cookpot
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183437; -- Cookpot
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183438; -- Cookpot
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185136; -- Cookpot
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=152587; -- Thousand Needles
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=144063; -- Equinex Monolith
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=195308; -- Mysterious Snow Mound
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185945; -- Apexis Decharger
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191708; -- Disturbed Snow
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185929; -- Dragonkin Nest 01
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185930; -- Dragonkin Nest 02
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185931; -- Dragonkin Nest 03
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=190661; -- Roc Nest
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191554; -- Skeletal Gryphon Roost
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185193; -- Legion Obelisk
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185195; -- Legion Obelisk
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185196; -- Legion Obelisk
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185197; -- Legion Obelisk
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185198; -- Legion Obelisk
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=201741; -- Empowering Blood Orb
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187869; -- Orb of the Blue Flight
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=188114; -- Orb of the Blue Flight
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=188115; -- Orb of the Blue Flight
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=188116; -- Orb of the Blue Flight
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182941; -- Grishnath Orb
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183342; -- Warboss Nekrogg's Orders
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=161527; -- Dinosaur Bone
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=165578; -- Dark Iron Ale TRAP
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=48568; -- Short Wooden Seat
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183934; -- Shredder Parts
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187995; -- Caribou Trap
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187997; -- Caribou Trap
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=188000; -- Caribou Trap
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=188001; -- Caribou Trap
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=188005; -- Caribou Trap
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=188006; -- Caribou Trap
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=188035; -- Mammoth Trap
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=188036; -- Mammoth Trap
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=188037; -- Mammoth Trap
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=188038; -- Mammoth Trap
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=186663; -- Freezing Trap
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=144050; -- Gordunni Trap
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=142343; -- Uldum Pedestal
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=181698; -- Voidstone
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=188150; -- Ice Stone
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=178826; -- Meeting Stone
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=180544; -- Lesser Wind Stone
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=180549; -- Lesser Wind Stone
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=180564; -- Lesser Wind Stone
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=180559; -- Greater Wind Stone
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=180502; -- Wind Stone
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=180534; -- Wind Stone
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=180554; -- Wind Stone
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=20923; -- Stone of Remembrance
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=190687; -- Wood Pile
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185861; -- Fel Cannonball Stack
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187275; -- Fizzcrank Airstrip
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=152584; -- High Wilderness
UPDATE `gameobject_template` SET `data1`=0, `data22`=10282, `WDBVerified`=15595 WHERE `entry`=177398; -- Demon Portal
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=190488; -- Pentarus' Portal to Sholazar Basin
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176498; -- Portal to Darnassus
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176497; -- Portal to Ironforge
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=182351; -- Portal to Exodar
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=176950; -- Ghost Walker Post
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183254; -- Sunspring Post
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185927; -- Fel Crystal Prism
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191577; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191580; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191581; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191582; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191583; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191584; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191585; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191586; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191587; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191588; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191589; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191590; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=48516; -- Master Control Program
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=164956; -- Western Crystal Pylon
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191646; -- Corpulous' Mess Hall Rules
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=192883; -- Blinking Rules & Regulations
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191648; -- Account of the Raising of a Frost Wyrm
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191633; -- Report from the Frontlines: Undercity
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191632; -- Report from the Frontlines: Dragonblight
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191618; -- Report from the Frontlines: Western Northrend
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191631; -- Report from the Frontlines: Eastern Kingdoms
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=183486; -- Netherstorm
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185890; -- Apexis Relic
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=177186; -- Turn Back!
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187764; -- Rohendor, The Second Gate
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=187283; -- Riplash Ruins
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=22245; -- Sack of Meat
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185082; -- Sanctum of the Stars
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185087; -- Sanctum of the Stars
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=188102; -- Coldarra Geological Monitor
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191652; -- Grooming for Ghouls
UPDATE `gameobject_template` SET `data10`=1, `WDBVerified`=15595 WHERE `entry`=201858; -- Alliance Teleporter
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=164868; -- KILL ON SIGHT
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=169294; -- Tablet of the Seven
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184726; -- Thunderlord Clan Drum
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=181618; -- ToWoW - Flag Cap Counter, Alliance
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=181619; -- ToWoW - Flag Cap Counter, Horde
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184825; -- Lashh'an Tome
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184504; -- Bloodmaul Brew Keg
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=192618; -- Torch
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=191616; -- Touch of the Banshee
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=190568; -- Light's Point Tower
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184624; -- Toshley's Turbo Tesla Turret
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184625; -- Toshley's Turbo Tesla Turret
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184626; -- Toshley's Turbo Tesla Turret
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184627; -- Toshley's Turbo Tesla Turret
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=61; -- A Weathered Grave
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=201615; -- Ooze Release Valve
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=201616; -- Gas Release Valve
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185097; -- Shadowmoon Village
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=185098; -- Shadowmoon Village
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=2030; -- Alterac City
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=177185; -- Abandon hope, all ye who enter here.
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184663; -- Shadow Sight
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184664; -- Shadow Sight
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=201834; -- Zeppelin, Horde (The Mighty Wind) (Icecrown Raid)
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184151; -- Area 52
UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=184153; -- Area 52
