-- New cost since cata
UPDATE `gossip_menu_option` SET `box_money`=100000 WHERE `menu_id`=0 AND `id`=16;
UPDATE `gossip_menu_option` SET `box_money`=100000 WHERE `menu_id`=6647 AND `id`=2;
