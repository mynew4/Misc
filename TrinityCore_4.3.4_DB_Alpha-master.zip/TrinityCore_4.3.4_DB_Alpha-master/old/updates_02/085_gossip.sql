UPDATE `creature_template` SET `gossip_menu_id`=10696 WHERE `entry`=35873; -- Celestine of the Harvest
UPDATE `creature_template` SET `gossip_menu_id`=10696 WHERE `entry`=44459; -- Celestine of the Harvest
UPDATE `creature_template` SET `gossip_menu_id`=10697 WHERE `entry`=35874; -- Huntsman Blake
UPDATE `creature_template` SET `gossip_menu_id`=10698 WHERE `entry`=35872; -- Myriam Spellwaker
UPDATE `creature_template` SET `gossip_menu_id`=10699 WHERE `entry`=35871; -- Loren the Fence
UPDATE `creature_template` SET `gossip_menu_id`=10700 WHERE `entry`=44468; -- Sister Almyra
UPDATE `creature_template` SET `gossip_menu_id`=10702 WHERE `entry`=35869; -- Vitus Darkwalker
UPDATE `creature_template` SET `gossip_menu_id`=10834 WHERE `entry`=36628; -- Celestine of the Harvest
UPDATE `creature_template` SET `gossip_menu_id`=10835 WHERE `entry`=36629; -- Huntsman Blake
UPDATE `creature_template` SET `gossip_menu_id`=10838 WHERE `entry`=36632; -- Sister Almyra
UPDATE `creature_template` SET `gossip_menu_id`=10841 WHERE `entry`=36695; -- Samantha Buckley
UPDATE `creature_template` SET `gossip_menu_id`=11654 WHERE `entry`=42638; -- Herezegor Flametusk
UPDATE `creature_template` SET `gossip_menu_id`=11659 WHERE `entry`=42777; -- Bilgewater Foreman
UPDATE `creature_template` SET `gossip_menu_id`=11794 WHERE `entry`=44125; -- Chris Moller
UPDATE `creature_template` SET `gossip_menu_id`=12074 WHERE `entry`=44169; -- Zaela
UPDATE `creature_template` SET `gossip_menu_id`=12075 WHERE `entry`=45823; -- High Executioner Nuzrak
UPDATE `creature_template` SET `gossip_menu_id`=12174 WHERE `entry`=46872; -- Prince Nadun
UPDATE `creature_template` SET `gossip_menu_id`=12180 WHERE `entry`=47418; -- Runda
UPDATE `creature_template` SET `gossip_menu_id`=12191 WHERE `entry`=50247; -- Jack "All-Trades" Derrington
UPDATE `creature_template` SET `gossip_menu_id`=12642 WHERE `entry`=50482; -- Marith Lazuria
UPDATE `creature_template` SET `gossip_menu_id`=12716 WHERE `entry`=50499; -- Myriam Spellwaker
UPDATE `creature_template` SET `gossip_menu_id`=12795 WHERE `entry`=52921; -- Deldren Ravenelm
UPDATE `creature_template` SET `gossip_menu_id`=12897 WHERE `entry`=53259; -- Arthorn Windsong
UPDATE `creature_template` SET `gossip_menu_id`=12911 WHERE `entry`=52669; -- Matoclaw
UPDATE `creature_template` SET `gossip_menu_id`=12930 WHERE `entry`=53652; -- Aggra
UPDATE `creature_template` SET `gossip_menu_id`=12940 WHERE `entry`=53738; -- Aggra
UPDATE `creature_template` SET `gossip_menu_id`=12991 WHERE `entry`=54313; -- Thrall
UPDATE `creature_template` SET `gossip_menu_id`=13061 WHERE `entry`=54931; -- Stone Guard Stok'ton
UPDATE `creature_template` SET `gossip_menu_id`=13163 WHERE `entry`=55500; -- Illidan Stormrage
UPDATE `creature_template` SET `gossip_menu_id`=13164 WHERE `entry`=55779; -- Thrall
UPDATE `creature_template` SET `gossip_menu_id`=13294 WHERE `entry`=56103; -- Thrall
UPDATE `creature_template` SET `gossip_menu_id`=1624 WHERE `entry`=43645; -- Ornag
UPDATE `creature_template` SET `gossip_menu_id`=5541 WHERE `entry`=45843; -- Yuka Screwspigot
UPDATE `creature_template` SET `gossip_menu_id`=5853 WHERE `entry`=50567; -- Fielding Chesterhill
UPDATE `creature_template` SET `gossip_menu_id`=5855 WHERE `entry`=50574; -- Amelia Atherton
