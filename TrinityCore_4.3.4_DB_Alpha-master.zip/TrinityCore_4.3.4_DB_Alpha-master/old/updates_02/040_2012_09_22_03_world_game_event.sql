-- Brewfest (372) duration fix by nelegalno
UPDATE `game_event` SET `length` = 21600 WHERE `eventEntry` = 24;
