DELETE FROM `creature` WHERE `id`=36095;
