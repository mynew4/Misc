UPDATE `creature_template` SET `spell1` = 0 WHERE `entry` IN (15490,5924);
