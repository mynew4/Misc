DELETE FROM `creature_model_info` WHERE `modelid` IN (2833, 15713, 19769, 17561, 22511, 22512);
