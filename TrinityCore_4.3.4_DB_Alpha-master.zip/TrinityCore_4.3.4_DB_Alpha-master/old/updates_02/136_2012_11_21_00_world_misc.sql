-- --------
DELETE FROM `command` WHERE `name`='flusharenapoints';
DELETE FROM `trinity_string` WHERE `entry` IN ('741','742','743','744','745','746');
