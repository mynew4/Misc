DELETE FROM `spell_bonus_data` WHERE `entry` IN (28880,59542,59543,59544,59545,59547,59548);
INSERT INTO `spell_bonus_data` (`entry`,`direct_bonus`,`dot_bonus`,`ap_bonus`,`ap_dot_bonus`,`comments`) VALUES
(28880,0,0,0,0,'Warrior - Gift of the Naaru'),
(59542,0,0,0,0,'Paladin - Gift of the Naaru'),
(59543,0,0,0,0,'Hunter - Gift of the Naaru'),
(59544,0,0,0,0,'Priest - Gift of the Naaru'),
(59545,0,0,0,0,'Deathknight - Gift of the Naaru'),
(59547,0,0,0,0,'Shaman - Gift of the Naaru'),
(59548,0,0,0,0,'Mage - Gift of the Naaru');
