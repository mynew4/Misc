UPDATE `creature_template` SET `npcflag`=`npcflag`|16|32 WHERE `subname` LIKE 'Mage Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|32 WHERE `subname` LIKE 'Hunter Trainer';
