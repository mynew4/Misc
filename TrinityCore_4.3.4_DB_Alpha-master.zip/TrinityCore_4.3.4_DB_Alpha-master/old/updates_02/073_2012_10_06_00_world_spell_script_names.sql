DELETE FROM `spell_script_names` WHERE `spell_id` IN (74562,74567,74610,74641,74792,74795,74800,74805,74807,74808,74812,75396,74769,77844,77845,77846);
INSERT INTO `spell_script_names` (`spell_id`, `ScriptName`) VALUES
(74562, 'spell_halion_fiery_combustion'),
(74567, 'spell_halion_mark_of_combustion'),
(74610, 'spell_halion_damage_aoe_summon'),
(74641, 'spell_halion_meteor_strike_marker'),
(74792, 'spell_halion_soul_consumption'),
(74795, 'spell_halion_mark_of_consumption'),
(74800, 'spell_halion_damage_aoe_summon'),
(74805, 'spell_halion_summon_exit_portals'),
(74807, 'spell_halion_enter_twilight_realm'),
(74808, 'spell_halion_twilight_phasing'),
(74812, 'spell_halion_leave_twilight_realm'),
(75396, 'spell_halion_clear_debuffs'),
(74769, 'spell_halion_twilight_cutter'),
(77844, 'spell_halion_twilight_cutter'),
(77845, 'spell_halion_twilight_cutter'),
(77846, 'spell_halion_twilight_cutter');
