UPDATE `creature_model_info` SET `bounding_radius`=0.025, `combat_reach`=0.05 WHERE `modelid`=38498; -- 38498
UPDATE `creature_model_info` SET `bounding_radius`=0.030556, `combat_reach`=0.5 WHERE `modelid`=38814; -- 38814
UPDATE `creature_model_info` SET `bounding_radius`=0.05, `combat_reach`=0.5 WHERE `modelid`=12191; -- 12191
UPDATE `creature_model_info` SET `bounding_radius`=0.05, `combat_reach`=1.5 WHERE `modelid`=38848; -- 38848
UPDATE `creature_model_info` SET `bounding_radius`=0.0525, `combat_reach`=0.15 WHERE `modelid`=38731; -- 38731
UPDATE `creature_model_info` SET `bounding_radius`=0.061112, `combat_reach`=1, `gender`=0 WHERE `modelid`=38557; -- 38557
UPDATE `creature_model_info` SET `bounding_radius`=0.061112, `combat_reach`=1, `gender`=1 WHERE `modelid`=38317; -- 38317
UPDATE `creature_model_info` SET `bounding_radius`=0.062, `combat_reach`=0.3 WHERE `modelid`=33254; -- 33254
UPDATE `creature_model_info` SET `bounding_radius`=0.0625, `combat_reach`=0.125 WHERE `modelid`=17188; -- 17188
UPDATE `creature_model_info` SET `bounding_radius`=0.075, `combat_reach`=0.225 WHERE `modelid`=38733; -- 38733
UPDATE `creature_model_info` SET `bounding_radius`=0.093, `combat_reach`=3 WHERE `modelid`=39125; -- 39125
UPDATE `creature_model_info` SET `bounding_radius`=0.1, `combat_reach`=0.2 WHERE `modelid`=16946; -- 16946
UPDATE `creature_model_info` SET `bounding_radius`=0.1, `combat_reach`=0.3 WHERE `modelid`=38739; -- 38739
UPDATE `creature_model_info` SET `bounding_radius`=0.1, `combat_reach`=1 WHERE `modelid`=36541; -- 36541
UPDATE `creature_model_info` SET `bounding_radius`=0.1, `combat_reach`=1, `gender`=1 WHERE `modelid`=36542; -- 36542
UPDATE `creature_model_info` SET `bounding_radius`=0.105, `combat_reach`=0.3 WHERE `modelid`=19754; -- 19754
UPDATE `creature_model_info` SET `bounding_radius`=0.105, `combat_reach`=0.3 WHERE `modelid`=36292; -- 36292
UPDATE `creature_model_info` SET `bounding_radius`=0.105, `combat_reach`=0.3 WHERE `modelid`=36293; -- 36293
UPDATE `creature_model_info` SET `bounding_radius`=0.105, `combat_reach`=0.3 WHERE `modelid`=36297; -- 36297
UPDATE `creature_model_info` SET `bounding_radius`=0.105, `combat_reach`=0.3 WHERE `modelid`=36298; -- 36298
UPDATE `creature_model_info` SET `bounding_radius`=0.105, `combat_reach`=0.3 WHERE `modelid`=36299; -- 36299
UPDATE `creature_model_info` SET `bounding_radius`=0.1085, `combat_reach`=0.35 WHERE `modelid`=22409; -- 22409
UPDATE `creature_model_info` SET `bounding_radius`=0.1085, `combat_reach`=3.5 WHERE `modelid`=30808; -- 30808
UPDATE `creature_model_info` SET `bounding_radius`=0.1155, `combat_reach`=0.33 WHERE `modelid`=38377; -- 38377
UPDATE `creature_model_info` SET `bounding_radius`=0.12, `combat_reach`=0.4, `gender`=0 WHERE `modelid`=22423; -- 22423
UPDATE `creature_model_info` SET `bounding_radius`=0.124, `combat_reach`=2.4, `gender`=0 WHERE `modelid`=30807; -- 30807
UPDATE `creature_model_info` SET `bounding_radius`=0.125, `combat_reach`=0.375 WHERE `modelid`=38740; -- 38740
UPDATE `creature_model_info` SET `bounding_radius`=0.135, `combat_reach`=1.8 WHERE `modelid`=31541; -- 31541
UPDATE `creature_model_info` SET `bounding_radius`=0.14, `combat_reach`=1.4 WHERE `modelid`=33867; -- 33867
UPDATE `creature_model_info` SET `bounding_radius`=0.14, `combat_reach`=7.2, `gender`=0 WHERE `modelid`=32081; -- 32081
UPDATE `creature_model_info` SET `bounding_radius`=0.1525, `combat_reach`=2.5 WHERE `modelid`=29424; -- 29424
UPDATE `creature_model_info` SET `bounding_radius`=0.1525, `combat_reach`=2.5 WHERE `modelid`=30080; -- 30080
UPDATE `creature_model_info` SET `bounding_radius`=0.15278, `combat_reach`=0.5 WHERE `modelid`=33845; -- 33845
UPDATE `creature_model_info` SET `bounding_radius`=0.155, `combat_reach`=0.5 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.155, `combat_reach`=0.5 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.155, `combat_reach`=1.5 WHERE `modelid`=33450; -- 33450
UPDATE `creature_model_info` SET `bounding_radius`=0.15655, `combat_reach`=0.505 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.1581, `combat_reach`=0.51 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.15965, `combat_reach`=0.515 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.1612, `combat_reach`=0.52 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.1612, `combat_reach`=0.52 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.16275, `combat_reach`=0.525 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.16275, `combat_reach`=0.525 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.1674, `combat_reach`=0.54 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.16895, `combat_reach`=0.545 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.17, `combat_reach`=1 WHERE `modelid`=1269; -- 1269
UPDATE `creature_model_info` SET `bounding_radius`=0.1705, `combat_reach`=0.55 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.1705, `combat_reach`=0.825 WHERE `modelid`=8109; -- 8109
UPDATE `creature_model_info` SET `bounding_radius`=0.17205, `combat_reach`=0.555 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.17205, `combat_reach`=0.555 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.1736, `combat_reach`=0.56 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.175, `combat_reach`=2.1875 WHERE `modelid`=16167; -- 16167
UPDATE `creature_model_info` SET `bounding_radius`=0.1767, `combat_reach`=0.57 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.17825, `combat_reach`=0.575 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.18135, `combat_reach`=0.585 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.18135, `combat_reach`=0.585 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.1829, `combat_reach`=0.59 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.1829, `combat_reach`=0.59 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.183336, `combat_reach`=3 WHERE `modelid`=38761; -- 38761
UPDATE `creature_model_info` SET `bounding_radius`=0.18445, `combat_reach`=0.595 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.186, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36547; -- 36547
UPDATE `creature_model_info` SET `bounding_radius`=0.186, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36549; -- 36549
UPDATE `creature_model_info` SET `bounding_radius`=0.186, `combat_reach`=9 WHERE `modelid`=39132; -- 39132
UPDATE `creature_model_info` SET `bounding_radius`=0.186, `combat_reach`=9 WHERE `modelid`=40116; -- 40116
UPDATE `creature_model_info` SET `bounding_radius`=0.1872, `combat_reach`=1.35, `gender`=1 WHERE `modelid`=30288; -- 30288
UPDATE `creature_model_info` SET `bounding_radius`=0.18755, `combat_reach`=0.605 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.18755, `combat_reach`=0.605 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.1891, `combat_reach`=0.61 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.19065, `combat_reach`=0.615 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.19065, `combat_reach`=0.615 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.19125, `combat_reach`=0.9375 WHERE `modelid`=21698; -- 21698
UPDATE `creature_model_info` SET `bounding_radius`=0.1922, `combat_reach`=0.62 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.19375, `combat_reach`=0.625 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.195, `combat_reach`=0.65, `gender`=0 WHERE `modelid`=22425; -- 22425
UPDATE `creature_model_info` SET `bounding_radius`=0.195, `combat_reach`=0.975 WHERE `modelid`=19685; -- 19685
UPDATE `creature_model_info` SET `bounding_radius`=0.1954576, `combat_reach`=1.5 WHERE `modelid`=30301; -- 30301
UPDATE `creature_model_info` SET `bounding_radius`=0.19685, `combat_reach`=0.635 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.19685, `combat_reach`=0.635 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.1984, `combat_reach`=0.64 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.1984, `combat_reach`=0.64 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.1986102, `combat_reach`=1.5 WHERE `modelid`=30301; -- 30301
UPDATE `creature_model_info` SET `bounding_radius`=0.19995, `combat_reach`=0.645 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.19995, `combat_reach`=0.645 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.2, `combat_reach`=0.04 WHERE `modelid`=34086; -- 34086
UPDATE `creature_model_info` SET `bounding_radius`=0.2, `combat_reach`=0.2, `gender`=0 WHERE `modelid`=32721; -- 32721
UPDATE `creature_model_info` SET `bounding_radius`=0.2, `combat_reach`=40 WHERE `modelid`=36493; -- 36493
UPDATE `creature_model_info` SET `bounding_radius`=0.2015, `combat_reach`=0.65 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.20305, `combat_reach`=0.655 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5 WHERE `modelid`=10480; -- 10480
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5 WHERE `modelid`=10486; -- 10486
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5 WHERE `modelid`=18121; -- 18121
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5 WHERE `modelid`=23111; -- 23111
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=15193; -- 15193
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30337; -- 30337
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35937; -- 35937
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=29760; -- 29760
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=29826; -- 29826
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=29897; -- 29897
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30049; -- 30049
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30050; -- 30050
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30092; -- 30092
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30209; -- 30209
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30220; -- 30220
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30225; -- 30225
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30289; -- 30289
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30304; -- 30304
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30717; -- 30717
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30820; -- 30820
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=31178; -- 31178
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=32014; -- 32014
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=32806; -- 32806
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33474; -- 33474
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34089; -- 34089
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34092; -- 34092
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34103; -- 34103
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34766; -- 34766
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=36140; -- 36140
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=36532; -- 36532
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=36732; -- 36732
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=37236; -- 37236
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=37881; -- 37881
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=38715; -- 38715
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=39155; -- 39155
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=39531; -- 39531
UPDATE `creature_model_info` SET `bounding_radius`=0.208, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=39600; -- 39600
UPDATE `creature_model_info` SET `bounding_radius`=0.21, `combat_reach`=1.5 WHERE `modelid`=29885; -- 29885
UPDATE `creature_model_info` SET `bounding_radius`=0.2138885, `combat_reach`=0.7 WHERE `modelid`=22597; -- 22597
UPDATE `creature_model_info` SET `bounding_radius`=0.217, `combat_reach`=0.7 WHERE `modelid`=35008; -- 35008
UPDATE `creature_model_info` SET `bounding_radius`=0.217, `combat_reach`=1.5 WHERE `modelid`=15507; -- 15507
UPDATE `creature_model_info` SET `bounding_radius`=0.217, `combat_reach`=3.5 WHERE `modelid`=39692; -- 39692
UPDATE `creature_model_info` SET `bounding_radius`=0.2184, `combat_reach`=1.575, `gender`=1 WHERE `modelid`=37105; -- 37105
UPDATE `creature_model_info` SET `bounding_radius`=0.2184, `combat_reach`=1.575, `gender`=1 WHERE `modelid`=37114; -- 37114
UPDATE `creature_model_info` SET `bounding_radius`=0.2205, `combat_reach`=0.945 WHERE `modelid`=1955; -- 1955
UPDATE `creature_model_info` SET `bounding_radius`=0.220678, `combat_reach`=0.5044068 WHERE `modelid`=6368; -- 6368
UPDATE `creature_model_info` SET `bounding_radius`=0.2232, `combat_reach`=0.72 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.225, `combat_reach`=3 WHERE `modelid`=31701; -- 31701
UPDATE `creature_model_info` SET `bounding_radius`=0.22785, `combat_reach`=0.735 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.22785, `combat_reach`=0.735 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `bounding_radius`=0.2294, `combat_reach`=0.74 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.2325, `combat_reach`=0.75 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `bounding_radius`=0.2325, `combat_reach`=1.125 WHERE `modelid`=39830; -- 39830
UPDATE `creature_model_info` SET `bounding_radius`=0.2325, `combat_reach`=1.125 WHERE `modelid`=39853; -- 39853
UPDATE `creature_model_info` SET `bounding_radius`=0.2325, `combat_reach`=1.5 WHERE `modelid`=33009; -- 33009
UPDATE `creature_model_info` SET `bounding_radius`=0.2325, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=22732; -- 22732
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5 WHERE `modelid`=15653; -- 15653
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5 WHERE `modelid`=20006; -- 20006
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5 WHERE `modelid`=23196; -- 23196
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5 WHERE `modelid`=24308; -- 24308
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=29902; -- 29902
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30383; -- 30383
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30675; -- 30675
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=31599; -- 31599
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=32693; -- 32693
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33031; -- 33031
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33091; -- 33091
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33117; -- 33117
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33247; -- 33247
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33295; -- 33295
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33623; -- 33623
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34099; -- 34099
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=36083; -- 36083
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=36731; -- 36731
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=37222; -- 37222
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=37223; -- 37223
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=38724; -- 38724
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=39614; -- 39614
UPDATE `creature_model_info` SET `bounding_radius`=0.2396136, `combat_reach`=1.566102 WHERE `modelid`=9021; -- 9021
UPDATE `creature_model_info` SET `bounding_radius`=0.244448, `combat_reach`=2.4 WHERE `modelid`=38265; -- 38265
UPDATE `creature_model_info` SET `bounding_radius`=0.2448, `combat_reach`=1.2 WHERE `modelid`=28097; -- 28097
UPDATE `creature_model_info` SET `bounding_radius`=0.248, `combat_reach`=1.2 WHERE `modelid`=38064; -- 38064
UPDATE `creature_model_info` SET `bounding_radius`=0.248, `combat_reach`=2.4 WHERE `modelid`=32565; -- 32565
UPDATE `creature_model_info` SET `bounding_radius`=0.248, `combat_reach`=2.4 WHERE `modelid`=39567; -- 39567
UPDATE `creature_model_info` SET `bounding_radius`=0.24895, `combat_reach`=0.975 WHERE `modelid`=19271; -- 19271
UPDATE `creature_model_info` SET `bounding_radius`=0.25, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.2596, `combat_reach`=1.65 WHERE `modelid`=19534; -- 19534
UPDATE `creature_model_info` SET `bounding_radius`=0.2596, `combat_reach`=1.65, `gender`=1 WHERE `modelid`=37237; -- 37237
UPDATE `creature_model_info` SET `bounding_radius`=0.2601, `combat_reach`=1.275 WHERE `modelid`=21288; -- 21288
UPDATE `creature_model_info` SET `bounding_radius`=0.2625, `combat_reach`=0.375 WHERE `modelid`=35803; -- 35803
UPDATE `creature_model_info` SET `bounding_radius`=0.275, `combat_reach`=0.55 WHERE `modelid`=26981; -- 26981
UPDATE `creature_model_info` SET `bounding_radius`=0.279, `combat_reach`=1.5 WHERE `modelid`=30301; -- 30301
UPDATE `creature_model_info` SET `bounding_radius`=0.279, `combat_reach`=1.5 WHERE `modelid`=30302; -- 30302
UPDATE `creature_model_info` SET `bounding_radius`=0.28, `combat_reach`=0.8 WHERE `modelid`=19029; -- 19029
UPDATE `creature_model_info` SET `bounding_radius`=0.28, `combat_reach`=0.8 WHERE `modelid`=36148; -- 36148
UPDATE `creature_model_info` SET `bounding_radius`=0.28, `combat_reach`=0.8 WHERE `modelid`=36150; -- 36150
UPDATE `creature_model_info` SET `bounding_radius`=0.28, `combat_reach`=0.8 WHERE `modelid`=36152; -- 36152
UPDATE `creature_model_info` SET `bounding_radius`=0.28, `combat_reach`=1.2 WHERE `modelid`=16724; -- 16724
UPDATE `creature_model_info` SET `bounding_radius`=0.28, `combat_reach`=1.2 WHERE `modelid`=4566; -- 4566
UPDATE `creature_model_info` SET `bounding_radius`=0.2832, `combat_reach`=1.8 WHERE `modelid`=12021; -- 12021
UPDATE `creature_model_info` SET `bounding_radius`=0.2832, `combat_reach`=1.8 WHERE `modelid`=14294; -- 14294
UPDATE `creature_model_info` SET `bounding_radius`=0.2832, `combat_reach`=1.8 WHERE `modelid`=14295; -- 14295
UPDATE `creature_model_info` SET `bounding_radius`=0.2832, `combat_reach`=1.8 WHERE `modelid`=18090; -- 18090
UPDATE `creature_model_info` SET `bounding_radius`=0.2832, `combat_reach`=1.8 WHERE `modelid`=9867; -- 9867
UPDATE `creature_model_info` SET `bounding_radius`=0.2832, `combat_reach`=1.8 WHERE `modelid`=9868; -- 9868
UPDATE `creature_model_info` SET `bounding_radius`=0.2832, `combat_reach`=1.8 WHERE `modelid`=9870; -- 9870
UPDATE `creature_model_info` SET `bounding_radius`=0.2832, `combat_reach`=1.8 WHERE `modelid`=9874; -- 9874
UPDATE `creature_model_info` SET `bounding_radius`=0.2832, `combat_reach`=1.8 WHERE `modelid`=9876; -- 9876
UPDATE `creature_model_info` SET `bounding_radius`=0.2832, `combat_reach`=1.8 WHERE `modelid`=9879; -- 9879
UPDATE `creature_model_info` SET `bounding_radius`=0.2832, `combat_reach`=1.8 WHERE `modelid`=9880; -- 9880
UPDATE `creature_model_info` SET `bounding_radius`=0.2832, `combat_reach`=1.8 WHERE `modelid`=9882; -- 9882
UPDATE `creature_model_info` SET `bounding_radius`=0.2832, `combat_reach`=1.8 WHERE `modelid`=9883; -- 9883
UPDATE `creature_model_info` SET `bounding_radius`=0.2832, `combat_reach`=1.8 WHERE `modelid`=9884; -- 9884
UPDATE `creature_model_info` SET `bounding_radius`=0.2832, `combat_reach`=1.8 WHERE `modelid`=9886; -- 9886
UPDATE `creature_model_info` SET `bounding_radius`=0.2907, `combat_reach`=1.425, `gender`=0 WHERE `modelid`=29619; -- 29619
UPDATE `creature_model_info` SET `bounding_radius`=0.2907, `combat_reach`=1.425, `gender`=1 WHERE `modelid`=28529; -- 28529
UPDATE `creature_model_info` SET `bounding_radius`=0.295, `combat_reach`=1.875 WHERE `modelid`=31210; -- 31210
UPDATE `creature_model_info` SET `bounding_radius`=0.2951387, `combat_reach`=1.275 WHERE `modelid`=27651; -- 27651
UPDATE `creature_model_info` SET `bounding_radius`=0.3, `combat_reach`=0.6, `gender`=1 WHERE `modelid`=13069; -- 13069
UPDATE `creature_model_info` SET `bounding_radius`=0.3, `combat_reach`=1 WHERE `modelid`=35979; -- 35979
UPDATE `creature_model_info` SET `bounding_radius`=0.3, `combat_reach`=1, `gender`=0 WHERE `modelid`=20041; -- 20041
UPDATE `creature_model_info` SET `bounding_radius`=0.3, `combat_reach`=1.875 WHERE `modelid`=37031; -- 37031
UPDATE `creature_model_info` SET `bounding_radius`=0.3, `combat_reach`=11, `gender`=0 WHERE `modelid`=32911; -- 32911
UPDATE `creature_model_info` SET `bounding_radius`=0.3, `combat_reach`=3 WHERE `modelid`=29073; -- 29073
UPDATE `creature_model_info` SET `bounding_radius`=0.3, `combat_reach`=50, `gender`=0 WHERE `modelid`=34135; -- 34135
UPDATE `creature_model_info` SET `bounding_radius`=0.3016, `combat_reach`=2.175, `gender`=0 WHERE `modelid`=31591; -- 31591
UPDATE `creature_model_info` SET `bounding_radius`=0.305, `combat_reach`=3.5 WHERE `modelid`=38798; -- 38798
UPDATE `creature_model_info` SET `bounding_radius`=0.305556, `combat_reach`=2.5 WHERE `modelid`=37993; -- 37993
UPDATE `creature_model_info` SET `bounding_radius`=0.30556, `combat_reach`=5 WHERE `modelid`=38012; -- 38012
UPDATE `creature_model_info` SET `bounding_radius`=0.30556, `combat_reach`=5 WHERE `modelid`=38443; -- 38443
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=10484; -- 10484
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=10546; -- 10546
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=10547; -- 10547
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=10668; -- 10668
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=14381; -- 14381
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=14530; -- 14530
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=15688; -- 15688
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=15959; -- 15959
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=16740; -- 16740
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=18667; -- 18667
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=19918; -- 19918
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=21706; -- 21706
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=2225; -- 2225
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=23448; -- 23448
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=23449; -- 23449
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=24982; -- 24982
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=25142; -- 25142
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=25433; -- 25433
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=26247; -- 26247
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=26653; -- 26653
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=28538; -- 28538
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=29603; -- 29603
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=29759; -- 29759
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=29896; -- 29896
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=29904; -- 29904
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=30048; -- 30048
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=31195; -- 31195
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=4773; -- 4773
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=4774; -- 4774
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=6675; -- 6675
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=6676; -- 6676
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=6709; -- 6709
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=7334; -- 7334
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=9293; -- 9293
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=9711; -- 9711
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=9727; -- 9727
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=29246; -- 29246
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=29301; -- 29301
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=29593; -- 29593
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=29694; -- 29694
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=29758; -- 29758
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=29762; -- 29762
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=29906; -- 29906
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30052; -- 30052
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30231; -- 30231
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30232; -- 30232
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30275; -- 30275
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30276; -- 30276
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30335; -- 30335
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30502; -- 30502
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30546; -- 30546
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30719; -- 30719
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31431; -- 31431
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31432; -- 31432
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31567; -- 31567
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31601; -- 31601
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31604; -- 31604
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31928; -- 31928
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31929; -- 31929
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31930; -- 31930
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31931; -- 31931
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31975; -- 31975
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31976; -- 31976
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31977; -- 31977
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31978; -- 31978
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32011; -- 32011
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32012; -- 32012
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32195; -- 32195
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32652; -- 32652
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32669; -- 32669
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32871; -- 32871
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32875; -- 32875
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32876; -- 32876
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33160; -- 33160
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33243; -- 33243
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33298; -- 33298
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33478; -- 33478
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34088; -- 34088
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34102; -- 34102
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34553; -- 34553
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34917; -- 34917
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35046; -- 35046
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35308; -- 35308
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35309; -- 35309
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35436; -- 35436
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35533; -- 35533
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35588; -- 35588
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35723; -- 35723
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35938; -- 35938
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36070; -- 36070
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36071; -- 36071
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36155; -- 36155
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36181; -- 36181
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36379; -- 36379
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36380; -- 36380
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36381; -- 36381
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36382; -- 36382
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36746; -- 36746
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36767; -- 36767
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36784; -- 36784
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36854; -- 36854
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37226; -- 37226
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37227; -- 37227
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37228; -- 37228
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37235; -- 37235
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37249; -- 37249
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37277; -- 37277
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37280; -- 37280
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37375; -- 37375
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37377; -- 37377
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37391; -- 37391
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37879; -- 37879
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=38050; -- 38050
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=38602; -- 38602
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=38714; -- 38714
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=38717; -- 38717
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=38723; -- 38723
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=39599; -- 39599
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=28520; -- 28520
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=28530; -- 28530
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=32877; -- 32877
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33115; -- 33115
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33116; -- 33116
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33199; -- 33199
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33481; -- 33481
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34094; -- 34094
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=35997; -- 35997
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=36069; -- 36069
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=36182; -- 36182
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=37766; -- 37766
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=38734; -- 38734
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=39606; -- 39606
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=7 WHERE `modelid`=28841; -- 28841
UPDATE `creature_model_info` SET `bounding_radius`=0.3068, `combat_reach`=1.95 WHERE `modelid`=14301; -- 14301
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=1 WHERE `modelid`=18632; -- 18632
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=1 WHERE `modelid`=25630; -- 25630
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=1 WHERE `modelid`=25658; -- 25658
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=1 WHERE `modelid`=25815; -- 25815
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=1 WHERE `modelid`=32500; -- 32500
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=1 WHERE `modelid`=32708; -- 32708
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=1 WHERE `modelid`=33719; -- 33719
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=1, `gender`=1 WHERE `modelid`=39623; -- 39623
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=1.5 WHERE `modelid`=28870; -- 28870
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=1.5 WHERE `modelid`=32811; -- 32811
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=1.5 WHERE `modelid`=35168; -- 35168
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=1.5 WHERE `modelid`=37369; -- 37369
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=25755; -- 25755
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=20 WHERE `modelid`=28817; -- 28817
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=3 WHERE `modelid`=32221; -- 32221
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=3 WHERE `modelid`=36702; -- 36702
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=3, `gender`=1 WHERE `modelid`=26096; -- 26096
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=33 WHERE `modelid`=28951; -- 28951
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=5 WHERE `modelid`=28979; -- 28979
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=5 WHERE `modelid`=36475; -- 36475
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=5 WHERE `modelid`=39277; -- 39277
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=5 WHERE `modelid`=39841; -- 39841
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=5 WHERE `modelid`=40117; -- 40117
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=6 WHERE `modelid`=39524; -- 39524
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=7.7 WHERE `modelid`=28831; -- 28831
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=7.7 WHERE `modelid`=35775; -- 35775
UPDATE `creature_model_info` SET `bounding_radius`=0.3123, `combat_reach`=1.35, `gender`=0 WHERE `modelid`=40165; -- 40165
UPDATE `creature_model_info` SET `bounding_radius`=0.3124998, `combat_reach`=1.35, `gender`=0 WHERE `modelid`=36777; -- 36777
UPDATE `creature_model_info` SET `bounding_radius`=0.3124998, `combat_reach`=1.35, `gender`=0 WHERE `modelid`=36779; -- 36779
UPDATE `creature_model_info` SET `bounding_radius`=0.3213, `combat_reach`=1.575, `gender`=0 WHERE `modelid`=29675; -- 29675
UPDATE `creature_model_info` SET `bounding_radius`=0.3213, `combat_reach`=1.575, `gender`=0 WHERE `modelid`=30215; -- 30215
UPDATE `creature_model_info` SET `bounding_radius`=0.3213, `combat_reach`=1.575, `gender`=0 WHERE `modelid`=30718; -- 30718
UPDATE `creature_model_info` SET `bounding_radius`=0.3213, `combat_reach`=1.575, `gender`=0 WHERE `modelid`=30730; -- 30730
UPDATE `creature_model_info` SET `bounding_radius`=0.3213, `combat_reach`=1.575, `gender`=0 WHERE `modelid`=30735; -- 30735
UPDATE `creature_model_info` SET `bounding_radius`=0.3213, `combat_reach`=1.575, `gender`=0 WHERE `modelid`=30785; -- 30785
UPDATE `creature_model_info` SET `bounding_radius`=0.3213, `combat_reach`=1.575, `gender`=0 WHERE `modelid`=30819; -- 30819
UPDATE `creature_model_info` SET `bounding_radius`=0.3213, `combat_reach`=1.575, `gender`=0 WHERE `modelid`=33686; -- 33686
UPDATE `creature_model_info` SET `bounding_radius`=0.3213, `combat_reach`=1.575, `gender`=1 WHERE `modelid`=31668; -- 31668
UPDATE `creature_model_info` SET `bounding_radius`=0.3255, `combat_reach`=1.575 WHERE `modelid`=2169; -- 2169
UPDATE `creature_model_info` SET `bounding_radius`=0.3262712, `combat_reach`=0.9788135 WHERE `modelid`=7470; -- 7470
UPDATE `creature_model_info` SET `bounding_radius`=0.33, `combat_reach`=1.1 WHERE `modelid`=19607; -- 19607
UPDATE `creature_model_info` SET `bounding_radius`=0.3304, `combat_reach`=2.1 WHERE `modelid`=24770; -- 24770
UPDATE `creature_model_info` SET `bounding_radius`=0.3328, `combat_reach`=2.4, `gender`=1 WHERE `modelid`=31789; -- 31789
UPDATE `creature_model_info` SET `bounding_radius`=0.3330508, `combat_reach`=0.9991525 WHERE `modelid`=7470; -- 7470
UPDATE `creature_model_info` SET `bounding_radius`=0.3330508, `combat_reach`=0.9991525 WHERE `modelid`=9028; -- 9028
UPDATE `creature_model_info` SET `bounding_radius`=0.334305, `combat_reach`=1.63875, `gender`=0 WHERE `modelid`=36515; -- 36515
UPDATE `creature_model_info` SET `bounding_radius`=0.3347458, `combat_reach`=1.004237 WHERE `modelid`=9029; -- 9029
UPDATE `creature_model_info` SET `bounding_radius`=0.3347458, `combat_reach`=1.004237 WHERE `modelid`=9354; -- 9354
UPDATE `creature_model_info` SET `bounding_radius`=0.3366, `combat_reach`=1.65 WHERE `modelid`=14421; -- 14421
UPDATE `creature_model_info` SET `bounding_radius`=0.3366, `combat_reach`=1.65 WHERE `modelid`=25660; -- 25660
UPDATE `creature_model_info` SET `bounding_radius`=0.3366, `combat_reach`=1.65 WHERE `modelid`=27151; -- 27151
UPDATE `creature_model_info` SET `bounding_radius`=0.3366, `combat_reach`=1.65 WHERE `modelid`=9291; -- 9291
UPDATE `creature_model_info` SET `bounding_radius`=0.3366, `combat_reach`=1.65, `gender`=1 WHERE `modelid`=31868; -- 31868
UPDATE `creature_model_info` SET `bounding_radius`=0.3366, `combat_reach`=1.65, `gender`=1 WHERE `modelid`=35709; -- 35709
UPDATE `creature_model_info` SET `bounding_radius`=0.341, `combat_reach`=1.5 WHERE `modelid`=15593; -- 15593
UPDATE `creature_model_info` SET `bounding_radius`=0.341, `combat_reach`=3.3 WHERE `modelid`=39377; -- 39377
UPDATE `creature_model_info` SET `bounding_radius`=0.341, `combat_reach`=3.3 WHERE `modelid`=39378; -- 39378
UPDATE `creature_model_info` SET `bounding_radius`=0.3415254, `combat_reach`=1.024576 WHERE `modelid`=13096; -- 13096
UPDATE `creature_model_info` SET `bounding_radius`=0.3447, `combat_reach`=1.35 WHERE `modelid`=19516; -- 19516
UPDATE `creature_model_info` SET `bounding_radius`=0.3447, `combat_reach`=1.35 WHERE `modelid`=19517; -- 19517
UPDATE `creature_model_info` SET `bounding_radius`=0.3449152, `combat_reach`=1.034746 WHERE `modelid`=9469; -- 9469
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5 WHERE `modelid`=17802; -- 17802
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5 WHERE `modelid`=21311; -- 21311
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5 WHERE `modelid`=23451; -- 23451
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5 WHERE `modelid`=26460; -- 26460
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5 WHERE `modelid`=4119; -- 4119
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5 WHERE `modelid`=4597; -- 4597
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5 WHERE `modelid`=5088; -- 5088
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5 WHERE `modelid`=5465; -- 5465
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5 WHERE `modelid`=8663; -- 8663
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=29895; -- 29895
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30334; -- 30334
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31433; -- 31433
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32015; -- 32015
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32620; -- 32620
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34535; -- 34535
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34536; -- 34536
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34537; -- 34537
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34538; -- 34538
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34539; -- 34539
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35273; -- 35273
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35277; -- 35277
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35511; -- 35511
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37216; -- 37216
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37217; -- 37217
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37218; -- 37218
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=38721; -- 38721
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34540; -- 34540
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=35701; -- 35701
UPDATE `creature_model_info` SET `bounding_radius`=0.347, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=36695; -- 36695
UPDATE `creature_model_info` SET `bounding_radius`=0.3472, `combat_reach`=1.12 WHERE `modelid`=24978; -- 24978
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=0.5, `gender`=0 WHERE `modelid`=32123; -- 32123
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=20761; -- 20761
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=21299; -- 21299
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22053; -- 22053
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22054; -- 22054
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22056; -- 22056
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22060; -- 22060
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22061; -- 22061
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22062; -- 22062
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22064; -- 22064
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22069; -- 22069
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22070; -- 22070
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22071; -- 22071
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22073; -- 22073
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22074; -- 22074
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22077; -- 22077
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22078; -- 22078
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22081; -- 22081
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22082; -- 22082
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22083; -- 22083
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22085; -- 22085
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=22086; -- 22086
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=28267; -- 28267
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=28268; -- 28268
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=28269; -- 28269
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=28270; -- 28270
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=28271; -- 28271
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=28272; -- 28272
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=28273; -- 28273
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=28274; -- 28274
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=28277; -- 28277
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=28278; -- 28278
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=28280; -- 28280
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=31211; -- 31211
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=32053; -- 32053
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=32350; -- 32350
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5 WHERE `modelid`=32352; -- 32352
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30234; -- 30234
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30293; -- 30293
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30294; -- 30294
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30295; -- 30295
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32951; -- 32951
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33508; -- 33508
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34713; -- 34713
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34714; -- 34714
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34728; -- 34728
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36154; -- 36154
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36160; -- 36160
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36183; -- 36183
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36186; -- 36186
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36188; -- 36188
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36189; -- 36189
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36190; -- 36190
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36771; -- 36771
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36772; -- 36772
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36778; -- 36778
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36800; -- 36800
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=38722; -- 38722
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33552; -- 33552
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=36161; -- 36161
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=36184; -- 36184
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=36742; -- 36742
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=36802; -- 36802
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=36803; -- 36803
UPDATE `creature_model_info` SET `bounding_radius`=0.347222, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=38719; -- 38719
UPDATE `creature_model_info` SET `bounding_radius`=0.34875, `combat_reach`=7.875 WHERE `modelid`=39094; -- 39094
UPDATE `creature_model_info` SET `bounding_radius`=0.35, `combat_reach`=0.8, `gender`=0 WHERE `modelid`=32070; -- 32070
UPDATE `creature_model_info` SET `bounding_radius`=0.35, `combat_reach`=1 WHERE `modelid`=31773; -- 31773
UPDATE `creature_model_info` SET `bounding_radius`=0.35, `combat_reach`=1 WHERE `modelid`=31984; -- 31984
UPDATE `creature_model_info` SET `bounding_radius`=0.35, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.35, `combat_reach`=3.5 WHERE `modelid`=33725; -- 33725
UPDATE `creature_model_info` SET `bounding_radius`=0.35, `combat_reach`=4, `gender`=0 WHERE `modelid`=12189; -- 12189
UPDATE `creature_model_info` SET `bounding_radius`=0.351394, `combat_reach`=1.15 WHERE `modelid`=32578; -- 32578
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725 WHERE `modelid`=11208; -- 11208
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725 WHERE `modelid`=11210; -- 11210
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725 WHERE `modelid`=14410; -- 14410
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725 WHERE `modelid`=14411; -- 14411
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725 WHERE `modelid`=14529; -- 14529
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725 WHERE `modelid`=21310; -- 21310
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725 WHERE `modelid`=23446; -- 23446
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725, `gender`=0 WHERE `modelid`=30336; -- 30336
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725, `gender`=0 WHERE `modelid`=31434; -- 31434
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725, `gender`=0 WHERE `modelid`=32016; -- 32016
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725, `gender`=0 WHERE `modelid`=33024; -- 33024
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725, `gender`=0 WHERE `modelid`=33062; -- 33062
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725, `gender`=0 WHERE `modelid`=34093; -- 34093
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725, `gender`=0 WHERE `modelid`=37878; -- 37878
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725, `gender`=0 WHERE `modelid`=38720; -- 38720
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725, `gender`=1 WHERE `modelid`=31666; -- 31666
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725, `gender`=1 WHERE `modelid`=37884; -- 37884
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725, `gender`=1 WHERE `modelid`=38718; -- 38718
UPDATE `creature_model_info` SET `bounding_radius`=0.354, `combat_reach`=1.5 WHERE `modelid`=37531; -- 37531
UPDATE `creature_model_info` SET `bounding_radius`=0.364, `combat_reach`=2.625 WHERE `modelid`=26448; -- 26448
UPDATE `creature_model_info` SET `bounding_radius`=0.3672, `combat_reach`=1.8 WHERE `modelid`=11270; -- 11270
UPDATE `creature_model_info` SET `bounding_radius`=0.3672, `combat_reach`=1.8 WHERE `modelid`=25661; -- 25661
UPDATE `creature_model_info` SET `bounding_radius`=0.3672, `combat_reach`=1.8 WHERE `modelid`=6439; -- 6439
UPDATE `creature_model_info` SET `bounding_radius`=0.3672, `combat_reach`=1.8 WHERE `modelid`=6687; -- 6687
UPDATE `creature_model_info` SET `bounding_radius`=0.3672, `combat_reach`=1.8 WHERE `modelid`=9732; -- 9732
UPDATE `creature_model_info` SET `bounding_radius`=0.3672, `combat_reach`=1.8, `gender`=0 WHERE `modelid`=36136; -- 36136
UPDATE `creature_model_info` SET `bounding_radius`=0.3672, `combat_reach`=1.8, `gender`=0 WHERE `modelid`=36322; -- 36322
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.2 WHERE `modelid`=24994; -- 24994
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.2 WHERE `modelid`=26177; -- 26177
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.2 WHERE `modelid`=27358; -- 27358
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.2 WHERE `modelid`=32794; -- 32794
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5 WHERE `modelid`=13278; -- 13278
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5 WHERE `modelid`=13280; -- 13280
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5 WHERE `modelid`=16967; -- 16967
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5 WHERE `modelid`=16968; -- 16968
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5 WHERE `modelid`=20136; -- 20136
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5 WHERE `modelid`=21398; -- 21398
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5 WHERE `modelid`=23275; -- 23275
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5 WHERE `modelid`=23453; -- 23453
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5 WHERE `modelid`=23933; -- 23933
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5 WHERE `modelid`=26410; -- 26410
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5 WHERE `modelid`=26508; -- 26508
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5 WHERE `modelid`=26652; -- 26652
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5 WHERE `modelid`=27044; -- 27044
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5 WHERE `modelid`=29901; -- 29901
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5 WHERE `modelid`=30674; -- 30674
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=29900; -- 29900
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30280; -- 30280
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30673; -- 30673
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30693; -- 30693
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31611; -- 31611
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32198; -- 32198
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32691; -- 32691
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32866; -- 32866
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32869; -- 32869
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32870; -- 32870
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32873; -- 32873
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33030; -- 33030
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33090; -- 33090
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33120; -- 33120
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33249; -- 33249
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33255; -- 33255
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33281; -- 33281
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33343; -- 33343
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33503; -- 33503
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33505; -- 33505
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34098; -- 34098
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35384; -- 35384
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35939; -- 35939
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35975; -- 35975
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36081; -- 36081
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36082; -- 36082
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36747; -- 36747
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37099; -- 37099
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37213; -- 37213
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37214; -- 37214
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37215; -- 37215
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37238; -- 37238
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37274; -- 37274
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37276; -- 37276
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37278; -- 37278
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=38730; -- 38730
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=39613; -- 39613
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=3.6 WHERE `modelid`=39564; -- 39564
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=3.6 WHERE `modelid`=39566; -- 39566
UPDATE `creature_model_info` SET `bounding_radius`=0.375, `combat_reach`=0.75 WHERE `modelid`=17612; -- 17612
UPDATE `creature_model_info` SET `bounding_radius`=0.375, `combat_reach`=0.75 WHERE `modelid`=19021; -- 19021
UPDATE `creature_model_info` SET `bounding_radius`=0.375, `combat_reach`=0.75 WHERE `modelid`=26055; -- 26055
UPDATE `creature_model_info` SET `bounding_radius`=0.375, `combat_reach`=0.75, `gender`=0 WHERE `modelid`=21040; -- 21040
UPDATE `creature_model_info` SET `bounding_radius`=0.378975, `combat_reach`=1.2225 WHERE `modelid`=23945; -- 23945
UPDATE `creature_model_info` SET `bounding_radius`=0.3817, `combat_reach`=1.65 WHERE `modelid`=19535; -- 19535
UPDATE `creature_model_info` SET `bounding_radius`=0.3817, `combat_reach`=1.65, `gender`=0 WHERE `modelid`=35270; -- 35270
UPDATE `creature_model_info` SET `bounding_radius`=0.3817, `combat_reach`=1.65, `gender`=0 WHERE `modelid`=35272; -- 35272
UPDATE `creature_model_info` SET `bounding_radius`=0.3817, `combat_reach`=1.65, `gender`=1 WHERE `modelid`=35958; -- 35958
UPDATE `creature_model_info` SET `bounding_radius`=0.3819442, `combat_reach`=1.65, `gender`=0 WHERE `modelid`=36780; -- 36780
UPDATE `creature_model_info` SET `bounding_radius`=0.3819442, `combat_reach`=1.65, `gender`=0 WHERE `modelid`=36781; -- 36781
UPDATE `creature_model_info` SET `bounding_radius`=0.3825, `combat_reach`=1.875 WHERE `modelid`=28403; -- 28403
UPDATE `creature_model_info` SET `bounding_radius`=0.3825, `combat_reach`=1.875 WHERE `modelid`=29898; -- 29898
UPDATE `creature_model_info` SET `bounding_radius`=0.3825, `combat_reach`=1.875 WHERE `modelid`=31208; -- 31208
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=10475; -- 10475
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=15539; -- 15539
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=18258; -- 18258
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=19192; -- 19192
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=19515; -- 19515
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=20778; -- 20778
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=20779; -- 20779
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=21508; -- 21508
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=21681; -- 21681
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=22113; -- 22113
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=22430; -- 22430
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=22540; -- 22540
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=22781; -- 22781
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=22834; -- 22834
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=22836; -- 22836
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=22839; -- 22839
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=22861; -- 22861
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=22894; -- 22894
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=22904; -- 22904
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=22923; -- 22923
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=23450; -- 23450
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=23468; -- 23468
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=23559; -- 23559
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=23714; -- 23714
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=25295; -- 25295
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=26654; -- 26654
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=30679; -- 30679
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=30691; -- 30691
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=30838; -- 30838
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=30878; -- 30878
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=30880; -- 30880
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=31013; -- 31013
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=4121; -- 4121
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5 WHERE `modelid`=8054; -- 8054
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=18145; -- 18145
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=22542; -- 22542
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=23557; -- 23557
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30056; -- 30056
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30102; -- 30102
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30103; -- 30103
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30291; -- 30291
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30292; -- 30292
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30678; -- 30678
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30680; -- 30680
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30714; -- 30714
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30720; -- 30720
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30769; -- 30769
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30786; -- 30786
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32692; -- 32692
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32862; -- 32862
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32872; -- 32872
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33190; -- 33190
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33244; -- 33244
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33687; -- 33687
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33749; -- 33749
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34090; -- 34090
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34101; -- 34101
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34190; -- 34190
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34191; -- 34191
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34192; -- 34192
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34193; -- 34193
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34451; -- 34451
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34453; -- 34453
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34455; -- 34455
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34456; -- 34456
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34461; -- 34461
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34462; -- 34462
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34463; -- 34463
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34466; -- 34466
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34467; -- 34467
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34470; -- 34470
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34471; -- 34471
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34474; -- 34474
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34475; -- 34475
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34479; -- 34479
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34480; -- 34480
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34487; -- 34487
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34491; -- 34491
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34492; -- 34492
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34495; -- 34495
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34496; -- 34496
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34497; -- 34497
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34498; -- 34498
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35532; -- 35532
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35560; -- 35560
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35692; -- 35692
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35702; -- 35702
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35941; -- 35941
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36853; -- 36853
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36855; -- 36855
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=38726; -- 38726
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=38729; -- 38729
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=39619; -- 39619
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30054; -- 30054
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30290; -- 30290
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30677; -- 30677
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30692; -- 30692
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30766; -- 30766
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30767; -- 30767
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=32199; -- 32199
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33246; -- 33246
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33250; -- 33250
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34452; -- 34452
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34454; -- 34454
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34457; -- 34457
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34458; -- 34458
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34460; -- 34460
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34464; -- 34464
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34465; -- 34465
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34468; -- 34468
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34469; -- 34469
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34472; -- 34472
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34473; -- 34473
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34477; -- 34477
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34486; -- 34486
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34489; -- 34489
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34494; -- 34494
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=35550; -- 35550
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=35561; -- 35561
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=37398; -- 37398
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=37864; -- 37864
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=38727; -- 38727
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=38728; -- 38728
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=39618; -- 39618
UPDATE `creature_model_info` SET `bounding_radius`=0.38709, `combat_reach`=1.8975 WHERE `modelid`=27150; -- 27150
UPDATE `creature_model_info` SET `bounding_radius`=0.3875 WHERE `modelid`=12163; -- 12163
UPDATE `creature_model_info` SET `bounding_radius`=0.389, `combat_reach`=1.5 WHERE `modelid`=11209; -- 11209
UPDATE `creature_model_info` SET `bounding_radius`=0.389, `combat_reach`=1.5 WHERE `modelid`=11256; -- 11256
UPDATE `creature_model_info` SET `bounding_radius`=0.389, `combat_reach`=1.5 WHERE `modelid`=15689; -- 15689
UPDATE `creature_model_info` SET `bounding_radius`=0.389, `combat_reach`=1.5 WHERE `modelid`=15690; -- 15690
UPDATE `creature_model_info` SET `bounding_radius`=0.389, `combat_reach`=1.5 WHERE `modelid`=15692; -- 15692
UPDATE `creature_model_info` SET `bounding_radius`=0.389, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32013; -- 32013
UPDATE `creature_model_info` SET `bounding_radius`=0.389, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32251; -- 32251
UPDATE `creature_model_info` SET `bounding_radius`=0.389, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36847; -- 36847
UPDATE `creature_model_info` SET `bounding_radius`=0.389, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37761; -- 37761
UPDATE `creature_model_info` SET `bounding_radius`=0.389, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=38083; -- 38083
UPDATE `creature_model_info` SET `bounding_radius`=0.389, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=38769; -- 38769
UPDATE `creature_model_info` SET `bounding_radius`=0.389, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=39610; -- 39610
UPDATE `creature_model_info` SET `bounding_radius`=0.39 WHERE `modelid`=18848; -- 18848
UPDATE `creature_model_info` SET `bounding_radius`=0.391, `combat_reach`=1.725 WHERE `modelid`=29522; -- 29522
UPDATE `creature_model_info` SET `bounding_radius`=0.39525, `combat_reach`=1.275 WHERE `modelid`=23945; -- 23945
UPDATE `creature_model_info` SET `bounding_radius`=0.3978, `combat_reach`=1.95 WHERE `modelid`=21289; -- 21289
UPDATE `creature_model_info` SET `bounding_radius`=0.3978, `combat_reach`=1.95, `gender`=1 WHERE `modelid`=38864; -- 38864
UPDATE `creature_model_info` SET `bounding_radius`=0.3978, `combat_reach`=1.95, `gender`=1 WHERE `modelid`=38865; -- 38865
UPDATE `creature_model_info` SET `bounding_radius`=0.4012, `combat_reach`=2.55, `gender`=1 WHERE `modelid`=40068; -- 40068
UPDATE `creature_model_info` SET `bounding_radius`=0.403, `combat_reach`=1.3 WHERE `modelid`=24698; -- 24698
UPDATE `creature_model_info` SET `bounding_radius`=0.403, `combat_reach`=3.9 WHERE `modelid`=39565; -- 39565
UPDATE `creature_model_info` SET `bounding_radius`=0.408, `combat_reach`=1.8 WHERE `modelid`=29504; -- 29504
UPDATE `creature_model_info` SET `bounding_radius`=0.4092, `combat_reach`=1.65 WHERE `modelid`=13415; -- 13415
UPDATE `creature_model_info` SET `bounding_radius`=0.4092, `combat_reach`=1.65 WHERE `modelid`=19532; -- 19532
UPDATE `creature_model_info` SET `bounding_radius`=0.4092, `combat_reach`=1.65 WHERE `modelid`=25746; -- 25746
UPDATE `creature_model_info` SET `bounding_radius`=0.4092, `combat_reach`=1.65 WHERE `modelid`=29530; -- 29530
UPDATE `creature_model_info` SET `bounding_radius`=0.4092, `combat_reach`=1.65 WHERE `modelid`=30982; -- 30982
UPDATE `creature_model_info` SET `bounding_radius`=0.4092, `combat_reach`=1.65, `gender`=0 WHERE `modelid`=32532; -- 32532
UPDATE `creature_model_info` SET `bounding_radius`=0.4092, `combat_reach`=1.65, `gender`=0 WHERE `modelid`=32533; -- 32533
UPDATE `creature_model_info` SET `bounding_radius`=0.4092, `combat_reach`=1.65, `gender`=0 WHERE `modelid`=32534; -- 32534
UPDATE `creature_model_info` SET `bounding_radius`=0.4092, `combat_reach`=1.65, `gender`=0 WHERE `modelid`=32535; -- 32535
UPDATE `creature_model_info` SET `bounding_radius`=0.4092, `combat_reach`=1.65, `gender`=0 WHERE `modelid`=32880; -- 32880
UPDATE `creature_model_info` SET `bounding_radius`=0.4092, `combat_reach`=1.65, `gender`=0 WHERE `modelid`=33294; -- 33294
UPDATE `creature_model_info` SET `bounding_radius`=0.41, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.4125, `combat_reach`=0.825 WHERE `modelid`=24719; -- 24719
UPDATE `creature_model_info` SET `bounding_radius`=0.4131, `combat_reach`=2.025, `gender`=1 WHERE `modelid`=38896; -- 38896
UPDATE `creature_model_info` SET `bounding_radius`=0.4131, `combat_reach`=2.025, `gender`=1 WHERE `modelid`=38897; -- 38897
UPDATE `creature_model_info` SET `bounding_radius`=0.4131, `combat_reach`=2.025, `gender`=1 WHERE `modelid`=38904; -- 38904
UPDATE `creature_model_info` SET `bounding_radius`=0.4131, `combat_reach`=2.025, `gender`=1 WHERE `modelid`=38905; -- 38905
UPDATE `creature_model_info` SET `bounding_radius`=0.4154, `combat_reach`=1.34 WHERE `modelid`=24698; -- 24698
UPDATE `creature_model_info` SET `bounding_radius`=0.416, `combat_reach`=3, `gender`=1 WHERE `modelid`=31546; -- 31546
UPDATE `creature_model_info` SET `bounding_radius`=0.416, `combat_reach`=3, `gender`=1 WHERE `modelid`=39828; -- 39828
UPDATE `creature_model_info` SET `bounding_radius`=0.4164, `combat_reach`=1.8 WHERE `modelid`=7764; -- 7764
UPDATE `creature_model_info` SET `bounding_radius`=0.4166664, `combat_reach`=1.8 WHERE `modelid`=16578; -- 16578
UPDATE `creature_model_info` SET `bounding_radius`=0.4166664, `combat_reach`=1.8 WHERE `modelid`=16581; -- 16581
UPDATE `creature_model_info` SET `bounding_radius`=0.4166664, `combat_reach`=1.8 WHERE `modelid`=16584; -- 16584
UPDATE `creature_model_info` SET `bounding_radius`=0.4166664, `combat_reach`=1.8 WHERE `modelid`=17013; -- 17013
UPDATE `creature_model_info` SET `bounding_radius`=0.4166664, `combat_reach`=1.8 WHERE `modelid`=17183; -- 17183
UPDATE `creature_model_info` SET `bounding_radius`=0.4166664, `combat_reach`=1.8 WHERE `modelid`=17184; -- 17184
UPDATE `creature_model_info` SET `bounding_radius`=0.4166664, `combat_reach`=1.8 WHERE `modelid`=17189; -- 17189
UPDATE `creature_model_info` SET `bounding_radius`=0.4166664, `combat_reach`=1.8 WHERE `modelid`=17726; -- 17726
UPDATE `creature_model_info` SET `bounding_radius`=0.4166664, `combat_reach`=1.8 WHERE `modelid`=17727; -- 17727
UPDATE `creature_model_info` SET `bounding_radius`=0.4166664, `combat_reach`=1.8 WHERE `modelid`=28281; -- 28281
UPDATE `creature_model_info` SET `bounding_radius`=0.4166664, `combat_reach`=1.8 WHERE `modelid`=29683; -- 29683
UPDATE `creature_model_info` SET `bounding_radius`=0.4166664, `combat_reach`=1.8 WHERE `modelid`=29685; -- 29685
UPDATE `creature_model_info` SET `bounding_radius`=0.4166664, `combat_reach`=1.8 WHERE `modelid`=29686; -- 29686
UPDATE `creature_model_info` SET `bounding_radius`=0.4166664, `combat_reach`=1.8, `gender`=0 WHERE `modelid`=37696; -- 37696
UPDATE `creature_model_info` SET `bounding_radius`=0.417, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31539; -- 31539
UPDATE `creature_model_info` SET `bounding_radius`=0.417, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32311; -- 32311
UPDATE `creature_model_info` SET `bounding_radius`=0.417, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32312; -- 32312
UPDATE `creature_model_info` SET `bounding_radius`=0.417, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=32313; -- 32313
UPDATE `creature_model_info` SET `bounding_radius`=0.4182, `combat_reach`=1.845 WHERE `modelid`=25632; -- 25632
UPDATE `creature_model_info` SET `bounding_radius`=0.4182, `combat_reach`=1.845 WHERE `modelid`=25775; -- 25775
UPDATE `creature_model_info` SET `bounding_radius`=0.4213, `combat_reach`=1.65 WHERE `modelid`=19518; -- 19518
UPDATE `creature_model_info` SET `bounding_radius`=0.4213, `combat_reach`=1.65 WHERE `modelid`=28128; -- 28128
UPDATE `creature_model_info` SET `bounding_radius`=0.4213, `combat_reach`=1.65 WHERE `modelid`=28129; -- 28129
UPDATE `creature_model_info` SET `bounding_radius`=0.4213, `combat_reach`=1.65, `gender`=0 WHERE `modelid`=29507; -- 29507
UPDATE `creature_model_info` SET `bounding_radius`=0.4213, `combat_reach`=1.65, `gender`=0 WHERE `modelid`=37094; -- 37094
UPDATE `creature_model_info` SET `bounding_radius`=0.4213, `combat_reach`=1.65, `gender`=1 WHERE `modelid`=37021; -- 37021
UPDATE `creature_model_info` SET `bounding_radius`=0.4278, `combat_reach`=1.725, `gender`=0 WHERE `modelid`=37275; -- 37275
UPDATE `creature_model_info` SET `bounding_radius`=0.4279, `combat_reach`=1.65 WHERE `modelid`=14422; -- 14422
UPDATE `creature_model_info` SET `bounding_radius`=0.4279, `combat_reach`=1.65 WHERE `modelid`=19536; -- 19536
UPDATE `creature_model_info` SET `bounding_radius`=0.4279, `combat_reach`=1.65, `gender`=0 WHERE `modelid`=28528; -- 28528
UPDATE `creature_model_info` SET `bounding_radius`=0.43, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.4309, `combat_reach`=1.39 WHERE `modelid`=24698; -- 24698
UPDATE `creature_model_info` SET `bounding_radius`=0.434, `combat_reach`=1.4 WHERE `modelid`=32792; -- 32792
UPDATE `creature_model_info` SET `bounding_radius`=0.4340275, `combat_reach`=1.875 WHERE `modelid`=29059; -- 29059
UPDATE `creature_model_info` SET `bounding_radius`=0.4340275, `combat_reach`=1.875, `gender`=0 WHERE `modelid`=39907; -- 39907
UPDATE `creature_model_info` SET `bounding_radius`=0.4375, `combat_reach`=0.625 WHERE `modelid`=26479; -- 26479
UPDATE `creature_model_info` SET `bounding_radius`=0.4375, `combat_reach`=1, `gender`=0 WHERE `modelid`=32673; -- 32673
UPDATE `creature_model_info` SET `bounding_radius`=0.4464, `combat_reach`=1.8 WHERE `modelid`=10177; -- 10177
UPDATE `creature_model_info` SET `bounding_radius`=0.4464, `combat_reach`=1.8 WHERE `modelid`=14292; -- 14292
UPDATE `creature_model_info` SET `bounding_radius`=0.4464, `combat_reach`=1.8 WHERE `modelid`=14293; -- 14293
UPDATE `creature_model_info` SET `bounding_radius`=0.4464, `combat_reach`=1.8 WHERE `modelid`=16580; -- 16580
UPDATE `creature_model_info` SET `bounding_radius`=0.4464, `combat_reach`=1.8 WHERE `modelid`=20624; -- 20624
UPDATE `creature_model_info` SET `bounding_radius`=0.4464, `combat_reach`=1.8 WHERE `modelid`=7889; -- 7889
UPDATE `creature_model_info` SET `bounding_radius`=0.4464, `combat_reach`=1.8 WHERE `modelid`=9603; -- 9603
UPDATE `creature_model_info` SET `bounding_radius`=0.4464, `combat_reach`=1.8 WHERE `modelid`=9614; -- 9614
UPDATE `creature_model_info` SET `bounding_radius`=0.4464, `combat_reach`=1.8 WHERE `modelid`=9617; -- 9617
UPDATE `creature_model_info` SET `bounding_radius`=0.4464, `combat_reach`=1.8 WHERE `modelid`=9619; -- 9619
UPDATE `creature_model_info` SET `bounding_radius`=0.4464, `combat_reach`=1.8 WHERE `modelid`=9656; -- 9656
UPDATE `creature_model_info` SET `bounding_radius`=0.4464, `combat_reach`=1.8 WHERE `modelid`=9657; -- 9657
UPDATE `creature_model_info` SET `bounding_radius`=0.4464, `combat_reach`=1.8 WHERE `modelid`=9661; -- 9661
UPDATE `creature_model_info` SET `bounding_radius`=0.4464, `combat_reach`=1.8 WHERE `modelid`=9665; -- 9665
UPDATE `creature_model_info` SET `bounding_radius`=0.4464, `combat_reach`=1.8 WHERE `modelid`=9738; -- 9738
UPDATE `creature_model_info` SET `bounding_radius`=0.44735, `combat_reach`=1.725 WHERE `modelid`=11207; -- 11207
UPDATE `creature_model_info` SET `bounding_radius`=0.44735, `combat_reach`=1.725 WHERE `modelid`=14407; -- 14407
UPDATE `creature_model_info` SET `bounding_radius`=0.44735, `combat_reach`=1.725 WHERE `modelid`=14408; -- 14408
UPDATE `creature_model_info` SET `bounding_radius`=0.44735, `combat_reach`=1.725 WHERE `modelid`=14409; -- 14409
UPDATE `creature_model_info` SET `bounding_radius`=0.44735, `combat_reach`=1.725 WHERE `modelid`=14412; -- 14412
UPDATE `creature_model_info` SET `bounding_radius`=0.44735, `combat_reach`=1.725 WHERE `modelid`=14420; -- 14420
UPDATE `creature_model_info` SET `bounding_radius`=0.44735, `combat_reach`=1.725 WHERE `modelid`=15996; -- 15996
UPDATE `creature_model_info` SET `bounding_radius`=0.44925, `combat_reach`=0.9375 WHERE `modelid`=1749; -- 1749
UPDATE `creature_model_info` SET `bounding_radius`=0.45, `combat_reach`=1.5 WHERE `modelid`=39065; -- 39065
UPDATE `creature_model_info` SET `bounding_radius`=0.45, `combat_reach`=1.5 WHERE `modelid`=39066; -- 39066
UPDATE `creature_model_info` SET `bounding_radius`=0.45, `combat_reach`=1.5 WHERE `modelid`=39067; -- 39067
UPDATE `creature_model_info` SET `bounding_radius`=0.45, `combat_reach`=6, `gender`=0 WHERE `modelid`=37744; -- 37744
UPDATE `creature_model_info` SET `bounding_radius`=0.4513886, `combat_reach`=1.95 WHERE `modelid`=17185; -- 17185
UPDATE `creature_model_info` SET `bounding_radius`=0.4513886, `combat_reach`=1.95 WHERE `modelid`=17725; -- 17725
UPDATE `creature_model_info` SET `bounding_radius`=0.4513886, `combat_reach`=1.95 WHERE `modelid`=22213; -- 22213
UPDATE `creature_model_info` SET `bounding_radius`=0.4513886, `combat_reach`=1.95, `gender`=0 WHERE `modelid`=30563; -- 30563
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25 WHERE `modelid`=13991; -- 13991
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25 WHERE `modelid`=14302; -- 14302
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25 WHERE `modelid`=14303; -- 14303
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25 WHERE `modelid`=14304; -- 14304
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25 WHERE `modelid`=17322; -- 17322
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25 WHERE `modelid`=17330; -- 17330
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25 WHERE `modelid`=17335; -- 17335
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25 WHERE `modelid`=17336; -- 17336
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25 WHERE `modelid`=17339; -- 17339
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25 WHERE `modelid`=17341; -- 17341
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25 WHERE `modelid`=17537; -- 17537
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25 WHERE `modelid`=29044; -- 29044
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25 WHERE `modelid`=29050; -- 29050
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25 WHERE `modelid`=29051; -- 29051
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25 WHERE `modelid`=29053; -- 29053
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=35670; -- 35670
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=37715; -- 37715
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25, `gender`=1 WHERE `modelid`=38603; -- 38603
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25, `gender`=1 WHERE `modelid`=38908; -- 38908
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25, `gender`=1 WHERE `modelid`=38909; -- 38909
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25, `gender`=1 WHERE `modelid`=38910; -- 38910
UPDATE `creature_model_info` SET `bounding_radius`=0.459, `combat_reach`=2.25, `gender`=1 WHERE `modelid`=38911; -- 38911
UPDATE `creature_model_info` SET `bounding_radius`=0.4596, `combat_reach`=1.8 WHERE `modelid`=20765; -- 20765
UPDATE `creature_model_info` SET `bounding_radius`=0.4596, `combat_reach`=1.8 WHERE `modelid`=21012; -- 21012
UPDATE `creature_model_info` SET `bounding_radius`=0.4596, `combat_reach`=1.8 WHERE `modelid`=22444; -- 22444
UPDATE `creature_model_info` SET `bounding_radius`=0.4596, `combat_reach`=1.8 WHERE `modelid`=23092; -- 23092
UPDATE `creature_model_info` SET `bounding_radius`=0.4596, `combat_reach`=1.8 WHERE `modelid`=27851; -- 27851
UPDATE `creature_model_info` SET `bounding_radius`=0.465 WHERE `modelid`=12164; -- 12164
UPDATE `creature_model_info` SET `bounding_radius`=0.465, `combat_reach`=1.5 WHERE `modelid`=36419; -- 36419
UPDATE `creature_model_info` SET `bounding_radius`=0.465, `combat_reach`=1.5 WHERE `modelid`=36520; -- 36520
UPDATE `creature_model_info` SET `bounding_radius`=0.465, `combat_reach`=1.5 WHERE `modelid`=36764; -- 36764
UPDATE `creature_model_info` SET `bounding_radius`=0.465, `combat_reach`=4.5 WHERE `modelid`=39629; -- 39629
UPDATE `creature_model_info` SET `bounding_radius`=0.465, `combat_reach`=4.5 WHERE `modelid`=39630; -- 39630
UPDATE `creature_model_info` SET `bounding_radius`=0.465, `combat_reach`=4.5 WHERE `modelid`=39785; -- 39785
UPDATE `creature_model_info` SET `bounding_radius`=0.465, `combat_reach`=4.5 WHERE `modelid`=39786; -- 39786
UPDATE `creature_model_info` SET `bounding_radius`=0.465, `combat_reach`=4.5 WHERE `modelid`=39787; -- 39787
UPDATE `creature_model_info` SET `bounding_radius`=0.465, `combat_reach`=4.5 WHERE `modelid`=39788; -- 39788
UPDATE `creature_model_info` SET `bounding_radius`=0.465, `combat_reach`=4.5 WHERE `modelid`=40158; -- 40158
UPDATE `creature_model_info` SET `bounding_radius`=0.465, `combat_reach`=7.5 WHERE `modelid`=26286; -- 26286
UPDATE `creature_model_info` SET `bounding_radius`=0.465, `combat_reach`=7.5, `gender`=0 WHERE `modelid`=28344; -- 28344
UPDATE `creature_model_info` SET `bounding_radius`=0.465, `gender`=0 WHERE `modelid`=29154; -- 29154
UPDATE `creature_model_info` SET `bounding_radius`=0.4687497, `combat_reach`=2.025 WHERE `modelid`=21383; -- 21383
UPDATE `creature_model_info` SET `bounding_radius`=0.472, `combat_reach`=3, `gender`=1 WHERE `modelid`=39914; -- 39914
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=17778; -- 17778
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=17813; -- 17813
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=17816; -- 17816
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=17819; -- 17819
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=17820; -- 17820
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=17842; -- 17842
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=17843; -- 17843
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=17844; -- 17844
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=17883; -- 17883
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=17884; -- 17884
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=18925; -- 18925
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=18926; -- 18926
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=21331; -- 21331
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=21332; -- 21332
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=21333; -- 21333
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=21334; -- 21334
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=21335; -- 21335
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=21336; -- 21336
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=21337; -- 21337
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=21338; -- 21338
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=21339; -- 21339
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875 WHERE `modelid`=21340; -- 21340
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875, `gender`=0 WHERE `modelid`=17845; -- 17845
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875, `gender`=0 WHERE `modelid`=28406; -- 28406
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875, `gender`=1 WHERE `modelid`=34133; -- 34133
UPDATE `creature_model_info` SET `bounding_radius`=0.47875, `combat_reach`=1.875, `gender`=1 WHERE `modelid`=40074; -- 40074
UPDATE `creature_model_info` SET `bounding_radius`=0.47955, `combat_reach`=1.725 WHERE `modelid`=1761; -- 1761
UPDATE `creature_model_info` SET `bounding_radius`=0.48, `combat_reach`=1.6 WHERE `modelid`=19259; -- 19259
UPDATE `creature_model_info` SET `bounding_radius`=0.4836, `combat_reach`=1.95 WHERE `modelid`=10173; -- 10173
UPDATE `creature_model_info` SET `bounding_radius`=0.4836, `combat_reach`=1.95 WHERE `modelid`=11967; -- 11967
UPDATE `creature_model_info` SET `bounding_radius`=0.4836, `combat_reach`=1.95 WHERE `modelid`=11969; -- 11969
UPDATE `creature_model_info` SET `bounding_radius`=0.4836, `combat_reach`=1.95 WHERE `modelid`=14296; -- 14296
UPDATE `creature_model_info` SET `bounding_radius`=0.4836, `combat_reach`=1.95 WHERE `modelid`=16969; -- 16969
UPDATE `creature_model_info` SET `bounding_radius`=0.4836, `combat_reach`=1.95 WHERE `modelid`=17190; -- 17190
UPDATE `creature_model_info` SET `bounding_radius`=0.4836, `combat_reach`=1.95 WHERE `modelid`=51; -- 51
UPDATE `creature_model_info` SET `bounding_radius`=0.4896, `combat_reach`=2.4, `gender`=0 WHERE `modelid`=31590; -- 31590
UPDATE `creature_model_info` SET `bounding_radius`=0.4896, `combat_reach`=2.4, `gender`=0 WHERE `modelid`=31790; -- 31790
UPDATE `creature_model_info` SET `bounding_radius`=0.4896, `combat_reach`=2.4, `gender`=0 WHERE `modelid`=39253; -- 39253
UPDATE `creature_model_info` SET `bounding_radius`=0.49, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.496, `combat_reach`=1.6 WHERE `modelid`=37027; -- 37027
UPDATE `creature_model_info` SET `bounding_radius`=0.496, `combat_reach`=1.6, `gender`=0 WHERE `modelid`=40070; -- 40070
UPDATE `creature_model_info` SET `bounding_radius`=0.4978999, `combat_reach`=1.95 WHERE `modelid`=15475; -- 15475
UPDATE `creature_model_info` SET `bounding_radius`=0.4978999, `combat_reach`=1.95 WHERE `modelid`=19045; -- 19045
UPDATE `creature_model_info` SET `bounding_radius`=0.4978999, `combat_reach`=1.95 WHERE `modelid`=58; -- 58
UPDATE `creature_model_info` SET `bounding_radius`=0.4992, `combat_reach`=3.6, `gender`=1 WHERE `modelid`=29572; -- 29572
UPDATE `creature_model_info` SET `bounding_radius`=0.4992, `combat_reach`=3.6, `gender`=1 WHERE `modelid`=29638; -- 29638
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=0.5 WHERE `modelid`=33168; -- 33168
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=0.625 WHERE `modelid`=35689; -- 35689
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=0.625 WHERE `modelid`=35690; -- 35690
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=0.625 WHERE `modelid`=6842; -- 6842
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1 WHERE `modelid`=13097; -- 13097
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1 WHERE `modelid`=31561; -- 31561
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1 WHERE `modelid`=33573; -- 33573
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1 WHERE `modelid`=34794; -- 34794
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1 WHERE `modelid`=34811; -- 34811
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1 WHERE `modelid`=37355; -- 37355
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1 WHERE `modelid`=37356; -- 37356
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1 WHERE `modelid`=37935; -- 37935
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1 WHERE `modelid`=38550; -- 38550
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1 WHERE `modelid`=39575; -- 39575
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1 WHERE `modelid`=39825; -- 39825
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1 WHERE `modelid`=39970; -- 39970
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1, `gender`=0 WHERE `modelid`=38123; -- 38123
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1, `gender`=1 WHERE `modelid`=29101; -- 29101
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1.25, `gender`=1 WHERE `modelid`=37312; -- 37312
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1.5 WHERE `modelid`=15464; -- 15464
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1.5 WHERE `modelid`=34900; -- 34900
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1.5 WHERE `modelid`=37241; -- 37241
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=15 WHERE `modelid`=39355; -- 39355
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=15 WHERE `modelid`=39776; -- 39776
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=15 WHERE `modelid`=39781; -- 39781
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=15 WHERE `modelid`=39782; -- 39782
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=15 WHERE `modelid`=39783; -- 39783
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=45 WHERE `modelid`=39947; -- 39947
UPDATE `creature_model_info` SET `bounding_radius`=0.5022, `combat_reach`=2.025 WHERE `modelid`=29899; -- 29899
UPDATE `creature_model_info` SET `bounding_radius`=0.5057, `combat_reach`=1.95, `gender`=0 WHERE `modelid`=38874; -- 38874
UPDATE `creature_model_info` SET `bounding_radius`=0.5057, `combat_reach`=1.95, `gender`=0 WHERE `modelid`=38968; -- 38968
UPDATE `creature_model_info` SET `bounding_radius`=0.5057, `combat_reach`=1.95, `gender`=0 WHERE `modelid`=38969; -- 38969
UPDATE `creature_model_info` SET `bounding_radius`=0.5057, `combat_reach`=1.95, `gender`=0 WHERE `modelid`=38970; -- 38970
UPDATE `creature_model_info` SET `bounding_radius`=0.51, `combat_reach`=2.25 WHERE `modelid`=28595; -- 28595
UPDATE `creature_model_info` SET `bounding_radius`=0.51, `combat_reach`=3 WHERE `modelid`=29327; -- 29327
UPDATE `creature_model_info` SET `bounding_radius`=0.5115, `combat_reach`=1.65 WHERE `modelid`=26596; -- 26596
UPDATE `creature_model_info` SET `bounding_radius`=0.515, `combat_reach`=0.75 WHERE `modelid`=25585; -- 25585
UPDATE `creature_model_info` SET `bounding_radius`=0.51705, `combat_reach`=2.025 WHERE `modelid`=21445; -- 21445
UPDATE `creature_model_info` SET `bounding_radius`=0.51705, `combat_reach`=2.025 WHERE `modelid`=23531; -- 23531
UPDATE `creature_model_info` SET `bounding_radius`=0.51705, `combat_reach`=2.025 WHERE `modelid`=23533; -- 23533
UPDATE `creature_model_info` SET `bounding_radius`=0.51705, `combat_reach`=2.025, `gender`=1 WHERE `modelid`=39774; -- 39774
UPDATE `creature_model_info` SET `bounding_radius`=0.5202, `combat_reach`=2.55 WHERE `modelid`=14498; -- 14498
UPDATE `creature_model_info` SET `bounding_radius`=0.5202, `combat_reach`=2.55, `gender`=0 WHERE `modelid`=38504; -- 38504
UPDATE `creature_model_info` SET `bounding_radius`=0.5202, `combat_reach`=2.55, `gender`=0 WHERE `modelid`=40049; -- 40049
UPDATE `creature_model_info` SET `bounding_radius`=0.5205, `combat_reach`=2.25 WHERE `modelid`=17321; -- 17321
UPDATE `creature_model_info` SET `bounding_radius`=0.5205, `combat_reach`=2.25 WHERE `modelid`=17324; -- 17324
UPDATE `creature_model_info` SET `bounding_radius`=0.5208, `combat_reach`=2.1 WHERE `modelid`=16628; -- 16628
UPDATE `creature_model_info` SET `bounding_radius`=0.5208, `combat_reach`=2.1 WHERE `modelid`=17186; -- 17186
UPDATE `creature_model_info` SET `bounding_radius`=0.5208, `combat_reach`=2.1 WHERE `modelid`=8664; -- 8664
UPDATE `creature_model_info` SET `bounding_radius`=0.5208, `combat_reach`=2.1, `gender`=0 WHERE `modelid`=36192; -- 36192
UPDATE `creature_model_info` SET `bounding_radius`=0.520833, `combat_reach`=2.25 WHERE `modelid`=23840; -- 23840
UPDATE `creature_model_info` SET `bounding_radius`=0.520833, `combat_reach`=2.25 WHERE `modelid`=24020; -- 24020
UPDATE `creature_model_info` SET `bounding_radius`=0.520833, `combat_reach`=2.25 WHERE `modelid`=27136; -- 27136
UPDATE `creature_model_info` SET `bounding_radius`=0.520833, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=31810; -- 31810
UPDATE `creature_model_info` SET `bounding_radius`=0.520833, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=31814; -- 31814
UPDATE `creature_model_info` SET `bounding_radius`=0.520833, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=32238; -- 32238
UPDATE `creature_model_info` SET `bounding_radius`=0.520833, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=32479; -- 32479
UPDATE `creature_model_info` SET `bounding_radius`=0.520833, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=37370; -- 37370
UPDATE `creature_model_info` SET `bounding_radius`=0.520833, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=37386; -- 37386
UPDATE `creature_model_info` SET `bounding_radius`=0.525, `combat_reach`=1.2, `gender`=0 WHERE `modelid`=32672; -- 32672
UPDATE `creature_model_info` SET `bounding_radius`=0.525, `combat_reach`=1.5 WHERE `modelid`=32259; -- 32259
UPDATE `creature_model_info` SET `bounding_radius`=0.525, `combat_reach`=1.75, `gender`=0 WHERE `modelid`=33501; -- 33501
UPDATE `creature_model_info` SET `bounding_radius`=0.525, `combat_reach`=15 WHERE `modelid`=16919; -- 16919
UPDATE `creature_model_info` SET `bounding_radius`=0.525, `combat_reach`=2.25 WHERE `modelid`=30045; -- 30045
UPDATE `creature_model_info` SET `bounding_radius`=0.525, `combat_reach`=2.25 WHERE `modelid`=30046; -- 30046
UPDATE `creature_model_info` SET `bounding_radius`=0.525, `combat_reach`=2.25 WHERE `modelid`=30047; -- 30047
UPDATE `creature_model_info` SET `bounding_radius`=0.525, `combat_reach`=3.75 WHERE `modelid`=14254; -- 14254
UPDATE `creature_model_info` SET `bounding_radius`=0.52515, `combat_reach`=2.025 WHERE `modelid`=14384; -- 14384
UPDATE `creature_model_info` SET `bounding_radius`=0.527, `combat_reach`=1.7, `gender`=1 WHERE `modelid`=39447; -- 39447
UPDATE `creature_model_info` SET `bounding_radius`=0.527, `combat_reach`=1.7, `gender`=1 WHERE `modelid`=40057; -- 40057
UPDATE `creature_model_info` SET `bounding_radius`=0.52785, `combat_reach`=2.5875, `gender`=0 WHERE `modelid`=37234; -- 37234
UPDATE `creature_model_info` SET `bounding_radius`=0.5355, `combat_reach`=2.625 WHERE `modelid`=25666; -- 25666
UPDATE `creature_model_info` SET `bounding_radius`=0.5355, `combat_reach`=2.625 WHERE `modelid`=29616; -- 29616
UPDATE `creature_model_info` SET `bounding_radius`=0.5355, `combat_reach`=2.625, `gender`=0 WHERE `modelid`=34837; -- 34837
UPDATE `creature_model_info` SET `bounding_radius`=0.5362, `combat_reach`=2.1 WHERE `modelid`=27411; -- 27411
UPDATE `creature_model_info` SET `bounding_radius`=0.5362, `combat_reach`=2.1 WHERE `modelid`=27508; -- 27508
UPDATE `creature_model_info` SET `bounding_radius`=0.5362, `combat_reach`=2.1, `gender`=0 WHERE `modelid`=40056; -- 40056
UPDATE `creature_model_info` SET `bounding_radius`=0.5394, `combat_reach`=1.74 WHERE `modelid`=23945; -- 23945
UPDATE `creature_model_info` SET `bounding_radius`=0.5418, `combat_reach`=1.2 WHERE `modelid`=38308; -- 38308
UPDATE `creature_model_info` SET `bounding_radius`=0.5425 WHERE `modelid`=12239; -- 12239
UPDATE `creature_model_info` SET `bounding_radius`=0.5425, `combat_reach`=1.75, `gender`=1 WHERE `modelid`=40055; -- 40055
UPDATE `creature_model_info` SET `bounding_radius`=0.5425, `combat_reach`=1.75, `gender`=2 WHERE `modelid`=27301; -- 27301
UPDATE `creature_model_info` SET `bounding_radius`=0.5425, `combat_reach`=10.5 WHERE `modelid`=34771; -- 34771
UPDATE `creature_model_info` SET `bounding_radius`=0.5425, `combat_reach`=2.625 WHERE `modelid`=36757; -- 36757
UPDATE `creature_model_info` SET `bounding_radius`=0.5446, `combat_reach`=2.1, `gender`=0 WHERE `modelid`=39162; -- 39162
UPDATE `creature_model_info` SET `bounding_radius`=0.55, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.55, `combat_reach`=11, `gender`=0 WHERE `modelid`=38797; -- 38797
UPDATE `creature_model_info` SET `bounding_radius`=0.5505625, `combat_reach`=2.15625 WHERE `modelid`=21341; -- 21341
UPDATE `creature_model_info` SET `bounding_radius`=0.558, `combat_reach`=1.8, `gender`=1 WHERE `modelid`=39617; -- 39617
UPDATE `creature_model_info` SET `bounding_radius`=0.558, `combat_reach`=2.25 WHERE `modelid`=17331; -- 17331
UPDATE `creature_model_info` SET `bounding_radius`=0.558, `combat_reach`=2.25 WHERE `modelid`=17337; -- 17337
UPDATE `creature_model_info` SET `bounding_radius`=0.558, `combat_reach`=2.25 WHERE `modelid`=20623; -- 20623
UPDATE `creature_model_info` SET `bounding_radius`=0.558, `combat_reach`=2.25 WHERE `modelid`=24763; -- 24763
UPDATE `creature_model_info` SET `bounding_radius`=0.558, `combat_reach`=2.25 WHERE `modelid`=29047; -- 29047
UPDATE `creature_model_info` SET `bounding_radius`=0.558, `combat_reach`=2.25 WHERE `modelid`=29054; -- 29054
UPDATE `creature_model_info` SET `bounding_radius`=0.558, `combat_reach`=2.25 WHERE `modelid`=29055; -- 29055
UPDATE `creature_model_info` SET `bounding_radius`=0.5610169, `combat_reach`=0.5610169 WHERE `modelid`=3006; -- 3006
UPDATE `creature_model_info` SET `bounding_radius`=0.5664001, `combat_reach`=3.6, `gender`=1 WHERE `modelid`=29658; -- 29658
UPDATE `creature_model_info` SET `bounding_radius`=0.57, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.5745, `combat_reach`=2.25 WHERE `modelid`=17325; -- 17325
UPDATE `creature_model_info` SET `bounding_radius`=0.5745, `combat_reach`=2.25 WHERE `modelid`=17329; -- 17329
UPDATE `creature_model_info` SET `bounding_radius`=0.5745, `combat_reach`=2.25 WHERE `modelid`=21530; -- 21530
UPDATE `creature_model_info` SET `bounding_radius`=0.5745, `combat_reach`=2.25 WHERE `modelid`=21531; -- 21531
UPDATE `creature_model_info` SET `bounding_radius`=0.5745, `combat_reach`=2.25 WHERE `modelid`=29046; -- 29046
UPDATE `creature_model_info` SET `bounding_radius`=0.5745, `combat_reach`=2.25 WHERE `modelid`=29049; -- 29049
UPDATE `creature_model_info` SET `bounding_radius`=0.5745, `combat_reach`=2.25 WHERE `modelid`=29052; -- 29052
UPDATE `creature_model_info` SET `bounding_radius`=0.5745, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=39030; -- 39030
UPDATE `creature_model_info` SET `bounding_radius`=0.5745, `combat_reach`=2.25, `gender`=1 WHERE `modelid`=39773; -- 39773
UPDATE `creature_model_info` SET `bounding_radius`=0.5835, `combat_reach`=2.25 WHERE `modelid`=17342; -- 17342
UPDATE `creature_model_info` SET `bounding_radius`=0.5835, `combat_reach`=2.25 WHERE `modelid`=17343; -- 17343
UPDATE `creature_model_info` SET `bounding_radius`=0.5835, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=39128; -- 39128
UPDATE `creature_model_info` SET `bounding_radius`=0.595, `combat_reach`=0.85 WHERE `modelid`=30081; -- 30081
UPDATE `creature_model_info` SET `bounding_radius`=0.5952, `combat_reach`=2.4, `gender`=0 WHERE `modelid`=31602; -- 31602
UPDATE `creature_model_info` SET `bounding_radius`=0.5952, `combat_reach`=2.4, `gender`=0 WHERE `modelid`=39256; -- 39256
UPDATE `creature_model_info` SET `bounding_radius`=0.6, `combat_reach`=0.5 WHERE `modelid`=855; -- 855
UPDATE `creature_model_info` SET `bounding_radius`=0.6, `combat_reach`=0.9 WHERE `modelid`=37932; -- 37932
UPDATE `creature_model_info` SET `bounding_radius`=0.6, `combat_reach`=1.2, `gender`=0 WHERE `modelid`=19277; -- 19277
UPDATE `creature_model_info` SET `bounding_radius`=0.6, `combat_reach`=2 WHERE `modelid`=25501; -- 25501
UPDATE `creature_model_info` SET `bounding_radius`=0.6, `combat_reach`=2 WHERE `modelid`=29041; -- 29041
UPDATE `creature_model_info` SET `bounding_radius`=0.6, `combat_reach`=2 WHERE `modelid`=31905; -- 31905
UPDATE `creature_model_info` SET `bounding_radius`=0.6, `combat_reach`=2 WHERE `modelid`=35179; -- 35179
UPDATE `creature_model_info` SET `bounding_radius`=0.6, `combat_reach`=2 WHERE `modelid`=35648; -- 35648
UPDATE `creature_model_info` SET `bounding_radius`=0.6, `combat_reach`=2 WHERE `modelid`=35649; -- 35649
UPDATE `creature_model_info` SET `bounding_radius`=0.6, `combat_reach`=2 WHERE `modelid`=36266; -- 36266
UPDATE `creature_model_info` SET `bounding_radius`=0.6, `combat_reach`=2 WHERE `modelid`=36465; -- 36465
UPDATE `creature_model_info` SET `bounding_radius`=0.6, `combat_reach`=2.25 WHERE `modelid`=15437; -- 15437
UPDATE `creature_model_info` SET `bounding_radius`=0.6, `combat_reach`=3 WHERE `modelid`=37866; -- 37866
UPDATE `creature_model_info` SET `bounding_radius`=0.6, `combat_reach`=3, `gender`=0 WHERE `modelid`=32568; -- 32568
UPDATE `creature_model_info` SET `bounding_radius`=0.6, `gender`=0 WHERE `modelid`=23723; -- 23723
UPDATE `creature_model_info` SET `bounding_radius`=0.6076385, `combat_reach`=2.625 WHERE `modelid`=27858; -- 27858
UPDATE `creature_model_info` SET `bounding_radius`=0.61, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.61, `combat_reach`=2, `gender`=0 WHERE `modelid`=19799; -- 19799
UPDATE `creature_model_info` SET `bounding_radius`=0.611112, `combat_reach`=2, `gender`=0 WHERE `modelid`=30809; -- 30809
UPDATE `creature_model_info` SET `bounding_radius`=0.612, `combat_reach`=3, `gender`=0 WHERE `modelid`=23350; -- 23350
UPDATE `creature_model_info` SET `bounding_radius`=0.612, `combat_reach`=4 WHERE `modelid`=38223; -- 38223
UPDATE `creature_model_info` SET `bounding_radius`=0.6128, `combat_reach`=2.4, `gender`=0 WHERE `modelid`=31606; -- 31606
UPDATE `creature_model_info` SET `bounding_radius`=0.6128, `combat_reach`=2.4, `gender`=0 WHERE `modelid`=31607; -- 31607
UPDATE `creature_model_info` SET `bounding_radius`=0.6186441, `combat_reach`=0.6186441 WHERE `modelid`=1742; -- 1742
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=1.5 WHERE `modelid`=38748; -- 38748
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=1.5 WHERE `modelid`=38749; -- 38749
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=23773; -- 23773
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=28324; -- 28324
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=10 WHERE `modelid`=33438; -- 33438
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=2 WHERE `modelid`=26157; -- 26157
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=2 WHERE `modelid`=27517; -- 27517
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=2 WHERE `modelid`=32248; -- 32248
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=2 WHERE `modelid`=32810; -- 32810
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=2 WHERE `modelid`=33080; -- 33080
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=2 WHERE `modelid`=37024; -- 37024
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=2 WHERE `modelid`=37025; -- 37025
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=2 WHERE `modelid`=37026; -- 37026
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=2, `gender`=0 WHERE `modelid`=26574; -- 26574
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=2, `gender`=0 WHERE `modelid`=36056; -- 36056
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=2, `gender`=0 WHERE `modelid`=37339; -- 37339
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=2, `gender`=0 WHERE `modelid`=39177; -- 39177
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=2, `gender`=1 WHERE `modelid`=39391; -- 39391
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=2, `gender`=1 WHERE `modelid`=39622; -- 39622
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=2, `gender`=2 WHERE `modelid`=28381; -- 28381
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=3 WHERE `modelid`=36019; -- 36019
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=3 WHERE `modelid`=38019; -- 38019
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=3 WHERE `modelid`=39586; -- 39586
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=4 WHERE `modelid`=26651; -- 26651
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=4 WHERE `modelid`=28465; -- 28465
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=4 WHERE `modelid`=28628; -- 28628
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=4 WHERE `modelid`=32724; -- 32724
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=4, `gender`=0 WHERE `modelid`=26782; -- 26782
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=6 WHERE `modelid`=38149; -- 38149
UPDATE `creature_model_info` SET `bounding_radius`=0.6249996, `combat_reach`=2.7 WHERE `modelid`=26979; -- 26979
UPDATE `creature_model_info` SET `bounding_radius`=0.6249996, `combat_reach`=2.7, `gender`=0 WHERE `modelid`=32473; -- 32473
UPDATE `creature_model_info` SET `bounding_radius`=0.625, `combat_reach`=8.75 WHERE `modelid`=33428; -- 33428
UPDATE `creature_model_info` SET `bounding_radius`=0.625, `combat_reach`=8.75 WHERE `modelid`=39138; -- 39138
UPDATE `creature_model_info` SET `bounding_radius`=0.63, `combat_reach`=10.5, `gender`=0 WHERE `modelid`=27013; -- 27013
UPDATE `creature_model_info` SET `bounding_radius`=0.63, `combat_reach`=7.2 WHERE `modelid`=11997; -- 11997
UPDATE `creature_model_info` SET `bounding_radius`=0.6375, `combat_reach`=2.125 WHERE `modelid`=36528; -- 36528
UPDATE `creature_model_info` SET `bounding_radius`=0.65, `combat_reach`=1.3 WHERE `modelid`=19704; -- 19704
UPDATE `creature_model_info` SET `bounding_radius`=0.65, `combat_reach`=1.3, `gender`=0 WHERE `modelid`=19275; -- 19275
UPDATE `creature_model_info` SET `bounding_radius`=0.65, `combat_reach`=1.625 WHERE `modelid`=8782; -- 8782
UPDATE `creature_model_info` SET `bounding_radius`=0.65, `combat_reach`=1.95 WHERE `modelid`=12966; -- 12966
UPDATE `creature_model_info` SET `bounding_radius`=0.65, `combat_reach`=1.95 WHERE `modelid`=17389; -- 17389
UPDATE `creature_model_info` SET `bounding_radius`=0.6511, `combat_reach`=2.55, `gender`=0 WHERE `modelid`=31783; -- 31783
UPDATE `creature_model_info` SET `bounding_radius`=0.6613, `combat_reach`=2.55, `gender`=0 WHERE `modelid`=38503; -- 38503
UPDATE `creature_model_info` SET `bounding_radius`=0.67, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.675, `combat_reach`=1.875, `gender`=0 WHERE `modelid`=10032; -- 10032
UPDATE `creature_model_info` SET `bounding_radius`=0.675, `combat_reach`=3.375, `gender`=0 WHERE `modelid`=32348; -- 32348
UPDATE `creature_model_info` SET `bounding_radius`=0.6894, `combat_reach`=2.7 WHERE `modelid`=21566; -- 21566
UPDATE `creature_model_info` SET `bounding_radius`=0.6894, `combat_reach`=2.7 WHERE `modelid`=21567; -- 21567
UPDATE `creature_model_info` SET `bounding_radius`=0.6894, `combat_reach`=2.7 WHERE `modelid`=21568; -- 21568
UPDATE `creature_model_info` SET `bounding_radius`=0.694, `combat_reach`=3 WHERE `modelid`=16313; -- 16313
UPDATE `creature_model_info` SET `bounding_radius`=0.694, `combat_reach`=4 WHERE `modelid`=5848; -- 5848
UPDATE `creature_model_info` SET `bounding_radius`=0.694444, `combat_reach`=1, `gender`=0 WHERE `modelid`=32262; -- 32262
UPDATE `creature_model_info` SET `bounding_radius`=0.694444, `combat_reach`=1, `gender`=0 WHERE `modelid`=32338; -- 32338
UPDATE `creature_model_info` SET `bounding_radius`=0.694444, `combat_reach`=3 WHERE `modelid`=25484; -- 25484
UPDATE `creature_model_info` SET `bounding_radius`=0.694444, `combat_reach`=3 WHERE `modelid`=25485; -- 25485
UPDATE `creature_model_info` SET `bounding_radius`=0.694444, `combat_reach`=3 WHERE `modelid`=25588; -- 25588
UPDATE `creature_model_info` SET `bounding_radius`=0.694444, `combat_reach`=3, `gender`=0 WHERE `modelid`=32503; -- 32503
UPDATE `creature_model_info` SET `bounding_radius`=0.6975, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=30864; -- 30864
UPDATE `creature_model_info` SET `bounding_radius`=0.6975, `combat_reach`=13.5, `gender`=0 WHERE `modelid`=34265; -- 34265
UPDATE `creature_model_info` SET `bounding_radius`=0.7, `combat_reach`=0.7, `gender`=1 WHERE `modelid`=24794; -- 24794
UPDATE `creature_model_info` SET `bounding_radius`=0.7, `combat_reach`=0.875 WHERE `modelid`=32063; -- 32063
UPDATE `creature_model_info` SET `bounding_radius`=0.7, `combat_reach`=0.875 WHERE `modelid`=36282; -- 36282
UPDATE `creature_model_info` SET `bounding_radius`=0.7, `combat_reach`=0.875 WHERE `modelid`=36283; -- 36283
UPDATE `creature_model_info` SET `bounding_radius`=0.7, `combat_reach`=0.875 WHERE `modelid`=36284; -- 36284
UPDATE `creature_model_info` SET `bounding_radius`=0.7, `combat_reach`=0.875 WHERE `modelid`=36314; -- 36314
UPDATE `creature_model_info` SET `bounding_radius`=0.7, `combat_reach`=0.875 WHERE `modelid`=5560; -- 5560
UPDATE `creature_model_info` SET `bounding_radius`=0.7, `combat_reach`=1.05 WHERE `modelid`=16346; -- 16346
UPDATE `creature_model_info` SET `bounding_radius`=0.7, `combat_reach`=1.05 WHERE `modelid`=19030; -- 19030
UPDATE `creature_model_info` SET `bounding_radius`=0.7, `combat_reach`=1.5 WHERE `modelid`=30782; -- 30782
UPDATE `creature_model_info` SET `bounding_radius`=0.7, `combat_reach`=2 WHERE `modelid`=38634; -- 38634
UPDATE `creature_model_info` SET `bounding_radius`=0.7, `combat_reach`=2.8, `gender`=1 WHERE `modelid`=39543; -- 39543
UPDATE `creature_model_info` SET `bounding_radius`=0.7, `combat_reach`=4, `gender`=0 WHERE `modelid`=5107; -- 5107
UPDATE `creature_model_info` SET `bounding_radius`=0.705, `combat_reach`=3 WHERE `modelid`=4626; -- 4626
UPDATE `creature_model_info` SET `bounding_radius`=0.708, `combat_reach`=4.5, `gender`=1 WHERE `modelid`=39318; -- 39318
UPDATE `creature_model_info` SET `bounding_radius`=0.71, `combat_reach`=1.25, `gender`=0 WHERE `modelid`=34619; -- 34619
UPDATE `creature_model_info` SET `bounding_radius`=0.71, `combat_reach`=1.25, `gender`=0 WHERE `modelid`=34732; -- 34732
UPDATE `creature_model_info` SET `bounding_radius`=0.71, `combat_reach`=1.25, `gender`=0 WHERE `modelid`=34747; -- 34747
UPDATE `creature_model_info` SET `bounding_radius`=0.7284999, `combat_reach`=7.05 WHERE `modelid`=20812; -- 20812
UPDATE `creature_model_info` SET `bounding_radius`=0.7322034, `combat_reach`=1.5 WHERE `modelid`=30213; -- 30213
UPDATE `creature_model_info` SET `bounding_radius`=0.7344, `combat_reach`=3.6 WHERE `modelid`=29571; -- 29571
UPDATE `creature_model_info` SET `bounding_radius`=0.7344, `combat_reach`=3.6 WHERE `modelid`=29637; -- 29637
UPDATE `creature_model_info` SET `bounding_radius`=0.7344, `combat_reach`=3.6 WHERE `modelid`=29649; -- 29649
UPDATE `creature_model_info` SET `bounding_radius`=0.7344, `combat_reach`=3.6, `gender`=0 WHERE `modelid`=29570; -- 29570
UPDATE `creature_model_info` SET `bounding_radius`=0.7344, `combat_reach`=3.6, `gender`=0 WHERE `modelid`=29636; -- 29636
UPDATE `creature_model_info` SET `bounding_radius`=0.7344, `combat_reach`=3.6, `gender`=0 WHERE `modelid`=29648; -- 29648
UPDATE `creature_model_info` SET `bounding_radius`=0.7344, `combat_reach`=3.6, `gender`=1 WHERE `modelid`=29644; -- 29644
UPDATE `creature_model_info` SET `bounding_radius`=0.7374915, `combat_reach`=0.6271186 WHERE `modelid`=503; -- 503
UPDATE `creature_model_info` SET `bounding_radius`=0.744 WHERE `modelid`=20950; -- 20950
UPDATE `creature_model_info` SET `bounding_radius`=0.744, `combat_reach`=3, `gender`=0 WHERE `modelid`=31792; -- 31792
UPDATE `creature_model_info` SET `bounding_radius`=0.744, `combat_reach`=3, `gender`=0 WHERE `modelid`=39829; -- 39829
UPDATE `creature_model_info` SET `bounding_radius`=0.7454644, `combat_reach`=0.6338983 WHERE `modelid`=503; -- 503
UPDATE `creature_model_info` SET `bounding_radius`=0.7454644, `combat_reach`=0.6338983 WHERE `modelid`=607; -- 607
UPDATE `creature_model_info` SET `bounding_radius`=0.748, `combat_reach`=0.6 WHERE `modelid`=15072; -- 15072
UPDATE `creature_model_info` SET `bounding_radius`=0.75, `combat_reach`=0.55, `gender`=0 WHERE `modelid`=21447; -- 21447
UPDATE `creature_model_info` SET `bounding_radius`=0.75, `combat_reach`=1.125 WHERE `modelid`=12962; -- 12962
UPDATE `creature_model_info` SET `bounding_radius`=0.75, `combat_reach`=1.125 WHERE `modelid`=12963; -- 12963
UPDATE `creature_model_info` SET `bounding_radius`=0.75, `combat_reach`=1.125, `gender`=0 WHERE `modelid`=10812; -- 10812
UPDATE `creature_model_info` SET `bounding_radius`=0.75, `combat_reach`=1.5 WHERE `modelid`=24719; -- 24719
UPDATE `creature_model_info` SET `bounding_radius`=0.75, `combat_reach`=1.875 WHERE `modelid`=10698; -- 10698
UPDATE `creature_model_info` SET `bounding_radius`=0.75, `combat_reach`=2.25 WHERE `modelid`=20560; -- 20560
UPDATE `creature_model_info` SET `bounding_radius`=0.75, `combat_reach`=2.5 WHERE `modelid`=31907; -- 31907
UPDATE `creature_model_info` SET `bounding_radius`=0.75, `combat_reach`=2.5 WHERE `modelid`=36525; -- 36525
UPDATE `creature_model_info` SET `bounding_radius`=0.75, `combat_reach`=3.75 WHERE `modelid`=8269; -- 8269
UPDATE `creature_model_info` SET `bounding_radius`=0.75, `combat_reach`=4.5 WHERE `modelid`=18930; -- 18930
UPDATE `creature_model_info` SET `bounding_radius`=0.75, `combat_reach`=6, `gender`=0 WHERE `modelid`=39183; -- 39183
UPDATE `creature_model_info` SET `bounding_radius`=0.766, `combat_reach`=3 WHERE `modelid`=18929; -- 18929
UPDATE `creature_model_info` SET `bounding_radius`=0.766, `combat_reach`=3 WHERE `modelid`=20033; -- 20033
UPDATE `creature_model_info` SET `bounding_radius`=0.775, `combat_reach`=11.25 WHERE `modelid`=36476; -- 36476
UPDATE `creature_model_info` SET `bounding_radius`=0.775, `combat_reach`=2.5 WHERE `modelid`=28051; -- 28051
UPDATE `creature_model_info` SET `bounding_radius`=0.775, `combat_reach`=5, `gender`=1 WHERE `modelid`=33465; -- 33465
UPDATE `creature_model_info` SET `bounding_radius`=0.775, `combat_reach`=6.25 WHERE `modelid`=35099; -- 35099
UPDATE `creature_model_info` SET `bounding_radius`=0.775, `combat_reach`=6.25 WHERE `modelid`=35181; -- 35181
UPDATE `creature_model_info` SET `bounding_radius`=0.778, `combat_reach`=3, `gender`=0 WHERE `modelid`=38790; -- 38790
UPDATE `creature_model_info` SET `bounding_radius`=0.78, `combat_reach`=2 WHERE `modelid`=38795; -- 38795
UPDATE `creature_model_info` SET `bounding_radius`=0.78075, `combat_reach`=4.5 WHERE `modelid`=13173; -- 13173
UPDATE `creature_model_info` SET `bounding_radius`=0.7812495, `combat_reach`=3.375 WHERE `modelid`=20201; -- 20201
UPDATE `creature_model_info` SET `bounding_radius`=0.7812495, `combat_reach`=3.375 WHERE `modelid`=20205; -- 20205
UPDATE `creature_model_info` SET `bounding_radius`=0.7812495, `combat_reach`=3.375 WHERE `modelid`=20470; -- 20470
UPDATE `creature_model_info` SET `bounding_radius`=0.7812495, `combat_reach`=3.375 WHERE `modelid`=20671; -- 20671
UPDATE `creature_model_info` SET `bounding_radius`=0.7875, `combat_reach`=2.1875, `gender`=0 WHERE `modelid`=11340; -- 11340
UPDATE `creature_model_info` SET `bounding_radius`=0.79, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.795, `combat_reach`=1.5 WHERE `modelid`=599; -- 599
UPDATE `creature_model_info` SET `bounding_radius`=0.8, `combat_reach`=1.5 WHERE `modelid`=30210; -- 30210
UPDATE `creature_model_info` SET `bounding_radius`=0.8, `combat_reach`=3 WHERE `modelid`=15738; -- 15738
UPDATE `creature_model_info` SET `bounding_radius`=0.8, `combat_reach`=4 WHERE `modelid`=32119; -- 32119
UPDATE `creature_model_info` SET `bounding_radius`=0.806, `combat_reach`=2.6 WHERE `modelid`=27707; -- 27707
UPDATE `creature_model_info` SET `bounding_radius`=0.8067796, `combat_reach`=1.008475 WHERE `modelid`=1307; -- 1307
UPDATE `creature_model_info` SET `bounding_radius`=0.81, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.8100001, `combat_reach`=13.5, `gender`=0 WHERE `modelid`=27002; -- 27002
UPDATE `creature_model_info` SET `bounding_radius`=0.825, `combat_reach`=2.75 WHERE `modelid`=29070; -- 29070
UPDATE `creature_model_info` SET `bounding_radius`=0.825, `combat_reach`=2.75 WHERE `modelid`=31906; -- 31906
UPDATE `creature_model_info` SET `bounding_radius`=0.8328, `combat_reach`=3.6 WHERE `modelid`=29634; -- 29634
UPDATE `creature_model_info` SET `bounding_radius`=0.8328, `combat_reach`=3.6, `gender`=0 WHERE `modelid`=29574; -- 29574
UPDATE `creature_model_info` SET `bounding_radius`=0.8328, `combat_reach`=3.6, `gender`=0 WHERE `modelid`=29635; -- 29635
UPDATE `creature_model_info` SET `bounding_radius`=0.834, `combat_reach`=3, `gender`=0 WHERE `modelid`=31540; -- 31540
UPDATE `creature_model_info` SET `bounding_radius`=0.834, `combat_reach`=3, `gender`=0 WHERE `modelid`=32159; -- 32159
UPDATE `creature_model_info` SET `bounding_radius`=0.837, `combat_reach`=3.375 WHERE `modelid`=17370; -- 17370
UPDATE `creature_model_info` SET `bounding_radius`=0.84, `combat_reach`=1.2, `gender`=0 WHERE `modelid`=30492; -- 30492
UPDATE `creature_model_info` SET `bounding_radius`=0.84456, `combat_reach`=4.14, `gender`=0 WHERE `modelid`=29643; -- 29643
UPDATE `creature_model_info` SET `bounding_radius`=0.85, `combat_reach`=1.0625 WHERE `modelid`=1938; -- 1938
UPDATE `creature_model_info` SET `bounding_radius`=0.85, `combat_reach`=1.0625 WHERE `modelid`=641; -- 641
UPDATE `creature_model_info` SET `bounding_radius`=0.85, `combat_reach`=1.0625 WHERE `modelid`=999; -- 999
UPDATE `creature_model_info` SET `bounding_radius`=0.85, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.85, `combat_reach`=9.35 WHERE `modelid`=31795; -- 31795
UPDATE `creature_model_info` SET `bounding_radius`=0.8558, `combat_reach`=3.3, `gender`=0 WHERE `modelid`=39127; -- 39127
UPDATE `creature_model_info` SET `bounding_radius`=0.8617499, `combat_reach`=3.375 WHERE `modelid`=20514; -- 20514
UPDATE `creature_model_info` SET `bounding_radius`=0.867, `combat_reach`=1.08375 WHERE `modelid`=999; -- 999
UPDATE `creature_model_info` SET `bounding_radius`=0.8675, `combat_reach`=5 WHERE `modelid`=6350; -- 6350
UPDATE `creature_model_info` SET `bounding_radius`=0.868055, `combat_reach`=3.75 WHERE `modelid`=20200; -- 20200
UPDATE `creature_model_info` SET `bounding_radius`=0.868055, `combat_reach`=3.75 WHERE `modelid`=28126; -- 28126
UPDATE `creature_model_info` SET `bounding_radius`=0.87, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.8725, `combat_reach`=3.75 WHERE `modelid`=23452; -- 23452
UPDATE `creature_model_info` SET `bounding_radius`=0.8725, `combat_reach`=3.75 WHERE `modelid`=29608; -- 29608
UPDATE `creature_model_info` SET `bounding_radius`=0.8725, `combat_reach`=3.75 WHERE `modelid`=30689; -- 30689
UPDATE `creature_model_info` SET `bounding_radius`=0.8725, `combat_reach`=3.75, `gender`=1 WHERE `modelid`=31594; -- 31594
UPDATE `creature_model_info` SET `bounding_radius`=0.8725, `combat_reach`=3.75, `gender`=1 WHERE `modelid`=32010; -- 32010
UPDATE `creature_model_info` SET `bounding_radius`=0.8725, `combat_reach`=3.75, `gender`=1 WHERE `modelid`=32253; -- 32253
UPDATE `creature_model_info` SET `bounding_radius`=0.8725, `combat_reach`=3.75, `gender`=1 WHERE `modelid`=32627; -- 32627
UPDATE `creature_model_info` SET `bounding_radius`=0.8725, `combat_reach`=3.75, `gender`=1 WHERE `modelid`=32865; -- 32865
UPDATE `creature_model_info` SET `bounding_radius`=0.8725, `combat_reach`=3.75, `gender`=1 WHERE `modelid`=34097; -- 34097
UPDATE `creature_model_info` SET `bounding_radius`=0.8725, `combat_reach`=3.75, `gender`=1 WHERE `modelid`=34104; -- 34104
UPDATE `creature_model_info` SET `bounding_radius`=0.875, `combat_reach`=2.625 WHERE `modelid`=15483; -- 15483
UPDATE `creature_model_info` SET `bounding_radius`=0.875, `combat_reach`=7.5 WHERE `modelid`=20862; -- 20862
UPDATE `creature_model_info` SET `bounding_radius`=0.8755, `combat_reach`=1.094375 WHERE `modelid`=1938; -- 1938
UPDATE `creature_model_info` SET `bounding_radius`=0.884, `combat_reach`=1.105 WHERE `modelid`=999; -- 999
UPDATE `creature_model_info` SET `bounding_radius`=0.89, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.8928, `combat_reach`=3.6 WHERE `modelid`=29579; -- 29579
UPDATE `creature_model_info` SET `bounding_radius`=0.8928, `combat_reach`=3.6 WHERE `modelid`=29659; -- 29659
UPDATE `creature_model_info` SET `bounding_radius`=0.8928, `combat_reach`=3.6, `gender`=0 WHERE `modelid`=29578; -- 29578
UPDATE `creature_model_info` SET `bounding_radius`=0.8928, `combat_reach`=3.6, `gender`=0 WHERE `modelid`=29660; -- 29660
UPDATE `creature_model_info` SET `bounding_radius`=0.9, `combat_reach`=1.5 WHERE `modelid`=35353; -- 35353
UPDATE `creature_model_info` SET `bounding_radius`=0.9, `combat_reach`=12.6 WHERE `modelid`=28548; -- 28548
UPDATE `creature_model_info` SET `bounding_radius`=0.9, `combat_reach`=4.5 WHERE `modelid`=12162; -- 12162
UPDATE `creature_model_info` SET `bounding_radius`=0.9, `combat_reach`=9, `gender`=0 WHERE `modelid`=20023; -- 20023
UPDATE `creature_model_info` SET `bounding_radius`=0.901, `combat_reach`=1.12625 WHERE `modelid`=1938; -- 1938
UPDATE `creature_model_info` SET `bounding_radius`=0.9045001, `combat_reach`=1.35, `gender`=0 WHERE `modelid`=32914; -- 32914
UPDATE `creature_model_info` SET `bounding_radius`=0.91, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.915, `combat_reach`=10.5 WHERE `modelid`=38414; -- 38414
UPDATE `creature_model_info` SET `bounding_radius`=0.916668, `combat_reach`=3, `gender`=0 WHERE `modelid`=19949; -- 19949
UPDATE `creature_model_info` SET `bounding_radius`=0.916668, `combat_reach`=3, `gender`=0 WHERE `modelid`=19950; -- 19950
UPDATE `creature_model_info` SET `bounding_radius`=0.91668, `combat_reach`=15 WHERE `modelid`=38501; -- 38501
UPDATE `creature_model_info` SET `bounding_radius`=0.918, `combat_reach`=6 WHERE `modelid`=38449; -- 38449
UPDATE `creature_model_info` SET `bounding_radius`=0.918, `combat_reach`=6 WHERE `modelid`=38450; -- 38450
UPDATE `creature_model_info` SET `bounding_radius`=0.9192, `combat_reach`=3.6 WHERE `modelid`=29581; -- 29581
UPDATE `creature_model_info` SET `bounding_radius`=0.9192, `combat_reach`=3.6 WHERE `modelid`=29652; -- 29652
UPDATE `creature_model_info` SET `bounding_radius`=0.9192, `combat_reach`=3.6 WHERE `modelid`=29653; -- 29653
UPDATE `creature_model_info` SET `bounding_radius`=0.9192, `combat_reach`=3.6, `gender`=0 WHERE `modelid`=29580; -- 29580
UPDATE `creature_model_info` SET `bounding_radius`=0.9192, `combat_reach`=3.6, `gender`=0 WHERE `modelid`=29651; -- 29651
UPDATE `creature_model_info` SET `bounding_radius`=0.9192, `combat_reach`=3.6, `gender`=0 WHERE `modelid`=29654; -- 29654
UPDATE `creature_model_info` SET `bounding_radius`=0.9192, `combat_reach`=3.6, `gender`=1 WHERE `modelid`=29655; -- 29655
UPDATE `creature_model_info` SET `bounding_radius`=0.93, `combat_reach`=3 WHERE `modelid`=21168; -- 21168
UPDATE `creature_model_info` SET `bounding_radius`=0.93, `combat_reach`=3 WHERE `modelid`=28578; -- 28578
UPDATE `creature_model_info` SET `bounding_radius`=0.93, `combat_reach`=3 WHERE `modelid`=32961; -- 32961
UPDATE `creature_model_info` SET `bounding_radius`=0.93, `combat_reach`=3, `gender`=0 WHERE `modelid`=34424; -- 34424
UPDATE `creature_model_info` SET `bounding_radius`=0.93, `combat_reach`=3, `gender`=0 WHERE `modelid`=37953; -- 37953
UPDATE `creature_model_info` SET `bounding_radius`=0.93, `combat_reach`=4.5 WHERE `modelid`=38030; -- 38030
UPDATE `creature_model_info` SET `bounding_radius`=0.93, `combat_reach`=7.5 WHERE `modelid`=35165; -- 35165
UPDATE `creature_model_info` SET `bounding_radius`=0.93, `combat_reach`=7.5, `gender`=0 WHERE `modelid`=35388; -- 35388
UPDATE `creature_model_info` SET `bounding_radius`=0.93, `combat_reach`=9 WHERE `modelid`=32654; -- 32654
UPDATE `creature_model_info` SET `bounding_radius`=0.93, `combat_reach`=9 WHERE `modelid`=33792; -- 33792
UPDATE `creature_model_info` SET `bounding_radius`=0.93, `combat_reach`=9 WHERE `modelid`=37282; -- 37282
UPDATE `creature_model_info` SET `bounding_radius`=0.93, `combat_reach`=9, `gender`=1 WHERE `modelid`=27983; -- 27983
UPDATE `creature_model_info` SET `bounding_radius`=0.9375, `combat_reach`=3.125 WHERE `modelid`=36527; -- 36527
UPDATE `creature_model_info` SET `bounding_radius`=0.9435, `combat_reach`=1.179375 WHERE `modelid`=1000; -- 1000
UPDATE `creature_model_info` SET `bounding_radius`=0.95, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.9594, `combat_reach`=2.7 WHERE `modelid`=571; -- 571
UPDATE `creature_model_info` SET `bounding_radius`=0.966, `combat_reach`=1.8, `gender`=0 WHERE `modelid`=36498; -- 36498
UPDATE `creature_model_info` SET `bounding_radius`=0.97, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05 WHERE `modelid`=13281; -- 13281
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05 WHERE `modelid`=24649; -- 24649
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05 WHERE `modelid`=26646; -- 26646
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05 WHERE `modelid`=30879; -- 30879
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05 WHERE `modelid`=9234; -- 9234
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05, `gender`=0 WHERE `modelid`=30681; -- 30681
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05, `gender`=0 WHERE `modelid`=30688; -- 30688
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05, `gender`=0 WHERE `modelid`=31600; -- 31600
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05, `gender`=0 WHERE `modelid`=31612; -- 31612
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05, `gender`=0 WHERE `modelid`=32618; -- 32618
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05, `gender`=0 WHERE `modelid`=32864; -- 32864
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05, `gender`=0 WHERE `modelid`=34105; -- 34105
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05, `gender`=0 WHERE `modelid`=37219; -- 37219
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05, `gender`=0 WHERE `modelid`=37220; -- 37220
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05, `gender`=0 WHERE `modelid`=37221; -- 37221
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05, `gender`=0 WHERE `modelid`=38725; -- 38725
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05, `gender`=0 WHERE `modelid`=39616; -- 39616
UPDATE `creature_model_info` SET `bounding_radius`=0.9847457, `combat_reach`=1.230932 WHERE `modelid`=9563; -- 9563
UPDATE `creature_model_info` SET `bounding_radius`=0.986, `combat_reach`=1.2325 WHERE `modelid`=1938; -- 1938
UPDATE `creature_model_info` SET `bounding_radius`=1 WHERE `modelid`=18684; -- 18684
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1 WHERE `modelid`=1336; -- 1336
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1 WHERE `modelid`=21244; -- 21244
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1 WHERE `modelid`=27879; -- 27879
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1 WHERE `modelid`=32786; -- 32786
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1 WHERE `modelid`=33850; -- 33850
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1, `gender`=0 WHERE `modelid`=30974; -- 30974
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1, `gender`=1 WHERE `modelid`=37729; -- 37729
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=17480; -- 17480
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=17515; -- 17515
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=20288; -- 20288
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=21308; -- 21308
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=21671; -- 21671
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=22473; -- 22473
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=22541; -- 22541
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=22835; -- 22835
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=22837; -- 22837
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=22842; -- 22842
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=22852; -- 22852
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=22971; -- 22971
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=23470; -- 23470
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=23558; -- 23558
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=23560; -- 23560
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=23716; -- 23716
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=23717; -- 23717
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=32954; -- 32954
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=36111; -- 36111
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=38018; -- 38018
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=38738; -- 38738
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=18327; -- 18327
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=20289; -- 20289
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31598; -- 31598
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31608; -- 31608
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33095; -- 33095
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33354; -- 33354
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=34100; -- 34100
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=35530; -- 35530
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=38257; -- 38257
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=31596; -- 31596
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33356; -- 33356
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33663; -- 33663
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=35694; -- 35694
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=38716; -- 38716
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=10 WHERE `modelid`=21446; -- 21446
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=15 WHERE `modelid`=27769; -- 27769
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=2 WHERE `modelid`=28419; -- 28419
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=20, `gender`=0 WHERE `modelid`=11121; -- 11121
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=3 WHERE `modelid`=15431; -- 15431
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=3 WHERE `modelid`=19673; -- 19673
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=3 WHERE `modelid`=37225; -- 37225
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=5 WHERE `modelid`=32000; -- 32000
UPDATE `creature_model_info` SET `bounding_radius`=1.005, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=31770; -- 31770
UPDATE `creature_model_info` SET `bounding_radius`=1.00625, `combat_reach`=1.875 WHERE `modelid`=32934; -- 32934
UPDATE `creature_model_info` SET `bounding_radius`=1.041666, `combat_reach`=4.5 WHERE `modelid`=25839; -- 25839
UPDATE `creature_model_info` SET `bounding_radius`=1.047, `combat_reach`=4.5 WHERE `modelid`=23841; -- 23841
UPDATE `creature_model_info` SET `bounding_radius`=1.047, `combat_reach`=4.5, `gender`=1 WHERE `modelid`=38034; -- 38034
UPDATE `creature_model_info` SET `bounding_radius`=1.047, `combat_reach`=4.5, `gender`=1 WHERE `modelid`=38035; -- 38035
UPDATE `creature_model_info` SET `bounding_radius`=1.05, `combat_reach`=0.875 WHERE `modelid`=18156; -- 18156
UPDATE `creature_model_info` SET `bounding_radius`=1.05, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.05, `combat_reach`=1.75 WHERE `modelid`=36313; -- 36313
UPDATE `creature_model_info` SET `bounding_radius`=1.05, `combat_reach`=12 WHERE `modelid`=14367; -- 14367
UPDATE `creature_model_info` SET `bounding_radius`=1.05, `combat_reach`=12, `gender`=0 WHERE `modelid`=34433; -- 34433
UPDATE `creature_model_info` SET `bounding_radius`=1.05, `combat_reach`=3.5, `gender`=1 WHERE `modelid`=20748; -- 20748
UPDATE `creature_model_info` SET `bounding_radius`=1.05, `combat_reach`=7.5 WHERE `modelid`=13170; -- 13170
UPDATE `creature_model_info` SET `bounding_radius`=1.065, `combat_reach`=1.875, `gender`=0 WHERE `modelid`=34735; -- 34735
UPDATE `creature_model_info` SET `bounding_radius`=1.065, `combat_reach`=1.875, `gender`=0 WHERE `modelid`=34736; -- 34736
UPDATE `creature_model_info` SET `bounding_radius`=1.065, `combat_reach`=1.875, `gender`=0 WHERE `modelid`=34745; -- 34745
UPDATE `creature_model_info` SET `bounding_radius`=1.065, `combat_reach`=1.875, `gender`=0 WHERE `modelid`=34790; -- 34790
UPDATE `creature_model_info` SET `bounding_radius`=1.071, `combat_reach`=1.33875 WHERE `modelid`=641; -- 641
UPDATE `creature_model_info` SET `bounding_radius`=1.07217, `combat_reach`=4.455 WHERE `modelid`=16966; -- 16966
UPDATE `creature_model_info` SET `bounding_radius`=1.085, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=34342; -- 34342
UPDATE `creature_model_info` SET `bounding_radius`=1.085, `combat_reach`=10.5, `gender`=1 WHERE `modelid`=39691; -- 39691
UPDATE `creature_model_info` SET `bounding_radius`=1.085, `combat_reach`=3.5 WHERE `modelid`=39321; -- 39321
UPDATE `creature_model_info` SET `bounding_radius`=1.090625, `combat_reach`=4.6875 WHERE `modelid`=23976; -- 23976
UPDATE `creature_model_info` SET `bounding_radius`=1.090625, `combat_reach`=4.6875 WHERE `modelid`=28408; -- 28408
UPDATE `creature_model_info` SET `bounding_radius`=1.1, `combat_reach`=1.5 WHERE `modelid`=35355; -- 35355
UPDATE `creature_model_info` SET `bounding_radius`=1.1, `combat_reach`=1.65 WHERE `modelid`=15375; -- 15375
UPDATE `creature_model_info` SET `bounding_radius`=1.1, `combat_reach`=1.65 WHERE `modelid`=16593; -- 16593
UPDATE `creature_model_info` SET `bounding_radius`=1.1, `combat_reach`=1.65 WHERE `modelid`=22972; -- 22972
UPDATE `creature_model_info` SET `bounding_radius`=1.1, `combat_reach`=1.65 WHERE `modelid`=27145; -- 27145
UPDATE `creature_model_info` SET `bounding_radius`=1.102983, `combat_reach`=0.8847458 WHERE `modelid`=9756; -- 9756
UPDATE `creature_model_info` SET `bounding_radius`=1.122, `combat_reach`=0.9 WHERE `modelid`=13111; -- 13111
UPDATE `creature_model_info` SET `bounding_radius`=1.122, `combat_reach`=0.9 WHERE `modelid`=36516; -- 36516
UPDATE `creature_model_info` SET `bounding_radius`=1.122, `combat_reach`=0.9 WHERE `modelid`=368; -- 368
UPDATE `creature_model_info` SET `bounding_radius`=1.122, `combat_reach`=0.9 WHERE `modelid`=958; -- 958
UPDATE `creature_model_info` SET `bounding_radius`=1.125, `combat_reach`=0.9375 WHERE `modelid`=666; -- 666
UPDATE `creature_model_info` SET `bounding_radius`=1.125, `combat_reach`=3.125, `gender`=0 WHERE `modelid`=14416; -- 14416
UPDATE `creature_model_info` SET `bounding_radius`=1.125, `combat_reach`=3.75, `gender`=0 WHERE `modelid`=14352; -- 14352
UPDATE `creature_model_info` SET `bounding_radius`=1.13, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.15, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.156, `combat_reach`=1.445 WHERE `modelid`=1000; -- 1000
UPDATE `creature_model_info` SET `bounding_radius`=1.167, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=17340; -- 17340
UPDATE `creature_model_info` SET `bounding_radius`=1.16964, `combat_reach`=4.860001, `gender`=0 WHERE `modelid`=30411; -- 30411
UPDATE `creature_model_info` SET `bounding_radius`=1.16964, `combat_reach`=4.860001, `gender`=0 WHERE `modelid`=33189; -- 33189
UPDATE `creature_model_info` SET `bounding_radius`=1.16964, `combat_reach`=4.860001, `gender`=0 WHERE `modelid`=38036; -- 38036
UPDATE `creature_model_info` SET `bounding_radius`=1.16964, `combat_reach`=4.860001, `gender`=0 WHERE `modelid`=38037; -- 38037
UPDATE `creature_model_info` SET `bounding_radius`=1.16964, `combat_reach`=4.860001, `gender`=0 WHERE `modelid`=38038; -- 38038
UPDATE `creature_model_info` SET `bounding_radius`=1.16964, `combat_reach`=4.860001, `gender`=0 WHERE `modelid`=38039; -- 38039
UPDATE `creature_model_info` SET `bounding_radius`=1.16964, `combat_reach`=4.860001, `gender`=0 WHERE `modelid`=38045; -- 38045
UPDATE `creature_model_info` SET `bounding_radius`=1.173, `combat_reach`=1.46625 WHERE `modelid`=1000; -- 1000
UPDATE `creature_model_info` SET `bounding_radius`=1.182, `combat_reach`=4.5 WHERE `modelid`=24274; -- 24274
UPDATE `creature_model_info` SET `bounding_radius`=1.2, `combat_reach`=1.2, `gender`=0 WHERE `modelid`=16839; -- 16839
UPDATE `creature_model_info` SET `bounding_radius`=1.2, `combat_reach`=1.5 WHERE `modelid`=20644; -- 20644
UPDATE `creature_model_info` SET `bounding_radius`=1.2, `combat_reach`=1.5 WHERE `modelid`=21101; -- 21101
UPDATE `creature_model_info` SET `bounding_radius`=1.2, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30408; -- 30408
UPDATE `creature_model_info` SET `bounding_radius`=1.2, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36384; -- 36384
UPDATE `creature_model_info` SET `bounding_radius`=1.2, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36782; -- 36782
UPDATE `creature_model_info` SET `bounding_radius`=1.2, `combat_reach`=1.8 WHERE `modelid`=14585; -- 14585
UPDATE `creature_model_info` SET `bounding_radius`=1.2, `combat_reach`=1.8 WHERE `modelid`=20767; -- 20767
UPDATE `creature_model_info` SET `bounding_radius`=1.2, `combat_reach`=3 WHERE `modelid`=29756; -- 29756
UPDATE `creature_model_info` SET `bounding_radius`=1.2075, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=36123; -- 36123
UPDATE `creature_model_info` SET `bounding_radius`=1.215277, `combat_reach`=5.25 WHERE `modelid`=20662; -- 20662
UPDATE `creature_model_info` SET `bounding_radius`=1.218375, `combat_reach`=5.0625 WHERE `modelid`=31209; -- 31209
UPDATE `creature_model_info` SET `bounding_radius`=1.222034, `combat_reach`=1.527542 WHERE `modelid`=9570; -- 9570
UPDATE `creature_model_info` SET `bounding_radius`=1.22224, `combat_reach`=4 WHERE `modelid`=17535; -- 17535
UPDATE `creature_model_info` SET `bounding_radius`=1.224, `combat_reach`=8 WHERE `modelid`=38258; -- 38258
UPDATE `creature_model_info` SET `bounding_radius`=1.24, `combat_reach`=4 WHERE `modelid`=21394; -- 21394
UPDATE `creature_model_info` SET `bounding_radius`=1.24, `combat_reach`=4 WHERE `modelid`=36511; -- 36511
UPDATE `creature_model_info` SET `bounding_radius`=1.24, `combat_reach`=4 WHERE `modelid`=36512; -- 36512
UPDATE `creature_model_info` SET `bounding_radius`=1.24, `combat_reach`=6 WHERE `modelid`=36323; -- 36323
UPDATE `creature_model_info` SET `bounding_radius`=1.24, `combat_reach`=6 WHERE `modelid`=36324; -- 36324
UPDATE `creature_model_info` SET `bounding_radius`=1.24, `combat_reach`=6 WHERE `modelid`=36328; -- 36328
UPDATE `creature_model_info` SET `bounding_radius`=1.24, `combat_reach`=6 WHERE `modelid`=38255; -- 38255
UPDATE `creature_model_info` SET `bounding_radius`=1.24, `combat_reach`=6 WHERE `modelid`=39548; -- 39548
UPDATE `creature_model_info` SET `bounding_radius`=1.24, `combat_reach`=6 WHERE `modelid`=39550; -- 39550
UPDATE `creature_model_info` SET `bounding_radius`=1.24, `combat_reach`=8 WHERE `modelid`=28844; -- 28844
UPDATE `creature_model_info` SET `bounding_radius`=1.24, `combat_reach`=8 WHERE `modelid`=39101; -- 39101
UPDATE `creature_model_info` SET `bounding_radius`=1.241, `combat_reach`=1.55125 WHERE `modelid`=1000; -- 1000
UPDATE `creature_model_info` SET `bounding_radius`=1.25, `combat_reach`=1.25, `gender`=1 WHERE `modelid`=37387; -- 37387
UPDATE `creature_model_info` SET `bounding_radius`=1.25, `combat_reach`=1.25, `gender`=1 WHERE `modelid`=37388; -- 37388
UPDATE `creature_model_info` SET `bounding_radius`=1.25, `combat_reach`=5 WHERE `modelid`=15343; -- 15343
UPDATE `creature_model_info` SET `bounding_radius`=1.25, `combat_reach`=5.5 WHERE `modelid`=23890; -- 23890
UPDATE `creature_model_info` SET `bounding_radius`=1.25, `combat_reach`=6.25 WHERE `modelid`=12233; -- 12233
UPDATE `creature_model_info` SET `bounding_radius`=1.25, `combat_reach`=6.25 WHERE `modelid`=38852; -- 38852
UPDATE `creature_model_info` SET `bounding_radius`=1.2665, `combat_reach`=1.583125 WHERE `modelid`=641; -- 641
UPDATE `creature_model_info` SET `bounding_radius`=1.26711, `combat_reach`=5.265 WHERE `modelid`=59; -- 59
UPDATE `creature_model_info` SET `bounding_radius`=1.27, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.29, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.3, `combat_reach`=1.625 WHERE `modelid`=6818; -- 6818
UPDATE `creature_model_info` SET `bounding_radius`=1.3, `combat_reach`=1.95 WHERE `modelid`=17920; -- 17920
UPDATE `creature_model_info` SET `bounding_radius`=1.3, `combat_reach`=1.95 WHERE `modelid`=7856; -- 7856
UPDATE `creature_model_info` SET `bounding_radius`=1.3, `combat_reach`=1.95 WHERE `modelid`=8149; -- 8149
UPDATE `creature_model_info` SET `bounding_radius`=1.3, `combat_reach`=1.95, `gender`=0 WHERE `modelid`=14380; -- 14380
UPDATE `creature_model_info` SET `bounding_radius`=1.3, `combat_reach`=2.6 WHERE `modelid`=31114; -- 31114
UPDATE `creature_model_info` SET `bounding_radius`=1.30875, `combat_reach`=5.625, `gender`=1 WHERE `modelid`=38604; -- 38604
UPDATE `creature_model_info` SET `bounding_radius`=1.31, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.324576, `combat_reach`=1.324576 WHERE `modelid`=12333; -- 12333
UPDATE `creature_model_info` SET `bounding_radius`=1.33, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.332203, `combat_reach`=1.332203 WHERE `modelid`=13211; -- 13211
UPDATE `creature_model_info` SET `bounding_radius`=1.333, `combat_reach`=8.6, `gender`=1 WHERE `modelid`=28839; -- 28839
UPDATE `creature_model_info` SET `bounding_radius`=1.3405, `combat_reach`=5.25 WHERE `modelid`=24934; -- 24934
UPDATE `creature_model_info` SET `bounding_radius`=1.3405, `combat_reach`=5.25, `gender`=0 WHERE `modelid`=39323; -- 39323
UPDATE `creature_model_info` SET `bounding_radius`=1.35, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.36458, `combat_reach`=5.67, `gender`=0 WHERE `modelid`=31784; -- 31784
UPDATE `creature_model_info` SET `bounding_radius`=1.3764, `combat_reach`=3.6 WHERE `modelid`=6089; -- 6089
UPDATE `creature_model_info` SET `bounding_radius`=1.39, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.4, `combat_reach`=1.75 WHERE `modelid`=32023; -- 32023
UPDATE `creature_model_info` SET `bounding_radius`=1.4, `combat_reach`=1.75 WHERE `modelid`=32075; -- 32075
UPDATE `creature_model_info` SET `bounding_radius`=1.4, `combat_reach`=1.75 WHERE `modelid`=32143; -- 32143
UPDATE `creature_model_info` SET `bounding_radius`=1.4, `combat_reach`=1.75 WHERE `modelid`=33122; -- 33122
UPDATE `creature_model_info` SET `bounding_radius`=1.4, `combat_reach`=1.75 WHERE `modelid`=38825; -- 38825
UPDATE `creature_model_info` SET `bounding_radius`=1.4, `combat_reach`=1.75 WHERE `modelid`=641; -- 641
UPDATE `creature_model_info` SET `bounding_radius`=1.4, `combat_reach`=1.75 WHERE `modelid`=6828; -- 6828
UPDATE `creature_model_info` SET `bounding_radius`=1.4, `combat_reach`=1.75 WHERE `modelid`=6830; -- 6830
UPDATE `creature_model_info` SET `bounding_radius`=1.4, `combat_reach`=2 WHERE `modelid`=21193; -- 21193
UPDATE `creature_model_info` SET `bounding_radius`=1.4055, `combat_reach`=2.25 WHERE `modelid`=36412; -- 36412
UPDATE `creature_model_info` SET `bounding_radius`=1.4288, `combat_reach`=2.4, `gender`=0 WHERE `modelid`=18355; -- 18355
UPDATE `creature_model_info` SET `bounding_radius`=1.43, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.45, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.46205, `combat_reach`=6.075 WHERE `modelid`=17332; -- 17332
UPDATE `creature_model_info` SET `bounding_radius`=1.46205, `combat_reach`=6.075 WHERE `modelid`=29048; -- 29048
UPDATE `creature_model_info` SET `bounding_radius`=1.46205, `combat_reach`=6.075, `gender`=0 WHERE `modelid`=38606; -- 38606
UPDATE `creature_model_info` SET `bounding_radius`=1.496, `combat_reach`=1.2 WHERE `modelid`=30495; -- 30495
UPDATE `creature_model_info` SET `bounding_radius`=1.5 WHERE `modelid`=16206; -- 16206
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=0.6 WHERE `modelid`=36112; -- 36112
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.1, `gender`=0 WHERE `modelid`=19877; -- 19877
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.25 WHERE `modelid`=785; -- 785
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.5 WHERE `modelid`=19142; -- 19142
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.5 WHERE `modelid`=19258; -- 19258
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.5 WHERE `modelid`=20635; -- 20635
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.5 WHERE `modelid`=20636; -- 20636
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.5 WHERE `modelid`=20637; -- 20637
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.5 WHERE `modelid`=20638; -- 20638
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.5 WHERE `modelid`=20639; -- 20639
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.5 WHERE `modelid`=20640; -- 20640
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.5 WHERE `modelid`=36631; -- 36631
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=39456; -- 39456
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=32478; -- 32478
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=32902; -- 32902
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.8 WHERE `modelid`=19592; -- 19592
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=15 WHERE `modelid`=28110; -- 28110
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=15 WHERE `modelid`=39110; -- 39110
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=15 WHERE `modelid`=39111; -- 39111
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=15 WHERE `modelid`=7806; -- 7806
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=15, `gender`=0 WHERE `modelid`=13992; -- 13992
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=2.5 WHERE `modelid`=32660; -- 32660
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=21 WHERE `modelid`=38415; -- 38415
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=21 WHERE `modelid`=38416; -- 38416
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=3 WHERE `modelid`=12210; -- 12210
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=3 WHERE `modelid`=15336; -- 15336
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=3 WHERE `modelid`=38404; -- 38404
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=5 WHERE `modelid`=15512; -- 15512
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=5.25, `gender`=0 WHERE `modelid`=31498; -- 31498
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=5.25, `gender`=0 WHERE `modelid`=36700; -- 36700
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=6 WHERE `modelid`=15742; -- 15742
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=7.5 WHERE `modelid`=38766; -- 38766
UPDATE `creature_model_info` SET `bounding_radius`=1.525, `combat_reach`=12.5 WHERE `modelid`=33477; -- 33477
UPDATE `creature_model_info` SET `bounding_radius`=1.55, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.55, `combat_reach`=12.5 WHERE `modelid`=35100; -- 35100
UPDATE `creature_model_info` SET `bounding_radius`=1.55, `combat_reach`=5 WHERE `modelid`=26968; -- 26968
UPDATE `creature_model_info` SET `bounding_radius`=1.5625, `combat_reach`=15.625 WHERE `modelid`=15432; -- 15432
UPDATE `creature_model_info` SET `bounding_radius`=1.56975, `combat_reach`=2.925, `gender`=0 WHERE `modelid`=36123; -- 36123
UPDATE `creature_model_info` SET `bounding_radius`=1.6, `combat_reach`=1.6 WHERE `modelid`=38507; -- 38507
UPDATE `creature_model_info` SET `bounding_radius`=1.6, `combat_reach`=6 WHERE `modelid`=15376; -- 15376
UPDATE `creature_model_info` SET `bounding_radius`=1.6095, `combat_reach`=2.25 WHERE `modelid`=11315; -- 11315
UPDATE `creature_model_info` SET `bounding_radius`=1.6095, `combat_reach`=2.25, `gender`=1 WHERE `modelid`=30145; -- 30145
UPDATE `creature_model_info` SET `bounding_radius`=1.61, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.65, `combat_reach`=60.5, `gender`=0 WHERE `modelid`=33322; -- 33322
UPDATE `creature_model_info` SET `bounding_radius`=1.6675, `combat_reach`=1.725 WHERE `modelid`=33316; -- 33316
UPDATE `creature_model_info` SET `bounding_radius`=1.69, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.705725, `combat_reach`=7.0875, `gender`=0 WHERE `modelid`=39399; -- 39399
UPDATE `creature_model_info` SET `bounding_radius`=1.725, `combat_reach`=3.45 WHERE `modelid`=6375; -- 6375
UPDATE `creature_model_info` SET `bounding_radius`=1.73, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.745, `combat_reach`=7.5, `gender`=1 WHERE `modelid`=39836; -- 39836
UPDATE `creature_model_info` SET `bounding_radius`=1.75, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.75, `combat_reach`=1.75 WHERE `modelid`=18954; -- 18954
UPDATE `creature_model_info` SET `bounding_radius`=1.75, `combat_reach`=1.75 WHERE `modelid`=20642; -- 20642
UPDATE `creature_model_info` SET `bounding_radius`=1.75, `combat_reach`=2.625, `gender`=0 WHERE `modelid`=32610; -- 32610
UPDATE `creature_model_info` SET `bounding_radius`=1.75, `combat_reach`=3.5, `gender`=0 WHERE `modelid`=31705; -- 31705
UPDATE `creature_model_info` SET `bounding_radius`=1.75, `combat_reach`=5.25 WHERE `modelid`=28133; -- 28133
UPDATE `creature_model_info` SET `bounding_radius`=1.77, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.78875, `combat_reach`=3.375, `gender`=0 WHERE `modelid`=20425; -- 20425
UPDATE `creature_model_info` SET `bounding_radius`=1.79, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.8 WHERE `modelid`=18287; -- 18287
UPDATE `creature_model_info` SET `bounding_radius`=1.8, `combat_reach`=1.5 WHERE `modelid`=20630; -- 20630
UPDATE `creature_model_info` SET `bounding_radius`=1.8, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=30408; -- 30408
UPDATE `creature_model_info` SET `bounding_radius`=1.8, `combat_reach`=1.8 WHERE `modelid`=20212; -- 20212
UPDATE `creature_model_info` SET `bounding_radius`=1.8, `combat_reach`=1.8 WHERE `modelid`=20641; -- 20641
UPDATE `creature_model_info` SET `bounding_radius`=1.8, `combat_reach`=1.8 WHERE `modelid`=30814; -- 30814
UPDATE `creature_model_info` SET `bounding_radius`=1.8, `combat_reach`=1.8 WHERE `modelid`=38506; -- 38506
UPDATE `creature_model_info` SET `bounding_radius`=1.81, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.83, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.833336, `combat_reach`=30 WHERE `modelid`=30167; -- 30167
UPDATE `creature_model_info` SET `bounding_radius`=1.85, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.85, `combat_reach`=5.55 WHERE `modelid`=18275; -- 18275
UPDATE `creature_model_info` SET `bounding_radius`=1.86, `combat_reach`=18 WHERE `modelid`=36703; -- 36703
UPDATE `creature_model_info` SET `bounding_radius`=1.86, `combat_reach`=9 WHERE `modelid`=37307; -- 37307
UPDATE `creature_model_info` SET `bounding_radius`=1.87, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.874, `combat_reach`=3 WHERE `modelid`=29155; -- 29155
UPDATE `creature_model_info` SET `bounding_radius`=1.875, `combat_reach`=2.1875, `gender`=0 WHERE `modelid`=31499; -- 31499
UPDATE `creature_model_info` SET `bounding_radius`=1.875, `combat_reach`=3.75 WHERE `modelid`=9129; -- 9129
UPDATE `creature_model_info` SET `bounding_radius`=1.89, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.91, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.9494, `combat_reach`=8.1, `gender`=0 WHERE `modelid`=38791; -- 38791
UPDATE `creature_model_info` SET `bounding_radius`=1.95, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=1.95, `combat_reach`=1.625 WHERE `modelid`=23114; -- 23114
UPDATE `creature_model_info` SET `bounding_radius`=1.95, `combat_reach`=1.95, `gender`=0 WHERE `modelid`=39456; -- 39456
UPDATE `creature_model_info` SET `bounding_radius`=1.95, `combat_reach`=3.9 WHERE `modelid`=9584; -- 9584
UPDATE `creature_model_info` SET `bounding_radius`=1.967, `combat_reach`=1.5 WHERE `modelid`=181; -- 181
UPDATE `creature_model_info` SET `bounding_radius`=10, `combat_reach`=10 WHERE `modelid`=39233; -- 39233
UPDATE `creature_model_info` SET `bounding_radius`=10, `combat_reach`=10, `gender`=0 WHERE `modelid`=26100; -- 26100
UPDATE `creature_model_info` SET `bounding_radius`=100, `combat_reach`=1.5 WHERE `modelid`=39316; -- 39316
UPDATE `creature_model_info` SET `bounding_radius`=11.4, `combat_reach`=1.5 WHERE `modelid`=39918; -- 39918
UPDATE `creature_model_info` SET `bounding_radius`=13.125, `combat_reach`=2.625 WHERE `modelid`=26140; -- 26140
UPDATE `creature_model_info` SET `bounding_radius`=16, `combat_reach`=16 WHERE `modelid`=34532; -- 34532
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=1.5 WHERE `modelid`=38524; -- 38524
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=22501; -- 22501
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=29842; -- 29842
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=36054; -- 36054
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=37304; -- 37304
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=38812; -- 38812
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=10 WHERE `modelid`=27542; -- 27542
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=10 WHERE `modelid`=38765; -- 38765
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=10 WHERE `modelid`=39429; -- 39429
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=10, `gender`=0 WHERE `modelid`=39681; -- 39681
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=2 WHERE `modelid`=22981; -- 22981
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=2 WHERE `modelid`=29074; -- 29074
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=2 WHERE `modelid`=31779; -- 31779
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=2 WHERE `modelid`=37286; -- 37286
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=2, `gender`=0 WHERE `modelid`=23352; -- 23352
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=2.4 WHERE `modelid`=39298; -- 39298
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=2.4 WHERE `modelid`=39545; -- 39545
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=2.5 WHERE `modelid`=21912; -- 21912
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=2.5 WHERE `modelid`=31993; -- 31993
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=3, `gender`=0 WHERE `modelid`=29538; -- 29538
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=3, `gender`=0 WHERE `modelid`=38256; -- 38256
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=3, `gender`=0 WHERE `modelid`=38477; -- 38477
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=4 WHERE `modelid`=30039; -- 30039
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=4.2, `gender`=0 WHERE `modelid`=33417; -- 33417
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=5 WHERE `modelid`=17764; -- 17764
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=5 WHERE `modelid`=31717; -- 31717
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=7, `gender`=0 WHERE `modelid`=22174; -- 22174
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=7, `gender`=0 WHERE `modelid`=33429; -- 33429
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=8, `gender`=0 WHERE `modelid`=40086; -- 40086
UPDATE `creature_model_info` SET `bounding_radius`=2.05, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=2.09, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=2.094, `combat_reach`=9, `gender`=1 WHERE `modelid`=29647; -- 29647
UPDATE `creature_model_info` SET `bounding_radius`=2.1, `combat_reach`=2.45, `gender`=0 WHERE `modelid`=31501; -- 31501
UPDATE `creature_model_info` SET `bounding_radius`=2.11, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=2.14434, `combat_reach`=8.91, `gender`=0 WHERE `modelid`=35963; -- 35963
UPDATE `creature_model_info` SET `bounding_radius`=2.15, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=2.17, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=2.17, `combat_reach`=7, `gender`=1 WHERE `modelid`=28009; -- 28009
UPDATE `creature_model_info` SET `bounding_radius`=2.19, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=2.2, `combat_reach`=2.2 WHERE `modelid`=38508; -- 38508
UPDATE `creature_model_info` SET `bounding_radius`=2.21, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=2.23, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=2.25, `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=2.25, `combat_reach`=6.75, `gender`=0 WHERE `modelid`=31710; -- 31710
UPDATE `creature_model_info` SET `bounding_radius`=2.26205, `combat_reach`=1.725, `gender`=0 WHERE `modelid`=31512; -- 31512
UPDATE `creature_model_info` SET `bounding_radius`=2.3375, `combat_reach`=1.875 WHERE `modelid`=9755; -- 9755
UPDATE `creature_model_info` SET `bounding_radius`=2.33928, `combat_reach`=9.720001 WHERE `modelid`=29583; -- 29583
UPDATE `creature_model_info` SET `bounding_radius`=2.33928, `combat_reach`=9.720001 WHERE `modelid`=29646; -- 29646
UPDATE `creature_model_info` SET `bounding_radius`=2.33928, `combat_reach`=9.720001, `gender`=0 WHERE `modelid`=29582; -- 29582
UPDATE `creature_model_info` SET `bounding_radius`=2.33928, `combat_reach`=9.720001, `gender`=0 WHERE `modelid`=29645; -- 29645
UPDATE `creature_model_info` SET `bounding_radius`=2.38, `combat_reach`=10.5, `gender`=1 WHERE `modelid`=25634; -- 25634
UPDATE `creature_model_info` SET `bounding_radius`=2.38, `combat_reach`=10.5, `gender`=1 WHERE `modelid`=25685; -- 25685
UPDATE `creature_model_info` SET `bounding_radius`=2.4, `combat_reach`=2.4 WHERE `modelid`=4960; -- 4960
UPDATE `creature_model_info` SET `bounding_radius`=2.4, `combat_reach`=3.6 WHERE `modelid`=29577; -- 29577
UPDATE `creature_model_info` SET `bounding_radius`=2.4, `combat_reach`=3.6 WHERE `modelid`=29640; -- 29640
UPDATE `creature_model_info` SET `bounding_radius`=2.4, `combat_reach`=3.6, `gender`=0 WHERE `modelid`=29576; -- 29576
UPDATE `creature_model_info` SET `bounding_radius`=2.4, `combat_reach`=3.6, `gender`=0 WHERE `modelid`=29639; -- 29639
UPDATE `creature_model_info` SET `bounding_radius`=2.4, `combat_reach`=3.6, `gender`=1 WHERE `modelid`=29641; -- 29641
UPDATE `creature_model_info` SET `bounding_radius`=2.4, `combat_reach`=6.25 WHERE `modelid`=28615; -- 28615
UPDATE `creature_model_info` SET `bounding_radius`=2.485, `combat_reach`=4.375, `gender`=0 WHERE `modelid`=35067; -- 35067
UPDATE `creature_model_info` SET `bounding_radius`=2.5, `combat_reach`=10 WHERE `modelid`=15392; -- 15392
UPDATE `creature_model_info` SET `bounding_radius`=2.5, `combat_reach`=2.5 WHERE `modelid`=20238; -- 20238
UPDATE `creature_model_info` SET `bounding_radius`=2.5, `combat_reach`=2.5, `gender`=0 WHERE `modelid`=20856; -- 20856
UPDATE `creature_model_info` SET `bounding_radius`=2.5, `combat_reach`=2.5, `gender`=0 WHERE `modelid`=28122; -- 28122
UPDATE `creature_model_info` SET `bounding_radius`=2.5, `combat_reach`=3.125 WHERE `modelid`=7845; -- 7845
UPDATE `creature_model_info` SET `bounding_radius`=2.5, `combat_reach`=3.75 WHERE `modelid`=32943; -- 32943
UPDATE `creature_model_info` SET `bounding_radius`=2.5, `combat_reach`=3.75 WHERE `modelid`=33055; -- 33055
UPDATE `creature_model_info` SET `bounding_radius`=2.5, `combat_reach`=3.75 WHERE `modelid`=33177; -- 33177
UPDATE `creature_model_info` SET `bounding_radius`=2.5, `combat_reach`=3.75 WHERE `modelid`=38779; -- 38779
UPDATE `creature_model_info` SET `bounding_radius`=2.5, `combat_reach`=3.75, `gender`=0 WHERE `modelid`=38239; -- 38239
UPDATE `creature_model_info` SET `bounding_radius`=2.625, `combat_reach`=2.625, `gender`=0 WHERE `modelid`=25662; -- 25662
UPDATE `creature_model_info` SET `bounding_radius`=2.625, `combat_reach`=2.625, `gender`=1 WHERE `modelid`=12892; -- 12892
UPDATE `creature_model_info` SET `bounding_radius`=2.75, `combat_reach`=2.75, `gender`=0 WHERE `modelid`=18607; -- 18607
UPDATE `creature_model_info` SET `bounding_radius`=2.75, `combat_reach`=2.75, `gender`=0 WHERE `modelid`=33147; -- 33147
UPDATE `creature_model_info` SET `bounding_radius`=2.75, `combat_reach`=3.4375 WHERE `modelid`=35080; -- 35080
UPDATE `creature_model_info` SET `bounding_radius`=2.7538, `combat_reach`=2.1, `gender`=0 WHERE `modelid`=31430; -- 31430
UPDATE `creature_model_info` SET `bounding_radius`=2.8, `combat_reach`=4.2, `gender`=0 WHERE `modelid`=11578; -- 11578
UPDATE `creature_model_info` SET `bounding_radius`=2.805, `combat_reach`=2.25 WHERE `modelid`=36517; -- 36517
UPDATE `creature_model_info` SET `bounding_radius`=2.8675, `combat_reach`=7.5 WHERE `modelid`=28651; -- 28651
UPDATE `creature_model_info` SET `bounding_radius`=2.8798, `combat_reach`=2.31 WHERE `modelid`=36518; -- 36518
UPDATE `creature_model_info` SET `bounding_radius`=2.9505, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=32970; -- 32970
UPDATE `creature_model_info` SET `bounding_radius`=2.9505, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=8311; -- 8311
UPDATE `creature_model_info` SET `bounding_radius`=20, `combat_reach`=20 WHERE `modelid`=38502; -- 38502
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=13.5 WHERE `modelid`=31450; -- 31450
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=15 WHERE `modelid`=7271; -- 7271
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=20, `gender`=0 WHERE `modelid`=11380; -- 11380
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=3 WHERE `modelid`=33553; -- 33553
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=3 WHERE `modelid`=38069; -- 38069
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=3 WHERE `modelid`=40058; -- 40058
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=3, `gender`=0 WHERE `modelid`=21318; -- 21318
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=3, `gender`=0 WHERE `modelid`=25663; -- 25663
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=3, `gender`=0 WHERE `modelid`=26644; -- 26644
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=3.75 WHERE `modelid`=9564; -- 9564
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=36 WHERE `modelid`=39354; -- 39354
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=36 WHERE `modelid`=39509; -- 39509
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=4.5 WHERE `modelid`=38424; -- 38424
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=4.5 WHERE `modelid`=38780; -- 38780
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=4.5, `gender`=0 WHERE `modelid`=38144; -- 38144
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=5.4 WHERE `modelid`=30174; -- 30174
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=5.67 WHERE `modelid`=15654; -- 15654
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=6 WHERE `modelid`=34580; -- 34580
UPDATE `creature_model_info` SET `bounding_radius`=3, `gender`=0 WHERE `modelid`=26352; -- 26352
UPDATE `creature_model_info` SET `bounding_radius`=3.04885, `combat_reach`=2.325, `gender`=0 WHERE `modelid`=31509; -- 31509
UPDATE `creature_model_info` SET `bounding_radius`=3.05556, `combat_reach`=10, `gender`=0 WHERE `modelid`=20952; -- 20952
UPDATE `creature_model_info` SET `bounding_radius`=3.1, `combat_reach`=10 WHERE `modelid`=28008; -- 28008
UPDATE `creature_model_info` SET `bounding_radius`=3.1, `combat_reach`=10 WHERE `modelid`=29001; -- 29001
UPDATE `creature_model_info` SET `bounding_radius`=3.26, `combat_reach`=3 WHERE `modelid`=15439; -- 15439
UPDATE `creature_model_info` SET `bounding_radius`=3.44225, `combat_reach`=2.625, `gender`=0 WHERE `modelid`=12893; -- 12893
UPDATE `creature_model_info` SET `bounding_radius`=3.5, `combat_reach`=17.5 WHERE `modelid`=39152; -- 39152
UPDATE `creature_model_info` SET `bounding_radius`=3.5, `combat_reach`=21, `gender`=0 WHERE `modelid`=39322; -- 39322
UPDATE `creature_model_info` SET `bounding_radius`=3.5, `combat_reach`=5.25, `gender`=0 WHERE `modelid`=38241; -- 38241
UPDATE `creature_model_info` SET `bounding_radius`=3.5, `combat_reach`=7.349999, `gender`=0 WHERE `modelid`=31796; -- 31796
UPDATE `creature_model_info` SET `bounding_radius`=3.666, `combat_reach`=9 WHERE `modelid`=23964; -- 23964
UPDATE `creature_model_info` SET `bounding_radius`=3.75, `combat_reach`=3.75 WHERE `modelid`=27072; -- 27072
UPDATE `creature_model_info` SET `bounding_radius`=3.75, `combat_reach`=3.75 WHERE `modelid`=8053; -- 8053
UPDATE `creature_model_info` SET `bounding_radius`=3.801, `combat_reach`=3.75 WHERE `modelid`=13489; -- 13489
UPDATE `creature_model_info` SET `bounding_radius`=3.82, `combat_reach`=10, `gender`=0 WHERE `modelid`=38793; -- 38793
UPDATE `creature_model_info` SET `bounding_radius`=4, `combat_reach`=20 WHERE `modelid`=32706; -- 32706
UPDATE `creature_model_info` SET `bounding_radius`=4, `combat_reach`=4 WHERE `modelid`=38445; -- 38445
UPDATE `creature_model_info` SET `bounding_radius`=4, `combat_reach`=5 WHERE `modelid`=36636; -- 36636
UPDATE `creature_model_info` SET `bounding_radius`=4, `combat_reach`=6 WHERE `modelid`=38426; -- 38426
UPDATE `creature_model_info` SET `bounding_radius`=4, `combat_reach`=6, `gender`=0 WHERE `modelid`=38240; -- 38240
UPDATE `creature_model_info` SET `bounding_radius`=4, `combat_reach`=6, `gender`=2 WHERE `modelid`=26704; -- 26704
UPDATE `creature_model_info` SET `bounding_radius`=4, `combat_reach`=60, `gender`=0 WHERE `modelid`=39099; -- 39099
UPDATE `creature_model_info` SET `bounding_radius`=4, `combat_reach`=8 WHERE `modelid`=35463; -- 35463
UPDATE `creature_model_info` SET `bounding_radius`=4, `combat_reach`=8 WHERE `modelid`=38706; -- 38706
UPDATE `creature_model_info` SET `bounding_radius`=4.2, `combat_reach`=12, `gender`=0 WHERE `modelid`=20939; -- 20939
UPDATE `creature_model_info` SET `bounding_radius`=4.2, `combat_reach`=7.5 WHERE `modelid`=39182; -- 39182
UPDATE `creature_model_info` SET `bounding_radius`=4.275, `combat_reach`=1.5 WHERE `modelid`=26876; -- 26876
UPDATE `creature_model_info` SET `bounding_radius`=4.5, `combat_reach`=4.5 WHERE `modelid`=37285; -- 37285
UPDATE `creature_model_info` SET `bounding_radius`=4.5, `combat_reach`=4.5, `gender`=0 WHERE `modelid`=25667; -- 25667
UPDATE `creature_model_info` SET `bounding_radius`=4.5, `combat_reach`=7.875, `gender`=0 WHERE `modelid`=17886; -- 17886
UPDATE `creature_model_info` SET `bounding_radius`=4.5624, `combat_reach`=7.2 WHERE `modelid`=27008; -- 27008
UPDATE `creature_model_info` SET `bounding_radius`=47.76, `combat_reach`=1.5 WHERE `modelid`=29771; -- 29771
UPDATE `creature_model_info` SET `bounding_radius`=5, `combat_reach`=10 WHERE `modelid`=38591; -- 38591
UPDATE `creature_model_info` SET `bounding_radius`=5, `combat_reach`=15 WHERE `modelid`=39349; -- 39349
UPDATE `creature_model_info` SET `bounding_radius`=5, `combat_reach`=15, `gender`=0 WHERE `modelid`=38227; -- 38227
UPDATE `creature_model_info` SET `bounding_radius`=5, `combat_reach`=25 WHERE `modelid`=39297; -- 39297
UPDATE `creature_model_info` SET `bounding_radius`=5, `combat_reach`=5 WHERE `modelid`=38070; -- 38070
UPDATE `creature_model_info` SET `bounding_radius`=5, `combat_reach`=7.5, `gender`=0 WHERE `modelid`=21069; -- 21069
UPDATE `creature_model_info` SET `bounding_radius`=5, `combat_reach`=7.5, `gender`=0 WHERE `modelid`=38448; -- 38448
UPDATE `creature_model_info` SET `bounding_radius`=50.13, `combat_reach`=1.5 WHERE `modelid`=29766; -- 29766
UPDATE `creature_model_info` SET `bounding_radius`=6, `combat_reach`=120 WHERE `modelid`=39507; -- 39507
UPDATE `creature_model_info` SET `bounding_radius`=7, `combat_reach`=14 WHERE `modelid`=25194; -- 25194
UPDATE `creature_model_info` SET `bounding_radius`=7.602, `combat_reach`=7.5 WHERE `modelid`=17846; -- 17846
UPDATE `creature_model_info` SET `bounding_radius`=8, `combat_reach`=16 WHERE `modelid`=38710; -- 38710
UPDATE `creature_model_info` SET `bounding_radius`=8, `combat_reach`=16, `gender`=0 WHERE `modelid`=38364; -- 38364
UPDATE `creature_model_info` SET `bounding_radius`=80 WHERE `modelid`=21145; -- 21145
UPDATE `creature_model_info` SET `combat_reach`=0.3, `gender`=0 WHERE `modelid`=25656; -- 25656
UPDATE `creature_model_info` SET `combat_reach`=0.5, `gender`=0 WHERE `modelid`=26193; -- 26193
UPDATE `creature_model_info` SET `combat_reach`=0.5, `gender`=0 WHERE `modelid`=28078; -- 28078
UPDATE `creature_model_info` SET `combat_reach`=0.6 WHERE `modelid`=17618; -- 17618
UPDATE `creature_model_info` SET `combat_reach`=0.6 WHERE `modelid`=26056; -- 26056
UPDATE `creature_model_info` SET `combat_reach`=0.64 WHERE `modelid`=27690; -- 27690
UPDATE `creature_model_info` SET `combat_reach`=0.66 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `combat_reach`=0.66 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `combat_reach`=0.665 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `combat_reach`=0.68 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `combat_reach`=0.685 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `combat_reach`=0.705 WHERE `modelid`=25390; -- 25390
UPDATE `creature_model_info` SET `combat_reach`=0.715 WHERE `modelid`=25391; -- 25391
UPDATE `creature_model_info` SET `combat_reach`=1.1, `gender`=0 WHERE `modelid`=19878; -- 19878
UPDATE `creature_model_info` SET `combat_reach`=1.43 WHERE `modelid`=24978; -- 24978
UPDATE `creature_model_info` SET `combat_reach`=1.44 WHERE `modelid`=24978; -- 24978
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=15242; -- 15242
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=15253; -- 15253
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=15506; -- 15506
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17113; -- 17113
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17463; -- 17463
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17464; -- 17464
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17583; -- 17583
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17584; -- 17584
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17586; -- 17586
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17589; -- 17589
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17590; -- 17590
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17591; -- 17591
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17592; -- 17592
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17594; -- 17594
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17595; -- 17595
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17599; -- 17599
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17600; -- 17600
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17606; -- 17606
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17609; -- 17609
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17619; -- 17619
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17648; -- 17648
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17680; -- 17680
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17691; -- 17691
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17705; -- 17705
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17728; -- 17728
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17747; -- 17747
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17755; -- 17755
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17756; -- 17756
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17757; -- 17757
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17760; -- 17760
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17766; -- 17766
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17767; -- 17767
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17818; -- 17818
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17823; -- 17823
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17824; -- 17824
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17831; -- 17831
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17833; -- 17833
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17837; -- 17837
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17838; -- 17838
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17955; -- 17955
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17956; -- 17956
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17973; -- 17973
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=17974; -- 17974
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18027; -- 18027
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18046; -- 18046
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18214; -- 18214
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18221; -- 18221
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18222; -- 18222
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18281; -- 18281
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18282; -- 18282
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18284; -- 18284
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18285; -- 18285
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18300; -- 18300
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18301; -- 18301
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18302; -- 18302
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18324; -- 18324
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18418; -- 18418
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18512; -- 18512
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18513; -- 18513
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18514; -- 18514
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18528; -- 18528
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18529; -- 18529
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18530; -- 18530
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18570; -- 18570
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18581; -- 18581
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18582; -- 18582
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18589; -- 18589
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18599; -- 18599
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18601; -- 18601
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18602; -- 18602
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18603; -- 18603
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18604; -- 18604
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18626; -- 18626
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18642; -- 18642
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=18656; -- 18656
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=19100; -- 19100
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=19108; -- 19108
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=19705; -- 19705
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=19720; -- 19720
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=19721; -- 19721
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=19841; -- 19841
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20031; -- 20031
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20035; -- 20035
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20279; -- 20279
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20312; -- 20312
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20333; -- 20333
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20334; -- 20334
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20388; -- 20388
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20422; -- 20422
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20440; -- 20440
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20478; -- 20478
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20523; -- 20523
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20660; -- 20660
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20661; -- 20661
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20668; -- 20668
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20670; -- 20670
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20694; -- 20694
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=20962; -- 20962
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21039; -- 21039
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21115; -- 21115
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21116; -- 21116
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21117; -- 21117
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21118; -- 21118
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21152; -- 21152
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21155; -- 21155
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21156; -- 21156
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21158; -- 21158
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21184; -- 21184
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21234; -- 21234
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21344; -- 21344
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21345; -- 21345
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21346; -- 21346
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21392; -- 21392
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21393; -- 21393
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21422; -- 21422
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21440; -- 21440
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21442; -- 21442
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21475; -- 21475
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21476; -- 21476
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=21594; -- 21594
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22003; -- 22003
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22042; -- 22042
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22044; -- 22044
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22088; -- 22088
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22089; -- 22089
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22124; -- 22124
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22125; -- 22125
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22181; -- 22181
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22199; -- 22199
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22471; -- 22471
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22474; -- 22474
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22475; -- 22475
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22611; -- 22611
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22719; -- 22719
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22742; -- 22742
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22750; -- 22750
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=22873; -- 22873
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=23131; -- 23131
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=23136; -- 23136
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=23137; -- 23137
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=23138; -- 23138
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=23434; -- 23434
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=23456; -- 23456
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=23482; -- 23482
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=23483; -- 23483
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=23681; -- 23681
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=23772; -- 23772
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=23774; -- 23774
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=23783; -- 23783
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=23826; -- 23826
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=23962; -- 23962
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=23999; -- 23999
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=24009; -- 24009
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=24071; -- 24071
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=24235; -- 24235
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=24256; -- 24256
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=24354; -- 24354
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=24357; -- 24357
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=24708; -- 24708
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25071; -- 25071
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25082; -- 25082
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25209; -- 25209
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25318; -- 25318
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25587; -- 25587
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25626; -- 25626
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25692; -- 25692
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25756; -- 25756
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25757; -- 25757
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25797; -- 25797
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25799; -- 25799
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25801; -- 25801
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25874; -- 25874
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25889; -- 25889
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25952; -- 25952
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25953; -- 25953
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25954; -- 25954
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26065; -- 26065
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26213; -- 26213
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26331; -- 26331
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26363; -- 26363
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26484; -- 26484
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26494; -- 26494
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26495; -- 26495
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26496; -- 26496
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26499; -- 26499
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26501; -- 26501
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26502; -- 26502
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26503; -- 26503
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26504; -- 26504
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26505; -- 26505
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26506; -- 26506
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26570; -- 26570
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26764; -- 26764
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26937; -- 26937
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27019; -- 27019
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27042; -- 27042
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27114; -- 27114
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27115; -- 27115
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27170; -- 27170
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27172; -- 27172
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27173; -- 27173
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27174; -- 27174
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27175; -- 27175
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27177; -- 27177
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27181; -- 27181
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27183; -- 27183
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27185; -- 27185
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27187; -- 27187
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27192; -- 27192
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27195; -- 27195
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27323; -- 27323
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27393; -- 27393
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27541; -- 27541
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27743; -- 27743
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27786; -- 27786
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27787; -- 27787
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28066; -- 28066
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28291; -- 28291
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28570; -- 28570
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28738; -- 28738
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28741; -- 28741
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28758; -- 28758
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28976; -- 28976
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=29075; -- 29075
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=29146; -- 29146
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=29147; -- 29147
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=29148; -- 29148
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=29202; -- 29202
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=29489; -- 29489
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=29743; -- 29743
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=29744; -- 29744
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=29746; -- 29746
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=29828; -- 29828
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30009; -- 30009
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30059; -- 30059
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30108; -- 30108
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30117; -- 30117
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30184; -- 30184
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30185; -- 30185
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30186; -- 30186
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30187; -- 30187
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30210; -- 30210
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30211; -- 30211
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30212; -- 30212
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30213; -- 30213
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30244; -- 30244
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30255; -- 30255
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30261; -- 30261
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30262; -- 30262
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30263; -- 30263
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30301; -- 30301
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30302; -- 30302
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30317; -- 30317
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30347; -- 30347
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30412; -- 30412
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30413; -- 30413
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30418; -- 30418
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30865; -- 30865
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=31126; -- 31126
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=31247; -- 31247
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=31288; -- 31288
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=31411; -- 31411
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=31482; -- 31482
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=31548; -- 31548
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=31981; -- 31981
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=31992; -- 31992
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=32236; -- 32236
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=32385; -- 32385
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=32410; -- 32410
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=32470; -- 32470
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=32497; -- 32497
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=32812; -- 32812
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=32813; -- 32813
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=32814; -- 32814
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=32909; -- 32909
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=32965; -- 32965
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=33003; -- 33003
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=33192; -- 33192
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=33217; -- 33217
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=33266; -- 33266
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=33303; -- 33303
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=33314; -- 33314
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=33315; -- 33315
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=33330; -- 33330
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=33339; -- 33339
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=33340; -- 33340
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=34044; -- 34044
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=34064; -- 34064
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=34336; -- 34336
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=34395; -- 34395
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=35095; -- 35095
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=35249; -- 35249
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=35250; -- 35250
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=35567; -- 35567
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=35568; -- 35568
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=35569; -- 35569
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=35700; -- 35700
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=36085; -- 36085
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=36114; -- 36114
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=36115; -- 36115
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=36116; -- 36116
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=36117; -- 36117
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=36174; -- 36174
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=36329; -- 36329
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=36332; -- 36332
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=36336; -- 36336
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=36388; -- 36388
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=36743; -- 36743
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=36963; -- 36963
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=36965; -- 36965
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=36966; -- 36966
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=37179; -- 37179
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=37572; -- 37572
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=37692; -- 37692
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=37798; -- 37798
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=37942; -- 37942
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=38009; -- 38009
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=38626; -- 38626
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=38802; -- 38802
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=38857; -- 38857
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=39060; -- 39060
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=39131; -- 39131
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=39164; -- 39164
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=39187; -- 39187
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=39319; -- 39319
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=39330; -- 39330
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=39331; -- 39331
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=39332; -- 39332
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=39549; -- 39549
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=22233; -- 22233
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=22243; -- 22243
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=22502; -- 22502
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=23793; -- 23793
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=25748; -- 25748
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=25754; -- 25754
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=25758; -- 25758
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=25759; -- 25759
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=25793; -- 25793
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=25794; -- 25794
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=25795; -- 25795
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=25987; -- 25987
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=25988; -- 25988
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=25989; -- 25989
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=25990; -- 25990
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=25992; -- 25992
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=25993; -- 25993
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=25994; -- 25994
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=25995; -- 25995
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=26212; -- 26212
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=26218; -- 26218
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=26220; -- 26220
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=26239; -- 26239
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=26303; -- 26303
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=26832; -- 26832
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=27043; -- 27043
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=0 WHERE `modelid`=28019; -- 28019
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=1 WHERE `modelid`=22120; -- 22120
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=1 WHERE `modelid`=22127; -- 22127
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=1 WHERE `modelid`=22485; -- 22485
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=1 WHERE `modelid`=23398; -- 23398
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=1 WHERE `modelid`=24072; -- 24072
UPDATE `creature_model_info` SET `combat_reach`=1.5, `gender`=1 WHERE `modelid`=28724; -- 28724
UPDATE `creature_model_info` SET `combat_reach`=1.65 WHERE `modelid`=24313; -- 24313
UPDATE `creature_model_info` SET `combat_reach`=1.8 WHERE `modelid`=24358; -- 24358
UPDATE `creature_model_info` SET `combat_reach`=1.8 WHERE `modelid`=30799; -- 30799
UPDATE `creature_model_info` SET `combat_reach`=1.875 WHERE `modelid`=24352; -- 24352
UPDATE `creature_model_info` SET `combat_reach`=10 WHERE `modelid`=2718; -- 2718
UPDATE `creature_model_info` SET `combat_reach`=10 WHERE `modelid`=27225; -- 27225
UPDATE `creature_model_info` SET `combat_reach`=10 WHERE `modelid`=28787; -- 28787
UPDATE `creature_model_info` SET `combat_reach`=11 WHERE `modelid`=24711; -- 24711
UPDATE `creature_model_info` SET `combat_reach`=12 WHERE `modelid`=29185; -- 29185
UPDATE `creature_model_info` SET `combat_reach`=15 WHERE `modelid`=28611; -- 28611
UPDATE `creature_model_info` SET `combat_reach`=18 WHERE `modelid`=27035; -- 27035
UPDATE `creature_model_info` SET `combat_reach`=18, `gender`=1 WHERE `modelid`=8570; -- 8570
UPDATE `creature_model_info` SET `combat_reach`=2 WHERE `modelid`=20672; -- 20672
UPDATE `creature_model_info` SET `combat_reach`=2.025 WHERE `modelid`=24066; -- 24066
UPDATE `creature_model_info` SET `combat_reach`=2.2 WHERE `modelid`=24812; -- 24812
UPDATE `creature_model_info` SET `combat_reach`=2.25 WHERE `modelid`=22429; -- 22429
UPDATE `creature_model_info` SET `combat_reach`=2.5 WHERE `modelid`=9567; -- 9567
UPDATE `creature_model_info` SET `combat_reach`=23.1 WHERE `modelid`=28875; -- 28875
UPDATE `creature_model_info` SET `combat_reach`=3 WHERE `modelid`=13109; -- 13109
UPDATE `creature_model_info` SET `combat_reach`=3 WHERE `modelid`=13110; -- 13110
UPDATE `creature_model_info` SET `combat_reach`=3 WHERE `modelid`=13172; -- 13172
UPDATE `creature_model_info` SET `combat_reach`=3 WHERE `modelid`=22106; -- 22106
UPDATE `creature_model_info` SET `combat_reach`=3, `gender`=0 WHERE `modelid`=14556; -- 14556
UPDATE `creature_model_info` SET `combat_reach`=3, `gender`=0 WHERE `modelid`=17679; -- 17679
UPDATE `creature_model_info` SET `combat_reach`=3.3 WHERE `modelid`=24829; -- 24829
UPDATE `creature_model_info` SET `combat_reach`=3.85 WHERE `modelid`=12819; -- 12819
UPDATE `creature_model_info` SET `combat_reach`=3.85 WHERE `modelid`=30803; -- 30803
UPDATE `creature_model_info` SET `combat_reach`=3.85 WHERE `modelid`=9760; -- 9760
UPDATE `creature_model_info` SET `combat_reach`=4 WHERE `modelid`=19438; -- 19438
UPDATE `creature_model_info` SET `combat_reach`=4 WHERE `modelid`=28134; -- 28134
UPDATE `creature_model_info` SET `combat_reach`=4, `gender`=0 WHERE `modelid`=26922; -- 26922
UPDATE `creature_model_info` SET `combat_reach`=4.5 WHERE `modelid`=18238; -- 18238
UPDATE `creature_model_info` SET `combat_reach`=5, `gender`=0 WHERE `modelid`=28132; -- 28132
UPDATE `creature_model_info` SET `combat_reach`=5.25 WHERE `modelid`=18662; -- 18662
UPDATE `creature_model_info` SET `combat_reach`=5.25 WHERE `modelid`=24307; -- 24307
UPDATE `creature_model_info` SET `combat_reach`=5.5 WHERE `modelid`=16215; -- 16215
UPDATE `creature_model_info` SET `combat_reach`=5.5 WHERE `modelid`=24832; -- 24832
UPDATE `creature_model_info` SET `combat_reach`=6 WHERE `modelid`=12029; -- 12029
UPDATE `creature_model_info` SET `combat_reach`=6 WHERE `modelid`=19165; -- 19165
UPDATE `creature_model_info` SET `combat_reach`=6 WHERE `modelid`=19301; -- 19301
UPDATE `creature_model_info` SET `combat_reach`=6.75, `gender`=0 WHERE `modelid`=25012; -- 25012
UPDATE `creature_model_info` SET `combat_reach`=7, `gender`=0 WHERE `modelid`=10115; -- 10115
UPDATE `creature_model_info` SET `combat_reach`=7.5, `gender`=0 WHERE `modelid`=27071; -- 27071
UPDATE `creature_model_info` SET `combat_reach`=8 WHERE `modelid`=27408; -- 27408
UPDATE `creature_model_info` SET `combat_reach`=9 WHERE `modelid`=21460; -- 21460
UPDATE `creature_model_info` SET `combat_reach`=9 WHERE `modelid`=28650; -- 28650
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=10094; -- 10094
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=10116; -- 10116
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=10193; -- 10193
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=10920; -- 10920
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11166; -- 11166
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11334; -- 11334
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11335; -- 11335
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11342; -- 11342
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11343; -- 11343
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11345; -- 11345
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11383; -- 11383
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11384; -- 11384
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11385; -- 11385
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11386; -- 11386
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11562; -- 11562
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11565; -- 11565
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11573; -- 11573
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11576; -- 11576
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11577; -- 11577
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11579; -- 11579
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11581; -- 11581
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11582; -- 11582
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=11585; -- 11585
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=12190; -- 12190
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=12369; -- 12369
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=12370; -- 12370
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=12373; -- 12373
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=12473; -- 12473
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=15374; -- 15374
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=16175; -- 16175
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=16309; -- 16309
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=16957; -- 16957
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=17032; -- 17032
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=17444; -- 17444
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=17540; -- 17540
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=17880; -- 17880
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=17977; -- 17977
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18031; -- 18031
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18033; -- 18033
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18037; -- 18037
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18058; -- 18058
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18236; -- 18236
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18291; -- 18291
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18311; -- 18311
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18323; -- 18323
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18369; -- 18369
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18370; -- 18370
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18371; -- 18371
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18422; -- 18422
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18526; -- 18526
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18638; -- 18638
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18647; -- 18647
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18712; -- 18712
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=18718; -- 18718
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=19162; -- 19162
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=19372; -- 19372
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=19637; -- 19637
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=19668; -- 19668
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=19889; -- 19889
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=19909; -- 19909
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=19945; -- 19945
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=19977; -- 19977
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=20018; -- 20018
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=20043; -- 20043
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=20127; -- 20127
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=20158; -- 20158
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=2020; -- 2020
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=20216; -- 20216
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=202; -- 202
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=20341; -- 20341
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=20342; -- 20342
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=20363; -- 20363
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=203; -- 203
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=20419; -- 20419
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=20468; -- 20468
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=20559; -- 20559
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=20678; -- 20678
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=20681; -- 20681
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=20822; -- 20822
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=20823; -- 20823
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=20986; -- 20986
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=21005; -- 21005
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=21021; -- 21021
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=21046; -- 21046
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=21112; -- 21112
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=21113; -- 21113
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=21120; -- 21120
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=21135; -- 21135
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=21191; -- 21191
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=21262; -- 21262
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=21357; -- 21357
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=21443; -- 21443
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=21490; -- 21490
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=21718; -- 21718
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=218; -- 218
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=22424; -- 22424
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=22708; -- 22708
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=22858; -- 22858
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=22859; -- 22859
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=2289; -- 2289
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=22906; -- 22906
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=23004; -- 23004
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=23276; -- 23276
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=23321; -- 23321
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=23356; -- 23356
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=2346; -- 2346
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=23512; -- 23512
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=23564; -- 23564
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=23881; -- 23881
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24102; -- 24102
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24272; -- 24272
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24446; -- 24446
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24491; -- 24491
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24500; -- 24500
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24575; -- 24575
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24654; -- 24654
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24682; -- 24682
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24787; -- 24787
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24789; -- 24789
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24793; -- 24793
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24800; -- 24800
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24801; -- 24801
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24823; -- 24823
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24848; -- 24848
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24855; -- 24855
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=24954; -- 24954
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=25096; -- 25096
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=25145; -- 25145
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=25149; -- 25149
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=25151; -- 25151
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=25239; -- 25239
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=25240; -- 25240
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=25242; -- 25242
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=25244; -- 25244
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=25297; -- 25297
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=25400; -- 25400
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=25491; -- 25491
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=25515; -- 25515
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=2554; -- 2554
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=25770; -- 25770
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=25906; -- 25906
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=26194; -- 26194
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=26209; -- 26209
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=26210; -- 26210
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=26292; -- 26292
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=26349; -- 26349
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=26580; -- 26580
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=26583; -- 26583
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=26590; -- 26590
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=26684; -- 26684
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=26740; -- 26740
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=26752; -- 26752
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=26923; -- 26923
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=27033; -- 27033
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=27056; -- 27056
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=27058; -- 27058
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=27062; -- 27062
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=27324; -- 27324
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=27376; -- 27376
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=27406; -- 27406
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=27407; -- 27407
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=27419; -- 27419
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=27422; -- 27422
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=27486; -- 27486
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=27821; -- 27821
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=27856; -- 27856
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=27914; -- 27914
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=28013; -- 28013
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=28349; -- 28349
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=28517; -- 28517
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=28549; -- 28549
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=28638; -- 28638
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=28679; -- 28679
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=28743; -- 28743
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=28821; -- 28821
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=28822; -- 28822
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=28977; -- 28977
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=30676; -- 30676
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=30768; -- 30768
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=30770; -- 30770
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=3208; -- 3208
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=38150; -- 38150
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=4453; -- 4453
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=4644; -- 4644
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=4652; -- 4652
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=5866; -- 5866
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=5988; -- 5988
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=6078; -- 6078
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=6097; -- 6097
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=6103; -- 6103
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=6105; -- 6105
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=6106; -- 6106
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=716; -- 716
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=729; -- 729
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=7649; -- 7649
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=8055; -- 8055
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=842; -- 842
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=8611; -- 8611
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=8612; -- 8612
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=918; -- 918
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=9334; -- 9334
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=9952; -- 9952
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=10925; -- 10925
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=10927; -- 10927
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=11381; -- 11381
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=12292; -- 12292
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=12337; -- 12337
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=12894; -- 12894
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=16462; -- 16462
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=17814; -- 17814
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=18923; -- 18923
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=19199; -- 19199
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=19888; -- 19888
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=19947; -- 19947
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=19948; -- 19948
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=20385; -- 20385
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=21243; -- 21243
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=21456; -- 21456
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=21502; -- 21502
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=21503; -- 21503
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=22596; -- 22596
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=23970; -- 23970
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=25247; -- 25247
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=27082; -- 27082
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=27401; -- 27401
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=27568; -- 27568
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=27609; -- 27609
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=28777; -- 28777
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=38252; -- 38252
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=4162; -- 4162
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=4647; -- 4647
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=6099; -- 6099
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=6100; -- 6100
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=6110; -- 6110
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=6111; -- 6111
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=7863; -- 7863
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=857; -- 857
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=21243; -- 21243
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=23751; -- 23751
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=23752; -- 23752
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=23753; -- 23753
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=23818; -- 23818
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=24493; -- 24493
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=24494; -- 24494
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=25549; -- 25549
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=25550; -- 25550
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=25551; -- 25551
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=25552; -- 25552
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=25982; -- 25982
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=25984; -- 25984
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=25985; -- 25985
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=26053; -- 26053
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=27483; -- 27483
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=28846; -- 28846
UPDATE `creature_model_info` SET `gender`=2 WHERE `modelid`=28847; -- 28847
