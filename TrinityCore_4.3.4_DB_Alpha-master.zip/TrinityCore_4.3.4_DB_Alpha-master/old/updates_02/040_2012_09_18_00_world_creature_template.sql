UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=33109; -- Salvaged Demolisher
UPDATE `creature_template` SET `unit_flags2`=2049 WHERE `entry`=33063; -- Wrecked Siege Engine
UPDATE `creature_template` SET `unit_flags2`=1 WHERE `entry`=33059; -- Wrecked Demolisher
UPDATE `creature_template` SET `unit_flags2`=0 WHERE `entry`=33167; -- Salvaged Demolisher Mechanic Seat
