UPDATE `game_tele` SET `position_x`=-8833.07, `position_y`=622.778, `position_z`=93.9317, `orientation`=0.6771 WHERE `id`=954; -- Stormwind
UPDATE `game_tele` SET `position_x`=-8728.45, `position_y`=409.289, `position_z`=97.7728, `orientation`=3.805283 WHERE `id`=696; -- Old Town
UPDATE `game_tele` SET `position_x`=-8379.79, `position_y`=253.323, `position_z`=155.3467, `orientation`=5.387816 WHERE `id`=1408; -- Stormwind Keep
UPDATE `game_tele` SET `position_x`=-8583.63, `position_y`=805.724, `position_z`=106.5192, `orientation`=0.660715 WHERE `id`=194; -- Cathedral Of Light
UPDATE `game_tele` SET `position_x`=-8658.394, `position_y`=746.877, `position_z`=96.825, `orientation`=0.646923 WHERE `id`=195; -- Cathedral Square
UPDATE `game_tele` SET `position_x`=-8394.208, `position_y`=606.628, `position_z`=94.6108, `orientation`=1.151476 WHERE `id`=318; -- Dwarven District
