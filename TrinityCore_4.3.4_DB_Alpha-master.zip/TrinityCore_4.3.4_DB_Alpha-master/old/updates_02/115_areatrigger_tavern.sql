DELETE FROM `areatrigger_tavern` WHERE `id` IN (6122, 6106, 6713, 6480, 6134, 6077, 6137, 6138, 6164, 5930);
INSERT INTO `areatrigger_tavern` (`id`, `name`) VALUES
(6122, 'Farstrider Lodge'),
(6106, 'Stormfeather Outpost'),
(6713, 'Fuselight-by-the-Sea'),
(6480, 'Fuselight'),
(6134, 'Bootlegger Outpost'),
(6077, 'Lor''danel'),
(6137, 'Greenwarden''s Grove'),
(6138, 'Swiftgear Station'),
(6164, 'Farwatcher''s Glen'),
(5930, 'Thal''darah Overlook');
