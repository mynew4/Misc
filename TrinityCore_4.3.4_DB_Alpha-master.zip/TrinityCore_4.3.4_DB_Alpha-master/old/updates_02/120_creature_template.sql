UPDATE `creature_template` SET `WDBVerified`=15595 WHERE `entry`=49156; -- Ritual Guardian
UPDATE `creature_template` SET `WDBVerified`=15595 WHERE `entry`=49148; -- Dark Ritualist Zakahn
