-- 120 Cone of Cold
DELETE FROM `spell_script_names` WHERE `spell_id` IN (120);
INSERT INTO `spell_script_names` VALUES
(120, "spell_mage_cone_of_cold");
