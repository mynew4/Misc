DELETE FROM `spell_script_names` WHERE `spell_id` IN (57669,61782);
INSERT INTO `spell_script_names` (`spell_id`,`ScriptName`) VALUES
(57669,'spell_gen_replenishment'),
(61782,'spell_gen_replenishment');
