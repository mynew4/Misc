DELETE FROM `creature_template_addon` WHERE `entry`=28670; -- Frostbrood Vanquisher
INSERT INTO `creature_template_addon` (`entry`,`path_id`,`mount`,`bytes1`,`bytes2`,`emote`,`auras`) VALUES 
(28670,0,0,0x3000000,0x1,0,'53112');
