DELETE FROM `spell_script_names` WHERE `spell_id`=6940;
INSERT INTO `spell_script_names` (`spell_id`,`ScriptName`) VALUES
(6940, 'spell_pal_hand_of_sacrifice');
