UPDATE `creature_template` SET `unit_flags2`=`unit_flags2`|0x800; -- UNIT_FLAG2_REGENERATE_POWER
