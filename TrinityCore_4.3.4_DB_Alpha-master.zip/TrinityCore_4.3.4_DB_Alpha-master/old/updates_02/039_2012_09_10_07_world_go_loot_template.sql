-- Vic's Keys drop chance ( http://old.wowhead.com/object=190778 ) by nelegalno
UPDATE `gameobject_loot_template` SET `ChanceOrQuestChance` = -100 WHERE `entry`=24861 AND `item`=39264;
