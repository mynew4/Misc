DELETE FROM `spell_script_names` WHERE `spell_id`=64205;
INSERT INTO `spell_script_names` (`spell_id`,`ScriptName`) VALUES
(64205, 'spell_pal_divine_sacrifice');
