UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=152583; -- AuctionNode
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=164639; -- Frost Trap
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=179944; -- Meeting Stone Summoning Portal
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=182797; -- Salvageable Metal
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=182798; -- Salvageable Metal
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=182799; -- Salvageable Wood
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=182936; -- Salvageable Wood
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=182937; -- Salvageable Metal
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=182938; -- Salvageable Metal
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=183384; -- Portal to Shattrath
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=184594; -- Portal to Shattrath
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=186811; -- Refreshment Portal
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=190942; -- Death Gate
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=191164; -- Portal to Dalaran
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=194108; -- Summoning Portal
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=194278; -- Orgrimmar Banner
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=21680; -- Duel Flag
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=2561; -- Freezing Trap
UPDATE `gameobject_template` SET `faction`=0 WHERE `entry`=29784; -- Basic Campfire
UPDATE `gameobject_template` SET `faction`=0, `flags`=0 WHERE `entry`=164839; -- Explosive Trap
UPDATE `gameobject_template` SET `faction`=0, `flags`=0 WHERE `entry`=193125; -- Anvil
UPDATE `gameobject_template` SET `faction`=0, `flags`=0 WHERE `entry`=193126; -- Forge
UPDATE `gameobject_template` SET `faction`=101 WHERE `entry`=2844; -- Tattered Chest
UPDATE `gameobject_template` SET `faction`=101, `flags`=4 WHERE `entry`=181649; -- Featherbeard's Journal
UPDATE `gameobject_template` SET `faction`=102, `flags`=4 WHERE `entry`=181671; -- Fel Horde Banner
UPDATE `gameobject_template` SET `faction`=104 WHERE `entry`=143984; -- Mailbox
UPDATE `gameobject_template` SET `faction`=104 WHERE `entry`=202588; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1081 WHERE `entry`=178088; -- Ragnaros
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=101811; -- Lever
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=175787; -- Unadorned Stake
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=175788; -- Unadorned Stake
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=177224; -- Troll Drum Sound Object
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=177257; -- Doodad_DireMaulCrystalGenerator02
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=177258; -- Doodad_DireMaulCrystalGenerator03
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=177259; -- Doodad_DireMaulCrystalGenerator01
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=178187; -- Molten Core Circle SULFURON
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=178189; -- Molten Core Circle SHAZZRAH
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=178190; -- Molten Core Circle GOLEMAGG
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=179504; -- Doodad_DireMaulCrystalGenerator04
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=179505; -- Doodad_DireMaulCrystalGenerator05
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=179507; -- Torch
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=179508; -- Torch
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=179509; -- Torch
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=179510; -- Torch
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=179881; -- The Severed Head of Nefarian
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180144; -- Food Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180146; -- Speed Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180148; -- Berserk Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180362; -- Food Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180376; -- Berserk Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180378; -- Berserk Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180379; -- Speed Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180381; -- Speed Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180382; -- Berserk Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180383; -- Food Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180384; -- Speed Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180534; -- Wind Stone
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180544; -- Lesser Wind Stone
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180549; -- Lesser Wind Stone
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180554; -- Wind Stone
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180559; -- Greater Wind Stone
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180564; -- Lesser Wind Stone
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=180795; -- Sandworm Base
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=181444; -- Kel'Thuzad Trigger
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=182064; -- Karazhan Bell
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=183356; -- Theatric Lightning
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=184640; -- Magtheridon's Head
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=184663; -- Shadow Sight
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=184664; -- Shadow Sight
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=184747; -- Flayer Fog
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=184964; -- Speed Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=184965; -- Restoration Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=184966; -- Berserk Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=184970; -- Speed Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=184971; -- Restoration Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=184972; -- Berserk Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=184974; -- Restoration Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=184975; -- Berserk Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=184976; -- Speed Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=184977; -- Restoration Buff
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=184979; -- Deathforged Infernal
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185296; -- Battered Cage
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185600; -- Netherwing Egg Trap (Gas)
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185692; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185693; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185694; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185695; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185696; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185697; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185698; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185699; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185704; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185705; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185706; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185707; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185708; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185709; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185710; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185711; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185712; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185713; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185714; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185715; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185716; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185717; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185718; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185719; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185720; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185721; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185722; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185723; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185756; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185757; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185758; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185759; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185760; -- Simon Game Base Yellow Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185761; -- Simon Game Base Green Smalll
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185762; -- Simon Game Base Red Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=185763; -- Simon Game Base Blue Small
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=186745; -- Bonfire
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=187084; -- Large Fire
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=188073; -- Ahune Bonfire
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=188077; -- Ice Spear
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=18900; -- Lever
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=18901; -- Lever
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=191794; -- Falling Rocks
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192252; -- Alliance Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192253; -- Alliance Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192267; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192268; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192271; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192272; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192276; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192279; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192424; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192425; -- Alliance Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192426; -- Alliance Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192428; -- Alliance Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192440; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192442; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192443; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192444; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192449; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192450; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192452; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192453; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=192538; -- Small Proto-Drake Egg
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=194120; -- Bear Cage
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=194121; -- Leopard Cage
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=194211; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=194296; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=194297; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=194458; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=194826; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=195005; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=195373; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=195401; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=195488; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=195489; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=195522; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=195523; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=195524; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=195525; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=195704; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=195707; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=196458; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=199328; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=200309; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=201591; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=201790; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=202104; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=202218; -- Drugan's Keg
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=202361; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=202545; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=202546; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=202549; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=202550; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=202551; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=202593; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=202664; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=202787; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=202879; -- Ritual Drum
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=203235; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=203259; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=203707; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=204266; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=204390; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=204391; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=204392; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205501; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205502; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205503; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205504; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205505; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205509; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205510; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205511; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205512; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205513; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205515; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205516; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205517; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205518; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205519; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205520; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205521; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205522; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205523; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=205821; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=206038; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=206039; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=206517; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=206561; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=206953; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=207252; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=207253; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=207260; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=207261; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=207262; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=207289; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=207311; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=207312; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=207313; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=207314; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=207315; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=207316; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=207317; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=207318; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=207319; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=207751; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=208456; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114 WHERE `entry`=208457; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=2 WHERE `entry`=185474; -- Cage
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=174849; -- 174849
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=177188; -- Door
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=177189; -- Door
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=177192; -- Door
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=177706; -- Melizza's Cage
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=178107; -- Lava Steam
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=178108; -- Lava Splash
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=178147; -- Ruul Snowhoof Cage
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=179469; -- Arena Door
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=180421; -- Alliance Banner Aura, Large
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=180422; -- Horde Banner Aura, Large
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=180423; -- Neutral Banner Aura, Large
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=180898; -- AQRUNE
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=180899; -- AQROOT
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=180904; -- Ancient Door
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=181247; -- Ice Block
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=181356; -- Sapphiron Birth
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=188067; -- Ice Block
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=188142; -- Ice Block, Big
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=191791; -- 191791
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=191877; -- Doodad_DalaranSewer01
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=192937; -- 192937
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=194203; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=194395; -- Doodad_DalaranSewer_ArenaWaterFall_Collision01
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=194577; -- Axe Gear
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=194632; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=194647; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=194648; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=195000; -- [DND] Ice Block, X-TRA Big
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=195638; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=195639; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196475; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196485; -- Saronite Rock
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196818; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196819; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196820; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196821; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196822; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196823; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196824; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196825; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196826; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196827; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196828; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196873; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196875; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196876; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196877; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196881; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=196882; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=201563; -- Oratory of the Damned Entrance
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=201612; -- Scientist Airlock Door Collision
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=201613; -- Scientist Airlock Door Orange
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=201614; -- Scientist Airlock Door Green
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=201719; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=201769; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=201857; -- Lord Marrowgar's Entrance
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=201858; -- Alliance Teleporter
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=201880; -- Horde Teleporter
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=201885; -- Ice Wall
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=201886; -- Horde Tent
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=201887; -- Horde Tent
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=201910; -- Doodad_IceCrown_Icewall02
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=201911; -- Icewall
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=201948; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202132; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202299; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202306; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202309; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202312; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202313; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202314; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202326; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202327; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202328; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202329; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202330; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202331; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202332; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202333; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202334; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202342; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202343; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202344; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202345; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202346; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202369; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202370; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202371; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202372; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202373; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202374; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202377; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202378; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202379; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202380; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202381; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202382; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202383; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202384; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202385; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202402; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202406; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202408; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202409; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202424; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202425; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202426; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202427; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202428; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202429; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202430; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202431; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202432; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202434; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202444; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202457; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202481; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202482; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202483; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202484; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202485; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202487; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202488; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202489; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202490; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202491; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202492; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202493; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202496; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202497; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202498; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202499; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202500; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202501; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202502; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202503; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202504; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202505; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202506; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202507; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202508; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202509; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202510; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202511; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202512; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202513; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202514; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202515; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202518; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202519; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202520; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202521; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202522; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202523; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202524; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202526; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202527; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202528; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202529; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202530; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202531; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202532; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202534; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202656; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202657; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202742; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=202850; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=203109; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=203193; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=203195; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=203234; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=203383; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=203397; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=203398; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=203399; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=203400; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=203401; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=203402; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=203975; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=204047; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=204340; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=204381; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=204573; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=204848; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=204850; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=204851; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=204853; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=204928; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=204946; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=204947; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=204948; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205064; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205065; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205069; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205102; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205110; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205111; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205112; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205113; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205115; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205116; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205119; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205120; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205121; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205122; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205125; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205126; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205127; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205128; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205129; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205130; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205131; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205133; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205196; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205495; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205496; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205830; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205958; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205959; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205960; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=205961; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206296; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206315; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206384; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206511; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206512; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206513; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206514; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206515; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206516; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206518; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206519; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206520; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206521; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206522; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206523; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206524; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206525; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206526; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206527; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206528; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206544; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206576; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206598; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206843; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206844; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206845; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=206854; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207177; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207178; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207250; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207263; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207374; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207375; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207376; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207377; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207434; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207435; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207438; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207439; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207440; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207441; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207442; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207443; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207444; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207446; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207447; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207448; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207451; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207453; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207455; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207457; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207458; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207580; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207581; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207582; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207589; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207593; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207597; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207619; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207662; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207663; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207664; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207665; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207716; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207726; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207756; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207757; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207758; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207759; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207760; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207761; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207762; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207869; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207870; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207871; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=207872; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208192; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208291; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208337; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208427; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208458; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208460; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208461; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208462; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208463; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208464; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208465; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208466; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208467; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208546; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208596; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208598; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208599; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208600; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208601; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208832; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208858; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208859; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208899; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208901; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208902; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=208953; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209022; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209023; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209024; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209025; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209026; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209027; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209028; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209029; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209030; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209031; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209082; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209083; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209084; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209085; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209086; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209087; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209088; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209089; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209090; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209091; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209092; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209263; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209596; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209849; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=209990; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=210097; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=32 WHERE `entry`=210234; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=33 WHERE `entry`=201613; -- Scientist Airlock Door Orange
UPDATE `gameobject_template` SET `faction`=114, `flags`=33 WHERE `entry`=204047; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=33 WHERE `entry`=206544; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=33 WHERE `entry`=208458; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=33 WHERE `entry`=208459; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=33 WHERE `entry`=208600; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=34 WHERE `entry`=179549; -- Door
UPDATE `gameobject_template` SET `faction`=114, `flags`=34 WHERE `entry`=206843; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=34 WHERE `entry`=206844; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=34 WHERE `entry`=206845; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=4 WHERE `entry`=186264; -- Missing: Kyle
UPDATE `gameobject_template` SET `faction`=114, `flags`=4 WHERE `entry`=195622; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=114, `flags`=4 WHERE `entry`=195687; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=12 WHERE `entry`=202578; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=12 WHERE `entry`=207077; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=12 WHERE `entry`=35591; -- Fishing Bobber
UPDATE `gameobject_template` SET `faction`=12, `flags`=32 WHERE `entry`=206111; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=12, `flags`=32 WHERE `entry`=207304; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=125 WHERE `entry`=203413; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=125 WHERE `entry`=35591; -- Fishing Bobber
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=179918; -- Doodad_PortcullisActive01
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=179919; -- Doodad_PortcullisActive02
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=179920; -- Doodad_PortcullisActive03
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=179921; -- Doodad_PortcullisActive04
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=180255; -- ALLIANCE DOOR
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=180256; -- HORDE DOOR
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=181640; -- Doodad_kelthuzad_throne02
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=181886; -- Firework Rocket, Promotion
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=182255; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=184697; -- Doodad_Coilfang Towers E_Particle01
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=201846; -- Doodad_IceCrown_Valve03
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=201847; -- Doodad_IceCrown_Valve04
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=203470; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=205542; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=206206; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=206207; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=206704; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=206705; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=207391; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry`=207400; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=175152; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=180424; -- Alterac Valley Gate
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=183443; -- Romeo and Juliet Backdrop
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=183491; -- Red Riding Hood Backdrop
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=183492; -- Red Riding Hood Tree
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=183493; -- Red Riding Hood House
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=183494; -- Romeo and Juliet Moon
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=183495; -- Romeo and Juliet Balcony
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=183817; -- Doodad_Portcullis_Gronn01
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=183932; -- Stage Curtain
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=183970; -- Doodad_PVP_Ogre_Door_Front01
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=183971; -- Doodad_PVP_Ogre_Door_Front02
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=183972; -- Doodad_PVP_Ogre_Door_Front03
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=183973; -- Doodad_PVP_Ogre_Door_Front04
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=183977; -- Doodad_PVP_Orc_Door_Front01
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=183978; -- Doodad_PVP_Orc_Door_Interior01
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=183979; -- Doodad_PVP_Orc_Door_Front01
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=183980; -- Doodad_PVP_Orc_Door_Interior01
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184203; -- Doodad_Coilfang_Raid_Bridge_Part01
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184204; -- Doodad_Coilfang_Raid_Bridge_Part02
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184205; -- Doodad_Coilfang_Raid_Bridge_Part03
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184274; -- Master's Terrace Door
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184277; -- Gamesman's Hall Exit Door
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184278; -- Stage Door Left
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184279; -- Stage Right Door
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184280; -- Master's Terrace Door
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184322; -- Mo'arg 2 Door
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184393; -- Prison Door
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184449; -- Nethermancer Encounter Door
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184569; -- Doodad_Coilfang_steam_off_on01
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184570; -- Doodad_Coilfang_steam_off_on02
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184571; -- Doodad_Coilfang_steam_off_on03
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184572; -- Doodad_Coilfang_steam_off_on04
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184573; -- Doodad_Coilfang_steam_off_on05
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184574; -- Doodad_Coilfang_steam_off_on06
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184632; -- Mo'arg 1 Door
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184662; -- Doodad_Portcullis_Gronn02
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184698; -- Doodad_Coilfang_steam_off_on10
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184699; -- Doodad_Coilfang_steam_off_on11
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184913; -- Doodad_Coilfang_steam_off_on15
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184914; -- Doodad_Coilfang_steam_off_on14
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184915; -- Doodad_Coilfang_steam_off_on12
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184916; -- Doodad_Coilfang_steam_off_on16
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184917; -- Doodad_Coilfang_steam_off_on17
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184918; -- Doodad_Coilfang_steam_off_on18
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184919; -- Doodad_Coilfang_steam_off_on19
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184920; -- Doodad_Coilfang_steam_off_on20
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=184921; -- Doodad_Coilfang_steam_off_on13
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=185134; -- Netherspace Door
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=185521; -- Massive Door
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=185917; -- Doodad_PVP_Lordaeron_Door02
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=185918; -- Doodad_PVP_Lordaeron_Door01
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=192685; -- Yellow Moon Sigil
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=192687; -- Green Moon Sigil
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=192689; -- Blue Moon Sigil
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=192690; -- Red Moon Sigil
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=192691; -- Purple Moon Sigil
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=193070; -- Nexus Raid Platform
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=195437; -- Doodad_VR_Portcullis01
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=195491; -- Doodad_ND_WinterOrc_Wall_GateFX_Door01
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=201517; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=201596; -- Cave In
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=201617; -- Doodad_IceCrown_OrangeTubes02
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=201618; -- Doodad_IceCrown_GreenTubes02
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=201709; -- Gunship Stairs
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=202211; -- Gunship Stairs
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=202307; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=202308; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=202310; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=202311; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203049; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203050; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203052; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203054; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203266; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203267; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203268; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203269; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203270; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203271; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203272; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203273; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203274; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203275; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203276; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203277; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203306; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203625; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=203710; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=204337; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=204338; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=204339; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=204341; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=205365; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=206506; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=206653; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=206654; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=206655; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=206699; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=206700; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=206701; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207343; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207672; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207673; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207674; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207725; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207737; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207922; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207923; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207924; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207925; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207926; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207927; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207928; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207929; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207930; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207997; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=207998; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=208205; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=208206; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=208207; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=208301; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=208302; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=209623; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=209631; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=209632; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=210048; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=210049; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=210147; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=32 WHERE `entry`=210148; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1375, `flags`=33 WHERE `entry`=201617; -- Doodad_IceCrown_OrangeTubes02
UPDATE `gameobject_template` SET `faction`=1375, `flags`=48 WHERE `entry`=204972; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=176511; -- Onyxia Egg
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=185923; -- Crystalforge controller
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=185924; -- Crystalforge controller
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=186663; -- Freezing Trap
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=187453; -- Bubbly Fissure
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=187455; -- Bubbly Fissure
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=190539; -- Broken Plague Sprayer
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=194465; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=194629; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=201963; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=202615; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=202715; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=203448; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=203731; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=203732; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=204355; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=204383; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=204384; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=204393; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=204394; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=209753; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=2561; -- Freezing Trap
UPDATE `gameobject_template` SET `faction`=14 WHERE `entry`=29784; -- Basic Campfire
UPDATE `gameobject_template` SET `faction`=14, `flags`=32 WHERE `entry`=182260; -- Roaring Flame
UPDATE `gameobject_template` SET `faction`=14, `flags`=32 WHERE `entry`=182592; -- Roaring Flame
UPDATE `gameobject_template` SET `faction`=14, `flags`=32 WHERE `entry`=194651; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14, `flags`=32 WHERE `entry`=195110; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14, `flags`=32 WHERE `entry`=202472; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14, `flags`=32 WHERE `entry`=202595; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14, `flags`=32 WHERE `entry`=204095; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14, `flags`=32 WHERE `entry`=204099; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14, `flags`=32 WHERE `entry`=205539; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14, `flags`=32 WHERE `entry`=205541; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14, `flags`=32 WHERE `entry`=206683; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14, `flags`=32 WHERE `entry`=206950; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14, `flags`=32 WHERE `entry`=207331; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14, `flags`=34 WHERE `entry`=204005; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=14, `flags`=36 WHERE `entry`=203431; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=16 WHERE `entry`=182607; -- Proximity Bomb
UPDATE `gameobject_template` SET `faction`=16 WHERE `entry`=191016; -- Seed Pod
UPDATE `gameobject_template` SET `faction`=16 WHERE `entry`=191457; -- Lava Bomb
UPDATE `gameobject_template` SET `faction`=16 WHERE `entry`=203460; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=16, `flags`=0 WHERE `entry`=194173; -- Snowdrift
UPDATE `gameobject_template` SET `faction`=16, `flags`=36 WHERE `entry`=202275; -- Wrathscale Fountain
UPDATE `gameobject_template` SET `faction`=1604 WHERE `entry`=202586; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1616 WHERE `entry`=209332; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1627 WHERE `entry`=181153; -- Wanted Poster: Kel'gash the Wicked
UPDATE `gameobject_template` SET `faction`=1665 WHERE `entry`=194300; -- Toasty Fire
UPDATE `gameobject_template` SET `faction`=168 WHERE `entry`=175534; -- Supply Crate
UPDATE `gameobject_template` SET `faction`=168 WHERE `entry`=175535; -- Supply Crate
UPDATE `gameobject_template` SET `faction`=168 WHERE `entry`=175536; -- Supply Crate
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=190219; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=190220; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=190221; -- Wintergrasp Fortress Tower
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=190358; -- Flamewatch Tower
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=190369; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=190370; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=190371; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=190372; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=190373; -- Wintergrasp Fortress Tower
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=190374; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=190375; -- Wintergrasp Fortress Gate
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=190376; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=190377; -- Wintergrasp Fortress Tower
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=190378; -- Wintergrasp Fortress Tower
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=191795; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=191796; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=191797; -- Wintergrasp Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=191798; -- Wintergrasp Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=191799; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=191800; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=191801; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=191802; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=191803; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=191804; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=191805; -- Wintergrasp Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=191806; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=191807; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=191808; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=191809; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=191810; -- Wintergrasp Fortress Door
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=194908; -- Lance Rack
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=195467; -- Mailbox
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=195468; -- Mailbox
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=197017; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=197018; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=197085; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=197134; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=197135; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=197136; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=197137; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=197186; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=197188; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=197189; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=197190; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=201515; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=201521; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=201619; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=201987; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=201989; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=203155; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=203156; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=203159; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=203164; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=203166; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=203752; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=204774; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=204985; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=204987; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=204988; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=205003; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=205004; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=205104; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=205105; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=205106; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=205107; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=205272; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=206594; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=206623; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=206757; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=207691; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=207692; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=207693; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=207694; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=207695; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=207983; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=207986; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=207989; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=207990; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=207992; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=207995; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=207996; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=208090; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=208094; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=208095; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=208227; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=208256; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=208948; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=209080; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732 WHERE `entry`=210175; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=190219; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=190220; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=190221; -- Wintergrasp Fortress Tower
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=190369; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=190370; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=190371; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=190372; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=190373; -- Wintergrasp Fortress Tower
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=190375; -- Wintergrasp Fortress Gate
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=190376; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=190377; -- Wintergrasp Fortress Tower
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=190378; -- Wintergrasp Fortress Tower
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=191795; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=191797; -- Wintergrasp Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=191798; -- Wintergrasp Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=191800; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=191801; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=191802; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=191803; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=191804; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=191805; -- Wintergrasp Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=191807; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=191808; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=191809; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=191810; -- Wintergrasp Fortress Door
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=204588; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=204589; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732, `flags`=288 WHERE `entry`=204590; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732, `flags`=32 WHERE `entry`=190753; -- Seaforium Bomb
UPDATE `gameobject_template` SET `faction`=1732, `flags`=32 WHERE `entry`=204588; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732, `flags`=32 WHERE `entry`=204589; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732, `flags`=32 WHERE `entry`=204590; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732, `flags`=32 WHERE `entry`=205358; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1732, `flags`=48 WHERE `entry`=190753; -- Seaforium Bomb
UPDATE `gameobject_template` SET `faction`=1732, `flags`=48 WHERE `entry`=194083; -- Titan Relic
UPDATE `gameobject_template` SET `faction`=1733 WHERE `entry`=203460; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1733 WHERE `entry`=209129; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1734 WHERE `entry`=204233; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=177044; -- Mailbox
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=185233; -- The Doctor's Strongbox
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=187390; -- Guild Vault
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=188128; -- Flame of the Exodar
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=190356; -- Shadowsight Tower
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=190357; -- Winter's Edge Tower
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=190704; -- Barbershop Chair
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=194620; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=194809; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=194909; -- Lance Rack
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=195142; -- Portal to Blasted Lands
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=197207; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=202536; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=202543; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=202544; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=203180; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=203181; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=203192; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=203429; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=204093; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=204252; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=204329; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=204330; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=204331; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=204332; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=204333; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=204334; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=204417; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=204999; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=205002; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=205090; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=205108; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=205230; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=205273; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=205371; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=205544; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=205894; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=206595; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=206725; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=206726; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=206727; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=206729; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=206730; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=206732; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=206733; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=206734; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=206735; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=206736; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=206737; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=206740; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=206741; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207146; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207147; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207148; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207149; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207150; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207614; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207630; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207631; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207632; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207633; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207634; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207635; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207636; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207637; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207638; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207639; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207640; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207641; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207642; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207643; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207644; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207645; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207646; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207982; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207984; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207985; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207987; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207988; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=207993; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=208054; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=208089; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=208093; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=208226; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=208258; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=209081; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735 WHERE `entry`=210176; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735, `flags`=288 WHERE `entry`=190356; -- Shadowsight Tower
UPDATE `gameobject_template` SET `faction`=1735, `flags`=288 WHERE `entry`=190357; -- Winter's Edge Tower
UPDATE `gameobject_template` SET `faction`=1735, `flags`=288 WHERE `entry`=204588; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735, `flags`=288 WHERE `entry`=204589; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735, `flags`=288 WHERE `entry`=204590; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735, `flags`=32 WHERE `entry`=194082; -- Titan Relic
UPDATE `gameobject_template` SET `faction`=1735, `flags`=32 WHERE `entry`=194086; -- Seaforium Bomb
UPDATE `gameobject_template` SET `faction`=1735, `flags`=32 WHERE `entry`=204588; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735, `flags`=32 WHERE `entry`=204589; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735, `flags`=32 WHERE `entry`=204590; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1735, `flags`=4 WHERE `entry`=188462; -- Anub'et'kan's Carapace
UPDATE `gameobject_template` SET `faction`=1735, `flags`=48 WHERE `entry`=192829; -- Titan Relic
UPDATE `gameobject_template` SET `faction`=1735, `flags`=48 WHERE `entry`=194082; -- Titan Relic
UPDATE `gameobject_template` SET `faction`=1735, `flags`=48 WHERE `entry`=194086; -- Seaforium Bomb
UPDATE `gameobject_template` SET `faction`=1801 WHERE `entry`=202563; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1813 WHERE `entry`=185946; -- Frost Trap
UPDATE `gameobject_template` SET `faction`=1865 WHERE `entry`=185915; -- Netherwing Egg
UPDATE `gameobject_template` SET `faction`=1877 WHERE `entry`=185877; -- Nethercite Deposit
UPDATE `gameobject_template` SET `faction`=1922 WHERE `entry`=187376; -- NPC Fishing Bobber
UPDATE `gameobject_template` SET `faction`=1924 WHERE `entry`=194092; -- Blackened Urn
UPDATE `gameobject_template` SET `faction`=1924 WHERE `entry`=206112; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1924 WHERE `entry`=208426; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=1971 WHERE `entry`=185465; -- Ethereum Stasis Chamber
UPDATE `gameobject_template` SET `faction`=1971 WHERE `entry`=185466; -- Ethereum Stasis Chamber
UPDATE `gameobject_template` SET `faction`=1971 WHERE `entry`=185467; -- Ethereum Stasis Chamber
UPDATE `gameobject_template` SET `faction`=1971 WHERE `entry`=185959; -- Proton Accelerator Controller
UPDATE `gameobject_template` SET `faction`=1971 WHERE `entry`=185962; -- Proton Accelerator Controller
UPDATE `gameobject_template` SET `faction`=1971 WHERE `entry`=185963; -- Proton Accelerator Controller
UPDATE `gameobject_template` SET `faction`=1971 WHERE `entry`=185964; -- Proton Accelerator Controller
UPDATE `gameobject_template` SET `faction`=1971, `flags`=32 WHERE `entry`=184595; -- Ethereum Stasis Chamber
UPDATE `gameobject_template` SET `faction`=1971, `flags`=32 WHERE `entry`=185461; -- Ethereum Stasis Chamber
UPDATE `gameobject_template` SET `faction`=1971, `flags`=32 WHERE `entry`=185462; -- Ethereum Stasis Chamber
UPDATE `gameobject_template` SET `faction`=1971, `flags`=32 WHERE `entry`=185463; -- Ethereum Stasis Chamber
UPDATE `gameobject_template` SET `faction`=1971, `flags`=32 WHERE `entry`=185464; -- Ethereum Stasis Chamber
UPDATE `gameobject_template` SET `faction`=1971, `flags`=32 WHERE `entry`=185512; -- Stasis Chamber Alpha
UPDATE `gameobject_template` SET `faction`=2059 WHERE `entry`=184142; -- Netherstorm Flag
UPDATE `gameobject_template` SET `faction`=2059, `flags`=1 WHERE `entry`=184142; -- Netherstorm Flag
UPDATE `gameobject_template` SET `faction`=21 WHERE `entry`=164638; -- Immolation Trap
UPDATE `gameobject_template` SET `faction`=21 WHERE `entry`=164639; -- Frost Trap
UPDATE `gameobject_template` SET `faction`=21 WHERE `entry`=183957; -- Snake Trap
UPDATE `gameobject_template` SET `faction`=2102, `flags`=33 WHERE `entry`=201385; -- Ice Wall
UPDATE `gameobject_template` SET `faction`=2159 WHERE `entry`=195378; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=2159 WHERE `entry`=202602; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=2159 WHERE `entry`=205494; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=2201 WHERE `entry`=207686; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=2201 WHERE `entry`=207687; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=2201 WHERE `entry`=207688; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=2201 WHERE `entry`=207689; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=2201 WHERE `entry`=207690; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=2206 WHERE `entry`=195360; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=2283, `flags`=48 WHERE `entry`=205364; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=230 WHERE `entry`=35591; -- Fishing Bobber
UPDATE `gameobject_template` SET `faction`=2339, `flags`=0 WHERE `entry`=191126; -- Duel Flag
UPDATE `gameobject_template` SET `faction`=29 WHERE `entry`=157637; -- Mailbox
UPDATE `gameobject_template` SET `faction`=29 WHERE `entry`=194803; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=29 WHERE `entry`=202440; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=29 WHERE `entry`=202587; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=29 WHERE `entry`=207344; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=29, `flags`=32 WHERE `entry`=206109; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=29, `flags`=32 WHERE `entry`=206116; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=29, `flags`=32 WHERE `entry`=207303; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=105576; -- Summoning Circle
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=180619; -- Ossirian Crystal
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=182072; -- Large Chapel Fire
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=184085; -- Mailbox
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=184955; -- Campfire
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=185965; -- Mailbox
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=190949; -- Musty Coffin
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=193908; -- Exit Portal
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=193988; -- Twilight Portal
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=193989; -- Normal Portal
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=195219; -- Mailbox
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=202080; -- Dart's Nest
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=202081; -- Takk's Nest
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=202212; -- The Captain's Chest
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=202277; -- Orb of Naxxramas
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=202278; -- Orb of Naxxramas
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=202337; -- The Captain's Chest
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=202967; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=203295; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=203418; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=203449; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=204273; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=204328; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=205268; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=206117; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=207971; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=207972; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=208184; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=208187; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=208188; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=208238; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=208239; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=208240; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=208241; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=208242; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=208262; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=209538; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35 WHERE `entry`=29784; -- Basic Campfire
UPDATE `gameobject_template` SET `faction`=35, `flags`=1 WHERE `entry`=186598; -- Tillinghast's Plagued Meat
UPDATE `gameobject_template` SET `faction`=35, `flags`=16 WHERE `entry`=194789; -- Cache of Innovation
UPDATE `gameobject_template` SET `faction`=35, `flags`=16 WHERE `entry`=201710; -- The Captain's Chest
UPDATE `gameobject_template` SET `faction`=35, `flags`=16 WHERE `entry`=203133; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=16 WHERE `entry`=203136; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=16 WHERE `entry`=205050; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=16 WHERE `entry`=207218; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=16 WHERE `entry`=207219; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=32 WHERE `entry`=195217; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=32 WHERE `entry`=195220; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=32 WHERE `entry`=202596; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=32 WHERE `entry`=203254; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=32 WHERE `entry`=204883; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=32 WHERE `entry`=204979; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=32 WHERE `entry`=207277; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=32 WHERE `entry`=207669; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=32 WHERE `entry`=208694; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=32 WHERE `entry`=208715; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=32 WHERE `entry`=208736; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=32 WHERE `entry`=208757; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=32 WHERE `entry`=208779; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=32 WHERE `entry`=208782; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=32 WHERE `entry`=208785; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=32 WHERE `entry`=209318; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=34 WHERE `entry`=204929; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=34 WHERE `entry`=209366; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=34 WHERE `entry`=209447; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=34 WHERE `entry`=209448; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=4 WHERE `entry`=1557; -- Lillith's Dinner Table
UPDATE `gameobject_template` SET `faction`=35, `flags`=4 WHERE `entry`=175324; -- Frostmaul Shards
UPDATE `gameobject_template` SET `faction`=35, `flags`=4 WHERE `entry`=186585; -- Dragonskin Scroll
UPDATE `gameobject_template` SET `faction`=35, `flags`=4 WHERE `entry`=190777; -- Artruis's Phylactery
UPDATE `gameobject_template` SET `faction`=35, `flags`=4 WHERE `entry`=195361; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=4 WHERE `entry`=20727; -- Gizmorium Shipping Crate
UPDATE `gameobject_template` SET `faction`=35, `flags`=4 WHERE `entry`=208874; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=4 WHERE `entry`=208876; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=4 WHERE `entry`=2701; -- Iridescent Shards
UPDATE `gameobject_template` SET `faction`=35, `flags`=48 WHERE `entry`=204276; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=35, `flags`=48 WHERE `entry`=209249; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=54 WHERE `entry`=177764; -- Inferno
UPDATE `gameobject_template` SET `faction`=54, `flags`=32 WHERE `entry`=181832; -- Blaze
UPDATE `gameobject_template` SET `faction`=68 WHERE `entry`=204449; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=68 WHERE `entry`=204856; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=714 WHERE `entry`=205091; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=714, `flags`=4 WHERE `entry`=202407; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83 WHERE `entry`=178936; -- Alliance Banner
UPDATE `gameobject_template` SET `faction`=83 WHERE `entry`=179284; -- Alliance Banner
UPDATE `gameobject_template` SET `faction`=83 WHERE `entry`=179481; -- Alliance Banner
UPDATE `gameobject_template` SET `faction`=83 WHERE `entry`=179482; -- Contested Banner
UPDATE `gameobject_template` SET `faction`=83 WHERE `entry`=18033; -- Mulgore
UPDATE `gameobject_template` SET `faction`=83 WHERE `entry`=18034; -- The Crossroads
UPDATE `gameobject_template` SET `faction`=83 WHERE `entry`=201876; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83 WHERE `entry`=202594; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=191306; -- Alliance Banner
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=191308; -- Alliance Banner
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=191310; -- Alliance Banner
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=208673; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=208676; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=208679; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=208691; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=208697; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=208700; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=208703; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=208718; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=208721; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=208724; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=208739; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=208742; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=208745; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=208760; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83, `flags`=32 WHERE `entry`=208763; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=83, `flags`=4 WHERE `entry`=142702; -- Venom Bottle
UPDATE `gameobject_template` SET `faction`=83, `flags`=4 WHERE `entry`=1627; -- Dalaran Crate
UPDATE `gameobject_template` SET `faction`=83, `flags`=48 WHERE `entry`=191306; -- Alliance Banner
UPDATE `gameobject_template` SET `faction`=83, `flags`=48 WHERE `entry`=191308; -- Alliance Banner
UPDATE `gameobject_template` SET `faction`=83, `flags`=48 WHERE `entry`=191310; -- Alliance Banner
UPDATE `gameobject_template` SET `faction`=84 WHERE `entry`=178393; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=84 WHERE `entry`=179285; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=84 WHERE `entry`=179443; -- Contested Banner
UPDATE `gameobject_template` SET `faction`=84 WHERE `entry`=179467; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=84 WHERE `entry`=179483; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=191305; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=191307; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=191309; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=208682; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=208685; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=208688; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=208706; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=208709; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=208727; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=208730; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=208733; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=208748; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=208751; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=208754; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=208766; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=208769; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=84, `flags`=32 WHERE `entry`=208772; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=84, `flags`=48 WHERE `entry`=191305; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=84, `flags`=48 WHERE `entry`=191307; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=84, `flags`=48 WHERE `entry`=191309; -- Horde Banner
UPDATE `gameobject_template` SET `faction`=94 WHERE `entry`=169243; -- Chest of The Seven
UPDATE `gameobject_template` SET `faction`=94 WHERE `entry`=185015; -- Overcharged Manacell
UPDATE `gameobject_template` SET `faction`=94 WHERE `entry`=185557; -- Ancient Gem Vein
UPDATE `gameobject_template` SET `faction`=94 WHERE `entry`=194821; -- Gift of the Observer
UPDATE `gameobject_template` SET `faction`=94 WHERE `entry`=195682; -- Portal to Dalaran
UPDATE `gameobject_template` SET `faction`=94 WHERE `entry`=202079; -- Portal to Dalaran
UPDATE `gameobject_template` SET `faction`=94 WHERE `entry`=202736; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=94 WHERE `entry`=202737; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=94 WHERE `entry`=202738; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=94 WHERE `entry`=202739; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=94 WHERE `entry`=202740; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=94 WHERE `entry`=202741; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=94 WHERE `entry`=206946; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=94 WHERE `entry`=210221; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=94 WHERE `entry`=210222; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=94 WHERE `entry`=2884; -- Clam
UPDATE `gameobject_template` SET `faction`=94, `flags`=16 WHERE `entry`=194313; -- Cache of Storms
UPDATE `gameobject_template` SET `faction`=94, `flags`=16 WHERE `entry`=195046; -- Cache of Living Stone
UPDATE `gameobject_template` SET `faction`=94, `flags`=16 WHERE `entry`=201875; -- Gunship Armory
UPDATE `gameobject_template` SET `faction`=94, `flags`=16 WHERE `entry`=202241; -- Deathbringer's Cache
UPDATE `gameobject_template` SET `faction`=94, `flags`=16 WHERE `entry`=205216; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=94, `flags`=16 WHERE `entry`=210221; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=94, `flags`=2 WHERE `entry`=180691; -- Scarab Coffer
UPDATE `gameobject_template` SET `faction`=94, `flags`=4 WHERE `entry`=203800; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=94, `flags`=4 WHERE `entry`=203977; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=94, `flags`=4 WHERE `entry`=203979; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=94, `flags`=4 WHERE `entry`=204281; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=94, `flags`=4 WHERE `entry`=208828; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=94, `flags`=4 WHERE `entry`=208833; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=974 WHERE `entry`=206963; -- -Unknown-
UPDATE `gameobject_template` SET `faction`=974 WHERE `entry`=207063; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=152620; -- Azsharite Formation
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=174881; -- Chair
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=175571; -- Ogre Coup Summoning Circle
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=175965; -- Frostwhisper's Embalming Fluid
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=175966; -- Enchanted Scarlet Thread
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=176089; -- Unfired Plate Gauntlets
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=176112; -- Malor's Strongbox
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=176224; -- Supply Crate
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=176311; -- Pew
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=176312; -- Pew
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=176313; -- Pew
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=176314; -- Pew
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=176315; -- Pew
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=176316; -- Pew
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=176498; -- Portal to Darnassus
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=177397; -- Demon Portal
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=177398; -- Demon Portal
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=177399; -- Demon Portal
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=177400; -- Demon Portal
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=177704; -- Lava Bomb
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=178388; -- Horde Banner
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=178929; -- Alliance Banner
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=179439; -- Contested Banner
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=179465; -- Alliance Banner
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=179468; -- Contested Banner
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=181271; -- Dreaming Glory
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=181278; -- Ancient Lichen
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=181281; -- Mana Thistle
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=181556; -- Adamantite Deposit
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=181569; -- Rich Adamantite Deposit
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=181690; -- Fertile Dirt Mound
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184189; -- Instance_Portal_Difficulty_1
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184190; -- Instance_Portal_Difficulty_0
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184255; -- Long Neck Spectrum Analyzer
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184909; -- Dave's Glowy Gem Thing
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184982; -- Campfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184983; -- Bonfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184984; -- Bonfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184985; -- Campfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184986; -- Bonfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184989; -- Campfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184990; -- Bonfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184991; -- Campfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184992; -- Bonfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184993; -- Campfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184994; -- Campfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184995; -- Campfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=184996; -- Bonfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=185878; -- Nethercite Smoke Effect
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=185881; -- Netherdust Bush
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=185913; -- Skull Pile
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=185952; -- Cage
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186609; -- Glowing Anvil
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186610; -- Glowing Anvil
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186611; -- Glowing Anvil
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186688; -- Doodad_VR_Bellows_First
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186689; -- Doodad_VR_Bellows_Second
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186690; -- Doodad_VR_Bellows_Third
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186695; -- Chair
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186696; -- Chair
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186697; -- Chair
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186698; -- Chair
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186699; -- Chair
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186700; -- Chair
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186701; -- Chair
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186702; -- Chair
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186703; -- Chair
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186704; -- Chair
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186705; -- Chair
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186706; -- Chair
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=186707; -- Chair
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=187184; -- Bonfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=187185; -- Campfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=187187; -- Bonfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=187242; -- Campfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=188376; -- Borean Tundra
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=188377; -- Agmar's Hammer
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=188378; -- Wyrmrest Temple
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=188398; -- Wintergarde Keep
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=188399; -- Wyrmrest Temple
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=188413; -- Grizzly Hills
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=188593; -- Stasis Generator
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=188715; -- Orb of the Nexus
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=189292; -- Scrying Orb
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=189294; -- Campfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=189985; -- Nexus Portal
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=19027; -- Tome of Mel'Thandris
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=190629; -- Drakuru's Brazier
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=190858; -- Volkhan Temper Visual
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=190914; -- Mailbox
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191077; -- Smoldering Leaves
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191081; -- Campfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191082; -- Campfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191237; -- Forge
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191238; -- Anvil
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191239; -- Campfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191240; -- Campfire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191347; -- Drakuru's Pedestal
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191440; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191444; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191445; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191555; -- Scourge Gryphon Roost Glow
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191577; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191580; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191581; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191582; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191583; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191584; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191585; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191586; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191587; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191588; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191589; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191590; -- Acherus Soul Prison
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191616; -- Touch of the Banshee
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191617; -- Compendium of Fallen Heroes
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191618; -- Report from the Frontlines: Western Northrend
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191631; -- Report from the Frontlines: Eastern Kingdoms
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191632; -- Report from the Frontlines: Dragonblight
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191633; -- Report from the Frontlines: Undercity
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191634; -- The Death Knights of Acherus
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191646; -- Corpulous' Mess Hall Rules
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191648; -- Account of the Raising of a Frost Wyrm
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191649; -- The Memoirs of Lord Thorval
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191650; -- Guide to the Side Effects of Reanimation
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191652; -- Grooming for Ghouls
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191653; -- Unknown Crusader's Diary
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191654; -- ATTENTION: Geists
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191655; -- One Truth in Undeath
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191656; -- On Scholomance
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191657; -- On Stratholme
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191658; -- On Naxxramas
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191659; -- On Undeath
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191662; -- A Zombie's Guide to Proper Nutrition
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191663; -- This is my Runeblade...
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191664; -- The Decree of the Scourge 
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191846; -- Doodad_InstanceNewPortal_Purple01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191847; -- Doodad_InstanceNewPortal_Purple_Skull01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191855; -- Lava
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191856; -- Lava
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191857; -- Lava
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191860; -- Lava
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191862; -- Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191866; -- Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191867; -- Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191869; -- Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191870; -- Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191871; -- Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191872; -- Lava
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191873; -- Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191874; -- Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191875; -- Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=191876; -- Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192067; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192068; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192083; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192084; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192085; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192086; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192087; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192088; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192089; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192163; -- Left Pipe
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192164; -- Right Pipe
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192235; -- 192235
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192280; -- Horde Banner
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192283; -- Horde Banner
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192289; -- Horde Banner
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192290; -- Horde Banner
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192434; -- Horde Banner
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192435; -- Horde Banner
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192458; -- Horde Banner
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192459; -- Horde Banner
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192460; -- Horde Banner
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192461; -- Horde Banner
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192465; -- Doodad_InstanceNewPortal_Purple01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192466; -- Doodad_InstanceNewPortal_Purple_Skull01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192467; -- Doodad_InstanceNewPortal_Purple01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192468; -- Doodad_InstanceNewPortal_Purple_Skull01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192489; -- Doodad_InstanceNewPortal_Purple01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192490; -- Doodad_InstanceNewPortal_Purple_Skull01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192503; -- Doodad_InstanceNewPortal_Purple_Skull01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192504; -- Doodad_InstanceNewPortal_Purple01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192513; -- Doodad_InstanceNewPortal_Purple02
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192514; -- Doodad_InstanceNewPortal_Purple_Skull02
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192528; -- Doodad_InstanceNewPortal_Purple01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192529; -- Doodad_InstanceNewPortal_Purple_Skull01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192622; -- Meeting Stone
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192677; -- Doodad_InstanceNewPortal_Purple_Skull01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192678; -- Doodad_InstanceNewPortal_Purple01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192679; -- Doodad_InstanceNewPortal_Purple02
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192680; -- Doodad_InstanceNewPortal_Purple_Skull02
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192681; -- Doodad_InstanceNewPortal_Purple01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192682; -- Doodad_InstanceNewPortal_Purple_Skull01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192850; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192853; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192903; -- Doodad_InstanceNewPortal_Green01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192904; -- Doodad_InstanceNewPortal_Green_Skull01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=192951; -- Vehicle Teleporter
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193039; -- Doodad_InstanceNewPortal_Green_Skull01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193040; -- Doodad_InstanceNewPortal_Green01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193147; -- 193147
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193148; -- 193148
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193149; -- 193149
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193150; -- 193150
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193151; -- 193151
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193152; -- 193152
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193153; -- 193153
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193154; -- 193154
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193155; -- 193155
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193156; -- 193156
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193157; -- 193157
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193158; -- 193158
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193159; -- 193159
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193212; -- Doodad_InstanceNewPortal_Purple_Skull04
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193213; -- Doodad_InstanceNewPortal_Purple04
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193587; -- Doodad_InstanceNewPortal_Green_Skull01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193588; -- Doodad_InstanceNewPortal_Green01
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=193907; -- Tribunal Control Console
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=22831; -- Cozy Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=22832; -- Cozy Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=22833; -- Cozy Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=22834; -- Cozy Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=22835; -- Cozy Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=22836; -- Cozy Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=3644; -- Bael Modan Flying Machine
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=3801; -- Cozy Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=3802; -- Cozy Fire
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry`=386; -- Metal Mace
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=181805; -- Holographic Emitter
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=187909; -- Coldrock Clam
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=191461; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=191462; -- Doodad_Dalaran_LampWall02
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=191463; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=191464; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=191465; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=191466; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=191467; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=191468; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=191469; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=191470; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=191471; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=191472; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=191473; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=191474; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=191665; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192069; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192070; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192090; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192091; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192092; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192093; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192094; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192095; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192096; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192097; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192098; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192099; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192102; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192103; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192498; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192851; -- Lamp
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192852; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192854; -- Lamp Post
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=192918; -- Brigg's Chest
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=208952; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=209441; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=1 WHERE `entry`=210132; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=148418; -- Eternal Flame
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=148419; -- Eternal Flame
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=148420; -- Eternal Flame
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=148421; -- Eternal Flame
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=164824; -- Dark Keeper Nameplate
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=175564; -- Brazier of the Herald
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=176944; -- Old Treasure Chest
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=176951; -- Rune of Koro
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=176952; -- Rune of Zeth
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=176953; -- Rune of Mazj
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=176954; -- Rune of Theri
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=181575; -- Naxxramas Portal
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=181576; -- Naxxramas Portal
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=185114; -- Serpentshrine Console
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=185115; -- Serpentshrine Console
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=185117; -- Serpentshrine Console
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=185118; -- Serpentshrine Console
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=185119; -- Dust Covered Chest
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=185168; -- Reinforced Fel Iron Chest
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=185169; -- Reinforced Fel Iron Chest
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=186883; -- Gjalerbron Cage
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=186895; -- Gjalerbron Cage
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=186907; -- Gjalerbron Cage
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=186910; -- Gjalerbron Cage
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=186911; -- Gjalerbron Cage
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=186923; -- Gjalerbron Cage
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=186924; -- Gjalerbron Cage
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=187892; -- Ice Chest
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=188471; -- Directional Rune 1
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=188505; -- Directional Rune 2
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=188506; -- Directional Rune 3
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=188507; -- Directional Rune 4
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=188689; -- Levine Family Termites
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=190586; -- Tribunal Chest
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=190663; -- Dark Runed Chest
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=191349; -- Cache of Eregos
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=192518; -- Altar of Slad'ran
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=192519; -- Altar of Moorabi
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=192520; -- Altar of the Drakkari Colossus
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=193597; -- Dark Runed Chest
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=193905; -- Alexstrasza's Gift
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=193967; -- Alexstrasza's Gift
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=193996; -- Tribunal Chest
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=194307; -- Cache of Winter
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=194327; -- Freya's Gift
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=195323; -- Confessor's Cache
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=195374; -- Eadric's Cache
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=195709; -- Champion's Cache
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=201615; -- Ooze Release Valve
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=201616; -- Gas Release Valve
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=203199; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=16 WHERE `entry`=210220; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=2 WHERE `entry`=175786; -- 175786
UPDATE `gameobject_template` SET `flags`=2 WHERE `entry`=182094; -- Cage
UPDATE `gameobject_template` SET `flags`=2 WHERE `entry`=184566; -- Waterfall Control Console
UPDATE `gameobject_template` SET `flags`=2 WHERE `entry`=184716; -- Coilskar Chest
UPDATE `gameobject_template` SET `flags`=2 WHERE `entry`=187369; -- Cage
UPDATE `gameobject_template` SET `flags`=2 WHERE `entry`=187561; -- Arcane Prison
UPDATE `gameobject_template` SET `flags`=2 WHERE `entry`=188259; -- Grizzly Hills Bounty Hunter Cage
UPDATE `gameobject_template` SET `flags`=2 WHERE `entry`=188472; -- Cage
UPDATE `gameobject_template` SET `flags`=2 WHERE `entry`=188487; -- Adarra's Cage
UPDATE `gameobject_template` SET `flags`=2 WHERE `entry`=190567; -- Cage
UPDATE `gameobject_template` SET `flags`=2 WHERE `entry`=75297; -- Large Iron Bound Chest
UPDATE `gameobject_template` SET `flags`=20 WHERE `entry`=179545; -- The Prince's Chest
UPDATE `gameobject_template` SET `flags`=20 WHERE `entry`=194158; -- Heart of Magic
UPDATE `gameobject_template` SET `flags`=20 WHERE `entry`=194159; -- Heart of Magic
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=190219; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=190221; -- Wintergrasp Fortress Tower
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=190356; -- Shadowsight Tower
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=190358; -- Flamewatch Tower
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=190369; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=190370; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=190372; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=190373; -- Wintergrasp Fortress Tower
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=190377; -- Wintergrasp Fortress Tower
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=190378; -- Wintergrasp Fortress Tower
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=190724; -- Gate of the Blue Sapphire
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=190727; -- Gate of the Yellow Moon
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=191795; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=191797; -- Wintergrasp Wall
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=191799; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=191801; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=191802; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=191805; -- Wintergrasp Wall
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=191806; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=191807; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=191808; -- Wintergrasp Fortress Wall
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=191810; -- Wintergrasp Fortress Door
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=192030; -- Goblin Workshop
UPDATE `gameobject_template` SET `flags`=288 WHERE `entry`=192549; -- Chamber of Ancient Relics
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=101850; -- Cathedral Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=101851; -- Armory Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=101854; -- Herod's Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=104591; -- Chapel Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=141869; -- Temple Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=143979; -- Cage Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=148503; -- Fire Plume Ridge Hot Spot
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=161460; -- The Shadowforge Lock
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=170559; -- Shadowforge Gate
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=170560; -- Shadowforge Gate
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=170570; -- East Garrison Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=174626; -- Scholomance Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=175167; -- Viewing Room Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=175352; -- King's Square Gate
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=175353; -- King's Square Gate
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=175357; -- Gauntlet Gate
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=175368; -- Service Entrance Gate
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=175369; -- Elders' Square Service Entrance
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=175379; -- Doodad_ZigguratDoor02
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=175381; -- Doodad_ZigguratDoor03
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=175968; -- Hoard Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=175969; -- Doodad_DwarvenTunnelPortcullis04
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=176194; -- Hall of the High Command
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=176694; -- Karazhan Side Entrance
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=176907; -- Conservatory Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=177164; -- Portcullis
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=177165; -- Portcullis
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=177198; -- Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=177211; -- Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=177212; -- Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=177213; -- Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=177215; -- Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=177217; -- Gordok Inner Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=177219; -- Gordok Courtyard Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=177220; -- Crumble Wall
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=177221; -- Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=177444; -- Stone Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=177928; -- Onyxia's Gate
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=178932; -- [PH] Alliance A2 Tower Banner BIG
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=178947; -- [PH] Alliance A3 Tower Banner BIG
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=178948; -- [PH] Alliance A4 Tower Banner BIG
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=179424; -- [PH] Alliance Graveyard Mid Pre-Banner BIG
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=179436; -- [PH] Horde A1 Tower Pre-Banner BIG
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=179440; -- [PH] Horde A2 Tower Pre-Banner BIG
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=179444; -- [PH] Horde A4 Tower Pre-Banner BIG
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=179446; -- [PH] Alliance H1 Tower Pre-Banner BIG
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=179454; -- [PH] Alliance H3 Tower Pre-Banner BIG
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=179503; -- Doodad_DireMaulBossForceField01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=179506; -- Doodad_DiremaulMagicVortex01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=179550; -- Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=180100; -- Alliance Banner Aura
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=180101; -- Horde Banner Aura
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=180102; -- Neutral Banner Aura
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=180218; -- Arathi Basin Pumpkin
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=180219; -- Arathi Basin Pumpkin Patch
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=180220; -- Arathi Basin Bone01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=180222; -- Arathi Basin Bone02
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=180223; -- Arathi Basin BlastedLandsSkull01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=180224; -- Arathi Basin BlastedLandsBonePile02
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=180225; -- Arathi Basin BlastedLandsBonePile03
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=180226; -- Arathi Basin Doomweed01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=180227; -- Arathi Basin Gloomweed01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=180419; -- Contested Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=180734; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=180735; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181032; -- Blood Drenched Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181042; -- Medivh's Chambers
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181221; -- Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181228; -- KelThuzad Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181402; -- Doodad_kelthuzad_window_portal01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181403; -- Doodad_kelthuzad_window_portal02
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181404; -- Doodad_kelthuzad_window_portal03
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181405; -- Doodad_kelthuzad_window_portal04
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181477; -- Doodad_nox_tesla05
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181478; -- Doodad_nox_tesla06
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181766; -- Doodad_Hellfire_DW_PrisonEntry01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181811; -- Doodad_Hellfire_DW_PrisonEntry02
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181812; -- Doodad_Hellfire_DW_PrisonEntry03
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181813; -- Prison Cell Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181814; -- Prison Cell Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181815; -- Prison Cell Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181816; -- Prison Cell Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181817; -- Prison Cell Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181818; -- Prison Cell Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181819; -- Doodad_Hellfire_DW_PrisonEntry04
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181820; -- Prison Cell Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181821; -- Prison Cell Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181822; -- Doodad_Hellfire_DW_PrisonEntry05
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=181823; -- Doodad_Hellfire_DW_SummonDoor01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=182012; -- Makeshift Prison
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=182090; -- Vector Coil Fire (L)
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=182297; -- Destroyed Wyvern Roost
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=182298; -- Destroyed Wyvern Roost
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=182299; -- Destroyed Wyvern Roost
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=182300; -- Destroyed Wyvern Roost
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=182301; -- Wyvern Roost
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=182302; -- Wyvern Roost
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=182305; -- Bomb Wagon
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=182306; -- Bomb Wagon
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=182529; -- Zangarmarsh Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=183051; -- Sethekk Cage
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=183294; -- The Shadow Labyrinth
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=183398; -- Doodad_Auchindoun_Door_Swinging01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=183401; -- Portcullis
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=183402; -- Portcullis
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=183411; -- Terokkar Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=183412; -- Terokkar Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=183413; -- Terokkar Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=183414; -- Terokkar Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=183450; -- Gatehouse Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=184125; -- Main Chambers Access Panel
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=184126; -- Main Chambers Access Panel
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=184164; -- Karazhan Gatehouse Portcullis
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=184212; -- Coilfang Resevoir Waterfall
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=184246; -- Heavy Iron Portcullis
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=184276; -- Gamesman's Hall Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=184289; -- Portal Kruul
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=184290; -- Portal Xilus
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=184320; -- The Arcatraz
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=184414; -- Portal Grimh
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=184453; -- Strange Bookcase
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=184517; -- Private Library Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=184568; -- Lady Vashj Bridge Console
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=184912; -- The Shattered Halls
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=185103; -- Dark Portal
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=185123; -- Lever
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=185519; -- Mana-Tombs Stasis Chamber
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=185522; -- Shaffar's Stasis Chamber
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=186287; -- Blackhoof Cage
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=186566; -- Dragonflayer Cage
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=186567; -- Dragonflayer Cage
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=186608; -- Giant Portcullis
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=186612; -- Giant Portcullis
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=186691; -- Doodad_VR_ForgeFire_Third
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=186692; -- Doodad_VR_ForgeFire_First
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=186693; -- Doodad_VR_ForgeFire_Second
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=186694; -- Giant Portcullis
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=186756; -- Giant Portcullis
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=186805; -- Hippogryph Nest
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=187055; -- Spectral Rift
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=188072; -- Ice Stone Mount
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=188081; -- Sanctum Planetarium
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=188458; -- Seer of Zeb'Halak
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=188460; -- Thor Modan Mole Machine
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=188480; -- Grizzly Hills - FireDoor01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=188554; -- Dun Argol Cage
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=188596; -- Loken's Pedestal
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=188706; -- Wooden Cage
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=189299; -- Ritual Crystal
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=189300; -- Ritual Crystal
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=189301; -- Ritual Crystal
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=189302; -- Ritual Crystal
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=189310; -- Venture Bay Lighthouse
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=189975; -- Doodad_DT_bigDoor01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=189977; -- Brittle Cage
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=189986; -- Dragon Cage
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190192; -- Gate
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190402; -- Blaze
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190475; -- Wintergrasp NE Factory Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190487; -- Wintergrasp NW Factory Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190538; -- Argent Crusade Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190568; -- Light's Point Tower
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190569; -- Acherus Lightning
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190574; -- Zul'Drak Stoneface 01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190594; -- Zul'Drak Skull Pile 02
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190647; -- Corpses
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190687; -- Wood Pile
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190722; -- Gate of the Green Emerald
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190723; -- Gate of the Purple Amethyst
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190724; -- Gate of the Blue Sapphire
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190726; -- Gate of the Red Sun
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190727; -- Gate of the Yellow Moon
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190752; -- Massive Seaforium Charge
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190763; -- Defender's Portal
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190784; -- Zol'Maz Gate
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190789; -- 190789
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190799; -- 190799
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190800; -- 190800
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190859; -- 190859
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190860; -- 190860
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190861; -- 190861
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190862; -- 190862
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190863; -- 190863
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190864; -- 190864
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190865; -- 190865
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190866; -- 190866
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190867; -- 190867
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190868; -- 190868
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190869; -- 190869
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190870; -- 190870
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190871; -- 190871
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190872; -- 190872
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190873; -- 190873
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190874; -- 190874
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190875; -- 190875
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190876; -- 190876
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190877; -- 190877
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190878; -- 190878
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190879; -- 190879
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190880; -- 190880
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190881; -- 190881
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190882; -- 190882
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190883; -- 190883
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190884; -- 190884
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190885; -- 190885
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190886; -- 190886
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190887; -- 190887
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190888; -- 190888
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190889; -- 190889
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190890; -- 190890
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190891; -- 190891
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190892; -- 190892
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190893; -- 190893
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190898; -- 190898
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190899; -- 190899
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190900; -- 190900
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190901; -- 190901
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190902; -- 190902
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190903; -- 190903
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190904; -- 190904
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190905; -- 190905
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190906; -- 190906
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190907; -- 190907
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190908; -- 190908
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190909; -- 190909
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190910; -- 190910
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190911; -- 190911
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190930; -- 190930
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190931; -- 190931
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190932; -- 190932
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190933; -- 190933
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=190934; -- 190934
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191018; -- Akali Chain Anchor
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191148; -- 191148
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191166; -- 191166
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191167; -- 191167
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191169; -- 191169
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191171; -- 191171
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191172; -- 191172
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191173; -- 191173
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191178; -- 191178
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191191; -- 191191
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191292; -- Doodad_UL_Ulduar_doors06
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191293; -- Doodad_UL_Ulduar_doors04
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191294; -- Doodad_UL_Ulduar_doors05
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191295; -- Doodad_UL_Ulduar_doors03
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191296; -- Doodad_UL_Ulduar_doors02
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191311; -- Flagpole
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191324; -- Doodad_UL_Ulduar_doors02
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191325; -- Doodad_UL_Ulduar_doors07
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191326; -- Doodad_UL_Ulduar_doors05
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191327; -- Doodad_UL_Ulduar_doors06
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191328; -- Doodad_UL_Ulduar_doors04
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191351; -- Spotlight
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191364; -- Doodad_Nox_portal_orange_bossroom01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191369; -- Cosmetic Object - Fire Large
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191415; -- Doodad_UL_Ulduar_doors09
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191416; -- Doodad_UL_Ulduar_doors10
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191459; -- Doodad_UL_Ulduar_doors07
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191503; -- Anvil
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191504; -- Anvil
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191505; -- Forge
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191506; -- Anvil
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191507; -- Anvil
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191508; -- Forge
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191527; -- Doodad_UL_SkyRoom_Floor01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191538; -- Doodad_Nox_portal_purple_bossroom01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191539; -- Doodad_Nox_portal_purple_bossroom17
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191540; -- Alchemy Lab
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191541; -- Alchemy Lab
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191549; -- Nidavelir Mole Machine
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191552; -- Large Nidavelir Mole Machine
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191554; -- Skeletal Gryphon Roost
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191556; -- Cell
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191557; -- Cell
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191558; -- Cell
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191559; -- Cell
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191560; -- Cell
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191562; -- Cell
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191563; -- Cell
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191564; -- Cell
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191565; -- Cell
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191566; -- Cell
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191575; -- Defender's Portal
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191606; -- Cell
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191612; -- Eye of Acherus (Flavor)
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191613; -- Eye of Acherus (Flavor Trap)
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191614; -- Argent Stand Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191669; -- Tribunal Head - Center
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191670; -- Tribunal Head - Right
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191671; -- Tribunal Head - Left
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191722; -- Cell
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191723; -- Prison Seal
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191745; -- Doodad_Utgarde_Mirror_FX01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191746; -- Runeforge
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191747; -- Runeforge
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=191748; -- Runeforge
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192134; -- Norgannon's Binding
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192173; -- Doodad_VR_Portcullis01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192174; -- Doodad_VR_Portculliswithchain01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192175; -- Harpoon Launcher
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192176; -- Harpoon Launcher
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192177; -- Harpoon Launcher
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192236; -- Taldaram Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192244; -- Argent Vanguard Support
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192245; -- Argent Vanguard Support
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192246; -- Argent Vanguard Tower
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192247; -- Argent Vanguard Tower
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192248; -- Argent Vanguard Tower
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192249; -- Argent Vanguard Tower
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192250; -- Argent Vanguard Support
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192251; -- Argent Vanguard Support
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192390; -- Doodad_org_arena_pulley02
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192395; -- Doodad_Azjol_Door_Small_04
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192396; -- Doodad_Azjol_Door_Boss_01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192397; -- Doodad_Azjol_Door_Boss_02
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192398; -- Doodad_Azjol_Door_Boss_03
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192549; -- Chamber of Ancient Relics
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192564; -- Doodad_GunDrak_Key_Snake05
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192565; -- Doodad_GunDrak_Key_Mammoth01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192566; -- Doodad_GunDrak_Key_Rhino01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192567; -- Doodad_GunDrak_Key_Troll01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192568; -- Gal'darah Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192569; -- Eck Underwater Grate
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192626; -- Wintergrasp NE Factory Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192632; -- Eck Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192633; -- Doodad_GunDrak_Collision_01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192654; -- Doodad_UL_Throne_02
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192734; -- Doodad_ZulDrak_Alter02
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192735; -- Alter
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192736; -- Alter
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192741; -- Fence
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192819; -- Defender's Portal
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192934; -- 192934
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192935; -- 192935
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192936; -- 192936
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192938; -- 192938
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192953; -- 192953
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192954; -- 192954
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192955; -- 192955
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192956; -- 192956
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192957; -- 192957
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192958; -- 192958
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192959; -- 192959
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192960; -- 192960
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192961; -- 192961
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192962; -- 192962
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192963; -- 192963
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192964; -- 192964
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192965; -- 192965
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192966; -- 192966
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192967; -- 192967
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192968; -- 192968
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192969; -- 192969
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192970; -- 192970
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192971; -- 192971
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192972; -- 192972
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192973; -- 192973
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192974; -- 192974
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192975; -- 192975
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192976; -- 192976
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192977; -- 192977
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192978; -- 192978
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192979; -- 192979
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192980; -- 192980
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192981; -- 192981
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192982; -- 192982
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192983; -- 192983
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192985; -- 192985
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192986; -- 192986
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192987; -- 192987
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192988; -- 192988
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192989; -- 192989
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192990; -- 192990
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192991; -- 192991
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192994; -- 192994
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=192995; -- 192995
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193019; -- The Violet Hold
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193057; -- Ahn'kahet Brazier
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193093; -- Ancient Nerubian Device
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193094; -- Ancient Nerubian Device
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193198; -- Shoulder [PH]
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193208; -- Doodad_DT_bigDoor01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193209; -- Doodad_DT_bigDoor02
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193220; -- 193220
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193221; -- 193221
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193222; -- 193222
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193223; -- 193223
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193224; -- 193224
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193225; -- 193225
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193226; -- 193226
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193227; -- 193227
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193228; -- 193228
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193229; -- 193229
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193230; -- 193230
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193231; -- 193231
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193232; -- 193232
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193233; -- 193233
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193234; -- 193234
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193235; -- 193235
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193236; -- 193236
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193237; -- 193237
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193238; -- 193238
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193239; -- 193239
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193240; -- 193240
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193241; -- 193241
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193242; -- 193242
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193243; -- 193243
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193244; -- 193244
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193245; -- 193245
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193246; -- 193246
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193247; -- 193247
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193248; -- 193248
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193249; -- 193249
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193250; -- 193250
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193251; -- 193251
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193252; -- 193252
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193253; -- 193253
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193254; -- 193254
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193255; -- 193255
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193256; -- 193256
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193257; -- 193257
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193258; -- 193258
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193259; -- 193259
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193260; -- 193260
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193261; -- 193261
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193262; -- 193262
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193263; -- 193263
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193264; -- 193264
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193265; -- 193265
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193266; -- 193266
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193267; -- 193267
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193268; -- 193268
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193269; -- 193269
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193270; -- 193270
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193271; -- 193271
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193272; -- 193272
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193273; -- 193273
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193274; -- 193274
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193275; -- 193275
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193276; -- 193276
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193277; -- 193277
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193278; -- 193278
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193279; -- 193279
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193280; -- 193280
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193281; -- 193281
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193282; -- 193282
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193283; -- 193283
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193284; -- 193284
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193285; -- 193285
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193286; -- 193286
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193287; -- 193287
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193288; -- 193288
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193289; -- 193289
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193290; -- 193290
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193291; -- 193291
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193292; -- 193292
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193293; -- 193293
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193294; -- 193294
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193295; -- 193295
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193296; -- 193296
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193297; -- 193297
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193298; -- 193298
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193299; -- 193299
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193300; -- 193300
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193301; -- 193301
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193302; -- 193302
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193303; -- 193303
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193304; -- 193304
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193305; -- 193305
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193306; -- 193306
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193307; -- 193307
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193308; -- 193308
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193309; -- 193309
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193310; -- 193310
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193311; -- 193311
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193312; -- 193312
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193313; -- 193313
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193314; -- 193314
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193315; -- 193315
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193316; -- 193316
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193317; -- 193317
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193318; -- 193318
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193319; -- 193319
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193320; -- 193320
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193321; -- 193321
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193322; -- 193322
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193323; -- 193323
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193324; -- 193324
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193325; -- 193325
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193326; -- 193326
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193327; -- 193327
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193328; -- 193328
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193329; -- 193329
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193330; -- 193330
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193331; -- 193331
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193332; -- 193332
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193333; -- 193333
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193334; -- 193334
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193335; -- 193335
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193336; -- 193336
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193337; -- 193337
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193338; -- 193338
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193339; -- 193339
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193340; -- 193340
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193341; -- 193341
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193342; -- 193342
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193343; -- 193343
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193344; -- 193344
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193345; -- 193345
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193346; -- 193346
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193347; -- 193347
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193348; -- 193348
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193349; -- 193349
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193350; -- 193350
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193351; -- 193351
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193352; -- 193352
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193353; -- 193353
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193354; -- 193354
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193355; -- 193355
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193356; -- 193356
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193357; -- 193357
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193358; -- 193358
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193359; -- 193359
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193360; -- 193360
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193361; -- 193361
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193362; -- 193362
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193363; -- 193363
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193364; -- 193364
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193365; -- 193365
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193366; -- 193366
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193367; -- 193367
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193368; -- 193368
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193369; -- 193369
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193370; -- 193370
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193371; -- 193371
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193372; -- 193372
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193373; -- 193373
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193374; -- 193374
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193375; -- 193375
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193376; -- 193376
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193377; -- 193377
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193379; -- 193379
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193380; -- 193380
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193381; -- 193381
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193382; -- 193382
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193383; -- 193383
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193384; -- 193384
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193385; -- 193385
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193386; -- 193386
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193388; -- 193388
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193389; -- 193389
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193390; -- 193390
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193391; -- 193391
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193392; -- 193392
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193393; -- 193393
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193394; -- 193394
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193395; -- 193395
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193396; -- 193396
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193397; -- 193397
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193398; -- 193398
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193399; -- 193399
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193471; -- 193471
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193562; -- Icecrown - Nexus - Dragon Egg - Blue Dragon Egg 01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193563; -- Icecrown - Nexus - Dragon Egg - Blue Dragon Egg 02
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193564; -- Doodad_Azjol_Platform_FX_01
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193565; -- Ymirheim Peak Skulls
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193566; -- VR_StandingLight_Snow_Blue
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193622; -- Grimkor's Orb
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193906; -- Sjonnir Console
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=193995; -- Dragon Cage Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194005; -- Shadow Council Torch
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194237; -- Drak'Mar Brazier
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194239; -- Drak'Mar Lily Pad
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194497; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194589; -- Exodar Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194590; -- Undercity Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194591; -- Silvermoon City Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194592; -- Gnomeregan Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194593; -- Ironforge Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194594; -- Stormwind Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194595; -- Darnassus Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194596; -- Sen'jin Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194597; -- Orgrimmar Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194598; -- Thunder Bluff Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194599; -- Stormwind Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194600; -- Ironforge Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194601; -- Exodar Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194602; -- Darnassus Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194603; -- Gnomeregan Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194604; -- Thunder Bluff Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194605; -- Silvermoon City Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194606; -- Sen'jin Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194607; -- Orgrimmar Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194608; -- Undercity Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194625; -- Flee to the Surface
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194739; -- DO NOT PUSH THIS BUTTON!
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194827; -- Bonfire
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194839; -- 194839
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194840; -- 194840
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194841; -- 194841
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194842; -- 194842
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194843; -- 194843
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194849; -- 194849
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194850; -- 194850
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194851; -- 194851
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194852; -- 194852
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194853; -- 194853
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194912; -- Call Tram
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194916; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194917; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194918; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194919; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194920; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194921; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194922; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194923; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194924; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194925; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194934; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194959; -- Wintergrasp SE Factory Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194960; -- Wintergrasp SE Factory Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=194963; -- Wintergrasp SW Factory Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=195188; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=195305; -- Stormforged Mole Machine
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=195310; -- Black Cage
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=195449; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=195450; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=195485; -- Web Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=195589; -- West Portcullis
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=195590; -- South Portcullis
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=195591; -- North Portcullis
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=195597; -- Main Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=195647; -- Main Gate
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=195648; -- East Portcullis
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=195649; -- South Portcullis
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=195650; -- North Portcullis
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196396; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196397; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196420; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196421; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196422; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196423; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196424; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196425; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196426; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196427; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196428; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196429; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196431; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196432; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196433; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196434; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196435; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196436; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196437; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196438; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196439; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196441; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196442; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196443; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196444; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196446; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196447; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196448; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196449; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196450; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196451; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196452; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196453; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196454; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196455; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=196456; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201370; -- Green Plague Monster Entrance
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201371; -- Orange Plague Monster Entrance
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201372; -- Scientist Entrance
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201386; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201584; -- Drink Me!
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201604; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201720; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201721; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201736; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201739; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201740; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201745; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201768; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201770; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201791; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201825; -- Saurfang's Door
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201938; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201962; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201966; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=201967; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202134; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202166; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202297; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202298; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202300; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202357; -- Drakuru's Last Wish
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202391; -- Forge
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202392; -- Forge
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202393; -- Forge
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202394; -- Forge
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202454; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202455; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202456; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202458; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202459; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202486; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202494; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202495; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202614; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202788; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202831; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=202897; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203137; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203152; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203153; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203169; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203194; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203210; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203211; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203212; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203213; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203218; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203221; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203248; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203257; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203260; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203372; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203386; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203388; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203390; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203391; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203415; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203420; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203421; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203422; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203423; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203424; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203425; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203426; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203447; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203471; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203735; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203746; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203756; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203838; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203862; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=203973; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204088; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204089; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204090; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204097; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204098; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204116; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204117; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204254; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204379; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204395; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204396; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204397; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204435; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204441; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204442; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204530; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204582; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204828; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204859; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=204860; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205061; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205068; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205077; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205096; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205101; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205103; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205138; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205139; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205143; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205161; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205165; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205220; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205221; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205356; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205359; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205360; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205389; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205435; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205436; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205437; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205438; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205439; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205440; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205441; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205442; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205443; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205444; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205445; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205446; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205447; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205448; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205449; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205450; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205451; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205452; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205453; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205454; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205455; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205456; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205457; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205458; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205459; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205460; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205461; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205462; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205463; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205464; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205465; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205466; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205467; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205468; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205469; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205487; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205488; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205489; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205528; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205529; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205530; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205531; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205532; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205533; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205585; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205586; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205587; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205819; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205866; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205867; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205868; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205869; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205870; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205871; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205872; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205919; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205920; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205921; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205936; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205937; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205938; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=205939; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206037; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206040; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206103; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206110; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206501; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206552; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206625; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206690; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206691; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206702; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206703; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206846; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206848; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206975; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206978; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206979; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=206986; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207130; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207151; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207166; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207208; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207235; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207236; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207237; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207238; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207239; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207240; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207241; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207242; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207243; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207244; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207245; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207246; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207258; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207278; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207280; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207298; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207338; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207349; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207355; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207401; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207402; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207403; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207404; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207414; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207416; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207425; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207445; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207449; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207452; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207454; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207460; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207462; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207565; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207566; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207577; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207578; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207579; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207583; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207584; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207585; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207586; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207587; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207588; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207627; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207657; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207671; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207698; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207802; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207948; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=207949; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208377; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208378; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208379; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208396; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208454; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208529; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208531; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208532; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208552; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208584; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208586; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208632; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208807; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208887; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208888; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208889; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208890; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208900; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208955; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=208956; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=209039; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=209278; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=209331; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=209544; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=209670; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=209692; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=209693; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=209694; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=209695; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=210061; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=210081; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=210082; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=210084; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=210151; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=210177; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=210181; -- Deathwing Trophy (0.7)
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=210210; -- New Year Alliance Hanging Banner
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry`=210211; -- New Year Alliance Hanging Banner 02
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=101850; -- Cathedral Door
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=101851; -- Armory Door
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=174626; -- Scholomance Door
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=176694; -- Karazhan Side Entrance
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=177928; -- Onyxia's Gate
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=180636; -- Door
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=181921; -- Doodad_Hellfire_DW_LargeFloor_Crack02onoff
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=181922; -- Doodad_Hellfire_DW_LargeFloor_Crack03
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=181923; -- Doodad_Hellfire_DW_LargeFloor_Crack04onoff
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=181924; -- Doodad_Hellfire_DW_SmallFloor_Crack03onoff
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=181925; -- Doodad_Hellfire_DW_SmallFloor_Crack04onoff
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=181926; -- Doodad_Hellfire_DW_SmallFloor_Crack05onoff
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=181927; -- Doodad_Hellfire_DW_SmallFloor_Crack06onoff
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=182012; -- Makeshift Prison
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=182490; -- Warmaul Prison
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=182521; -- Corki's Prison
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=183294; -- The Shadow Labyrinth
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=184164; -- Karazhan Gatehouse Portcullis
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=184212; -- Coilfang Resevoir Waterfall
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=184290; -- Portal Xilus
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=184320; -- The Arcatraz
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=184912; -- The Shattered Halls
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=186567; -- Dragonflayer Cage
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=188118; -- Doodad_SunwellRaid_Gate_08
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=188706; -- Wooden Cage
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=190784; -- Zol'Maz Gate
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=193019; -- The Violet Hold
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=194704; -- Freya's Targetting Crystal
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=194705; -- Mimiron's Targetting Crystal
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=194706; -- Thorim's Targetting Crystal
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=195310; -- Black Cage
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=201919; -- Frostwing Door
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=201920; -- Bloodwing Door
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=204828; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=33 WHERE `entry`=206625; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=34 WHERE `entry`=124367; -- Temple Door
UPDATE `gameobject_template` SET `flags`=34 WHERE `entry`=181119; -- Deathknight Door
UPDATE `gameobject_template` SET `flags`=34 WHERE `entry`=182060; -- Horde Encampment Portal
UPDATE `gameobject_template` SET `flags`=34 WHERE `entry`=182061; -- Night Elf Village Portal
UPDATE `gameobject_template` SET `flags`=34 WHERE `entry`=182539; -- Grand Warlock Chamber Door
UPDATE `gameobject_template` SET `flags`=34 WHERE `entry`=182540; -- Grand Warlock Chamber Door
UPDATE `gameobject_template` SET `flags`=34 WHERE `entry`=183049; -- Main Chambers Door
UPDATE `gameobject_template` SET `flags`=34 WHERE `entry`=184275; -- Side Entrance Door
UPDATE `gameobject_template` SET `flags`=34 WHERE `entry`=184281; -- Servant's Access Door
UPDATE `gameobject_template` SET `flags`=34 WHERE `entry`=187764; -- Rohendor, The Second Gate
UPDATE `gameobject_template` SET `flags`=34 WHERE `entry`=187765; -- Archonisus, The Third Gate
UPDATE `gameobject_template` SET `flags`=34 WHERE `entry`=187766; -- Agamath, The First Gate
UPDATE `gameobject_template` SET `flags`=34 WHERE `entry`=195112; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=34 WHERE `entry`=201848; -- Halls of Reflection Portcullis
UPDATE `gameobject_template` SET `flags`=35 WHERE `entry`=195112; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=186432; -- Cove Cannon
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=187565; -- Elder Atkanok
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=187884; -- Evanor's Prison
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=188261; -- Battered Journal
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=188419; -- Elder Mana'loa
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=190222; -- Vrykul Hawk Roost
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=190522; -- Drakkari Pedestal
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=190535; -- Zim'Abwa
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=190555; -- Nerubian Crater
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=190602; -- Zim'Torga
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=190618; -- Blue Cauldron
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=190619; -- Purple Cauldron
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=190620; -- Red Cauldron
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=190630; -- Green Cauldron
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=190657; -- Zim'Rhuk
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=190917; -- Abandoned Mail
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=191609; -- Eye of Acherus Control Mechanism
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=191697; -- Warsong Granary
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=191698; -- Torp's Farm
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=191699; -- Warsong Slaughterhouse
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=191728; -- Wanted!
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=191766; -- Orders From Drakuru
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=192079; -- Hodir's Spear
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=192080; -- Hodir's Helm
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=192524; -- Arngrim the Insatiable
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=193003; -- Pile of Crusader Skulls
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=193768; -- Chulo the Mad's Totem
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=193769; -- Gawanil's Totem
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=193770; -- Kutube'sa's Totem
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=194145; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=194309; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=194310; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=194311; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=194613; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=195134; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=195438; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=195497; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=195517; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=195600; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=199333; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=201972; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=202108; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=202133; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=202613; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=202759; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=202766; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=202871; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=202887; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=202916; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=202975; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=203128; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=203186; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=203239; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=203289; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=203301; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=203305; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=203395; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=203446; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=204344; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=204837; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=204959; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=205146; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=205151; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=205152; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=205266; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=205350; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=205486; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=205540; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=206017; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=206018; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=206019; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=206312; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=206313; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=206314; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=206585; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=206944; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=207279; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=208381; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=209288; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=2702; -- Stone of Inner Binding
UPDATE `gameobject_template` SET `flags`=36 WHERE `entry`=3076; -- Dirt-stained Map
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=131474; -- The Discs of Norgannon
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=138492; -- Shards of Myzrael
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=142151; -- Sealed Barrel
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=142185; -- Flame of Byltan
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=142187; -- Flame of Imbel
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=142188; -- Flame of Samha
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=142343; -- Uldum Pedestal
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=142703; -- Venom Bottle
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=142704; -- Venom Bottle
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=142705; -- Venom Bottle
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=142706; -- Venom Bottle
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=142707; -- Venom Bottle
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=142712; -- Venom Bottle
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=142713; -- Venom Bottle
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=142714; -- Venom Bottle
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=144181; -- Sword of the Barbarian King
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=148504; -- A Conspicuous Gravestone
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=152097; -- Belnistrasz's Brazier
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=1561; -- Sealed Crate
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=156561; -- Wanted Poster
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=1586; -- Crate of Candles
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=164689; -- Monument of Franclorn Forgewright
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=164867; -- WANTED
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=164868; -- KILL ON SIGHT
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=17182; -- Buzzbox 827
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=17183; -- Buzzbox 411
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=1726; -- Missing: Corporal Keeshan
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=174728; -- Damaged Crate
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=175586; -- Jaron's Wagon
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=175607; -- Dark Iron Dwarf Corpse
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=175608; -- Dark Iron Dwarf Corpse
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=175609; -- Dark Iron Dwarf Corpse
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=176090; -- Human Remains
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=176091; -- Deadwood Cauldron
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=176248; -- Premium Siabi Tobacco
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=176327; -- Blacksmithing Plans
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=176392; -- Scourge Cauldron
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=176631; -- Menethil's Gift
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=1767; -- Helcular's Grave
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=178125; -- Lotharian Lotus
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=178553; -- Hive'Ashi Pod
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=179006; -- Vanndar's Documents
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=179007; -- Vanndar's Documents
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=179008; -- Vanndar's Documents
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=179437; -- Wanted: ORCS!
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=179438; -- Wanted: DWARVES!
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=179485; -- Broken Trap
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=179517; -- Treasure of the Shen'dralar
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=179880; -- Drakkisath's Brand
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=180025; -- Mysterious Eastvale Haystack
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=180448; -- Wanted Poster: Deathclasp
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=180503; -- Sandy Cookbook
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=180633; -- Crystalline Tear
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=180918; -- Wanted: Thaelis the Hungerer
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=181011; -- Magister Duskwither's Journal
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=181053; -- Basket of Bloodkelp
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=181095; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=181698; -- Voidstone
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=181748; -- Blood Crystal
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=182062; -- Insect Species of Outland
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=182065; -- A Field Guide to Seeds
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=182549; -- Fel Orc Plans
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=182934; -- Glyph Inscribed Obelisk
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=182941; -- Grishnath Orb
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=183266; -- Footlocker
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=183267; -- Dresser
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=183268; -- Bookshelf
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=183269; -- Weapon Rack
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=183340; -- Imarion's Shield
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=183341; -- Makha's Shield
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=183435; -- Marksman Regiment's Cooking Pot
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=184070; -- Nexus-Prince Haramad's Teleporter
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=184115; -- Arelion's Knapsack
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=184300; -- Necromantic Focus
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=184466; -- Metal Coffer
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=184477; -- Abandoned Wagon
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=184796; -- Rotten Arakkoa Egg
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=184825; -- Lashh'an Tome
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=184967; -- The Second Prophecy
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=184968; -- The Third Prophecy
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=184969; -- The Fourth Prophecy
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=185165; -- Legion Communicator
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=185166; -- Wanted Poster
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=185226; -- Cabal Chest
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=185549; -- Monstrous Kaliri Egg
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=185954; -- Hazzik's Package
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186266; -- Deserter Propaganda
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186301; -- Blackhoof Armaments
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186390; -- Plague Container
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186397; -- Steel Gate Artifact
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186403; -- Whisper Gulch Ore
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186427; -- Westguard Cannonball
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186565; -- Ceremonial Dragonflayer Harpoon
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186587; -- Wyrmskull Tablet
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186591; -- Spotted Hippogryph Down
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186595; -- Wyrmskull Tablet
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186607; -- Sacred Artifact
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186616; -- Sprung Trap
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186618; -- Dragonflayer Battle Plans
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186619; -- Sprung Trap
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186632; -- Dwarven Keg
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186656; -- Cauldron of Vrykul Blood
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186657; -- Harris's Plague Samples
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186659; -- Water Plant
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186660; -- Water Plant
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186661; -- Water Plant
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186662; -- Reagent Pouch
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186666; -- Frozen Waterfall
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186679; -- Apothecary's Package
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186684; -- Iron Rune Carving Tools
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186770; -- Sunken Boat
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186814; -- Talonshrike's Egg
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186828; -- Harpoon Operation Manual
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186830; -- Saga of the Val'kyr
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186832; -- Saga of the Winter Curse
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186864; -- Outhouse
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186885; -- Amani Vase
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186886; -- Eagle Figurine
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186912; -- Valgarde Supply Crate
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186935; -- Doodad_VR_WallMap_01
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186938; -- Loose Rock
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186944; -- Dirt Mound
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186949; -- School of Tasty Reef Fish
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186950; -- Building Tools
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186954; -- Large Barrel
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=186955; -- Industrial Strength Rope
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=187022; -- Mound of Debris
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=187023; -- Unlocked Chest
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=187026; -- Long Tail Feather
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=187027; -- Cannonball
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=187032; -- The Frozen Heart of Isuldof
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=187033; -- The Staff of Storm's Fury
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=187238; -- Sorlof's Booty
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=187381; -- The Ancient Armor of the Kvaldir
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=187577; -- Warsong Banner
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=187655; -- Nerub'ar Egg Sac
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=187851; -- Cultist Shrine
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=187885; -- Gurgleboggle's Bauble
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=187984; -- West Point Station Valve
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188015; -- Shipment of Animal Parts
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188016; -- Shipment of Animal Parts
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188017; -- Shipment of Animal Parts
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188085; -- Plagued Grain
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188101; -- Coldarra Geological Monitor
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188102; -- Coldarra Geological Monitor
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188103; -- Coldarra Geological Monitor
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188106; -- West Point Station Valve
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188120; -- Fields, Factories and Workshops
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188163; -- Bell Rope
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188260; -- Boulder
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188262; -- Missing Journal Page
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188263; -- Missing Journal Page
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188345; -- Shimmering Snowcaps
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188351; -- Waterweed
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188364; -- Wrecked Crab Trap
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188422; -- The Pearl of the Depths
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188423; -- Burning Brazier
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188461; -- Drakkari Tablets
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188463; -- Anub'ar Mechanism
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188489; -- Ruby Lilac
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188499; -- Drakkari Canopic Jar
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188501; -- War Golem Part
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188502; -- War Golem Part
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188503; -- War Golem Part
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188518; -- Gan'jo's Chest
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188525; -- Drakkari Spirit Particles
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188530; -- Sacred Drakkari Offering
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188600; -- Hazewood Bush
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188601; -- Sweetroot
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188646; -- Emerald Dragon Tear
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188650; -- Emerald Dragon Tear
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188658; -- Scarlet Onslaught Armor Stand
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188659; -- Scarlet Onslaught Weapon Rack
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188667; -- Amberseed
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188670; -- Blackroot
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188691; -- Vordrassil's Seed
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188695; -- Necromantic Rune
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188699; -- Strange Ore
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188702; -- Grooved Cog
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188703; -- Notched Sprocket
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188705; -- High Tension Spring
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=188713; -- Abbey Bell Rope
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=189288; -- Wintergarde Mine Bomb
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=189290; -- School of Northern Salmon
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=189293; -- The Diary of High General Abbendis
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=189295; -- Murkweed
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=189304; -- Forgotten Ruins
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=189306; -- Forgotten Treasure
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=189311; -- Flesh-bound Tome
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=189312; -- Scourge Communicator
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=189313; -- Wolfsbane Root
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=189972; -- Ruuna's Crystal Ball
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=189983; -- Wild Carrot
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190189; -- Onslaught Map
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190208; -- Dull Carving Knife
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190223; -- Scourged Troll Mummy
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190283; -- Talonshrike's Egg
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190354; -- Scythe of Antiok
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190399; -- Muddlecap Fungus
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190507; -- Offering Bowl
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190510; -- Captured Jormungar Spawn
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190534; -- Mature Water-Poppy
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190537; -- Crashed Plague Sprayer
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190540; -- Chunk of Saronite
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190541; -- Dead Thornwood
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190542; -- Dead Thornwood
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190543; -- Dead Thornwood
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190550; -- Ancient Dirt Mound
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190584; -- Battle-worn Sword
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190612; -- Treasure of Chulo the Mad
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190613; -- Treasure of Gawanil
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190614; -- Treasure of Kutube'sa
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190633; -- Har'koan Relic
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190635; -- Pressure Valve
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190691; -- Saronite Arrow
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190695; -- Heb'Jin's Drum
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190707; -- Soul Font
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190717; -- Underworld Power Fragment
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190718; -- Underworld Power Fragment
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190719; -- Underworld Power Fragment
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190720; -- Harvested Blight Crystal
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190767; -- Inconspicuous Mine Car
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190836; -- Zol'Maz Stronghold Cache
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=190948; -- Musty Coffin
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=191090; -- Elder Takret
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=191210; -- Zepik's Trap Stash
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=191458; -- Drakuru's Skull
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=191567; -- Mammoth Meat
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=191760; -- Inventor's Library Console
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=191761; -- Prototype Console
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=191814; -- Granite Boulder
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=191815; -- Granite Boulder
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=191842; -- Frostgut's Altar
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=191844; -- Enchanted Earth
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=191845; -- Enchanted Earth
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192058; -- Ore Cart
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192060; -- Fjorn's Anvil
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192072; -- Harpoon Crate
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192171; -- Colossus Attack Specs
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192172; -- Colossus Defense Specs
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192181; -- The Heart of the Storm
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192495; -- Third History Scroll
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192542; -- Taunka Artifact
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192543; -- Taunka Artifact
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192544; -- Taunka Artifact
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192545; -- Taunka Artifact
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192556; -- Cave Mushroom
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192693; -- Mammoth Carcass
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192826; -- Drakkari History Tablet
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192833; -- Bridenbrad's Possessions
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192932; -- Embalming Fluid
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192933; -- Blood Orb
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192941; -- Untarnished Silver Bar
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192942; -- Shiny Bauble
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192943; -- Shiny Bauble
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192944; -- Golden Goblet
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=192945; -- Jade Statue
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=193051; -- Nerubian Scourge Egg
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=193059; -- Vrykul Weapons
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=193060; -- Grasping Arm
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=193196; -- Fordragon's Shield
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=193197; -- Saurfang's Battle Armor
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=193404; -- Weeping Quarry Ledger
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=193560; -- Prospector Soren's Maps
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=193561; -- Prospector Khrona's Notes
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=193767; -- Shard of Horror
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=193792; -- Shard of Despair
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=193943; -- Alumeth's Skull
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=193945; -- Alumeth's Scepter
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=193946; -- Alumeth's Robes
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194088; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194089; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194090; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194100; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194107; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194123; -- Horn of Elemental Fury
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194126; -- Gundrak Raptor Egg
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194150; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194202; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194204; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194208; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194238; -- Blade of Drak'Mar
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194341; -- Dusty Journal
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194423; -- Stolen Tournament Invitation
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194424; -- Black Knight's Orders
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194464; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194537; -- Sir Wendell's Grave
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194538; -- Connall's Grave
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194539; -- Lorien's Grave
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194566; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194612; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194714; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=194997; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195002; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195012; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195022; -- Venomhide Egg
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195037; -- Silithid Egg
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195042; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195077; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195079; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195111; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195118; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195135; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195136; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195138; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195146; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195186; -- Black Knight's Grave
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195201; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195203; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195211; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195224; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195240; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195274; -- Stolen Tallstrider Leg
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195308; -- Mysterious Snow Mound
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195309; -- Mysterious Snow Mound
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195311; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195344; -- Discarded Soul Crystal
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195352; -- Bucket of Fresh Chum
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195353; -- Bucket of Fresh Chum
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195440; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195447; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195448; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195455; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195461; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195492; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195513; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195515; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195516; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195518; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195519; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195531; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195535; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195601; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195623; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195674; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195676; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195683; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=195692; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=196395; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=196486; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=197344; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=197345; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=197346; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201299; -- Unmentionables
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201300; -- Shirts
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201301; -- Pants
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201367; -- Heart of the Mists
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201603; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201701; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201733; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201734; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201735; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201737; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201738; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201742; -- Runeforge
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201855; -- Water Bucket
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201934; -- Pants
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201935; -- Shirts
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201936; -- Unmentionables
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201971; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201974; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201975; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=201977; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202112; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202135; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202136; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202159; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202160; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202198; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202264; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202320; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202321; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202322; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202323; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202324; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202325; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202335; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202351; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202405; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202420; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202422; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202467; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202477; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202478; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202533; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202542; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202552; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202553; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202554; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202560; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202574; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202606; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202607; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202608; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202697; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202701; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202702; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202703; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202705; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202706; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202711; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202712; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202714; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202731; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202745; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202754; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202775; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202793; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202846; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202859; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202875; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202876; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202896; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202956; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202957; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202959; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202960; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=202961; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203014; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203015; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203016; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203017; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203032; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203046; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203047; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203048; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203061; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203089; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203090; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203097; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203099; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203101; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203102; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203103; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203104; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203113; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203134; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203139; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203140; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203183; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203204; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203205; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203206; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203209; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203214; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203215; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203216; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203224; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203225; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203226; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203229; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203247; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203253; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203279; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203280; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203300; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203310; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203385; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203443; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203450; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203452; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=20359; -- Egg of Onyxia
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203734; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203751; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203762; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203801; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203964; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203965; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203966; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203967; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203968; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203969; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203972; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203982; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=203989; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204014; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204015; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204016; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204017; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204120; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204253; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204274; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204284; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204296; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204297; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204336; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204345; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204347; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204348; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204350; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204352; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204360; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204374; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204375; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204376; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204377; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204378; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204388; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204389; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204398; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204399; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204406; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204424; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204425; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204432; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204457; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204462; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204464; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204580; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204817; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204827; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=204880; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205092; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205097; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205099; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205137; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205144; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205147; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205153; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205154; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205195; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205207; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205208; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205246; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205250; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205251; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205332; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205422; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205423; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205476; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205477; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205479; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205534; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205545; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205559; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205560; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205823; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205824; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205874; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205878; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=205989; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206289; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206290; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206291; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206295; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206297; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206298; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206299; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206320; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206390; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206393; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206408; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206410; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206411; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206420; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206499; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206503; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206562; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206563; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206573; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206580; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206583; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206597; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206638; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206640; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206644; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206651; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206652; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206659; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206664; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206706; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206754; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206764; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206852; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206853; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206882; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206890; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206905; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206952; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=206996; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207089; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207090; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207104; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207105; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207125; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207126; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207145; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207158; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207162; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207259; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207281; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207301; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207359; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207406; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207407; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207408; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207409; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207410; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207411; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207412; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207415; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=207422; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208189; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208201; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208202; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208203; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=2083; -- Bloodsail Correspondence
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208420; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208423; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208431; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208442; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208474; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208537; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208540; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208541; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208544; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208551; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208576; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208587; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208588; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208589; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208592; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208593; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208672; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208814; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208816; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208818; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208819; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208825; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208829; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208831; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208839; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208860; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208864; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208867; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208870; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208872; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208875; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208878; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=208880; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=209001; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=209242; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=209273; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=209274; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=209275; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=209283; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=209284; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=209287; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=209347; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=209348; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=20985; -- Loose Dirt
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=24798; -- Sundried Driftwood
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=2553; -- A Soggy Scroll
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=259; -- Half-buried Barrel
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=261; -- Damaged Crate
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=2657; -- Legends of the Earth
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=2688; -- Keystone
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=2691; -- Stone of East Binding
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=2713; -- Wanted Board
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=2734; -- Waterlogged Chest
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=2868; -- Crumpled Map
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=2875; -- Battered Dwarven Skeleton
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=290; -- Furlbrow's Wardrobe
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=30854; -- Atal'ai Artifact
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=30855; -- Atal'ai Artifact
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=30856; -- Atal'ai Artifact
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=31; -- Old Lion Statue
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=32569; -- Galen's Strongbox
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=3643; -- Old Footlocker
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=37099; -- Atal'ai Tablet
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=3740; -- Bubbling Fissure
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=3972; -- WANTED
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=4141; -- Control Console
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=47; -- Wanted: Lieutenant Fangore
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=55; -- A half-eaten body
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=5619; -- Flawed Power Stone
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=5620; -- Flawed Power Stones
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=5621; -- Flawed Power Stones
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=56; -- Rolf's corpse
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=60; -- Wanted: Gath'Ilzogg
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=61934; -- Brazier of the Dormant Flame
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=61; -- A Weathered Grave
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=65407; -- Graznab's Machine
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=68; -- Wanted Poster
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=7510; -- Sprouted Frond
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=7923; -- Denalan's Planter
UPDATE `gameobject_template` SET `flags`=4 WHERE `entry`=92420; -- Bailor's Ore
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=175611; -- Iron Gate
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=175612; -- Iron Gate
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=175613; -- Iron Gate
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=175614; -- Iron Gate
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=175615; -- Iron Gate
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=180100; -- Alliance Banner Aura
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=180101; -- Horde Banner Aura
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=183104; -- Terokkar Banner
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=185051; -- Shield Generator
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=185052; -- Shield Generator
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=185053; -- Shield Generator
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=185054; -- Shield Generator
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=187869; -- Orb of the Blue Flight
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=188114; -- Orb of the Blue Flight
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=188115; -- Orb of the Blue Flight
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=188116; -- Orb of the Blue Flight
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=189299; -- Ritual Crystal
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=189300; -- Ritual Crystal
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=189301; -- Ritual Crystal
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=189302; -- Ritual Crystal
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=193611; -- Activation Crystal
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=193615; -- Intro Activation Crystal
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=194557; -- Runed Stone Door
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=194558; -- Runed Stone Door
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=194569; -- Ulduar Teleporter
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=202242; -- Scourge Transporter
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=202243; -- Scourge Transporter
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=202244; -- Scourge Transporter
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=202245; -- Scourge Transporter
UPDATE `gameobject_template` SET `flags`=48 WHERE `entry`=209937; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=49 WHERE `entry`=201759; -- The Forge of Souls Portcullis
UPDATE `gameobject_template` SET `flags`=49 WHERE `entry`=201760; -- The Halls of Reflection Gate
UPDATE `gameobject_template` SET `flags`=49 WHERE `entry`=201761; -- The Pit of Saron Portcullis
UPDATE `gameobject_template` SET `flags`=50 WHERE `entry`=209937; -- -Unknown-
UPDATE `gameobject_template` SET `flags`=6 WHERE `entry`=205098; -- -Unknown-
