DELETE FROM `spell_script_names` WHERE `scriptname`='spell_sha_astral_shift';
