UPDATE `spell_script_names` SET `spell_id`=27285 WHERE `spell_id`=-27285;
UPDATE `spell_script_names` SET `spell_id`=1454 WHERE `spell_id`=-1454;
UPDATE `spell_script_names` SET `spell_id`=48181 WHERE `spell_id`=-48181;
UPDATE `spell_script_names` SET `spell_id`=30108 WHERE `spell_id`=-30108;
UPDATE `spell_script_names` SET `spell_id`=603, `ScriptName`='spell_warl_bane_of_doom' WHERE `spell_id`=-603;
