UPDATE `areatrigger_teleport` SET `target_position_x`=-329.484, `target_position_y`=-3.22991, `target_position_z`=-152.846, `target_orientation`=2.96706 WHERE `id`=324; -- Gnomeregan Entrance
UPDATE `areatrigger_teleport` SET `target_position_x`=-14.5732, `target_position_y`=-385.475, `target_position_z`=62.4561, `target_orientation`=1.570796 WHERE `id`=78; -- DeadMines Entrance
UPDATE `areatrigger_teleport` SET `target_position_x`=-158.441, `target_position_y`=131.601, `target_position_z`=-74.2552, `target_orientation`=5.846854 WHERE `id`=228; -- The Barrens - Wailing Caverns
UPDATE `areatrigger_teleport` SET `target_position_x`=-228.191, `target_position_y`=2111.41, `target_position_z`=76.8904, `target_orientation`=1.221731 WHERE `id`=145; -- Shadowfang Keep Entrance
UPDATE `areatrigger_teleport` SET `target_position_x`=-150.234, `target_position_y`=106.594, `target_position_z`=-39.779, `target_orientation`=4.45059 WHERE `id`=257; -- Blackphantom Deeps Entrance
UPDATE `areatrigger_teleport` SET `target_position_x`=-601.151, `target_position_y`=809.526, `target_position_z`=244.809, `target_orientation`=0 WHERE `id`=6201; -- Throne of the Tides (Enterance)
UPDATE `areatrigger_teleport` SET `target_position_x`=209.903, `target_position_y`=1133.02, `target_position_z`=205.569, `target_orientation`=4.677483 WHERE `id`=6108; -- Blackrock Caverns (Enterance)
UPDATE `areatrigger_teleport` SET `target_position_x`=-337.627, `target_position_y`=15.3073, `target_position_z`=626.979, `target_orientation`=3.892085 WHERE `id`=6612; -- The Vortex Pinnacle (Enterance)
UPDATE `areatrigger_teleport` SET `target_position_x`=851.052, `target_position_y`=986.474, `target_position_z`=317.266, `target_orientation`=0 WHERE `id`=6196; -- The Stonecore (Enterance)
UPDATE `areatrigger_teleport` SET `target_position_x`=97.7989, `target_position_y`=1001.99, `target_position_z`=-86.7756, `target_orientation`=0 WHERE `id`=4598; -- Black Temple (Entrance)
UPDATE `areatrigger_teleport` SET `target_position_x`=2593.68, `target_position_y`=1111.23, `target_position_z`=50.9518, `target_orientation`=4.712389 WHERE `id`=442; -- Razorfen Downs Entrance
