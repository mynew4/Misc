-- Remove all bgs from e1bee86ee6f5c3ab7b1da6d1b54c98c2851f11ec
DELETE FROM `battleground_template` WHERE `id` = 6; -- all Bgs
