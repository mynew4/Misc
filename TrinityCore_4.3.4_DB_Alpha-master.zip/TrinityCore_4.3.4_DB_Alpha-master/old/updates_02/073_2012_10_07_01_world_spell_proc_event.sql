UPDATE `spell_proc_event` SET `procflags`=0x15510 WHERE `entry`=53386;
