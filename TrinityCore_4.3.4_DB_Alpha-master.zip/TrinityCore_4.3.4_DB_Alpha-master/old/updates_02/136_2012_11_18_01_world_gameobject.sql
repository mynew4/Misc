-- Ossirian Crystal
UPDATE `gameobject_template` SET `ScriptName`='go_ossirian_crystal' WHERE `entry`=180619;

