-- Imposing Confrontation (26315) Questfix
-- by Naios for Arkania

UPDATE `creature_template` SET `ScriptName`='npc_boden_the_imposing' WHERE `entry`=42471 LIMIT 1;