-- Conclave of Wind Updates
-- by Naios

UPDATE `creature_template` SET `ScriptName`='boss_anshal' WHERE `entry`=45870 LIMIT 1;
UPDATE `creature_template` SET `ScriptName`='boss_nezir' WHERE `entry`=45871 LIMIT 1;
UPDATE `creature_template` SET `ScriptName`='boss_rohash' WHERE `entry`=45872 LIMIT 1;

-- Anshal
-- 45813
