-- Al'Akir Updates
-- by Naios

REPLACE INTO `creature_model_info` (`modelid`, `bounding_radius`, `combat_reach`, `gender`, `modelid_other_gender`)
VALUES (46753, 5, 0, 2, 0);
