-- Halfus Whyrmbreaker Updated
-- by Naios

-- Assign Scriptname to his helper Dragons
UPDATE `creature_template` SET `ScriptName`='npc_halfus_dragon' WHERE `entry` IN (44652, 44645, 44650, 44797, 48436);