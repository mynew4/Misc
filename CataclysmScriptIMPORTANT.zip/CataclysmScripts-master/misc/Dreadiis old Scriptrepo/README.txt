---------== Cata Scripts 2011/2012 ==----------

a scripting repo for World of Warcraft Cataclysm 4.3.0a /4.3.x bosses and instances
this repo is 100% public for every dev. if you want to work here too contact me (Dreadii) on github.
With this scripting project I try to work like a kind of scriptdev2. so a external script repo for public usage
